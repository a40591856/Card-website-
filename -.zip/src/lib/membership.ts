/* ─────────────────────────────────────────────────────────────
   BLACK MART · نظام العضوية (Swiss-Vault Identity)
   تخزين محلي (LocalStorage) + مزامنة اختيارية مع قاعدة البيانات
   للدخول من جهاز آخر بنفس البريد وكلمة المرور.
   كل النصوص والمراحل تُعدَّل من هذا الملف (100% قابل للتوسعة).
   ───────────────────────────────────────────────────────────── */
import type { L } from "./site";

const A = (ar: string, en = ar): L => ({ ar, en });

export const MEMBER_KEYS = {
  accounts: "bm_member_accounts",   // السجل المحلي: بريد → هاش الباسورد + المعرّف
  session: "bm_member_session",     // الجلسة الحالية
  orders: "bm_member_orders",       // صندوق الطلبات المحلي
  points: "bm_member_points",       // محفظة النقاط
  ref: "bm_pending_ref",            // إحالة قادمة من رابط ?ref=
};

export interface MemberAccount {
  id: string;          // 8 أرقام
  name: string;
  email: string;
  passHash: string;    // هاش محلي (لا تُحفظ كلمة المرور نصاً)
  refCode: string;
  avatar?: string;
  createdAt: string;
}

export interface MemberSession {
  id: string;
  name: string;
  email: string;
  refCode: string;
  avatar?: string;
  points: number;
}

export interface MemberOrder {
  id: string;
  owner: string;
  name: string;
  priceUsd: number;
  qty: number;
  at: string;
}

/** هاش محلي بسيط وسريع (العزل الحقيقي يتم على الخادم عبر SHA-256) */
export const localHash = (s: string) => {
  let h1 = 0x811c9dc5;
  let h2 = 0x01000193;
  for (let i = 0; i < s.length; i++) {
    h1 = Math.imul(h1 ^ s.charCodeAt(i), 16777619) >>> 0;
    h2 = Math.imul(h2 + s.charCodeAt(i), 2246822519) >>> 0;
  }
  return `${h1.toString(16)}${h2.toString(16)}`;
};

/** معرّف عضوي عشوائي من 8 أرقام */
export const make8 = () => String(Math.floor(10000000 + Math.random() * 90000000));
export const nowStamp = () => {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
};

/* ── سجل الحسابات المحلي ── */
export const loadAccounts = (): MemberAccount[] => {
  try { return JSON.parse(localStorage.getItem(MEMBER_KEYS.accounts) || "[]"); }
  catch { return []; }
};
export const saveAccount = (a: MemberAccount) => {
  const all = loadAccounts();
  const idx = all.findIndex((x) => x.email === a.email);
  if (idx >= 0) all[idx] = a; else all.push(a);
  localStorage.setItem(MEMBER_KEYS.accounts, JSON.stringify(all));
};
export const findAccount = (email: string) =>
  loadAccounts().find((x) => x.email.toLowerCase() === email.trim().toLowerCase());

/* ── الجلسة ── */
export const loadSession = (): MemberSession | null => {
  try { return JSON.parse(localStorage.getItem(MEMBER_KEYS.session) || "null"); }
  catch { return null; }
};
export const saveSession = (s: MemberSession) =>
  localStorage.setItem(MEMBER_KEYS.session, JSON.stringify(s));
export const clearSession = () => localStorage.removeItem(MEMBER_KEYS.session);

/* ── محفظة النقاط ── */
export const getPoints = (id: string) => {
  const all = JSON.parse(localStorage.getItem(MEMBER_KEYS.points) || "{}") as Record<string, number>;
  return all[id] ?? 0;
};
export const addPoint = (id: string) => {
  const all = JSON.parse(localStorage.getItem(MEMBER_KEYS.points) || "{}") as Record<string, number>;
  all[id] = (all[id] ?? 0) + 1;
  localStorage.setItem(MEMBER_KEYS.points, JSON.stringify(all));
  return all[id];
};
export const setPoints = (id: string, n: number) => {
  const all = JSON.parse(localStorage.getItem(MEMBER_KEYS.points) || "{}") as Record<string, number>;
  all[id] = n;
  localStorage.setItem(MEMBER_KEYS.points, JSON.stringify(all));
};
export const referralLink = (ref: string) => {
  const origin = typeof window !== "undefined" ? window.location.origin : "https://blackmart.zone";
  return `${origin}/?ref=${ref}`;
};

/* ── صندوق الطلبات ── */
export const getOrders = (owner: string): MemberOrder[] => {
  try {
    return (JSON.parse(localStorage.getItem(MEMBER_KEYS.orders) || "[]") as MemberOrder[])
      .filter((o) => o.owner === owner);
  } catch { return []; }
};
export const addOrder = (o: MemberOrder) => {
  const all = (() => { try { return JSON.parse(localStorage.getItem(MEMBER_KEYS.orders) || "[]") as MemberOrder[]; } catch { return []; } })();
  localStorage.setItem(MEMBER_KEYS.orders, JSON.stringify([o, ...all].slice(0, 100)));
};

/** التقاط رابط الإحالة ?ref= عند فتح الموقع */
export const captureRef = () => {
  if (typeof window === "undefined") return;
  const ref = new URLSearchParams(window.location.search).get("ref");
  if (ref) localStorage.setItem(MEMBER_KEYS.ref, ref);
};
export const pendingRef = () => localStorage.getItem(MEMBER_KEYS.ref);
export const clearPendingRef = () => localStorage.removeItem(MEMBER_KEYS.ref);

/* ═══════════ النصوص الرسمية ═══════════ */
export const PRIVACY_NOTE: L = A(
  "🔒 معلوماتك في أمان تام، وهويتك الرقمية مشفرة بالكامل، وحتى إدارة الموقع ليس لها الحق أو الصلاحية في كشف بياناتك أو الاطلاع عليها.",
  "🔒 Your information is fully secure and your digital identity is completely encrypted — even site administration has no right or permission to view it.",
);
export const ENCRYPT_STEPS: L[] = [
  A("[جاري توليد مفاتيح التشفير الرقمية...]"),
  A("[جاري تشفير الجلسة بالكامل 256-bit...]"),
  A("[تأمين الهوية وحماية الخصوصية...]"),
  A("[تم إنشاء الحساب المشفر بنجاح ✔️]"),
];
export const CERT_TITLE: L = A("شهادة التشفير الرقمية", "Digital Encryption Certificate");
export const NO_ACCOUNT: L = A("الحساب غير موجود، يرجى إنشاء حساب جديد", "Account not found — please create a new account");
export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/* ═══════════ مزامنة الخادم (للدخول من جهاز آخر) ═══════════ */
export interface ServerProfile {
  id: string; name: string; email: string; points: number;
  refCode: string; avatar?: string | null; createdAt?: string;
}
export async function serverRegister(p: {
  name: string; email: string; pass: string; refCode?: string; id: string;
}): Promise<ServerProfile | null> {
  try {
    const r = await fetch("/api/member", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "register", ...p }),
    });
    const d = await r.json();
    return d.ok ? (d.profile as ServerProfile) : null;
  } catch { return null; }
}
export async function serverLogin(email: string, pass: string): Promise<ServerProfile | null> {
  try {
    const r = await fetch("/api/member", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "login", email, pass }),
    });
    const d = await r.json();
    return d.ok ? (d.profile as ServerProfile) : null;
  } catch { return null; }
}
export async function serverSync(p: {
  id: string; name?: string; pass?: string; newPass?: string; avatar?: string; points?: number;
}) {
  try {
    await fetch("/api/member", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "sync", ...p }),
    });
  } catch { /* العمل المحلي يبقى سليماً */ }
}
export async function serverRefer(refCode: string) {
  try {
    await fetch("/api/member", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "refer", refCode }),
    });
  } catch { /* noop */ }
}
