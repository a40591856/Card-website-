/* ─────────────────────────────────────────────────────────────
   BLACK MART · طبقة الحالة على العميل
   لغة · مصادقة · سلة · مفضلة · إشعارات · تخفّي · تنبيهات
   ───────────────────────────────────────────────────────────── */
"use client";

import {
  createContext,
  useCallback,
  useContext,
  useSyncExternalStore,
} from "react";
import { dictionaries, LANGS, type Lang, type LangDef } from "./i18n";

/* ── أدوات عامة ── */
export const prefersReducedMotion = () =>
  typeof window !== "undefined" &&
  window.matchMedia("(prefers-reduced-motion: reduce)").matches;

export const hex = (len: number) =>
  Array.from({ length: len }, () =>
    "0123456789ABCDEF".charAt(Math.floor(Math.random() * 16)),
  ).join("");

export const fmtMoney = (n: number) => (n === 0 ? "FREE" : `$${n}`);

export async function api<T = unknown>(path: string, init?: RequestInit): Promise<T> {
  const r = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...init,
  });
  return (await r.json()) as T;
}

/* ── اللغة ── */
const LS = {
  lang: "bm_lang",
  last: "bm_last",
  cart: "bm_cart",
  wl: "bm_wl",
  auth: "bm_auth",
  client: "bm_client",
  read: "bm_read",
};

function readLS<T>(k: string, fallback: T): T {
  try {
    const v = localStorage.getItem(k);
    return v ? (JSON.parse(v) as T) : fallback;
  } catch {
    return fallback;
  }
}

export const langDef = (code: Lang): LangDef =>
  LANGS.find((l) => l.code === code) ?? LANGS[0];

let _lang: Lang =
  typeof window !== "undefined"
    ? ((localStorage.getItem(LS.lang) as Lang) || "ar")
    : "ar";
const langSubs = new Set<() => void>();

export function changeLang(l: Lang) {
  _lang = l;
  localStorage.setItem(LS.lang, l);
  if (typeof document !== "undefined") {
    const d = langDef(l);
    document.documentElement.dir = d.dir;
    document.documentElement.lang = l;
  }
  langSubs.forEach((f) => f());
}

const EMPTY_CART: Cart = {};
const EMPTY_IDS: number[] = [];

export function useLang(): Lang {
  return useSyncExternalStore(
    (cb) => {
      langSubs.add(cb);
      return () => langSubs.delete(cb);
    },
    () => _lang,
    () => "ar",
  );
}

export function useT() {
  const lang = useLang();
  return useCallback((k: string) => {
    const v = dictRaw(lang, k);
    return typeof v === "string" ? v : k;
  }, [lang]);
}

function dictRaw(lang: Lang, key: string): unknown {
  const all = dictionaries as Record<string, Record<string, unknown>>;
  return all[lang]?.[key] ?? all.en?.[key] ?? key;
}

export const tArr = (lang: Lang, key: string): string[] => {
  const v = dictRaw(lang, key);
  return Array.isArray(v) ? (v as string[]) : [];
};

/* ── حفظ آخر صفحة ── */
export function saveLast(p: string) {
  if (p && p !== "/") {
    try {
      localStorage.setItem(LS.last, p);
    } catch {
      /* noop */
    }
  }
}
export function getLast() {
  return typeof window !== "undefined" ? localStorage.getItem(LS.last) : null;
}

/* ── معرف الزائر ── */
export function clientId() {
  let c = localStorage.getItem(LS.client);
  if (!c) {
    c = "C-" + Math.random().toString(36).slice(2, 10);
    localStorage.setItem(LS.client, c);
  }
  return c;
}

/* ── المصادقة ── */
let _auth: string | null =
  typeof window !== "undefined" ? localStorage.getItem(LS.auth) : null;
const authSubs = new Set<() => void>();

export function setAuth(t: string | null) {
  _auth = t;
  if (t) localStorage.setItem(LS.auth, t);
  else localStorage.removeItem(LS.auth);
  authSubs.forEach((f) => f());
}
export function useAuth(): string | null {
  return useSyncExternalStore(
    (cb) => {
      authSubs.add(cb);
      return () => authSubs.delete(cb);
    },
    () => _auth,
    () => null,
  );
}

/* ── السلة ── */
type Cart = Record<number, number>;
let _cart: Cart =
  typeof window !== "undefined" ? readLS<Cart>(LS.cart, {}) : {};
const cartSubs = new Set<() => void>();
function saveCart() {
  try {
    localStorage.setItem(LS.cart, JSON.stringify(_cart));
  } catch {
    /* noop */
  }
  cartSubs.forEach((f) => f());
}
export function useCart(): Cart {
  return useSyncExternalStore(
    (cb) => {
      cartSubs.add(cb);
      return () => cartSubs.delete(cb);
    },
    () => _cart,
    () => EMPTY_CART,
  );
}
export function addToCart(id: number, qty = 1) {
  _cart = { ..._cart, [id]: (_cart[id] || 0) + qty };
  saveCart();
}
export function bumpCart(id: number, delta: number) {
  const next = { ..._cart };
  const q = (next[id] || 0) + delta;
  if (q <= 0) delete next[id];
  else next[id] = q;
  _cart = next;
  saveCart();
}
export function clearCart() {
  _cart = {};
  saveCart();
}
export const cartCount = (c: Cart) =>
  Object.values(c).reduce((a, b) => a + b, 0);

/* ── المفضلة ── */
let _wl: number[] =
  typeof window !== "undefined" ? readLS<number[]>(LS.wl, []) : [];
const wlSubs = new Set<() => void>();
function saveWl() {
  try {
    localStorage.setItem(LS.wl, JSON.stringify(_wl));
  } catch {
    /* noop */
  }
  wlSubs.forEach((f) => f());
}
export function useWishlist(): number[] {
  return useSyncExternalStore(
    (cb) => {
      wlSubs.add(cb);
      return () => wlSubs.delete(cb);
    },
    () => _wl,
    () => EMPTY_IDS,
  );
}
export function toggleWishlist(id: number) {
  _wl = _wl.includes(id) ? _wl.filter((x) => x !== id) : [..._wl, id];
  saveWl();
}

/* ── التنبيهات المنبثقة ── */
export interface ToastMsg {
  id: number;
  msg: string;
  kind: "ok" | "warn";
}
let _toasts: ToastMsg[] = [];
let toastSeq = 0;
const toastSubs = new Set<(t: ToastMsg[]) => void>();
function pushToasts() {
  toastSubs.forEach((f) => f(_toasts));
}
export function toast(msg: string, kind: "ok" | "warn" = "ok") {
  const t = { id: ++toastSeq, msg, kind };
  _toasts = [..._toasts, t];
  pushToasts();
  setTimeout(() => {
    _toasts = _toasts.filter((x) => x.id !== t.id);
    pushToasts();
  }, 3600);
}
export function useToasts(): ToastMsg[] {
  return useSyncExternalStore(
    (cb) => {
      toastSubs.add(cb);
      return () => toastSubs.delete(cb);
    },
    () => _toasts,
    () => EMPTY_IDS as unknown as ToastMsg[],
  );
}

/* ── وضع التخفّي ── */
let _stealth = false;
const stealthSubs = new Set<() => void>();
export function setStealth(v: boolean) {
  _stealth = v;
  stealthSubs.forEach((f) => f());
}
export function useStealth(): boolean {
  return useSyncExternalStore(
    (cb) => {
      stealthSubs.add(cb);
      return () => stealthSubs.delete(cb);
    },
    () => _stealth,
    () => false,
  );
}

/* ── سياق الغلاف (شريط علوي/قائمة…) ── */
export interface ShellApi {
  openMenu: () => void;
  openCart: () => void;
  openLang: () => void;
  openLogin: () => void;
  gotoEntry: () => void;
}
export const ShellCtx = createContext<ShellApi | null>(null);
export const useShell = () => useContext(ShellCtx);

/** فتح رابط خارجي لحظة الضغط — لا يظهر كـ href في الواجهة */
export function openExternal(url: string) {
  try {
    window.open(url, "_blank", "noreferrer");
  } catch {
    window.location.href = url;
  }
}

/* ── مشاركة الموقع ── */
export async function shareSite(t: (k: string) => string) {
  const url = window.location.href;
  try {
    if (navigator.share) {
      await navigator.share({ title: "BLACK MART", url });
    } else {
      await navigator.clipboard.writeText(url);
      toast(t("c.copied"));
    }
  } catch {
    /* user cancelled */
  }
}
