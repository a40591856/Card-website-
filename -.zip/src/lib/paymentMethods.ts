/* ─────────────────────────────────────────────────────────────
   BLACK MART · صفحة طرق الدفع الرسمية (إعدادات مركزية)
   العناوين والشبكات والنصوص والرسائل تُعدَّل من هنا فقط.
   ───────────────────────────────────────────────────────────── */
import type { L } from "./site";

const A = (ar: string, en = ar): L => ({ ar, en });

export interface PaymentCoin {
  id: "usdt" | "btc" | "eth";
  symbol: string;
  badge: string;
  name: L;
  network: L;
  networkTag: L;
  address: string;
  note?: L;
  color: string;   // لون الملصق
  mono: string;
}

/** العناوين الرسمية الثابتة — لا تُغيَّر إلا من هذا الملف */
export const PAYMENT_COINS: PaymentCoin[] = [
  {
    id: "usdt", symbol: "🟢", badge: "₮", name: A("USDT"), network: A("Tron — TRC20"),
    networkTag: A("شبكة TRC20 مع ملصق ترون"), address: "TK92Er5nLg6DkEfcgqebD8HW3cfgTsetjn",
    color: "#26A17B", mono: "USDT",
  },
  {
    id: "btc", symbol: "🟠", badge: "₿", name: A("Bitcoin"), network: A("Bitcoin — Mainnet"),
    networkTag: A("شبكة البيتكوين الرئيسية"), address: "bc1qqz3kgyaqur7vh9mr8xl2ppd9akz5u938j6qcsd",
    note: A("يُقبل الإيداع من عناوين 1, 3, bc1p, bc1q"),
    color: "#F7931A", mono: "BTC",
  },
  {
    id: "eth", symbol: "🔵", badge: "Ξ", name: A("Ethereum"), network: A("Ethereum — ERC20"),
    networkTag: A("شبكة الإيثيريوم ERC20"), address: "0xDAeA4661926Cc59B9d0AaA35109F7860D789f000",
    color: "#627EEA", mono: "ETH",
  },
];

/** روابط التواصل الرسمية لهذه الصفحة */
export const PAY_LINKS = {
  support: "http://t.me/custour?direct",
  manager: "https://t.me/k22zzo",
  channel: "https://t.me/+3ji36yCsWRc2NTJk",
  managerUser: "k22zzo",
};

/* ═══════════ نصوص الصفحة ═══════════ */
export const PAY_TITLE: L = A("صفحة طرق الدفع الرسمية 🔒", "Official Payment Methods 🔒");
export const PAY_INTRO: L = A(
  "لشراء الخدمات واختيار محفظة الدفع... الدفع آمن ومشفر 100% لضمان حمايتك وراحتك. للاستفسار أو طلب الدعم، فريقنا معك خطوة بخطوة عبر خدمة العملاء أو القناة.",
  "To purchase services and choose a payment wallet... Payment is 100% secure and encrypted for your protection and comfort. For inquiries or support, our team is with you step by step via customer service or the channel.",
);
export const NETWORK_WARNING: L = A(
  "⚠️ تأكد من اختيار الشبكة الصحيحة لتفادي فقدان الأموال",
  "⚠️ Make sure you select the correct network to avoid losing funds",
);
export const ORDER_DETAILS: L = A(
  "بعد إكمال الدفع توجه لأحد مسؤولي الموقع، أرسل إيصال الدفع وسيتم إرسال الخدمة إليك مباشرة مع شرح تفصيلي لطريقة الربط والتفريغ عبر مسؤول تيليجرام.",
  "After completing payment, contact one of the site managers, send the payment receipt, and the service will be delivered directly with a detailed guide on linking and draining via the Telegram manager.",
);
export const PAY_FEATURES: L[] = [
  A("🎓 كورس شامل لطريقة الربط والاستخدام والتشفير."),
  A("🛡️ الحماية والتشفير: تأمين العمليات بأحدث أساليب التشفير."),
  A("🔗 الربط والحقن: شرح آليات الربط عبر بوابات الدفع العالمية."),
  A("💳 بوابات الدفع الذكية: شروحات احترافية (Apple Pay & Google Play)."),
  A("⚡ تجاوز الأنظمة: طرق تخطي الحماية لضمان نجاح العملية."),
];
export const ALT_NOTE: L = A(
  "إذا لم تكن طرق الدفع بالعملات الرقمية متاحة لديك، توجه للمسؤول للاستفسار عن طرق دفع بديله.",
  "If crypto payment methods are not available to you, contact the manager to ask about alternative payment methods.",
);

/* ═══════════ الرسائل الجاهزة ═══════════ */
export const MSG_SUPPORT = "مرحباً Black Mart، قمت بزيارة موقعكم واريد الاستفسار عن الخدمات";
export const MSG_ALT = "مرحباً، هل يتوفر لديكم طرق دفع بديله؟";
export const continueMessage = (coin: PaymentCoin) =>
  `مرحباً، لقد اخترت طريقة الدفع ${coin.mono} (${coin.network.ar})، متى يمكنني استلام الخدمة؟`;
