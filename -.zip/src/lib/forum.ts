/* ─────────────────────────────────────────────────────────────
   BLACK MART · FORUM HUB (Zero-Footprint)
   كل الأقسام / الخدمات / الحقول / الشروحات هنا فقط.
   أضف خدمة أو تخصصاً من هذا الملف دون لمس أي كود واجهة.
   ───────────────────────────────────────────────────────────── */
import type { L } from "./site";
import { FORUM_GUIDES } from "./forumGuides";

export interface FieldDef {
  id: string;
  label: L;
  type: "text" | "number" | "textarea" | "file";
  ph?: L;
  required?: boolean;
}

export interface ServiceDef {
  id: string;
  icon: string;
  name: L;
  guide: L;
  fields: FieldDef[];
  group?: "inbound" | "outbound";
  /** تصنيف الخدمة لتيوبات لوحة الطلبات: منفذ / مستقبل / كلاهما */
  offer?: "operator" | "receiver" | "both";
  /** الشرح الإضافي الطويل — يظهر خلف زر منسدل تحت الحقول */
  extra?: L;
}

export interface SpecialtyDef {
  id: string;
  icon: string;
  name: L;
  desc: L;
  services: ServiceDef[];
}

export interface RoleDef {
  a: L; // صاحب الخدمة / مطلوب منفذ
  b: L; // المنفذ / متاح للعمل
}

export type ForumMode = "services" | "affiliate" | "meetings" | "specialty";

export interface ForumSectionDef {
  id: string;
  short: L;
  icon: string;
  name: L;
  desc: L;
  mode: ForumMode;
  roles?: RoleDef;
  /** قسم يعرض تيوبات [الكل | متاح كمنفذ | متاح كمستقبل] بدل اختيار الصفة */
  offerTabs?: boolean;
  groupLabels?: { inbound: L; outbound: L };
  groupDetails?: { inbound: L; outbound: L };
  groupCards?: { id: "inbound" | "outbound"; icon: string; name: L; desc: L }[];
  services?: ServiceDef[];
  specialties?: SpecialtyDef[];
}

/* ── حقول قياسية ── */
const fShort: FieldDef = {
  id: "subject",
  label: { ar: "عنوان الطلب", en: "Request subject", ru: "Тема запроса" },
  type: "text",
  ph: { ar: "اكتب المطلوب باختصار…", en: "Briefly state the need…", ru: "Кратко опишите…" },
  required: true,
};
const fLong: FieldDef = {
  id: "details",
  label: { ar: "تفاصيل الطلب", en: "Request details", ru: "Детали запроса" },
  type: "textarea",
  ph: { ar: "اشرح المطلوب بدقة دون روابط خارجية مكشوفة…", en: "Describe precisely, no exposed external links…", ru: "Опишите точно, без внешних ссылок…" },
  required: true,
};
const fFile: FieldDef = {
  id: "attachment",
  label: { ar: "مرفقات (يُمسح EXIF تلقائياً)", en: "Attachment (EXIF auto-stripped)", ru: "Вложение (EXIF удаляется)" },
  type: "file",
};
const baseFields = (): FieldDef[] => [fShort, fLong, fFile];

const guide = (ar: string, en: string, ru?: string): L => (ru ? { ar, en, ru } : { ar, en });
const l = (ar: string, en: string, ru?: string): L => (ru ? { ar, en, ru } : { ar, en });

const svc = (
  id: string,
  icon: string,
  ar: string,
  en: string,
  g: L,
  group?: "inbound" | "outbound",
  fields?: FieldDef[],
): ServiceDef => ({
  id,
  icon,
  name: l(ar, en),
  guide: g,
  fields: fields ?? baseFields(),
  group,
});

const G_REQUEST = guide(
  "اكتب متطلباتك بدقة، وحدد الكمية والوقت المتوقع. لا تُدرج أي يوزر أو رابط خارجي مكشوف — التوجيه يتم عبر القناة المشفرة فقط.",
  "State your requirements precisely, with quantity and expected timing. Never include an exposed handle or external link — routing happens through the encrypted relay only.",
);
const G_TECH = guide(
  "يرجى كتابة المتطلبات التقنية بدقة وعدم إدراج أي روابط خارجية مكشوفة لضمان سرية الجلسة. أي مرفق يُمسح من بيانات الموقع والجهاز والتاريخ تلقائياً قبل الحفظ.",
  "Write the technical requirements precisely and never include exposed external links to keep the session private. Any attachment is stripped of GPS, device, and timestamp metadata before saving.",
);
const G_MEET = guide(
  "اختر المدينة المعتمدة وحدّد الوقت بـ48 ساعة على الأقل. تُنسَّق المقابلة عبر الوسيط فقط، ويُشترط وصول الطرفين قبل الموعد بـ10 دقائق.",
  "Pick an approved city and schedule at least 48h ahead. Meetings are coordinated via the relay only; both parties arrive 10 minutes early.",
);
const G_AFF = guide(
  "يُولَّد معرف الإحالة المشفر محلياً على جهازك فقط، ولا يُرسل أي بيانات للخادم. انسخه واستخدمه في حملتك؛ تُحسب النسب أسبوعياً.",
  "The encrypted affiliate hash is generated locally on your device only — no data is sent to any server. Copy it and use it in your campaign.",
);

/* حقول التخصصات التقنية الثلاثة */
const secFields = (platform: L, detail: L): FieldDef[] => [
  { id: "platform", label: platform, type: "text", ph: l("مثال: Linux / Web / Android…", "e.g. Linux / Web / Android…"), required: true },
  { id: "details", label: detail, type: "textarea", ph: l("اشرح المطلوب تقنياً بدقة…", "Describe the technical need precisely…"), required: true },
  fFile,
];

/* ═══════════════ القسم 1: لودر التفريغ والاستقبال ═══════════════ */
const DRAIN_SERVICES: ServiceDef[] = [
  svc("d-in-1", "box", "طلب مكينة جاهزة لسحب", "Ready POS Machine Request", G_REQUEST, "inbound"),
  svc("d-in-2", "terminal", "طلب سيرفر جاهز لتفريغ", "Ready Draining Server Request", G_REQUEST, "inbound"),
  svc("d-in-3", "coin", "طلب بوابة دفع جاهزة للاستقبال", "Ready Payment Gateway Request", G_REQUEST, "inbound"),
  svc("d-in-4", "link", "طلب لينكات ومتاجر D2", "D2 Links & Stores Request", G_REQUEST, "inbound"),
  svc("d-in-5", "shield", "طلب حسابات بنكية للاستقبال", "Bank Receiving Accounts Request", G_REQUEST, "inbound"),
  svc("d-in-6", "card", "طلب بطاقات لشحن بروتوكول", "Protocol Charge Cards Request", G_REQUEST, "inbound"),
  svc("d-in-7", "wallet", "طلب محافظ باردة للاستقبال", "Cold Wallets Request", G_REQUEST, "inbound"),
  svc("d-in-8", "plus", "طلبات أخرى مخصصة", "Other Custom Requests", G_REQUEST, "inbound"),
  svc("d-out-1", "code", "طلب لودر سحب بطاقات", "Card Draining Loader Request", G_REQUEST, "outbound"),
  svc("d-out-2", "user", "طلب لودر سحب حسابات", "Account Draining Loader Request", G_REQUEST, "outbound"),
  svc("d-out-3", "swap", "طلب مستقبل تحويل / Wire Receiver", "Wire Receiver Request", G_REQUEST, "outbound"),
  svc("d-out-4", "terminal", "كود سحب آلي / Cardless ATM Cashout", "Cardless ATM Cashout Code", G_REQUEST, "outbound"),
  svc("d-out-5", "wallet", "رصيد محفظة / E-Wallet Balance", "E-Wallet Balance Drain", G_REQUEST, "outbound"),
  svc("d-out-6", "star", "نقاط مكافآت / Reward Points Drain", "Reward Points Drain", G_REQUEST, "outbound"),
  svc("d-out-7", "plus", "طلبات أخرى مخصصة", "Other Custom Requests", G_REQUEST, "outbound"),
];

/* ═══════════════ القسم 2: طلب الخدمات التقنية والميدانية ═══════════════ */
/** خدمة لوحة الطلبات مع تصنيفها (عدّل التصنيف من هنا فقط) */
const bsvc = (
  id: string,
  icon: string,
  ar: string,
  en: string,
  offer: "operator" | "receiver" | "both",
): ServiceDef => ({ ...svc(id, icon, ar, en, G_REQUEST), offer });

const BOARD_SERVICES: ServiceDef[] = [
  /* خدمات تطلب منفّذاً */
  bsvc("b-1", "swap", "مستقبل أموال | محول أموال", "Money Receiver | Money Converter", "both"),
  bsvc("b-2", "card", "مسدد فواتير | صاحب فواتير", "Bill Payer | Bill Holder", "both"),
  bsvc("b-3", "link", "مسدد لينكات دفع | صاحب سيرفر", "Payment Link Payer | Server Owner", "both"),
  bsvc("b-4", "code", "صاحب بروتوكول | صاحب بوابة دفع", "Protocol Owner | Gateway Owner", "both"),
  bsvc("b-5", "user", "صاحب حساب | حقن حساب", "Account Owner | Account Injection", "both"),
  bsvc("b-6", "terminal", "صفحات صيد / Landers", "Phishing Landers", "operator"),
  bsvc("b-7", "lock", "تشفير FUD", "FUD Encryption", "operator"),
  bsvc("b-8", "chat", "هندسة اجتماعية", "Social Engineering", "operator"),
  /* خدمات تريد مستقبِلاً */
  bsvc("b-9", "shieldCheck", "توثيق هويات KYC", "KYC Identity Verification", "receiver"),
  bsvc("b-10", "box", "استضافة منيعة (Bulletproof Hosting)", "Bulletproof Hosting", "receiver"),
  bsvc("b-11", "plus", "طلبات أخرى مخصصة", "Other Custom Requests", "both"),
];

/* ═══════════════ القسم 5: القسم التقني الذاتي ═══════════════ */
const CYBER = secFields(
  l("نوع النظام أو المنصة المستهدفة", "Target system / platform"),
  l("طبيعة الثغرة أو الفحص المطلوب", "Nature of the vulnerability or required test"),
);
const DEV = secFields(
  l("لغة البرمجة أو التقنية المطلوبة", "Required language / technology"),
  l("شرح تفصيلي للمشروع أو الفكرة البرمجية", "Detailed project description"),
);
const OTHER = secFields(
  l("مسمى الخدمة أو الطلب المخصص", "Custom service / request title"),
  l("تفاصيل وشروط التنفيذ", "Execution details & conditions"),
);

const AUTONOMOUS_SPECIALTIES: SpecialtyDef[] = [
  {
    id: "sp-cyber",
    icon: "shield",
    name: l("قسم الأمن السيبراني", "Cybersecurity Experts", "Эксперты по кибербезопасности"),
    desc: l("فحص، تأمين، واستجابة للحوادث.", "Testing, hardening, and incident response."),
    services: [
      svc("cy-1", "search", "فحص ثغرات وتأمين سيرفرات (Penetration Testing)", "Penetration Testing & Server Hardening", G_TECH, undefined, CYBER),
      svc("cy-2", "lock", "تأمين وتشفير قنوات الاتصال (FUD & Encryption)", "FUD & Channel Encryption", G_TECH, undefined, CYBER),
      svc("cy-3", "shieldCheck", "إعداد استجابة للحوادث وحماية قواعد البيانات", "Incident Response & DB Protection", G_TECH, undefined, CYBER),
      svc("cy-4", "code", "فحص حماية التطبيقات (Web/Mobile App Security)", "Web / Mobile App Security", G_TECH, undefined, CYBER),
      svc("cy-5", "chat", "استشارات أمنية متقدمة", "Advanced Security Consulting", G_TECH, undefined, CYBER),
    ],
  },
  {
    id: "sp-dev",
    icon: "terminal",
    name: l("قسم البرمجة وتطوير الأنظمة", "Developers Hub", "Хаб разработчиков"),
    desc: l("بوتات، بوابات، واجهات، وأتمتة.", "Bots, gateways, interfaces, automation."),
    services: [
      svc("dv-1", "plane", "برمجة بوتات تيليجرام متقدمة (Bots & Mini-Apps)", "Advanced Telegram Bots & Mini-Apps", G_TECH, undefined, DEV),
      svc("dv-2", "coin", "تطوير بوابات دفع وربط APIs", "Payment Gateways & API Integration", G_TECH, undefined, DEV),
      svc("dv-3", "code", "برمجة واجهات مستخدم وتطبيقات SPA", "SPA Interfaces & UI Development", G_TECH, undefined, DEV),
      svc("dv-4", "tool", "تطوير سكربتات أتمتة وكشط بيانات", "Automation & Scraping Scripts", G_TECH, undefined, DEV),
      svc("dv-5", "terminal", "تعديل وبرمجة أكواد خاصة (Custom Scripting)", "Custom Scripting", G_TECH, undefined, DEV),
    ],
  },
  {
    id: "sp-other",
    icon: "plus",
    name: l("خدمات تقنية متخصصة أخرى", "Other Specialized Services", "Другие услуги"),
    desc: l("توثيق، استشارات، وتوجيه حركة.", "Verification, consulting, traffic routing."),
    services: [
      svc("ot-1", "shieldCheck", "توثيق هويات وخدمات KYC", "KYC & Identity Services", G_TECH, undefined, OTHER),
      svc("ot-2", "chat", "هندسة اجتماعية استشارية", "Social Engineering Consulting", G_TECH, undefined, OTHER),
      svc("ot-3", "send", "خدمات تسويق وتوجيه حركة مرور", "Traffic Routing & Marketing", G_TECH, undefined, OTHER),
      svc("ot-4", "gear", "استشارات تشغيلية وهيكلة عمليات", "Operations Consulting", G_TECH, undefined, OTHER),
    ],
  },
];

/* ═══════════════ القسم 4: تنسيق المقابلات ═══════════════ */
const meetingFields = (city: L): FieldDef[] => [
  { id: "city", label: l("المدينة المعتمدة", "Approved city"), type: "text", ph: l("المدينة…", "City…"), required: true },
  { id: "schedule", label: l("التاريخ والوقت المقترح", "Proposed date & time"), type: "text", ph: l("YYYY-MM-DD HH:mm", "YYYY-MM-DD HH:mm"), required: true },
  { id: "details", label: l("موضوع المقابلة وطبيعة الصفقة", "Meeting topic & deal nature"), type: "textarea", ph: l("اكتب الموضوع دون بيانات حساسة…", "State the topic without sensitive data…"), required: true },
];
const CITIES = [
  ["m-riyadh", "الرياض", "Riyadh"],
  ["m-dubai", "دبي", "Dubai"],
  ["m-texas", "تكساس", "Texas"],
  ["m-moscow", "موسكو", "Moscow"],
  ["m-berlin", "برلين", "Berlin"],
] as const;
const MEETING_SERVICES: ServiceDef[] = CITIES.map(([id, ar, en]) =>
  svc(id, "user", `تنسيق مقابلة — ${ar}`, `Meeting Coordination — ${en}`, G_MEET, undefined, meetingFields(l(ar, en))),
);

/* ═══════════════ الأقسام الخمسة ═══════════════ */
export const FORUM_SECTIONS: ForumSectionDef[] = [
  {
    id: "drain",
    short: l("اللودر", "LOADER"),
    icon: "code",
    name: l("لودر التفريغ والاستقبال", "DRAIN & LOADER HUB", "Хаб слива и приёма"),
    desc: l("اتجاهان: طلب منفذ (Inbound) أو طلب مستقبل (Outbound).", "Two directions: inbound receiver or outbound drain.", "Два направления: приём или слив."),
    mode: "services",
    roles: {
      a: l("أنا صاحب الخدمة وأبحث عن منفذ", "I own the service, seeking an operator", "Я владелец услуги, ищу исполнителя"),
      b: l("أنا المنفذ وأبحث عن صاحب خدمة", "I'm the operator, seeking a service owner", "Я исполнитель, ищу владельца"),
    },
    groupLabels: {
      inbound: l("أ) طلب منفذ (Inbound Receiver)", "A) Inbound Receiver", "А) Приём"),
      outbound: l("ب) طلب مستقبل (Outbound Drain)", "B) Outbound Drain", "Б) Слив"),
    },
    groupDetails: {
      inbound: l(
        "قسم «طلب منفذ» يخص من يملك المادة ويبحث عن جهة مستقبِلة جاهزة: مكينة، سيرفر، بوابة دفع، لينكات D2، حسابات بنكية، بطاقات شحن بروتوكول، محافظ باردة، أو طلب مخصص.",
        "The Inbound Receiver group is for those who own the material and need a ready receiving endpoint: POS machine, server, payment gateway, D2 links, bank accounts, protocol charge cards, cold wallets, or a custom request.",
      ),
      outbound: l(
        "قسم «طلب مستقبل» يخص من يملك أداة التفريغ ويبحث عن مادة: لودر سحب بطاقات/حسابات، مستقبل تحويل Wire، كود Cardless ATM، رصيد محفظة، نقاط مكافآت، أو طلب مخصص.",
        "The Outbound Drain group is for those who own the draining tool and need material: card/account loaders, Wire receiver, Cardless ATM code, e-wallet balance, reward points, or a custom request.",
      ),
    },
    groupCards: [
      {
        id: "inbound",
        icon: "box",
        name: l("طلب منفذ", "Inbound Receiver", "Запрос приёмника"),
        desc: l("أملك المادة وأبحث عن جهة استقبال جاهزة — 8 خدمات.", "I own the material, seeking a ready endpoint — 8 services.", "Есть материал, нужен приёмник — 8 услуг."),
      },
      {
        id: "outbound",
        icon: "code",
        name: l("طلب مستقبل", "Outbound Drain", "Запрос слива"),
        desc: l("أملك أداة التفريغ وأبحث عن مادة — 7 خدمات.", "I own the draining tool, seeking material — 7 services.", "Есть инструмент слива, нужен материал — 7 услуг."),
      },
    ],
    services: DRAIN_SERVICES,
  },
  {
    id: "board",
    short: l("الخدمات", "SERVICES"),
    icon: "gear",
    name: l("طلب الخدمات التقنية والميدانية", "SERVICE REQUESTS BOARD", "Доска запросов услуг"),
    desc: l("ثلاثة تيوبات: الكل، متاح كمنفذ، متاح كمستقبل — تصفية فورية للخدمات.", "Three tabs: All, Available as operator, Available as receiver — instant filtering.", "Три таба: Все, Исполнитель, Приёмник."),
    mode: "services",
    offerTabs: true,
    roles: {
      a: l("مطلوب منفذ", "Operator needed", "Требуется исполнитель"),
      b: l("متاح للعمل كمنفذ", "Available to work as operator", "Доступен как исполнитель"),
    },
    services: BOARD_SERVICES,
  },
  {
    id: "autonomous",
    short: l("التقني", "AUTONOMOUS"),
    icon: "shield",
    name: l("القسم التقني الذاتي والخدمات الأمنية", "Autonomous Section", "Автономный техотдел"),
    desc: l("ثلاثة تخصصات: الأمن السيبراني، المبرمجون، وخدمات أخرى.", "Three specialties: cybersecurity, developers, and others."),
    mode: "specialty",
    specialties: AUTONOMOUS_SPECIALTIES,
  },
  {
    id: "percent",
    short: l("النسبة", "PERCENT"),
    icon: "coin",
    name: l("العمل بالنسبة", "PERCENT & AFFILIATE WORK", "Работа по проценту"),
    desc: l("توليد رابط الإحالة المشفر محلياً (Alias Router).", "Generate the encrypted affiliate hash locally."),
    mode: "affiliate",
    services: [
      svc("af-1", "link", "توليد رابط الإحالة المشفر", "Encrypted Affiliate Hash Generator", G_AFF, undefined, [
        { id: "subject", label: l("اسم الحملة", "Campaign name"), type: "text", ph: l("مثال: SPRING-26", "e.g. SPRING-26"), required: true },
        { id: "details", label: l("وصف الحملة", "Campaign description"), type: "textarea", ph: l("اشرح قنوات الترويج…", "Describe promotion channels…") },
      ]),
    ],
  },
  {
    id: "meetings",
    short: l("المقابلات", "MEETINGS"),
    icon: "user",
    name: l("تنسيق المقابلات", "MEETING COORDINATION", "Координация встреч"),
    desc: l("المدن المعتمدة: الرياض، دبي، تكساس، موسكو، برلين.", "Approved cities: Riyadh, Dubai, Texas, Moscow, Berlin."),
    mode: "meetings",
    services: MEETING_SERVICES,
  },
];

/* ═════════════════════════════════════════════════════════════
   مكتبة الحقول الديناميكية — كل خدمة تحدد مجموعة حقولها هنا فقط.
   أضف preset جديداً أو غيّر حقول خدمة من الخريطة بالأسفل،
   ولا يحتاج أي كود واجهة للتغيير (التوسعة 100%).
   ═════════════════════════════════════════════════════════════ */
const txt = (id: string, ar: string, en: string, ph: string, required = true): FieldDef => ({
  id,
  label: l(ar, en),
  type: "text",
  ph: l(ph, ph),
  required,
});
const num = (id: string, ar: string, en: string, ph: string): FieldDef => ({
  id,
  label: l(ar, en),
  type: "number",
  ph: l(ph, ph),
  required: true,
});
const notes = (ar: string, en: string): FieldDef => ({
  id: "notes",
  label: l(ar, en),
  type: "textarea",
  ph: l("اكتب الملاحظات والتفاصيل اللوجستية…", "Write notes & logistical details…"),
  required: true,
});
const upload = (): FieldDef => ({ ...fFile, id: "attachment" });

/** كل preset دالة تُرجع نسخة جديدة (لا تشارك مراجع بين الخدمات) */
export const FIELD_PRESETS: Record<string, () => FieldDef[]> = {
  pos: () => [
    txt("deviceType", "نوع الجهاز", "Device type", "Pax A920 / Ingenico…"),
    txt("country", "الدولة", "Country", "السعودية / UAE…"),
    num("percent", "النسبة %", "Percent %", "20"),
    notes("الملاحظات", "Notes"),
    upload(),
  ],
  server: () => [
    txt("serverType", "نوع السيرفر", "Server type", "VPS / Dedicated…"),
    txt("country", "الدولة", "Country", "DE / US…"),
    num("capacity", "السعة المطلوبة", "Required capacity", "10"),
    notes("التفاصيل اللوجستية", "Logistical details"),
    upload(),
  ],
  gateway: () => [
    txt("gatewayName", "اسم البوابة", "Gateway name", "Stripe / Custom…"),
    txt("country", "الدولة", "Country", "US…"),
    num("amount", "القيمة المتوقعة", "Expected volume", "5000"),
    notes("وصف المتطلبات", "Requirement description"),
    upload(),
  ],
  links: () => [
    txt("platform", "المنصة / المتجر", "Platform / store", "D2 / Shop…"),
    num("count", "عدد اللينكات", "Number of links", "5"),
    notes("التفاصيل", "Details"),
    upload(),
  ],
  bank: () => [
    txt("bankName", "اسم البنك", "Bank name", "Al Rajhi / Chase…"),
    txt("country", "الدولة", "Country", "SA…"),
    txt("accountType", "نوع الحساب", "Account type", "IBAN / Business…", false),
    notes("وصف المتطلبات", "Requirement description"),
    upload(),
  ],
  cards: () => [
    txt("cardType", "نوع البطاقة", "Card type", "Visa / Mastercard…"),
    txt("country", "الدولة", "Country", "US…"),
    num("quantity", "الكمية", "Quantity", "10"),
    notes("الملاحظات", "Notes"),
    upload(),
  ],
  wallet: () => [
    txt("walletType", "نوع المحفظة", "Wallet type", "Cold / Hot…"),
    txt("currency", "العملة", "Currency", "USDT / BTC…"),
    num("amount", "الرصيد / القيمة", "Balance / Amount", "1000"),
    notes("التفاصيل", "Details"),
    upload(),
  ],
  loader: () => [
    txt("toolName", "اسم اللودر / الأداة", "Loader / tool name", "Card loader v2…"),
    txt("country", "الدولة", "Country", "US…"),
    num("count", "العدد المطلوب", "Required count", "1"),
    notes("وصف المتطلبات", "Requirement description"),
    upload(),
  ],
  transfer: () => [
    txt("method", "طريقة التحويل", "Transfer method", "Wire / SEPA / SWIFT…"),
    num("amount", "المبلغ", "Amount", "5000"),
    txt("country", "الدولة", "Country", "US…"),
    notes("التفاصيل اللوجستية", "Logistical details"),
    upload(),
  ],
  balance: () => [
    txt("platform", "المنصة", "Platform", "E-Wallet / Rewards…"),
    num("amount", "الرصيد", "Balance", "1000"),
    notes("الملاحظات", "Notes"),
    upload(),
  ],
  custom: () => [
    txt("title", "مسمى الطلب المخصص", "Custom request title", "اكتب المطلوب…"),
    txt("country", "الدولة (اختياري)", "Country (optional)", "—", false),
    notes("تفاصيل وشروط التنفيذ", "Execution details & conditions"),
    upload(),
  ],
  role: () => [
    txt("roleType", "نوع الدور المطلوب", "Required role type", "مسدد / مستقبل…"),
    txt("country", "الدولة", "Country", "SA…"),
    num("percent", "النسبة %", "Percent %", "20"),
    notes("وصف المتطلبات", "Requirement description"),
    upload(),
  ],
  tech: () => [
    txt("platform", "النظام / التقنية", "System / technology", "Linux / Node.js…"),
    txt("country", "الدولة (اختياري)", "Country (optional)", "—", false),
    notes("شرح تفصيلي للمطلوب", "Detailed description"),
    upload(),
  ],
};

/** ربط كل خدمة بـ preset — عدّل سطراً واحداً لتغيير حقول أي خدمة */
export const FIELD_PRESET_BY_SERVICE: Record<string, string> = {
  // 1) لودر التفريغ — Inbound
  "d-in-1": "pos", "d-in-2": "server", "d-in-3": "gateway", "d-in-4": "links",
  "d-in-5": "bank", "d-in-6": "cards", "d-in-7": "wallet", "d-in-8": "custom",
  // 1) لودر التفريغ — Outbound
  "d-out-1": "loader", "d-out-2": "loader", "d-out-3": "transfer", "d-out-4": "loader",
  "d-out-5": "balance", "d-out-6": "balance", "d-out-7": "custom",
  // 2) لوحة الطلبات
  "b-1": "transfer", "b-2": "role", "b-3": "links", "b-4": "gateway", "b-5": "bank",
  "b-6": "tech", "b-7": "tech", "b-8": "tech", "b-9": "tech", "b-10": "server", "b-11": "custom",
  // بقية الأقسام (النسبة / المقابلات / التخصصات التقنية) تحتفظ بحقولها
  // المخصصة ويُضاف لها حقل المرفقات تلقائياً إن لم يكن موجوداً.
};

/* تطبيق الحقول المخصصة على كل الخدمات في كل الأقسام (Once) */
for (const section of FORUM_SECTIONS) {
  const list: ServiceDef[] = [
    ...(section.services ?? []),
    ...(section.specialties ?? []).flatMap((sp) => sp.services),
  ];
  for (const s of list) {
    const key = FIELD_PRESET_BY_SERVICE[s.id];
    if (key && FIELD_PRESETS[key]) s.fields = FIELD_PRESETS[key]();
    else if (!s.fields.some((f) => f.type === "file")) s.fields = [...s.fields, upload()];

    /* ربط الشرح التشغيلي من الكتالوج تلقائياً */
    const g = FORUM_GUIDES[s.id];
    if (g) {
      s.guide = g.guide;
      s.extra = g.extra;
    }
  }
}

/* ═══════════════ قسم تنسيق المقابلات — Hub ═══════════════ */

/** صندوق الشرح والسياسة (يظهر في الأعلى فوق الحقول) */
export const MEETING_POLICY: L = {
  ar: `🛡️ خدمات بلاك مارت (BLACK MART) - التنسيق للمقابلات والخدمات الرقمية
نحن جاهزون لتنسيق مقابلتك للحصول على مجموعة واسعة من الخدمات الرقمية المتقدمة التي تتجاوز قيمتها 2,000 دولار، مثل:
• حقن بطاقات التحويلات الدولية.
• شراء حسابات مستعارة (أمريكان إكسبريس، نومو، أو أي بنك آخر).
• استلام بطاقات الفيزا المحقونة.
• استلام حسابات تيك توك مشحونة.
• سداد الفواتير والخدمات الكبرى التي تصل قيمتها إلى 2,000$.

⚙️ طريقة العمل والخطوات:
1. تحديد الخدمة: تواصل أولاً مع المسؤول لتحديد نوع الخدمة المطلوبة بدقة.
2. تجهيز المبالغ (لإثبات الجدية):
   - تجهيز قيمة الخدمة بالعملات الرقمية.
   - تجهيز النسبة المئوية المتبقية بالعملة النقدية (الكاش).
3. التقاط صورة للمحفظة الرقمية مع واجهة الموقع لإثبات الجدية.
4. التنسيق: إرسال الإثباتات للمسؤول ليقوم بترتيب موعد المقابلة وتوجيهك إلى المسؤول المختص لاستلام خدمتك وجهاً لوجه لضمان حقوق الطرفين.

🌍 الدول المتاحة للمقابلات الشخصية:
الولايات المتحدة الأمريكية | روسيا | فرنسا | المملكة العربية السعودية | مصر
*(ملاحظة: بالنسبة للدول الأخرى غير المذكورة، يمكنك التنسيق مباشرة مع المسؤول لإيجاد طريقة مناسبة).*`,
  en: `🛡️ BLACK MART — Meeting Coordination & Digital Services
We are ready to coordinate your meeting for a wide range of advanced digital services exceeding $2,000, such as:
• International transfer card injection.
• Purchasing borrowed accounts (American Express, Nomo, or any other bank).
• Receiving injected Visa cards.
• Receiving charged TikTok accounts.
• Settling major bills and services up to $2,000.

⚙️ How it works:
1. Define the service: contact the manager first to specify the exact service.
2. Prepare the funds (proof of seriousness): the service value in crypto + the remaining percentage in cash.
3. Capture a photo of the digital wallet with the site interface as proof of seriousness.
4. Coordination: send the proofs to the manager to arrange the meeting and direct you to the specialist for a face-to-face handover protecting both parties.

🌍 Available countries for in-person meetings:
United States | Russia | France | Saudi Arabia | Egypt
*(For other countries, coordinate directly with the manager to find a suitable method).*`,
  ru: `🛡️ BLACK MART — Координация встреч и цифровые услуги
Мы готовы скоординировать встречу для широкого спектра продвинутых цифровых услуг стоимостью свыше $2,000.
⚙️ Порядок работы: 1) Уточните услугу у менеджера. 2) Подготовьте сумму в криптовалюте и оставшийся процент наличными. 3) Сделайте снимок кошелька с интерфейсом сайта. 4) Отправьте доказательства менеджеру для назначения встречи.
🌍 Доступные страны: США | Россия | Франция | Саудовская Аравия | Египет
*(Для других стран согласуйте способ напрямую с менеджером).*`,
};

/** حقول أداة تنسيق المقابلات (تحت الشرح مباشرة) */
export const MEETING_FIELDS: FieldDef[] = [
  { id: "serviceName", label: l("اسم الخدمة المطلوبة", "Requested service name", "Название услуги"), type: "text", ph: l("اكتب اسم الخدمة بدقة…", "Write the exact service name…", "Точное название…"), required: true },
  { id: "price", label: l("سعر الخدمة ($)", "Service price ($)", "Цена услуги ($)"), type: "number", ph: l("2000", "2000", "2000"), required: true },
  { id: "country", label: l("الدولة", "Country", "Страна"), type: "text", ph: l("السعودية / USA…", "Saudi Arabia / USA…", "Саудовская Аравия…"), required: true },
  { id: "city", label: l("المدينة", "City", "Город"), type: "text", ph: l("الرياض / Dubai…", "Riyadh / Dubai…", "Эр-Рияд…"), required: true },
  { id: "date", label: l("تاريخ المقابلة المقترح", "Proposed meeting date", "Предлагаемая дата"), type: "text", ph: l("YYYY-MM-DD HH:mm", "YYYY-MM-DD HH:mm", "YYYY-MM-DD HH:mm"), required: true },
];

/** مدن سريعة لتعبئة الحقول بلمسة */
export const MEETING_CITY_PRESETS: { country: L; city: L }[] = [
  { country: l("الولايات المتحدة الأمريكية", "United States"), city: l("Texas / New York", "Texas / New York") },
  { country: l("روسيا", "Russia"), city: l("موسكو", "Moscow") },
  { country: l("فرنسا", "France"), city: l("باريس", "Paris") },
  { country: l("المملكة العربية السعودية", "Saudi Arabia"), city: l("الرياض", "Riyadh") },
  { country: l("مصر", "Egypt"), city: l("القاهرة", "Cairo") },
];

/** تيوب التنقل العلوي داخل قسم المقابلات */
export const MEETING_TOP_TABS: { id: string; label: L }[] = [
  { id: "drain", label: l("لودر التفريغ", "DRAIN & LOADER", "Лодер") },
  { id: "board", label: l("الخدمات التقنية", "SERVICE REQUESTS", "Тех. услуги") },
  { id: "autonomous", label: l("المتخصصين", "SPECIALISTS", "Специалисты") },
  { id: "meetings", label: l("تنسيق المقابلات", "MEETINGS", "Встречи") },
];

export const MEETING_GUIDE: L = l(
  "يرجى كتابة اسم الخدمة وسعرها بدقة، واختيار الدولة والمدينة من الدول المتاحة، وتحديد موعد قبل 48 ساعة على الأقل. لا تُدرج أي روابط أو معرفات مكشوفة — التوجيه يتم عبر القناة المشفرة فقط.",
  "Write the service name and price precisely, choose an available country and city, and set a date at least 48h ahead. Never include exposed links or handles — routing happens through the encrypted relay only.",
);

export const forumById = (id: string) => FORUM_SECTIONS.find((s) => s.id === id);
