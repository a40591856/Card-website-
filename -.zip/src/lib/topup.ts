/* ─────────────────────────────────────────────────────────────
   BLACK MART · APP TOP-UP VAULT (شحن التطبيقات الصوتية والمرئية)
   كل الأقسام / الباقات / الصور / الأسعار / التحذيرات / الرسائل هنا.
   أضف تطبيقاً أو باقة من هذا الملف دون لمس الواجهة (100%).
   ───────────────────────────────────────────────────────────── */
import type { L } from "./site";

const A = (ar: string, en = ar): L => ({ ar, en });

/** نسبة «السعر القديم» العرضية — قابلة للتعديل من سطر واحد */
export const OLD_PRICE_RATIO = 1.3;
export const oldPrice = (p: number) => Math.round(p * OLD_PRICE_RATIO);

export interface TopupPackage {
  id: string;
  name: L;
  desc: L;
  details: L;
  img: string;
  balance: L;       // كمية الشحن
  qty: number;      // القيمة الرقمية للكمية (للحساب)
  priceUsd: number;
  oldPriceUsd: number;
  app: string;      // معرف التطبيق
  badges: string[];
  featured?: boolean;
}

export interface TopupApp {
  id: string;
  name: L;
  short: L;
  img: string;
  desc: L;
  packages: TopupPackage[];
}

export interface TopupSection {
  id: "visual" | "audio";
  name: L;
  short: L;
  desc: L;
  icon: string;
  hero: string;
  guideTitle: L;
  guide: L[];
  apps: TopupApp[];
}

/* ═══════════ التحذير الأمني الموحد (قاعدة الـ 3 ساعات) ═══════════ */
export const THREE_HOUR_WARNING: L[] = [
  A("⚠️ تنبيه أمني هام (قاعدة الـ 3 ساعات)"),
  A("توصية: يُفضل استخدام حساب جديد للشحن؛ ففي حال تم البلاغ عن البطاقة المستخدمة، سيتم حظر الحساب."),
  A("تنبيه: لا تترك العملات/الشحن في الحساب لأكثر من 3 ساعات."),
  A("تحذير: حدوث أي بلاغ على البطاقة يؤدي فوراً إلى استرداد الشحن (Chargeback) وحظر الحساب نهائياً من قبل إدارة التطبيق."),
];

const VISUAL_DETAILS = `⚠️ تنبيه أمني هام (قاعدة الـ 3 ساعات):
• توصية: يُفضل استخدام حساب جديد للشحن؛ ففي حال تم البلاغ عن البطاقة المستخدمة، سيتم حظر الحساب.
• تنبيه: لا تترك العملات/الشحن في الحساب لأكثر من 3 ساعات.
• تحذير: حدوث أي بلاغ على البطاقة يؤدي فوراً إلى استرداد الشحن (Chargeback) وحظر الحساب نهائياً من قبل إدارة التطبيق.

📦 التسليم: يُشحن الرصيد مباشرة إلى حسابك بعد تأكيد الطلب مع المسؤول. يُرجى تجهيز يوزر الحساب وكلمة المرور، واستخدام حساب جديد لتجنب الحظر.`;

const AUDIO_DETAILS = `⚠️ تنبيه أمني هام (قاعدة الـ 3 ساعات):
• توصية: يُفضل استخدام حساب جديد للشحن؛ ففي حال تم البلاغ عن البطاقة المستخدمة، سيتم حظر الحساب.
• تنبيه: لا تترك العملات/الشحن في الحساب لأكثر من 3 ساعات.
• تحذير: حدوث أي بلاغ على البطاقة يؤدي فوراً إلى استرداد الشحن (Chargeback) وحظر الحساب نهائياً من قبل إدارة التطبيق.

📦 هذه هي الباقة الأساسية الأولى للتطبيق. للكميات الأكبر استخدم «أداة الشحن الذكي» أسفل القسم؛ يُحتسب السعر تلقائياً من سعر الوحدة لهذه الباقة.`;

const VISUAL_HERO = "https://i.postimg.cc/pTjKhf76/1782248179435.png";
const AUDIO_HERO = "https://i.postimg.cc/sDH1zBHQ/Screenshot-20260623-234908-Google.jpg";
const TIKTOK_IMG = "https://i.postimg.cc/764Z9Sbq/78f9333416b0b46b544591e05767d7c3.jpg";
const JACO_IMG = "https://i.postimg.cc/gcN2yXpb/dcd2d8c1c66012f95d72e8bfc0142d2f.jpg";

const PKG = (
  app: string, id: string, label: string, qtyLabel: string, qty: number,
  price: number, img: string, desc: string, details: string, featured?: boolean,
): TopupPackage => ({
  id, app, name: A(label), balance: A(qtyLabel), qty, priceUsd: price,
  oldPriceUsd: oldPrice(price), img,
  desc: A(desc), details: A(details),
  badges: ["3H_RULE", "INSTANT_TOPUP"], featured,
});

const tiktokOffers: [string, string, number, number][] = [
  ["50K", "50,000 عملة", 50000, 85], ["80K", "80,000 عملة", 80000, 120],
  ["100K", "100,000 عملة", 100000, 160], ["200K", "200,000 عملة", 200000, 249],
  ["500K", "500,000 عملة", 500000, 499], ["700K", "700,000 عملة", 700000, 699],
  ["1M", "1,000,000 عملة", 1000000, 999],
];
const jacoOffers: [string, string, number, number][] = [
  ["25K", "25,000 عملة", 25000, 85], ["50K", "50,000 عملة", 50000, 149],
  ["100K", "100,000 عملة", 100000, 249], ["200K", "200,000 عملة", 200000, 399],
  ["500K", "500,000 عملة", 500000, 699], ["700K", "700,000 عملة", 700000, 999],
  ["1M", "1,000,000 عملة", 1000000, 1199],
];

const audioApps: TopupApp[] = [
  { id: "bigo", name: A("Bigo Live"), short: A("Bigo"), img: "https://i.postimg.cc/ncXpv3T9/Screenshot-20260614-172944.jpg", desc: A("شحن ماسات Bigo Live — الباقة الأساسية الأولى."), packages: [
    PKG("bigo", "bigo1", "Bigo Live — 25,000 ماسة", "25,000 ماسة", 25000, 99, "https://i.postimg.cc/ncXpv3T9/Screenshot-20260614-172944.jpg", "شحن 25,000 ماسة إلى حساب Bigo Live مباشرة.", AUDIO_DETAILS, true) ] },
  { id: "likee", name: A("Likee"), short: A("Likee"), img: "https://i.postimg.cc/NGVWwB7k/Screenshot-20260614-173012.jpg", desc: A("شحن ماسات Likee — الباقة الأساسية الأولى."), packages: [
    PKG("likee", "likee1", "Likee — 20,000 ماسة", "20,000 ماسة", 20000, 85, "https://i.postimg.cc/NGVWwB7k/Screenshot-20260614-173012.jpg", "شحن 20,000 ماسة إلى حساب Likee مباشرة.", AUDIO_DETAILS) ] },
  { id: "mico", name: A("Mico"), short: A("Mico"), img: "https://i.postimg.cc/rpQPZkws/Screenshot-20260614-173049.jpg", desc: A("شحن كوينز Mico — الباقة الأساسية الأولى."), packages: [
    PKG("mico", "mico1", "Mico — 250,000 كوينز", "250,000 كوينز", 250000, 99, "https://i.postimg.cc/rpQPZkws/Screenshot-20260614-173049.jpg", "شحن 250,000 كوينز إلى حساب Mico مباشرة.", AUDIO_DETAILS) ] },
  { id: "yoyo", name: A("YoYo"), short: A("YoYo"), img: "https://i.postimg.cc/4nkLH4B8/Screenshot-20260614-173107.jpg", desc: A("شحن كوينز YoYo — الباقة الأساسية الأولى."), packages: [
    PKG("yoyo", "yoyo1", "YoYo — 300,000 كوينز", "300,000 كوينز", 300000, 75, "https://i.postimg.cc/4nkLH4B8/Screenshot-20260614-173107.jpg", "شحن 300,000 كوينز إلى حساب YoYo مباشرة.", AUDIO_DETAILS) ] },
  { id: "yoho", name: A("YoHo"), short: A("YoHo"), img: "https://i.postimg.cc/cLsqFTB7/Screenshot-20260614-173214.jpg", desc: A("شحن كوينز YoHo — الباقة الأساسية الأولى."), packages: [
    PKG("yoho", "yoho1", "YoHo — 2,000,000 كوينز", "2,000,000 كوينز", 2000000, 75, "https://i.postimg.cc/cLsqFTB7/Screenshot-20260614-173214.jpg", "شحن 2,000,000 كوينز إلى حساب YoHo مباشرة.", AUDIO_DETAILS) ] },
  { id: "hiyoo", name: A("Hiyoo"), short: A("Hiyoo"), img: "https://i.postimg.cc/0y53Yj8s/Screenshot-20260614-173521.jpg", desc: A("شحن كوينز Hiyoo — الباقة الأساسية الأولى."), packages: [
    PKG("hiyoo", "hiyoo1", "Hiyoo — 300,000 كوينز", "300,000 كوينز", 300000, 85, "https://i.postimg.cc/0y53Yj8s/Screenshot-20260614-173521.jpg", "شحن 300,000 كوينز إلى حساب Hiyoo مباشرة.", AUDIO_DETAILS) ] },
  { id: "hiya", name: A("Hiya"), short: A("Hiya"), img: "https://i.postimg.cc/CLhJt29f/Screenshot-20260614-173539.jpg", desc: A("شحن كوينز Hiya — الباقة الأساسية الأولى."), packages: [
    PKG("hiya", "hiya1", "Hiya — 300,000 كوينز", "300,000 كوينز", 300000, 119, "https://i.postimg.cc/CLhJt29f/Screenshot-20260614-173539.jpg", "شحن 300,000 كوينز إلى حساب Hiya مباشرة.", AUDIO_DETAILS) ] },
  { id: "waho", name: A("Waho"), short: A("Waho"), img: "https://i.postimg.cc/pTQYcQZ5/Screenshot-20260614-173554.jpg", desc: A("شحن كوينز Waho — الباقة الأساسية الأولى."), packages: [
    PKG("waho", "waho1", "Waho — 1,500,000 كوينز", "1,500,000 كوينز", 1500000, 99, "https://i.postimg.cc/pTQYcQZ5/Screenshot-20260614-173554.jpg", "شحن 1,500,000 كوينز إلى حساب Waho مباشرة.", AUDIO_DETAILS) ] },
  { id: "xena", name: A("Xena Live"), short: A("Xena"), img: "https://i.postimg.cc/wT45rjXg/Screenshot-20260614-172901.jpg", desc: A("شحن كوينز Xena Live — الباقة الأساسية الأولى."), packages: [
    PKG("xena", "xena1", "Xena Live — 1,000,000 كوينز", "1,000,000 كوينز", 1000000, 99, "https://i.postimg.cc/wT45rjXg/Screenshot-20260614-172901.jpg", "شحن 1,000,000 كوينز إلى حساب Xena Live مباشرة.", AUDIO_DETAILS) ] },
];

export const TOPUP_SECTIONS: TopupSection[] = [
  {
    id: "visual", name: A("شحن التطبيقات المرئية (Visual Apps)"), short: A("مرئية"),
    desc: A("عرض كامل لجميع باقات تطبيقات الشحن المرئي (TikTok, Jaco) مع أداة شحن دقيقة باختيار الباقة فقط."),
    icon: "play", hero: VISUAL_HERO,
    guideTitle: A("📺 دليل الشحن المرئي"),
    guide: [
      A("التطبيقات المشمولة: TikTok و Jaco. اختر التطبيق ليظهر كامل باقاته."),
      A("⚠️ تنبيه هام لاختيار الباقة: يرجى اختيار الباقة المطلوبة مباشرة من القائمة المنسدلة أعلاه. لا يمكن تنفيذ أي طلبات خارج الباقات المحددة."),
      A("تأكد من اختيار الباقة التي تناسب احتياجك بدقة قبل الضغط على «إكمال الشحن»."),
      A("تُصفَّر جميع الحقول تلقائياً بعد نجاح الإرسال لحماية خصوصيتك."),
    ],
    apps: [
      { id: "tiktok", name: A("TikTok 🎵"), short: A("TikTok"), img: TIKTOK_IMG, desc: A("باقات شحن عملات TikTok كاملة — من 50K إلى 1M."), packages:
        tiktokOffers.map(([label, bal, qty, price], i) =>
          PKG("tiktok", `tt${i}`, `TikTok 🎵 ${label}`, bal, qty, price, TIKTOK_IMG,
            `شحن ${bal} إلى حساب TikTok مباشرة.`, VISUAL_DETAILS, i === 0 || i === 6)) },
      { id: "jaco", name: A("Jaco 🟣"), short: A("Jaco"), img: JACO_IMG, desc: A("باقات شحن عملات Jaco كاملة — من 25K إلى 1M."), packages:
        jacoOffers.map(([label, bal, qty, price], i) =>
          PKG("jaco", `jc${i}`, `Jaco 🟣 ${label}`, bal, qty, price, JACO_IMG,
            `شحن ${bal} إلى حساب Jaco مباشرة.`, VISUAL_DETAILS, i === 0 || i === 6)) },
    ],
  },
  {
    id: "audio", name: A("شحن التطبيقات الصوتية (Audio/Live Apps)"), short: A("صوتية"),
    desc: A("الباقة الأولى لكل تطبيق من تطبيقات البث الصوتي التسعة، مع أداة الشحن الذكي الموحدة لحساب أي كمية أكبر تلقائياً."),
    icon: "chat", hero: AUDIO_HERO,
    guideTitle: A("🎧 دليل الشحن الصوتي"),
    guide: [
      A("التطبيقات المشمولة: Bigo Live, Likee, Mico, YoYo, YoHo, Hiyoo, Hiya, Waho, Xena Live."),
      A("⚠️ تنبيه: اختر التطبيق المطلوب، ثم أدخل كمية شحن أكبر من كمية الباقة الأساسية المعروضة للتطبيق. سيتم احتساب السعر تلقائياً بناءً على سعر الباقة الأساسية."),
      A("المعادلة: سعر الوحدة = سعر الباقة ÷ كمية الباقة، ثم السعر الإجمالي = الكمية الجديدة × سعر الوحدة."),
      A("تُصفَّر جميع الحقول تلقائياً بعد نجاح الإرسال لحماية خصوصيتك."),
    ],
    apps: audioApps,
  },
];

export const topupSectionById = (id: string) => TOPUP_SECTIONS.find((s) => s.id === id);

/** الملاحظة الثابتة تحت كل الأقسام */
export const CUSTOM_REQUEST_NOTE: L = A(
  "طلب مخصص: إذا لم تجد التطبيق المطلوب في القائمة، راسل المسؤول فوراً لتحديد التكلفة وتوفير الخدمة. وسيتم شحن التطبيق المطلوب.",
  "Custom request: if your app is not listed, message the manager now to set the price and provide the service.",
);
export const CUSTOM_REQUEST_MESSAGE =
  "مرحباً، لم أجد التطبيق المطلوب في قائمة الشحن. أرغب بطلب شحن مخصص، يرجى تحديد التكلفة وتوفير الخدمة.";

/* ═══════════ رسائل تليجرام ═══════════ */
export function packageOrderMessage(p: TopupPackage, appName: string): string {
  return [
    "⚡ طلب شحن جديد",
    `📱 التطبيق: ${appName}`,
    `📦 الباقة: ${p.name.ar || ""}`,
    `💰 الرصيد: ${p.balance.ar || ""}`,
    `💵 السعر: ${p.priceUsd}$`,
    "الرجاء تزويدي بمحفظة الدفع لإتمام العملية فوراً.",
  ].join("\n");
}

export function visualToolMessage(o: {
  app: string; pkg: string; price: number; user: string; pass: string;
}) {
  return [
    "⚡ طلب شحن مرئي جديد",
    `📱 التطبيق: ${o.app}`,
    `📦 الباقة: ${o.pkg}`,
    `💵 السعر: ${o.price}$`,
    `👤 اليوزر: ${o.user}`,
    `🔑 الباسورد: ${o.pass}`,
    "زودني بالتفاصيل لإنهاء عملية الشحن ومحفظة الدفع.",
  ].join("\n");
}

export function audioToolMessage(o: {
  app: string; qty: number; price: number; id: string; userPass: string;
}) {
  return [
    "⚡ طلب شحن مخصص (كمية أكبر)",
    `📱 التطبيق: ${o.app}`,
    `📦 الكمية المطلوبة: ${o.qty.toLocaleString()}`,
    `💵 السعر المحتسب: ${o.price}$`,
    `🆔 الـ ID: ${o.id}`,
    `👤 اليوزر/الباسورد: ${o.userPass}`,
    "زودني بالتفاصيل لإنهاء عملية الشحن ومحفظة الدفع.",
  ].join("\n");
}

/** سعر الوحدة للباقة الأساسية */
export const unitPrice = (p: TopupPackage) => p.priceUsd / p.qty;

/** رسالة نافذة شحن الباقة الثابتة (TOOL-09) */
export function visualPackageMessage(o: {
  app: string; pkg: string; qty: string; price: number; id: string; pass: string;
}) {
  return [
    "⚡ طلب شحن تطبيق مرئي:",
    `📱 التطبيق: ${o.app}`,
    `📦 الباقة: ${o.pkg}`,
    `📦 الكمية: ${o.qty}`,
    `💵 السعر: ${o.price}$`,
    `🆔 الـ ID: ${o.id}`,
    `👤 الباسورد: ${o.pass}`,
  ].join("\n");
}
