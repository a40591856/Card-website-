/* ─────────────────────────────────────────────────────────────
   BLACK MART · FORUM CLIENT (Zero-Footprint)
   - المسودات: LocalStorage  |  سجل المرفقات: IndexedDB
   - لا قاعدة بيانات مركزية، لا يوزر ظاهر في الواجهة
   - مسح EXIF/GPS/الجهاز/التاريخ قبل أي حفظ
   - تأريخ [YYYY-MM-DD HH:mm:ss] + توجيه tg://msg_url مشفر
   ───────────────────────────────────────────────────────────── */
"use client";

/* ── وسيط مخفي (مشفّر في الكود، لا يظهر نصاً ولا رابطاً في الواجهة) ── */
const RELAY_B64 = "Q2Flc2FyMTJS"; // Caesar12R — لا يُعرض أبداً
const TRACK_B64 = "VHJhY2syXzE="; // Track2_1 — وسيط المقابلات، لا يُعرض أبداً
export const relayHandle = () => atob(RELAY_B64);
export const trackHandle = () => atob(TRACK_B64);

/* ── LocalStorage: المسودات ── */
export type DraftData = Record<string, string>;
const draftKey = (section: string, service: string) => `bm_forum_draft::${section}::${service}`;

export function saveDraft(section: string, service: string, data: DraftData) {
  try {
    localStorage.setItem(draftKey(section, service), JSON.stringify({ data, at: Date.now() }));
  } catch {
    /* noop */
  }
}
export function loadDraft(section: string, service: string): DraftData {
  try {
    const v = localStorage.getItem(draftKey(section, service));
    return v ? (JSON.parse(v).data as DraftData) : {};
  } catch {
    return {};
  }
}
export function clearDraft(section: string, service: string) {
  try {
    localStorage.removeItem(draftKey(section, service));
  } catch {
    /* noop */
  }
}

/* ── IndexedDB: سجل المرفقات بعد المسح (بيانات وصفية فقط) ── */
const DB_NAME = "bm_forum_vault";
const STORE = "attachments";
function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const r = indexedDB.open(DB_NAME, 1);
    r.onupgradeneeded = () => {
      if (!r.result.objectStoreNames.contains(STORE)) r.result.createObjectStore(STORE, { keyPath: "id" });
    };
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}
export interface AttachmentLog {
  id: string;
  originalName: string;
  safeName: string;
  size: number;
  kind: string;
  stripped: boolean;
  at: string;
}
export async function logAttachment(a: AttachmentLog): Promise<void> {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(a);
    await new Promise<void>((res) => {
      tx.oncomplete = () => res();
      tx.onerror = () => res();
    });
  } catch {
    /* IndexedDB غير متاح — التخزين المحلي يكفي */
  }
}

/* ── مسح الميتاداتا (EXIF Stripper) ── */
export interface StrippedFile {
  file: File | null; // ملف نظيف في الذاكرة فقط (لا يُرفع لأي خادم)
  log: AttachmentLog;
}
export async function stripMetadata(input: File): Promise<StrippedFile> {
  const id = `att-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const at = timestamp(false);
  const safeName = input.type.startsWith("image/") ? `clean-${id}.png` : `clean-${id}.bin`;

  // الصور: إعادة رسم عبر Canvas تقضي على EXIF/GPS/الجهاز/التاريخ
  if (input.type.startsWith("image/")) {
    try {
      const bmp = await createImageBitmap(input);
      const c = document.createElement("canvas");
      c.width = bmp.width;
      c.height = bmp.height;
      const ctx = c.getContext("2d");
      if (ctx) ctx.drawImage(bmp, 0, 0);
      bmp.close();
      const blob: Blob | null = await new Promise((res) => c.toBlob(res, "image/png"));
      if (blob) {
        const clean = new File([blob], safeName, { type: "image/png" });
        return {
          file: clean,
          log: { id, originalName: "[REDACTED]", safeName, size: clean.size, kind: input.type, stripped: true, at },
        };
      }
    } catch {
      /* fallthrough */
    }
  }

  // باقي الملفات: إعادة تغليف البايتات باسم مجهول + نوع عام (دون بيانات وصفية)
  try {
    const buf = await input.arrayBuffer();
    const clean = new File([buf], safeName, { type: "application/octet-stream" });
    return {
      file: clean,
      log: { id, originalName: "[REDACTED]", safeName, size: clean.size, kind: input.type || "unknown", stripped: true, at },
    };
  } catch {
    return {
      file: null,
      log: { id, originalName: "[REDACTED]", safeName, size: 0, kind: "blocked", stripped: true, at },
    };
  }
}

/* ── التأريخ الآلي الفوري ── */
export function timestamp(brackets = true): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  const s = `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
  return brackets ? `[${s}]` : s;
}

/** التأريخ بالدقيقة — قالب الطلب الموحد [YYYY-MM-DD HH:mm] */
export function stampMinute(): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

/* ── معرف الإحالة المشفر (Alias Router / Affiliate Hash) ── */
export function affiliateHash(campaign: string): string {
  const seed = `${campaign}::${Date.now()}::${Math.random().toString(36).slice(2)}`;
  let h1 = 0x811c9dc5;
  let h2 = 0x1000193;
  for (let i = 0; i < seed.length; i++) {
    h1 = Math.imul(h1 ^ seed.charCodeAt(i), 16777619) >>> 0;
    h2 = Math.imul(h2 + seed.charCodeAt(i), 2246822519) >>> 0;
  }
  const hex = (h1.toString(16).toUpperCase().padStart(8, "0") + h2.toString(16).toUpperCase().padStart(8, "0")).slice(0, 12);
  const out = `BM-AFF-${hex.slice(0, 4)}-${hex.slice(4, 8)}-${hex.slice(8, 12)}`;
  try {
    localStorage.setItem("bm_affiliate_hash", out);
  } catch {
    /* noop */
  }
  return out;
}
export const savedAffiliateHash = () => {
  try {
    return localStorage.getItem("bm_affiliate_hash") || "";
  } catch {
    return "";
  }
};

/**
 * ═══ القالب الموحد لكل أزرار الإرسال في المنصة ═══
 * Dynamic Payload Title: السطر الأول = [ اسم الخدمة التي اختارها العميل تماماً ]
 * يُستخدم في كل أقسام المنتدى بلا استثناء (ودالة واحدة فقط).
 */
export function buildForumMessage(o: {
  section: string;
  service: string;
  role?: string;
  specialty?: string;
  fields: { label: string; value: string }[];
  hash?: string;
  attachment?: string;
}): string {
  const title = o.service.trim() || "REQUEST";
  const lines = [
    `[ ${title} ]`,
    `[ BLACK MART VERIFIED REQUEST - ${timestamp(false)} ]`,
    "",
    `• اسم الخدمة أو عنوان الطلب: ${title}`,
    `• SECTION: ${o.section}`,
    ...(o.specialty ? [`• SPECIALTY: ${o.specialty}`] : []),
    ...(o.role ? [`• ROLE: ${o.role}`] : []),
    ...(o.hash ? [`• AFFILIATE_HASH: ${o.hash}`] : []),
    ...o.fields.map((f) => `• ${f.label}: ${f.value}`),
    "",
    ...(o.attachment
      ? [`[🔒 تم مسح الميتاداتا وإخفاء المعرفات بنجاح]`, `• ATTACHMENT: ${o.attachment}`, ""]
      : []),
    "--------------------------------------",
    "🔒 ZERO-FOOTPRINT · LOCAL DRAFT ONLY",
    "[SYSTEM_ID: AUTO_GENERATED]",
  ];
  return lines.join("\n");
}

/** الاسم المطلوب في المواصفة — نفس دالة المسح */
export const stripExifData = stripMetadata;

/* ── التوجيه المشفر عبر Deep-Linking (لا يوزر مكشوف) ── */
export function buildRelayLink(message: string, handle: string = relayHandle()): string {
  const target = `https://t.me/${handle}`;
  return `tg://msg_url?url=${encodeURIComponent(target)}&text=${encodeURIComponent(message)}`;
}
export function buildWebFallback(message: string, handle: string = relayHandle()): string {
  return `https://t.me/${handle}?text=${encodeURIComponent(message)}`;
}
/** زر المقابلات المباشر: رسالة جاهزة إلى وسيط المقابلات */
export const MEETING_DIRECT_MESSAGE = "ارغب في تنسيق مقابله";
export const buildTrackLink = (text: string) => buildRelayLink(text, trackHandle());
export const buildTrackWebFallback = (text: string) => buildWebFallback(text, trackHandle());
export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}

/**
 * ═══ التوجيه الموحد لكل أزرار الإرسال ═══
 * 1) نسخ النص احتياطياً لحافظة الهاتف
 * 2) فتح tg:// بحقل جاهز
 * 3) بديل https (يُبنى لحظة الضغط فقط — لا يوزر في DOM)
 */
export async function dispatchToTelegram(message: string, handle: string = relayHandle()) {
  await copyText(message);
  try {
    window.location.href = buildRelayLink(message, handle);
  } catch {
    /* المتصفح قد يحجب tg:// */
  }
  try {
    window.open(buildWebFallback(message, handle), "_blank", "noreferrer");
  } catch {
    /* noop */
  }
}
