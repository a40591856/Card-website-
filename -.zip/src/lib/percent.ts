/* ─────────────────────────────────────────────────────────────
   BLACK MART · PERCENT & AFFILIATE HUB (Zero-Footprint)
   كل النصوص / الحقول / النصائح / الأزرار هنا فقط.
   أضف أو عدّل أي عنصر دون لمس كود الواجهة.
   ───────────────────────────────────────────────────────────── */
import type { L } from "./site";
import type { FieldDef } from "./forum";

const l = (ar: string, en: string, ru?: string): L => (ru ? { ar, en, ru } : { ar, en });

/* ═══ 2 — بطاقة الشرح الرئيسية ═══ */
export const PERCENT_POLICY: L = {
  ar: `🔥 BLACK MART - سوقك الخاص، أرباحك العالمية

انضم إلى فريق نخبـة المروجين في BLACK MART
الآن بإمكان الجميع البدء في جني الأرباح.. سواء كنت مبتدئاً أو محترفاً، نحن نوفر لك المنصة والأدوات، وعليك أنت الذكاء في الترويج!

🛠️ كيف تبدأ رحلتك؟
• راسل مسؤول القناة الآن واطلب تسجيلك كـ "مروج معتمد". سيتم فوراً إنشاء رابط خاص للقناة يحمل اسمك، ليكون هذا الرابط هو بصمتك الخاصة ومصدر أرباحك الحصري.

🔄 آلية العمل (ببساطة):
• رابط الهوية: بمجرد تسجيلك، ستحصل على رابط خاص للقناة باسمك الشخصي.
• مهمتك: ابدأ بنشر رابطك في منصات التواصل (تيك توك، فيسبوك، انستقرام) والمنتديات العربية والأجنبية.
• الربح المباشر: كل شخص يدخل أو يشتري عن طريق رابطك يضمن لك عمولة فورية.
• كشف دوري (كل 5 أيام): لست بحاجة للانتظار؛ كل 5 أيام راسل المسؤول واطلب "كشف الرابط" لمتابعة الإحصائيات والمبيعات أمام عينك.

💸 نظام العمولات والمكافآت
• عمولة ثابتة: احصل على 10% من قيمة كل عملية بيع تتم عبر رابطك.
• خيارات الاستلام: يتم تحويل أرباحك إليك مباشرة، أو يمكنك استبدالها بخدمات وأدوات من الموقع.

🏆 المنافسة الشهرية الكبرى (جرد نهاية الشهر)
في نهاية كل شهر، نقوم بجرد شامل، وأكثر الروابط جذباً للعملاء تفوز بالجوائز التالية:
🥇 المركز الأول: 500 دولار كاش.
🥈 المركز الثاني: 250 دولار كاش.
🥉 المركز الثالث: 100 دولار كاش.
🏅 المركز الرابع والخامس: بطاقة Non-VBV بقيمة 75 دولار.

🛡️ لماذا تعمل معنا؟
✅ حقوقك محفوظة: الرابط يحمل اسمك والجرد يتم بناءً على طلبك.
✅ لا سقف للأرباح: كلما زاد اجتهادك، تضاعفت عمولتك وفرصك في الجوائز.
✅ بدء فوري: لا قيود ولا شروط معقدة، الانطلاقة تبدأ من هذه اللحظة.`,
  en: `🔥 BLACK MART — Your own market, worldwide profits

Join the elite promoters team at BLACK MART
Everyone can start earning now — beginner or pro, we provide the platform and the tools; you bring the intelligence in promotion.

🛠️ How to start?
• Message the channel manager now and ask to register as an "approved promoter". A private channel link carrying your name is created instantly — your own fingerprint and exclusive income source.

🔄 How it works:
• Identity link: once registered you get a private channel link with your personal name.
• Your mission: publish it on social platforms (TikTok, Facebook, Instagram) and Arabic & international forums.
• Direct profit: every person who joins or buys through your link guarantees an instant commission.
• Periodic statement (every 5 days): no waiting — message the manager every 5 days for a "link statement" to see stats and sales.

💸 Commissions & rewards
• Fixed commission: 10% of every sale made through your link.
• Payout options: profits transferred directly, or exchanged for services and tools from the site.

🏆 Monthly grand competition (end-of-month tally)
At the end of every month we run a full tally; the links attracting the most customers win:
🥇 1st: $500 cash.  🥈 2nd: $250 cash.  🥉 3rd: $100 cash.
🏅 4th & 5th: a Non-VBV card worth $75.

🛡️ Why work with us?
✅ Your rights preserved: the link carries your name, and the tally runs on your request.
✅ No profit ceiling: the more you work, the more your commission and prize chances multiply.
✅ Instant start: no restrictions, no complex terms — the launch begins now.`,
  ru: `🔥 BLACK MART — ваш рынок, мировая прибыль
Присоединяйтесь к команде элитных промоутеров BLACK MART.
🛠️ Напишите менеджеру канала и зарегистрируйтесь как «одобренный промоутер» — получите личную ссылку со своим именем.
🔄 Публикуйте ссылку (TikTok, Facebook, Instagram, форумы), получайте комиссию с каждого входа и каждой покупки, запрашивайте отчёт каждые 5 дней.
💸 Фиксированная комиссия 10% · Выплата напрямую или обмен на услуги сайта.
🏆 Итоги месяца: 1-е $500 · 2-е $250 · 3-е $100 · 4–5-е карта Non-VBV на $75.
🛡️ Права защищены · без потолка прибыли · мгновенный старт.`,
};

/* ═══ 1 — تيوب التنقل العلوي ═══ */
export const PERCENT_TOP_TABS: { id: string; label: L }[] = [
  { id: "drain", label: l("لودر التفريغ", "DRAIN & LOADER", "Лодер") },
  { id: "board", label: l("الخدمات التقنية", "SERVICE REQUESTS", "Тех. услуги") },
  { id: "autonomous", label: l("المتخصصين", "SPECIALISTS", "Специалисты") },
  { id: "meetings", label: l("تنسيق المقابلات", "MEETINGS", "Встречи") },
  { id: "percent", label: l("العمل بالنسبة", "PERCENT & AFFILIATE", "Проценты") },
];

/* ═══ 4 — أداة التسجيل ═══ */
export const AFFILIATE_FIELDS: FieldDef[] = [
  { id: "name", label: l("الاسم", "Name", "Имя"), type: "text", ph: l("اكتب اسمك…", "Your name…", "Ваше имя…"), required: true },
  { id: "contact", label: l("البريد الإلكتروني أو يوزر التيليجرام", "Email or Telegram username", "Почта или Telegram"), type: "text", ph: l("name@mail.com / @alias", "name@mail.com / @alias", "name@mail.com / @alias"), required: true },
  { id: "residence", label: l("مكان الإقامة", "Place of residence", "Место проживания"), type: "text", ph: l("الدولة / المدينة…", "Country / City…", "Страна / Город…"), required: true },
  { id: "notes", label: l("ملاحظات", "Notes", "Заметки"), type: "textarea", ph: l("أضف أي ملاحظة للمسؤول…", "Any note for the manager…", "Любая заметка…") },
];

/* ═══ 6 — طلب عمل آخر ═══ */
export const OTHER_WORK_FIELDS: FieldDef[] = [
  { id: "name", label: l("الاسم", "Name", "Имя"), type: "text", ph: l("اكتب اسمك…", "Your name…"), required: true },
  { id: "specialty", label: l("التخصص", "Specialty", "Специальность"), type: "text", ph: l("مثال: تسويق / برمجة / دعم…", "e.g. marketing / dev / support…"), required: true },
  { id: "residence", label: l("مكان الإقامة", "Place of residence", "Место проживания"), type: "text", ph: l("الدولة / المدينة…", "Country / City…"), required: true },
  { id: "experience", label: l("الخبرات التي يملكها", "Your experience", "Ваш опыт"), type: "textarea", ph: l("اشرح خبراتك بالتفصيل…", "Describe your experience in detail…"), required: true },
];

/* ═══ 7 — عمل مخصص ═══ */
export const CUSTOM_WORK_FIELDS: FieldDef[] = [
  { id: "title", label: l("مسمى العمل المخصص", "Custom work title", "Название работы"), type: "text", ph: l("اكتب مسمى العمل…", "Write the work title…"), required: true },
  { id: "details", label: l("تفاصيل العمل", "Work details", "Детали работы"), type: "textarea", ph: l("اشرح العمل المطلوب بالتفصيل…", "Describe the requested work…"), required: true },
];

/* ═══ 5 — نصائح الترويج ═══ */
export const PERCENT_TIPS: { platform: L; text: L }[] = [
  { platform: l("تيك توك", "TikTok"), text: l("انشر مقاطع قصيرة تشرح فكرة المنصة دون كشف أي معرفات، واستهدف التعليقات المهتمة بالتقنية والخدمات الرقمية بالرد المباشر.", "Post short clips explaining the platform without exposing handles; target tech-interested comments with direct replies.") },
  { platform: l("إكس / X", "X / Twitter"), text: l("استخدم threads قصيرة وردوداً على الحسابات المتخصصة في المجال، مع تثبيت رابطك في البايو وتجديد التغريدة كل 5 أيام.", "Use short threads and replies to niche accounts, pin your link in the bio, and refresh the post every 5 days.") },
  { platform: l("يوتيوب", "YouTube"), text: l("ضع الرابط في وصف الفيديوهات التعليمية والشروحات الطويلة، واستهدف قنوات المراجعات التقنية بالتعليقات الهادفة.", "Place the link in descriptions of tutorials and long guides; target tech-review channels with meaningful comments.") },
  { platform: l("تيليجرام", "Telegram"), text: l("روّج داخل القنوات والمنتديات المتخصصة، واطلب كشف الرابط كل 5 أيام لمعرفة أي قناة تجلب أفضل الزوار.", "Promote inside niche channels and forums; request a link statement every 5 days to see which channel converts best.") },
  { platform: l("إنستغرام", "Instagram"), text: l("استخدم القصص والريلز مع عبارة دعوة واضحة، واستهدف التعليقات في الصفحات المتخصصة بدقة دون إزعاج.", "Use stories and reels with a clear call-to-action; target comments on niche pages precisely without spam.") },
  { platform: l("استهداف التعليقات والقنوات", "Comments & niche channels"), text: l("ركز على التعليقات التي تطرح أسئلة حقيقية، وأجب بقيمة قبل وضع الرابط — الجودة أهم من الكمية في جرد نهاية الشهر.", "Focus on comments asking real questions; deliver value before dropping the link — quality beats quantity in the monthly tally.") },
];

/** التحفيز داخل قائمة النصائح */
export const PERCENT_MOTIVATION: L = l(
  "كلما زاد نشاطك وطالت مدة ترويجك، ارتفعت نسبتك فوق الـ 10% تدريجياً، وسيتم تهيئتك لتكون مسؤول بيع أو لتتولى عملاً أفضل داخل الموقع — اجتهادك اليوم هو موقعك غداً.",
  "The more active you are and the longer you promote, the higher your rate climbs above 10% — and you'll be prepared to become a sales manager or take on better work inside the platform. Today's effort is tomorrow's position.",
  "Чем активнее и дольше вы продвигаете, тем выше ваш процент сверх 10% — и вас подготовят к роли менеджера по продажам или более серьёзной работе на платформе.",
);

/* ═══ 7 — شرح كيفية الترويج (تفاصيل إضافية) ═══ */
export const PERCENT_HOWTO: { title: L; text: L }[] = [
  { title: l("الخطوة 1 — التسجيل", "Step 1 — Register"), text: l("املأ أداة التسجيل أدناه واضغط التوجيه للمسؤول؛ تُنسخ الرسالة تلقائياً وتفتح تيليجرام بحقل جاهز، تضغط إرسال فقط.", "Fill the registration tool below and hit the manager button; the message is copied automatically and Telegram opens with a ready field — just press send.") },
  { title: l("الخطوة 2 — استلام رابط الهوية", "Step 2 — Get your identity link"), text: l("ينشئ المسؤول رابطاً خاصاً باسمك. لا تشاركه مع أي طرف آخر؛ هو بصمتك ومصدر أرباحك الحصري.", "The manager creates a private link with your name. Never share it with anyone else — it's your fingerprint and exclusive income source.") },
  { title: l("الخطوة 3 — النشر الذكي", "Step 3 — Smart publishing"), text: l("وزّع الرابط على المنصات والمنتديات المتخصصة، واستهدف التعليقات ذات النية الحقيقية بدل النشر العشوائي.", "Distribute the link across niche platforms and forums; target comments with real intent instead of random blasting.") },
  { title: l("الخطوة 4 — كشف كل 5 أيام", "Step 4 — Statement every 5 days"), text: l("راسل المسؤول كل 5 أيام لطلب كشف الرابط، تابع الإحصائيات، ثم ضاعف التركيز على القنوات الأفضل أداءً قبل جرد نهاية الشهر.", "Message the manager every 5 days for a link statement, review the stats, then double down on the best-performing channels before the monthly tally.") },
];

/** عناوين الرسائل المتحولة */
export const PERCENT_MSG_TITLES = {
  register: l("ارغب في الترويج", "I want to promote", "Хочу продвигать"),
  otherWork: l("يطلب عمل", "Requesting work", "Запрос на работу"),
  customWork: l("عمل مخصص", "Custom work", "Индивидуальная работа"),
};
