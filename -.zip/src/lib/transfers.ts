/* ─────────────────────────────────────────────────────────────
   BLACK MART · MONEY_FLOW_SYSTEM (التحويلات والتبييض)
   كل الأقسام / العروض / الصور / الأسعار / الشروحات / أدوات الطلب هنا فقط.
   أضف عرضاً أو قسماً من هذا الملف دون لمس الواجهة (100% extensible).
   ───────────────────────────────────────────────────────────── */
import type { L } from "./site";

const A = (ar: string, en = ar): L => ({ ar, en });

export interface TField {
  id: string;
  label: L;
  ph: L;
  optional?: boolean;
  options?: L[];
}

export interface TProduct {
  id: string;
  name: L;
  desc: L;
  details: L;
  img: string;
  priceUsd: number;
  oldPriceUsd?: number;
  balance?: L;
  badges: string[];
  featured?: boolean;
}

export type CustomKind = "amex" | "bank" | "ewallet" | "flash";

export interface WalletFields {
  id: string;
  name: L;
  fields: TField[];
}

export interface CustomCfg {
  kind: CustomKind;
  title: L;
  note: L;
  min: number;
  labelMin?: number;   // الحد الأدنى الظاهر في النص التوضيحي
  pricePer1000: number;
  unitLabel: L;
  fields: TField[];
  wallets?: WalletFields[];
  steps?: { title: L; field: TField }[];
  messageTitle: L;
  messageFooter: L;
  submitLabel: L;
  continueLabel: L;
}

export interface TSection {
  id: string;
  short: L;
  name: L;
  desc: L;
  icon: string;
  hero: string;
  techTitle: L;
  tech: L[];
  buyNote: L;
  products: TProduct[];
  custom?: CustomCfg;
}

const P = (
  id: string, ar: string, en: string, descAr: string, descEn: string,
  img: string, price: number, old: number | undefined, detailsAr: string,
  badges: string[], balance?: string, featured?: boolean,
): TProduct => ({
  id, name: A(ar, en), desc: A(descAr, descEn), img, priceUsd: price, oldPriceUsd: old,
  details: A(detailsAr), badges, balance: balance ? A(balance) : undefined, featured,
});

const F = (id: string, ar: string, en: string, ph: string, optional?: boolean): TField => ({
  id, label: A(ar, en), ph: A(ph), optional,
});

/* ═══════════ الشروحات الكاملة ═══════════ */
const AMEX_TECH: L[] = [
  A("الصورة: بطاقة American Express بتصميم معدني فخم. تعتمد الخدمة على بروتوكول «التحويل المباشر» من الحساب إلى الحساب، مع ضمان عدم التتبع أو رصد الأرصدة المحوّلة."),
  A("سيرفر الوسيط (Proxy Gateway): يتم تمرير الطلب عبر سيرفرات سكنية (Residential Proxies) تطابق جغرافية صاحب البطاقة لتجنب تنبيهات Fraud Detection."),
  A("الحقن عبر الجلسة (Session Injection): بدلاً من عملية دفع تقليدية، تُحقن بيانات البطاقة داخل «جلسة» مفعّلة مسبقاً في موقع الهدف، فتبدو المعاملة جزءاً من سجل العميل الأصلي."),
  A("إخفاء الأثر: تعديل التوقيع الرقمي (Digital Fingerprint) للمعاملة لتجاوز أنظمة AVS/CVV دون ترك أثر في سجلات التتبع المركزي."),
  A("[ 💎 بروتوكول حقن American Express 10.1 ] التقنية: حقن مباشر ومشفّر لبيانات البطاقة عبر بروتوكول 10.1 يضمن رفع الرصيد دون اكتشاف النظام الأمني."),
  A("الأمان: قنوات اتصال مشفّرة لا تترك أثراً للعملية، آمنة تماماً ومناسبة للمبالغ الضخمة. الضمان: نتكفل بتجاوز كافة أنظمة الـ Security الخاصة بـ AMEX مع سياسة الاستبدال الفوري عند أي خلل تقني."),
];

const BANK_TECH: L[] = [
  A("الخصوصية: جميع بيانات الحسابات يتم تشفيرها ولا تُخزن في قاعدة بيانات المتجر."),
  A("🛡️ سياسة الصفقات: 1) العمليات الرقمية: تُنفَّذ جميع الصفقات (أقل من 2,000$) رقمياً بالكامل عبر قنواتنا الرسمية بسرعة فائقة وبكل سرية."),
  A("2) المقابلات الشخصية: متاحة فقط للصفقات 2,000$ فما فوق. إثبات الملاءة: فيديو واضح يظهر محفظتك الرقمية ومبلغ الخدمة. التنسيق المسبق مع المسؤول المعتمد لتحديد الموعد والمكان، ولا تُعتمد أي مقابلة بدون حجز مسبق."),
  A("الدول المتوفرة للمقابلة: السعودية «جدة» · أمريكا «تكساس» · روسيا «موسكو» · ألمانيا «برلين»."),
  A("3) بروتوكول التسليم (يوم اللقاء): يلتقي بك مندوبنا المعتمد → تُحوَّل رسوم الخدمة للمحفظة التي يحددها → فور التأكيد يُرسل بيانات حسابك البنكي ويُحوَّل المبلغ كاملاً فوراً → لا يغادر المندوب إلا بعد تأكدك الشخصي من وصول كامل المبلغ."),
  A("⚠️ إخلاء مسؤولية: نحن مسؤولون عن إيصال الأموال لحسابك فقط. أي إجراءات لاحقة تتعلق بطرق صرف الأموال أو غسيلها تقع تحت مسؤوليتك الشخصية والكاملة."),
  A("📜 بروتوكول التحويل البنكي الآمن — التغطية: متاح لكافة البنوك (الخليجية، الأوروبية، والأمريكية). السرية: نظام «الطبقات المتعددة» لإخفاء مصدر التحويل الأصلي، حوالة آمنة 100% للاستقبال الشخصي."),
  A("الضمان: في حال رفض البنك المستلم للحوالة (نادر)، تُرسل حوالة بديلة فوراً من بنك آخر دون رسوم إضافية."),
];

const EWALLET_TECH: L[] = [
  A("الخصوصية: لا يتم تخزين بيانات حسابك؛ نستخدم وسائط تحويل مشفرة لضمان عدم تتبع المصدر."),
  A("الوصف التقني: نرسل أرصدة من حسابات E-wallet تجارية (Business) قديمة ونشطة. الحقن يتم بنظام «الدفع مقابل خدمة» لتخطي نظام الحجز (No Hold) ووصول الأموال مباشرة إلى رصيدك القابل للسحب."),
  A("بدون حجز (No Hold): نرسل الأموال من حسابات موثوقة جداً لدى كل محفظة، فيظهر المبلغ في رصيدك «المتاح» فوراً وليس «المعلق»."),
  A("حماية كاملة: طرق تقنية تمنع استرداد الأموال (Dispute) بعد إرسالها، لضمان بقاء الرصيد في حسابك للأبد."),
  A("طريقة الاستلام: كل ما تحتاجه هو إرسال إيميل حسابك أو رابط المحفظة الخاص بك، وسيتولى فريقنا التنفيذ."),
  A("السرية التامة: بروتوكولات تشفير لإخفاء العلاقة بين حساباتنا وحسابك الشخصي. الشحن خلال 15 دقيقة (15 Min Delivery)."),
];

const FLASH_USDT_TECH: L[] = [
  A("الشرح: خدمة شحن رصيد USDT الفوري إلى محفظتك أو منصة التداول (Binance, Bybit, Trust Wallet, MetaMask). الرصيد قابل للاستخدام في التداول، الألعاب، والمراهنات، ويدعم TRC20 / BEP20 / ERC20 / Solana."),
  A("مواصفات خدمة «فلاش USDT»: أصول الفلاش أدوات تجريبية مخصصة لأغراض محددة ضمن إطار زمني ثابت."),
  A("شبكات النقل: البروتوكولات القياسية TRC20 و BEP20. الاستخدام المعتمد: حصرياً داخل مواقع الرهان والتداول المباشر. دورة الحياة: صلاحية كاملة 70 يوماً من تاريخ الإصدار."),
  A("قيود النظام: غير قابلة للتداول — لا يمكن نقلها لمنصات التبادل المركزي (CEX) أو P2P؛ أي محاولة إدراجها في منصات البيع تؤدي لرفض المعاملة فوراً."),
];

const FLASH_BTC_TECH: L[] = [
  A("الشرح: شحن رصيد البيتكوين (BTC) بشكل فوري ومباشر إلى محفظتك. قابلة للتحويل والتداول، وتصلك مباشرة إلى محفظتك أو منصة التداول بسرعة فائقة."),
  A("شبكة النقل: شبكة البيتكوين الأساسية (Mainnet). مدة الصلاحية: 50 يوماً من تاريخ الإصدار."),
  A("مجال الاستخدام: مخصص حصرياً لمواقع الرهان والتداول المباشر. القيود التقنية: غير قابل للتداول أو البيع عبر P2P، وأي إيداع في منصات التداول المركزية يؤدي لتجميد المعاملة فوراً."),
  A("✅ موثّق (Verified): كل عرض موثّق وجاهز للتنفيذ الفوري."),
];

/* ═══════════ الأقسام الخمسة ═══════════ */
const AMEX_IMG = "https://i.postimg.cc/Kv1gsSmx/1770287724-amex-gold-credit.png";
const BANK_IMG = "https://i.postimg.cc/7YgMNJDW/Screenshot-20260624-040807-Chrome.jpg";
const EWALLET_IMG = "https://i.postimg.cc/Y9Zfd1hN/1782266069309.png";
const USDT_IMG = "https://i.postimg.cc/W3kJbx18/231013-Blog-What-Is-Tether-USDT.webp";
const BTC_IMG = "https://i.postimg.cc/mgpc3TcC/images-(45).jpg";

const amexOffers: [string, number, number, string][] = [
  ["1,000$", 130, 300, "a1"], ["2,000$", 260, 500, "a2"], ["3,000$", 390, 700, "a3"],
  ["7,000$", 910, 1200, "a4"], ["10,000$", 1300, 1500, "a5"], ["13,000$", 1690, 2000, "a6"],
  ["15,000$", 1950, 2500, "a7"], ["20,000$", 2600, 3500, "a8"], ["30,000$", 3900, 5000, "a9"],
];

const bankOffers: [string, number, number, string][] = [
  ["5,000$", 1000, 1200, "b1"], ["10,000$", 2000, 2300, "b2"], ["15,000$", 3000, 3500, "b3"],
  ["20,000$", 4000, 4800, "b4"], ["30,000$", 5500, 6500, "b5"], ["40,000$", 7500, 8800, "b6"],
  ["50,000$", 10000, 12000, "b7"],
];

const walletsList: { id: string; ar: string; en: string; img: string }[] = [
  { id: "paypal", ar: "حقن PayPal", en: "PayPal Injection", img: "https://i.postimg.cc/ZKwywYkm/dx-DDsqfo-P43IAsnrv-Oi8hu6p-C8Bm-Hg-Tn-W2DF95Lv-XN4.jpg" },
  { id: "payoneer", ar: "حقن Payoneer", en: "Payoneer Injection", img: "https://i.postimg.cc/6Qv26d8s/images.png" },
  { id: "payer", ar: "حقن Payer", en: "Payer Injection", img: "https://i.postimg.cc/2SB8nCr4/unnamed.png" },
  { id: "neteller", ar: "حقن Neteller", en: "Neteller Injection", img: "https://i.postimg.cc/x1kqgKyY/images-(21).jpg" },
  { id: "skrill", ar: "حقن Skrill", en: "Skrill Injection", img: "https://i.postimg.cc/7h0jxPzt/images-(44).jpg" },
  { id: "cashapp", ar: "حقن CashApp", en: "CashApp Injection", img: "https://i.postimg.cc/PfzD8z2x/images-(20).jpg" },
  { id: "wise", ar: "حقن Wise", en: "Wise Injection", img: "https://i.postimg.cc/xjWZcQpD/images-(26).jpg" },
  { id: "revolut", ar: "حقن Revolut", en: "Revolut Injection", img: "https://i.postimg.cc/FH9w44HR/images-(43).jpg" },
  { id: "perfectmoney", ar: "حقن Perfect Money", en: "Perfect Money Injection", img: "https://i.postimg.cc/fy2TfLV7/images-(2).png" },
];

const walletRecipientFields: Record<string, TField[]> = {
  paypal: [F("f1", "الإيميل المرتبط بحساب PayPal", "PayPal Email", "name@mail.com"), F("f2", "اسم صاحب الحساب في PayPal", "PayPal account holder", "Full name"), F("f3", "ملاحظة إضافية (شخصي أم تجاري؟)", "Note (personal / business?)", "—", true)],
  payoneer: [F("f1", "الإيميل المرتبط بحساب Payoneer", "Payoneer Email", "name@mail.com"), F("f2", "رقم الـ Payoneer ID", "Payoneer ID", "ID"), F("f3", "ملاحظة إضافية", "Note", "—", true)],
  payer: [F("f1", "رقم حساب Payer (يبدأ بـ P)", "Payer account (starts with P)", "P1234567"), F("f3", "ملاحظة إضافية", "Note", "—", true)],
  neteller: [F("f1", "الإيميل المرتبط بحساب Neteller", "Neteller Email", "name@mail.com"), F("f2", "رقم العضوية (Account ID)", "Account ID", "ID"), F("f3", "ملاحظة إضافية", "Note", "—", true)],
  skrill: [F("f1", "الإيميل المرتبط بحساب Skrill", "Skrill Email", "name@mail.com"), F("f2", "نوع الحساب (شخصي أم تجاري؟)", "Account type", "Personal / Business"), F("f3", "ملاحظة إضافية", "Note", "—", true)],
  cashapp: [F("f1", "الـ $Cashtag الخاص بالحساب", "$Cashtag", "$username"), F("f2", "الاسم الكامل لصاحب الحساب", "Full name", "Full name"), F("f3", "ملاحظة إضافية", "Note", "—", true)],
  wise: [F("f1", "رقم الحساب البنكي (Account Number)", "Account Number", "000123456"), F("f2", "اسم المستلم الكامل", "Full recipient name", "Full name"), F("f3", "نوع الحساب (شخصي أم تجاري؟)", "Account type", "—", true)],
  revolut: [F("f1", "رقم الـ IBAN أو الـ Revtag", "IBAN / Revtag", "revolut / IBAN"), F("f2", "اسم المستخدم", "Username", "Username"), F("f3", "نوع الحساب (شخصي أم تجاري؟)", "Account type", "—", true)],
  perfectmoney: [F("f1", "رقم حساب Perfect Money (Account ID)", "Perfect Money Account ID", "U1234567"), F("f3", "ملاحظة إضافية", "Note", "—", true)],
};

export const TRANSFER_SECTIONS: TSection[] = [
  /* 1 — تحويل American Express (أول قسم) */
  {
    id: "amex", short: A("AMEX"), name: A("تحويل American Express"),
    desc: A("بوابات آمنة لنقل السيولة من حساباتنا إلى حسابك مباشرة بخصومات ضخمة. بطاقة American Express بتصميم معدني فخم وبروتوكول الحقن المباشر 10.1."),
    icon: "card", hero: AMEX_IMG, techTitle: A("💎 بروتوكول حقن American Express 10.1 — الشرح التقني الكامل"), tech: AMEX_TECH,
    buyNote: A("طلب تحويل American Express جديد (Protocol 10.1) - جاهز للدفع عبر (USDT/BTC)."),
    products: amexOffers.map(([amount, price, old, id]) =>
      P(id, `تحويل ${amount} — AMEX Protocol 10.1`, `AMEX Transfer ${amount}`,
        "تحويل مباشر من الحساب إلى الحساب مع ضمان عدم التتبع أو رصد الأرصدة المحوّلة.", "Direct account-to-account transfer with no-trace guarantee.",
        AMEX_IMG, price, old,
        `المبلغ المحوّل: ${amount}. السعر القديم ${old}$ → السعر الحالي ${price}$.\nبروتوكول «التحويل المباشر» مع سيرفر وسيط (Residential Proxies) يطابق جغرافية صاحب البطاقة، وحقن عبر الجلسة (Session Injection)، وتعديل التوقيع الرقمي لتجاوز AVS/CVV دون أثر.\nالأمان: قنوات مشفّرة لا تترك أثراً، مناسبة للمبالغ الضخمة، مع سياسة الاستبدال الفوري عند أي خلل تقني.`,
        ["Anti-Freeze Protection", "Clean Funds"], amount, id === "a5")),
    custom: {
      kind: "amex", title: A("⚙️ طلب حقن مخصص — American Express"),
      note: A("أدخل المبلغ المراد حقنه (الحد الأدنى 1,000$). الحسبة: كل 1,000$ = 130$."),
      min: 1000, pricePer1000: 130, unitLabel: A("USD"),
      fields: [
        F("holder", "اسم صاحب البطاقة", "Cardholder name", "Full name"),
        F("cc", "رقم البطاقة (CC)", "Card number", "3792 **** **** ***"),
        F("exp", "تاريخ الانتهاء + الـ CID", "Expiry + CID", "MM/YY · ****"),
        F("billing", "عنوان الفواتير (Billing Address)", "Billing Address", "Street, City, ZIP"),
      ],
      messageTitle: A("طلب حقن American Express جديد (Protocol 10.1)"),
      messageFooter: A("يرجى تزويدي بمحفظة الدفع لإتمام العملية."),
      submitLabel: A("تأكيد وشراء"), continueLabel: A("متابعة الحقن"),
    },
  },

  /* 2 — التحويلات البنكية */
  {
    id: "bank", short: A("SWIFT/SEPA"), name: A("التحويلات البنكية (SWIFT/SEPA)"),
    desc: A("نظام تحويلات بنكية دولية عبر بروتوكولات SWIFT/SEPA. تُرسل المبالغ من حسابات تجارية موثقة لضمان وصول الأموال كـ «حوالة نظيفة» تماماً، مع تجاوز أنظمة الرقابة البنكية."),
    icon: "swap", hero: BANK_IMG, techTitle: A("🏦 الشرح الكامل — سياسة الصفقات وبروتوكول التحويل"), tech: BANK_TECH,
    buyNote: A("طلب تحويل بنكي - جاهز لإرسال الرسوم عبر (USDT/BTC)."),
    products: bankOffers.map(([amount, price, old, id]) =>
      P(id, `تحويل مبلغ ${amount}`, `Bank Wire ${amount}`,
        "حوالة نظيفة من حساب تجاري موثق إلى حسابك الشخصي عبر SWIFT/SEPA.", "Clean wire from a verified business account via SWIFT/SEPA.",
        BANK_IMG, price, old,
        `قيمة المبلغ الواصل لحسابك: ${amount}. رسوم الخدمة: ${price}$ (بدل ${old}$).\nنظام «الطبقات المتعددة» لإخفاء مصدر التحويل الأصلي. التغطية: كافة البنوك الخليجية والأوروبية والأمريكية.\nالضمان: في حال رفض البنك المستلم للحوالة تُرسل حوالة بديلة فوراً من بنك آخر دون رسوم إضافية. الخصوصية: بيانات الحسابات مشفّرة ولا تُخزن في قاعدة بيانات المتجر.`,
        ["Anti-Freeze Protection", "Clean Funds"], amount, id === "b4")),
    custom: {
      kind: "bank", title: A("🏦 طلب تحويل مخصص (USD فقط)"),
      note: A("أدخل الكمية المطلوبة (الحد الأدنى 1000 وحدة). الحسبة: كل 1000 وحدة = 200 دولار. العملة موحّدة: USD."),
      min: 100, labelMin: 1000, pricePer1000: 200, unitLabel: A("USD"),
      fields: [
        F("name", "اسم صاحب الحساب الكامل", "Full account holder name", "Full name"),
        F("swift", "رمز السويفت كود (SWIFT/BIC Code)", "SWIFT / BIC", "ABCDUS33XXX"),
        F("iban", "رقم الحساب الدولي (IBAN) بالدولار", "IBAN (USD)", "US00 0000 0000 0000"),
        F("bank", "اسم البنك وعنوانه", "Bank name & address", "Bank, Street, City"),
      ],
      messageTitle: A("طلب شراء جديد (تحويل بنكي - USD)"),
      messageFooter: A("زودني بالتفاصيل لإنهاء معاملة التحويل ومحفظة الدفع."),
      submitLabel: A("تأكيد وشراء"), continueLabel: A("متابعة التحويل"),
    },
  },

  /* 3 — حقن PayPal E-wallet */
  {
    id: "ewallet", short: A("E-Wallet"), name: A("حقن PayPal E-wallet"),
    desc: A("نرسل أرصدة من حسابات E-wallet تجارية (Business) قديمة ونشطة. الحقن بنظام «الدفع مقابل خدمة» لضمان تخطي نظام الحجز (No Hold) ووصول الأموال مباشرة إلى رصيدك القابل للسحب."),
    icon: "wallet", hero: EWALLET_IMG, techTitle: A("💳 بروتوكول الحقن الآمن عبر E-wallet — لماذا نحن الأفضل؟"), tech: EWALLET_TECH,
    buyNote: A("أريد طلب رصيد E-wallet - جاهز للدفع."),
    products: walletsList.map((w, i) =>
      P(`w${i}`, w.ar, w.en,
        "رصيد 1,000 يصل إلى محفظتك كرصيد متاح فوراً بدون حجز (No Hold).", "1,000 balance delivered instantly as available funds (No Hold).",
        w.img, 150, 300,
        `المحفظة: ${w.ar}. الرصيد الواصل: 1,000. السعر: 150$ (بدل 300$).\nإرسال من حساب تجاري قديم ونشط بنظام «الدفع مقابل خدمة» لتخطي الحجز (No Hold).\nحماية Anti-Refund تمنع استرداد الأموال (Dispute). طريقة الاستلام: إيميل حسابك أو رابط المحفظة فقط. السرية: بروتوكولات تشفير تخفي العلاقة بين حساباتنا وحسابك. التنفيذ خلال 15 دقيقة.`,
        ["Anti-Refund System", "15 Min Delivery"], "1,000", i === 0)),
    custom: {
      kind: "ewallet", title: A("💳 الطلب المخصص — حقن المحافظ الإلكترونية"),
      note: A("اختر المحفظة، ثم أدخل الكمية (الحد الأدنى 1000 وحدة). الحسبة: كل 1000 وحدة = 150 دولار (USD فقط)."),
      min: 100, labelMin: 1000, pricePer1000: 150, unitLabel: A("USD"),
      fields: [F("email", "إيميل الحساب", "Account email", "name@mail.com"), F("name", "اسم الحساب", "Account name", "Full name"), F("notes", "ملاحظات", "Notes", "—", true)],
      wallets: walletsList.map((w) => ({ id: w.id, name: A(w.ar.replace("حقن ", ""), w.en.replace(" Injection", "")), fields: walletRecipientFields[w.id] })),
      messageTitle: A("طلب شراء جديد (تحويل - USD)"),
      messageFooter: A("زودني بالتفاصيل لإنهاء معاملة التحويل ومحفظة الدفع."),
      submitLabel: A("تأكيد وشراء"), continueLabel: A("متابعة الحقن"),
    },
  },

  /* 4 — Flash USDT */
  {
    id: "usdt", short: A("Flash USDT"), name: A("تحويل Flash USDT"),
    desc: A("خدمة شحن رصيد USDT الفوري إلى محفظتك أو منصة التداول (Binance, Bybit, Trust Wallet, MetaMask). يدعم TRC20 / BEP20 / ERC20 / Solana. ✅ موثّق."),
    icon: "coin", hero: USDT_IMG, techTitle: A("⚡ مواصفات خدمة Flash USDT — أصول الفلاش"), tech: FLASH_USDT_TECH,
    buyNote: A("أريد شراء Flash USDT - جاهز للدفع عبر (USDT/BTC)."),
    products: [1000, 2000, 3000, 4000, 5000].map((qty, i) =>
      P(`u${i}`, `${qty.toLocaleString()} USDT — Flash`, `Flash ${qty.toLocaleString()} USDT`,
        "رصيد USDT فوري قابل للاستخدام في التداول، الألعاب، والمراهنات.", "Instant USDT usable for trading, gaming, and betting.",
        USDT_IMG, qty / 20, undefined,
        `الكمية: ${qty.toLocaleString()} USDT. السعر: ${qty / 20}$. صلاحية كاملة 70 يوماً من تاريخ الإصدار.\nشبكات النقل: TRC20 و BEP20 (و ERC20 / Solana للعروض العامة). الاستخدام المعتمد: حصرياً داخل مواقع الرهان والتداول المباشر.\n⚠️ قيود النظام: غير قابلة للتداول — لا يمكن نقلها إلى منصات CEX أو P2P، وأي محاولة بيع تؤدي لرفض المعاملة فوراً.`,
        ["Verified", "70 DAYS"], `${qty.toLocaleString()} USDT`, qty === 5000)),
    custom: {
      kind: "flash", title: A("⚡ طلب كمية مخصصة — Flash USDT"),
      note: A("أقل كمية للطلب هي 1000 وحدة. كل 1000 وحدة = 50 دولار (USD فقط)."),
      min: 1000, pricePer1000: 50, unitLabel: A("USDT"),
      fields: [],
      steps: [
        { title: A("النافذة 1 — اختيار المنصة"), field: { id: "platform", label: A("المنصة", "Platform"), ph: A("—"), options: [A("Binance Wallet Exchange"), A("Trust Wallet")] } },
        { title: A("النافذة 2 — شبكة الاستلام"), field: { id: "network", label: A("شبكة الاستلام", "Network"), ph: A("—"), options: [A("BEP20 Binance Chain"), A("TRC20 Tron Network")] } },
        { title: A("النافذة 3 — عنوان المحفظة"), field: F("address", "عنوان محفظة الاستلام", "Wallet address", "T… / 0x…") },
      ],
      messageTitle: A("أريد شراء كمية مخصصة من Flash USDT"),
      messageFooter: A("يرجى إرسال محفظة الدفع لإتمام العملية."),
      submitLabel: A("شراء"), continueLabel: A("تأكيد الكمية"),
    },
  },

  /* 5 — Flash Bitcoin */
  {
    id: "btc", short: A("Flash BTC"), name: A("تحويل Flash Bitcoin"),
    desc: A("شحن رصيد البيتكوين (BTC) بشكل فوري ومباشر إلى محفظتك. قابل للتحويل والتداول، يصلك مباشرة إلى محفظتك أو منصة التداول بسرعة فائقة. ✅ موثّق."),
    icon: "coin", hero: BTC_IMG, techTitle: A("₿ مواصفات خدمة Flash Bitcoin"), tech: FLASH_BTC_TECH,
    buyNote: A("أريد شراء Flash Bitcoin بالكمية المختارة - جاهز للدفع عبر (USDT/BTC)."),
    products: [["0.5 BTC", 99], ["1 BTC", 180], ["2 BTC", 350], ["4 BTC", 500], ["5 BTC", 550], ["10 BTC", 999]].map(([label, price], i) =>
      P(`bt${i}`, `${label} — Flash`, `Flash ${label}`,
        "رصيد BTC فوري على شبكة Mainnet، صلاحية 50 يوماً.", "Instant BTC on Mainnet, 50-day validity.",
        BTC_IMG, price as number, undefined,
        `الكمية: ${label}. السعر: ${price}$. شبكة النقل: Bitcoin Mainnet. مدة الصلاحية: 50 يوماً من تاريخ الإصدار.\nمجال الاستخدام: حصرياً لمواقع الرهان والتداول المباشر.\n⚠️ القيود التقنية: غير قابل للتداول أو البيع عبر P2P، وأي إيداع في منصات التداول المركزية يؤدي لتجميد المعاملة فوراً.`,
        ["Verified", "50 DAYS"], label as string, i === 5)),
  },
];

export const transferSectionById = (id: string) => TRANSFER_SECTIONS.find((s) => s.id === id);

/* زر «استكشف باقي الخدمات» — قائمة انزلاقية */
export const EXPLORE_ITEMS: { id: string; label: L; route: string; icon: string }[] = [
  { id: "cards", label: A("البطاقات المحقونة", "Injected Cards"), route: "/market/cards", icon: "card" },
  { id: "transfer", label: A("التحويلات والتبييض", "Transfers"), route: "/market/transfer", icon: "swap" },
  { id: "injection", label: A("حقن الحسابات", "Account Injection"), route: "/market/injection", icon: "code" },
  { id: "accounts", label: A("الحسابات المستعارة", "Borrowed Accounts"), route: "/market/accounts", icon: "user" },
  { id: "gifts", label: A("بطاقات الهدايا", "Gift Cards"), route: "/market/gifts", icon: "gift" },
  { id: "topup", label: A("شحن التطبيقات", "App Top-Ups"), route: "/market/topup", icon: "play" },
  { id: "proxy", label: A("البروكسي والتشفير", "Proxy & Encryption"), route: "/market/proxy", icon: "shield" },
];

/* زر «حقن خدمات أخرى» في صفحة AMEX */
export const OTHER_SERVICES: { id: string; label: L }[] = [
  { id: "wallets", label: A("محافظ إلكترونية", "E-Wallets") },
  { id: "gifts", label: A("بطاقات هدايا", "Gift Cards") },
  { id: "bank", label: A("تحويلات بنكية أخرى", "Other bank transfers") },
];

/* ═══════════ القالب الموحد + الرسائل المخصصة ═══════════ */
export function orderMessage(name: string, price: number, extra?: string[]): string {
  return [
    "[🚨 طلب شراء جديد - BLACK MART]",
    "--------------------------------------",
    `💳 الخدمة المطلوبة: ${name}`,
    `💰 القيمة: ${price}$`,
    "--------------------------------------",
    "📝 نص الطلب: ",
    `أريد شراء ${name}. يرجى تزويدي بمحافظ الدفع المتاحة والتعليمات المطلوبة لإتمام المعاملة.`,
    ...(extra ?? []),
    "--------------------------------------",
    "[SYSTEM_ID: AUTO_GENERATED]",
  ].join("\n");
}

export function customOrderMessage(o: {
  cfg: CustomCfg;
  section: TSection;
  qty: number;
  price: number;
  walletName?: string;
  values: Record<string, string>;
}): string {
  const lines = [
    "[🚨 طلب شراء جديد - BLACK MART]",
    "--------------------------------------",
    `💳 الخدمة المطلوبة: ${o.cfg.messageTitle.ar}${o.walletName ? ` — ${o.walletName}` : ""}`,
    `💰 القيمة: ${o.price}$`,
    "--------------------------------------",
    `📊 الكمية المطلوبة: ${o.qty.toLocaleString()} ${o.cfg.unitLabel.ar}`,
    `💵 المبلغ المستحق: ${o.price} دولار`,
  ];

  if (o.cfg.kind === "amex") {
    lines.push("📝 بيانات البطاقة:");
    for (const f of o.cfg.fields) lines.push(`• ${f.label.ar}: ${o.values[f.id] || "—"}`);
  } else if (o.cfg.kind === "bank") {
    lines.push("📝 بيانات التحويل:");
    for (const f of o.cfg.fields) lines.push(`• ${f.label.ar}: ${o.values[f.id] || "—"}`);
  } else if (o.cfg.kind === "ewallet") {
    lines.push(`📝 بيانات مستلم ${o.walletName ?? "المحفظة"}:`);
    const wf = o.cfg.wallets?.find((w) => w.name.ar === o.walletName || w.name.en === o.walletName)?.fields ?? o.cfg.fields;
    for (const f of wf) lines.push(`• ${f.label.ar}: ${o.values[f.id] || "—"}`);
  } else {
    lines.push("📝 تفاصيل الاستلام:");
    for (const s of o.cfg.steps ?? []) lines.push(`• ${s.field.label.ar}: ${o.values[s.field.id] || "—"}`);
  }
  lines.push("--------------------------------------", o.cfg.messageFooter.ar ?? "", "[SYSTEM_ID: AUTO_GENERATED]");
  return lines.join("\n");
}
