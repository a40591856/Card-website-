import type { Lang } from "./i18n";

/* أنواع صفوف قاعدة البيانات (مطابقة لـ src/db/schema.ts) */
export interface ProductRow {
  id: number;
  slug: string;
  nameAr: string;
  nameEn: string;
  nameRu: string;
  descAr: string;
  descEn: string;
  descRu: string;
  catId: string;
  branchId: string;
  tag: string;
  img: string | null;
  priceUsd: number;
  oldPriceUsd: number;
  balanceUsd: number;
  verified: boolean;
  featured: boolean;
  views: number;
  orders: number;
  active: boolean;
}

export interface RatingRow {
  id: number;
  name: string;
  stars: number;
  text: string;
  status: string;
  createdAt: string;
}

export interface OpinionRow {
  id: number;
  name: string;
  kind: string;
  text: string;
  status: string;
  createdAt: string;
}

export interface NotificationRow {
  id: number;
  kind: string;
  titleAr: string;
  titleEn: string;
  titleRu: string;
  bodyAr: string;
  bodyEn: string;
  bodyRu: string;
  active: boolean;
  createdAt: string;
}

export interface MemberRow {
  id: string;
  name: string;
  passHash: string;
  createdAt: string;
  lastSeen: string;
}

export interface OrderRow {
  id: number;
  owner: string;
  productId: number;
  qty: number;
  totalUsd: number;
  status: string;
  createdAt: string;
}

/* مساعدات تسمية متعددة اللغات */
export const pName = (p: ProductRow, lang: Lang) =>
  lang === "ar" ? p.nameAr : lang === "ru" ? p.nameRu : p.nameEn;
export const pDesc = (p: ProductRow, lang: Lang) =>
  lang === "ar" ? p.descAr : lang === "ru" ? p.descRu : p.descEn;
export const nTitle = (n: NotificationRow, lang: Lang) =>
  lang === "ar" ? n.titleAr : lang === "ru" ? n.titleRu : n.titleEn;
export const nBody = (n: NotificationRow, lang: Lang) =>
  lang === "ar" ? n.bodyAr : lang === "ru" ? n.bodyRu : n.bodyEn;

export const fmtDate = (iso: string, lang: Lang) => {
  try {
    return new Date(iso).toLocaleDateString(
      lang === "ar" ? "ar" : lang === "ru" ? "ru" : "en",
      { year: "numeric", month: "2-digit", day: "2-digit" },
    );
  } catch {
    return iso;
  }
};
