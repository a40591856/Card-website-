/* ─────────────────────────────────────────────────────────────
   BLACK MART · DIGITAL_BANK_VAULT (الحسابات المستعارة)
   كل الأقسام / المنتجات / الصور / الأسعار / الشروحات / الدول هنا فقط.
   الواجهة تقرأ القوائم تلقائياً — التوسعة 100%.
   ───────────────────────────────────────────────────────────── */
import type { L } from "./site";

const A = (ar: string, en = ar): L => ({ ar, en });

export interface AccountProduct {
  id: string;
  name: L;
  desc: L;
  details: L;
  img: string;
  priceUsd: number;
  oldPriceUsd?: number;
  credit?: L;
  balance?: L;
  badges: string[];
  featured?: boolean;
}

export interface AccountSection {
  id: string;
  short: L;
  name: L;
  desc: L;
  icon: string;
  hero: string;
  deliveryTitle: L;
  delivery: L[];
  buyNote: L;
  products: AccountProduct[];
}

const P = (
  id: string, ar: string, en: string, descAr: string, descEn: string,
  img: string, priceUsd: number, oldPriceUsd: number | undefined,
  detailsAr: string, badges: string[], credit?: string, featured?: boolean,
): AccountProduct => ({
  id, name: A(ar, en), desc: A(descAr, descEn), img, priceUsd, oldPriceUsd,
  details: A(detailsAr), badges, credit: credit ? A(credit) : undefined, featured,
});

/* ═══════════ شروحات التسليم المشتركة ═══════════ */
const FULL_CONTROL: L[] = [
  A("تفويض كامل للتحكم بالحساب."),
  A("بيانات الداشبورد (لوحة التحكم) كاملة."),
  A("بيانات المالك كاملة."),
  A("وصول كامل لرقم الهاتف والبريد الإلكتروني المرتبطين."),
];

const BANK_DOCS: L[] = [
  A("بيانات الدخول: الإيميل، الباسورد، كود الـ 2FA، ورقم الهاتف الافتراضي المرتبط."),
  A("الوثائق الثبوتية: صور الهوية أو جواز السفر المستخدمة لفتح وتوثيق الحساب."),
  A("بيانات الـ IBAN: رقم الحساب الدولي وكود السويفت (SWIFT Code)."),
  A("دليل الاستخدام الآمن: شرح فيديو للدخول عبر (Proxy/VPN) لضمان عدم تجميد الحساب."),
];

const EXCHANGE_DOCS: L[] = [
  A("ملف البيانات: Email Access + Password + 2FA Secret Key."),
  A("ملف الهوية (Full Docs): صور جواز السفر أو الهوية التي تم بها تفعيل الحساب."),
  A("الضمان: دخول ناجح للحساب مع تعليمات الدخول عبر Static IP لتجنب الحظر."),
  A("الدعم: مساعدتك في ربط الحساب بمحفظتك الباردة أو تفعيل السحب الفوري."),
];

const WALLET_DOCS: L[] = [
  A("بيانات الدخول الشخصية: إيميل المحفظة، كلمة المرور، وأسئلة الأمان."),
  A("الرقم الافتراضي: الوصول لرقم الهاتف المرتبط لاستقبال أكواد التحقق (OTP)."),
  A("الوثائق المرفقة: صور الهوية أو المستندات المستخدمة في التوثيق لضمان الملكية."),
  A("دليل التخفي: شرح فيديو للدخول عبر (SOCKS5/Proxy) لحماية الحساب من الإغلاق."),
];

const COMMS_DOCS: L[] = [
  A("إيميلات قديمة (Aged): موثوقية عالية لدى Google والمنصات، تمنع الإغلاق الفوري."),
  A("أرقام تفعيل حقيقية: وصول دائم للأرقام لاستلام أكواد التحقق في أي وقت."),
  A("خصوصية تامة: جميع الحسابات منشأة عبر بروتوكولات Clean IP دون ربط بنشاط سابق."),
  A("بكجات Recovery وأسئلة الأمان مع كل حساب لضمان الملكية الكاملة."),
];

const SOCIAL_DOCS: L[] = [
  A("تجاوز الحظر: إرسال الرسائل والنشر بكثافة أكبر دون إغلاق الحساب فوراً."),
  A("الموثوقية: الحساب القديم يعطي انطباعاً بالاحترافية والصدق لعملائك."),
  A("الوصول الكامل: الإيميل الأساسي المرتبط (OG Email) لملكية 100% مدى الحياة."),
  A("جلسات Session جاهزة مع حماية ثنائية وتاريخ نشاط حقيقي."),
];

const GATEWAY_DOCS: L[] = [
  A("الموثوقية (Trust Score): تاريخ مالي ونقاط ثقة عالية لتجاوز أنظمة الرقابة."),
  A("التوثيق الكامل: كافة أوراق التوثيق (KYC) لضمان ملكيتك الكاملة."),
  A("العمر الرقمي: نشاط مسبق يمنح الحساب قوة أكبر من الحسابات الحديثة."),
  A("الدعم الفني: دليل خاص لتغيير إعدادات الأمان (البريد، الهاتف، كلمة السر) فور الاستلام."),
];

const AMEX_DOCS: L[] = [
  A("تسليم ملف بيانات كامل ومشفّر لفتح التطبيق."),
  ...FULL_CONTROL,
  A("يتيح لك التحويل، الاستقبال، وربط البطاقة بكل سهولة في أي بوابة دفع عالمية."),
  A("دليل التهيئة الفنية: بيئة آمنة، بصمة الجهاز، وبروتوكول التشغيل المعتمد."),
];

/* ═══════════ الأقسام السبعة ═══════════ */
export const ACCOUNT_SECTIONS: AccountSection[] = [
  /* 1 — American Express (النخبوي، في المقدمة) */
  {
    id: "amex", short: A("AMEX"), name: A("حسابات American Express"),
    desc: A("حسابات أمريكان إكسبريس النخبوية ببروتوكول 10.1 — وصول كامل للتطبيق، تفويض شامل، وحدود ائتمانية ضخمة."),
    icon: "card", hero: "https://i.postimg.cc/wMyTFzD9/Screenshot-20260624-033422-Google.jpg",
    deliveryTitle: A("💎 صندوق الضمانات — ماذا تستلم مع كل حساب AMEX؟"),
    delivery: AMEX_DOCS,
    buyNote: A("مرحباً، أريد طلب حساب American Express بقيمة محددة - أنا جاهز للدفع عبر (USDT/BTC)."),
    products: [
      P("am1", "AMEX Individual Personal - Protocol 10.1", "AMEX Individual Personal - Protocol 10.1",
        "حساب فردي (Individual) موثق بالكامل للتعاملات الشخصية بالدولار.", "Fully verified individual account for personal USD transactions.",
        "https://i.postimg.cc/RFGn2v3w/images-(30).jpg", 250, undefined,
        `[ 💎 حساب فردي - أفراد ]
حساب مصمم للتعاملات الشخصية اليومية بمميزات النخبة.
• البروتوكول: 10.1 المطور.
• الحد الائتماني: 100,000$.
• المحتويات: تسليم ملف بيانات كامل لفتح التطبيق.
• تفويض كامل للتحكم بالحساب.
• بيانات الداشبورد (لوحة التحكم) كاملة.
• بيانات المالك كاملة.
• وصول كامل لرقم الهاتف والبريد الإلكتروني المرتبطين.
• يتيح لك التحويل، الاستقبال، وربط البطاقة بكل سهولة.
• الاستخدام: مثالي لمن يحتاج حساب أمريكان إكسبريس آمن وسريع.`,
        ["PRO_PROTOCOL_10.1", "VERIFIED"], "$100,000", true),
      P("am2", "AMEX Business Classic - Protocol 10.1", "AMEX Business Classic - Protocol 10.1",
        "حساب أعمال (Classic) موثق للأعمال الناشئة والمشاريع.", "Verified business account for startups and projects.",
        "https://i.postimg.cc/Kv1gsSmx/1770287724-amex-gold-credit.png", 550, undefined,
        `[ 🎖️ حساب أعمال - Classic ]
حساب تجاري مخصص لفئة الأعمال الكلاسيكية، يجمع بين الموثوقية والسهولة.
• البروتوكول: 20.1 المطور.
• الحد الائتماني: 10,000,000$.
• المحتويات: تسليم ملف بيانات كامل لفتح التطبيق.
• تفويض كامل للتحكم بالحساب.
• بيانات الداشبورد (لوحة التحكم) كاملة.
• بيانات المالك كاملة.
• وصول كامل لرقم الهاتف والبريد الإلكتروني المرتبطين.
• يتيح لك التحويل، الاستقبال، وربط البطاقة في أي بوابة دفع عالمية.`,
        ["PRO_PROTOCOL_10.1", "VERIFIED"], "$10,000,000"),
      P("am3", "AMEX Platinum Corporate - Protocol 10.1", "AMEX Platinum Corporate - Protocol 10.1",
        "حساب شركات (Platinum) للنخبة وأصحاب الأعمال الضخمة.", "Platinum corporate account for high-volume operations.",
        "https://i.postimg.cc/yY23MQNy/images-(31).jpg", 3000, undefined,
        `[ 👑 حساب شركات - Platinum ]
أعلى فئة من حسابات أمريكان إكسبريس، مصممة لأصحاب الأعمال الذين يتطلب عملهم سيولة عالية وقدرات تحويل استثنائية.
• الحد الائتماني: 100,000,000$.
• البروتوكول: 10.1 المطور.
• المحتويات: تسليم ملف بيانات كامل ومشفّر لفتح التطبيق.
• تفويض كامل للتحكم بالحساب.
• بيانات الداشبورد (لوحة التحكم) كاملة.
• بيانات المالك كاملة.
• وصول كامل لرقم الهاتف والبريد الإلكتروني المرتبطين.
• يتيح لك التحويل والاستقبال بمبالغ ضخمة مع صلاحيات كاملة لربط البطاقة وإدارة العمليات التجارية.`,
        ["PRO_PROTOCOL_10.1", "VERIFIED"], "$100,000,000", true),
    ],
  },

  /* 2 — الحسابات البنكية (IBAN) */
  {
    id: "iban", short: A("IBAN"), name: A("الحسابات البنكية (IBAN)"),
    desc: A("وصول كامل إلى حسابات بنكية رقمية وعالمية موثقة بهويات حقيقية (KYC Verified). رقم IBAN مخصص، تفويض كامل، بيانات الداشبورد والمالك، ووصول للهاتف والبريد المرتبطين لاستقبال وإرسال الحوالات (SWIFT/SEPA) بسرية تامة."),
    icon: "shield", hero: "https://i.postimg.cc/sXPtrNyM/1782262248095.png",
    deliveryTitle: A("🔐 الخصوصية المالية المطلقة — ملف مشفر يحتوي على"),
    delivery: BANK_DOCS,
    buyNote: A("أريد شراء حساب بنك موثق من نوع محدد - جاهز للدفع عبر (USDT/BTC)."),
    products: [
      P("ib1", "حساب بنك Wise (أوروبي + أمريكي)", "Wise Bank (EU + US)", "حساب Wise متعدد العملات موثق بالكامل مع IBAN أوروبي وأمريكي.", "Fully verified multi-currency Wise account.", "https://i.postimg.cc/xjWZcQpD/images-(26).jpg", 180, 250,
        "حساب Wise متعدد العملات: IBAN أوروبي + حساب أمريكي، توثيق KYC كامل، بيانات الدخول والداشبورد، بيانات المالك، الهاتف والبريد المرتبطين، وكود SWIFT للحوالات الدولية.", ["FULL_DOCS_INCLUDED", "IBAN_READY"], "MULTI-IBAN"),
      P("ib2", "حساب بنك Revolut (Business)", "Revolut (Business)", "حساب أعمال Revolut موثق بحدود مرتفعة وجاهز للتحويلات.", "Verified Revolut Business account with high limits.", "https://i.postimg.cc/26g0bdwK/images-(27).jpg", 350, 450,
        "حساب Revolut Business: لوحة تحكم كاملة، بيانات المالك والوثائق، IBAN وSWIFT، وصول للهاتف والبريد المرتبطين، وتفويض كامل للتحكم.", ["FULL_DOCS_INCLUDED", "IBAN_READY"], "BUSINESS"),
      P("ib3", "حساب بنك Payoneer (مع بطاقة)", "Payoneer (with card)", "حساب Payoneer موثق مع بطاقة مرتبطة وجاهز للاستلام.", "Verified Payoneer account with linked card.", "https://i.postimg.cc/zXZdqj3Z/images-(28).jpg", 150, 200,
        "حساب Payoneer مع بطاقة: بيانات الدخول، وثائق التوثيق، بيانات الحساب البنكي للاستلام، الهاتف والبريد المرتبطين، وتفويض كامل.", ["FULL_DOCS_INCLUDED", "IBAN_READY"], "CARD LINKED"),
      P("ib4", "حساب بنك نيو (NeoBank) خليجي", "NeoBank (Gulf)", "بنك رقمي خليجي موثق بصلاحيات كاملة وحدود عالية.", "Verified Gulf neo-bank with full permissions.", "https://i.postimg.cc/dVJ4yV8G/images-(29).jpg", 450, 600,
        "NeoBank خليجي: IBAN محلي ودولي، بيانات الداشبورد، بيانات المالك والوثائق، رقم الهاتف والبريد، ودليل الدخول الآمن عبر Proxy.", ["FULL_DOCS_INCLUDED", "IBAN_READY"], "GULF"),
      P("ib5", "حساب بنك Zil (للشركات الأمريكية)", "Zil (US Companies)", "حساب Zil مخصص للشركات الأمريكية مع تحكم كامل.", "Zil account for US companies with full control.", "https://i.postimg.cc/HLh2R0fD/images-(6).png", 650, 800,
        "Zil للأعمال الأمريكية: حساب تجاري موثق، بيانات الدخول والـ 2FA، وثائق الشركة والمالك، ACH/ routing number، ودليل الاستخدام الآمن.", ["FULL_DOCS_INCLUDED", "IBAN_READY"], "US BUSINESS"),
      P("ib6", "حساب بنك Dukascopy (سويسري)", "Dukascopy (Swiss)", "حساب بنكي سويسري موثق بسرية عالية.", "Swiss verified bank account with high privacy.", "https://i.postimg.cc/5NSmbWZK/open-Bank-2-1.jpg", 250, 350,
        "Dukascopy السويسري: IBAN سويسري، كود SWIFT، بيانات الدخول والداشبورد، وثائق KYC، بيانات المالك، والهاتف والبريد المرتبطين.", ["FULL_DOCS_INCLUDED", "IBAN_READY"], "SWISS IBAN"),
      P("ib7", "حساب American Express (101/201)", "American Express (101/201)", "وصول كامل لتطبيق AMEX مع شريحة رقمية وبروتوكول 10.1/20.1.", "Full AMEX app access with digital chip.", "https://i.postimg.cc/wjWcRcx5/images-(7).png", 150, 250,
        "حساب American Express 101/201: وصول كامل للتطبيق + شريحة رقمية، ملف بيانات لفتح التطبيق، تفويض كامل، بيانات الداشبورد والمالك، والهاتف والبريد المرتبطين.", ["FULL_DOCS_INCLUDED", "IBAN_READY"], "PROTOCOL 10.1"),
    ],
  },

  /* 3 — المحافظ الإلكترونية */
  {
    id: "wallets", short: A("المحافظ"), name: A("المحافظ الإلكترونية"),
    desc: A("محافظ إلكترونية دولية موثقة (Verified) وجاهزة للاستخدام الفوري، مربوطة بأرقام هواتف افتراضية دائمة وهويات حقيقية. مثالية لاستقبال الأرباح وشحن التطبيقات بصمت."),
    icon: "wallet", hero: "https://i.postimg.cc/vZH8S5rT/Screenshot-20260624-034445-Google.jpg",
    deliveryTitle: A("📱 المرونة المالية في جيبك — باقة الوصول الكاملة"),
    delivery: WALLET_DOCS,
    buyNote: A("أريد شراء محفظة موثقة وجاهزة - أنا جاهز للدفع عبر (USDT/BTC)."),
    products: [
      P("w1", "محفظة CashApp (موثقة بـ SSN)", "CashApp (SSN Verified)", "محفظة CashApp موثقة بـ SSN وجاهزة للاستلام الفوري.", "SSN-verified CashApp wallet.", "https://i.postimg.cc/PfzD8z2x/images-(20).jpg", 100, 150,
        "CashApp موثقة بـ SSN: إيميل وباسورد، أسئلة الأمان، رقم الهاتف الافتراضي لاستقبال OTP، وثائق التوثيق، ودليل الدخول عبر SOCKS5.", ["PHONE_LINKED", "NO_LIMIT_TRANSFER"], "$1,000", true),
      P("w2", "محفظة PayPal (شخصي - موثق)", "PayPal (Personal Verified)", "حساب PayPal شخصي موثق بحدود مرتفعة.", "Verified personal PayPal account.", "https://i.postimg.cc/ZKwywYkm/dx-DDsqfo-P43IAsnrv-Oi8hu6p-C8Bm-Hg-Tn-W2DF95Lv-XN4.jpg", 70, 100,
        "PayPal شخصي موثق: بيانات الدخول، البطاقة/البنك المربوط، وثائق KYC، رقم الهاتف المرتبط، ودليل التخفي عبر Proxy.", ["PHONE_LINKED", "NO_LIMIT_TRANSFER"]),
      P("w3", "محفظة Payoneer (جاهزة للاستلام)", "Payoneer (Ready)", "محفظة Payoneer جاهزة لاستقبال الحوالات فوراً.", "Payoneer wallet ready to receive.", "https://i.postimg.cc/6Qv26d8s/images.png", 130, 180,
        "Payoneer جاهزة: بيانات الدخول والداشبورد، بيانات الحساب البنكي للاستلام، وثائق التوثيق، والهاتف والبريد المرتبطين.", ["PHONE_LINKED", "NO_LIMIT_TRANSFER"]),
      P("w4", "محفظة Skrill (High Limit)", "Skrill (High Limit)", "محفظة Skrill بحدود مرتفعة وتوثيق كامل.", "High-limit fully verified Skrill wallet.", "https://i.postimg.cc/ZnV0sHMp/images-(1).png", 90, 120,
        "Skrill High Limit: بيانات الدخول، وثائق KYC، رقم الهاتف المرتبط، حدود تحويل مرتفعة، ودليل الاستخدام الآمن.", ["PHONE_LINKED", "NO_LIMIT_TRANSFER"]),
      P("w5", "محفظة Neteller (Verified)", "Neteller (Verified)", "محفظة Neteller موثقة وجاهزة للتحويل.", "Verified Neteller wallet.", "https://i.postimg.cc/x1kqgKyY/images-(21).jpg", 90, 120,
        "Neteller Verified: بيانات الدخول وأسئلة الأمان، وثائق التوثيق، رقم الهاتف، ودليل الدخول عبر Static IP.", ["PHONE_LINKED", "NO_LIMIT_TRANSFER"]),
      P("w6", "محفظة Perfect Money (موثقة)", "Perfect Money (Verified)", "محفظة Perfect Money موثقة بصلاحيات كاملة.", "Verified Perfect Money wallet.", "https://i.postimg.cc/fy2TfLV7/images-(2).png", 60, 90,
        "Perfect Money موثقة: بيانات الحساب، وثائق التوثيق، الهاتف والبريد المرتبطين، وتفويض كامل للتحكم.", ["PHONE_LINKED", "NO_LIMIT_TRANSFER"]),
      P("w7", "محفظة Payer (No Limit)", "Payer (No Limit)", "محفظة Payer بلا قيود تحويل.", "Payer wallet with no transfer limits.", "https://i.postimg.cc/2SB8nCr4/unnamed.png", 55, 80,
        "Payer No Limit: بيانات الدخول، وثائق KYC، رقم الهاتف المرتبط، بلا قيود تحويل، ودليل التخفي.", ["PHONE_LINKED", "NO_LIMIT_TRANSFER"]),
    ],
  },

  /* 4 — المنصات الرقمية */
  {
    id: "platforms", short: A("المنصات"), name: A("المنصات الرقمية"),
    desc: A("حسابات في أكبر منصات التداول العالمية (Binance, OKX, Bybit) موثقة بالكامل بمستويات متقدمة (KYC Level 2). جاهزة لاستقبال وإرسال كميات ضخمة من الكريبتو دون قيود، مع تسليم كافة الوثائق."),
    icon: "coin", hero: "https://i.postimg.cc/TYQfmhzp/1782262062038.png",
    deliveryTitle: A("🔶 تحكم كامل، هوية مخفية — ماذا تشتري فعلياً؟"),
    delivery: EXCHANGE_DOCS,
    buyNote: A("طلب شراء حساب منصة موثق - جاهز للدفع عبر (USDT/BTC)."),
    products: [
      P("px1", "حساب Binance موثق (هوية أجنبية)", "Binance Verified (Foreign ID)", "حساب Binance موثق Level 2/3 بهوية أجنبية، جاهز للتداول والسحب.", "Binance Level 2/3 verified with foreign ID.", "https://i.postimg.cc/B6FxzrTP/images-(22).jpg", 150, 200,
        "Binance موثق: Email + Password + 2FA Secret Key، صور الوثائق المستخدمة بالتوثيق، حدود سحب مرتفعة، وتعليمات الدخول عبر Static IP.", ["2FA_READY", "FULL_KYC_DOCS"], "KYC LEVEL 2", true),
      P("px2", "حساب Binance VIP (قديم + نشط)", "Binance VIP (Aged + Active)", "حساب Binance VIP قديم ونشط بمستوى VIP ورسوم منخفضة.", "Aged active Binance VIP account.", "https://i.postimg.cc/zvSTzTPr/images-(33).jpg", 350, 450,
        "Binance VIP: تاريخ تداول حقيقي، مستوى VIP، بيانات الدخول والـ 2FA، وثائق KYC كاملة، ودعم ربط المحفظة الباردة.", ["2FA_READY", "FULL_KYC_DOCS"], "VIP"),
      P("px3", "حساب OKX موثق بالكامل", "OKX Fully Verified", "حساب OKX موثق بالكامل وجاهز للتداول بلا قيود.", "Fully verified OKX account.", "https://i.postimg.cc/WbTM9fhh/images-(3).png", 130, 180,
        "OKX موثق: بيانات الدخول والـ 2FA، وثائق التوثيق، حدود سحب كاملة، ودليل الدخول الآمن.", ["2FA_READY", "FULL_KYC_DOCS"]),
      P("px4", "حساب Bybit (Level 2 Verified)", "Bybit (Level 2 Verified)", "حساب Bybit بمستوى توثيق متقدم.", "Bybit Level 2 verified account.", "https://i.postimg.cc/rwYxwVgD/images-(4).png", 110, 150,
        "Bybit Level 2: بيانات الدخول، 2FA، وثائق KYC، حدود سحب مرتفعة، ودليل Static IP.", ["2FA_READY", "FULL_KYC_DOCS"]),
      P("px5", "حساب KuCoin (No Limit)", "KuCoin (No Limit)", "حساب KuCoin بلا قيود سحب وتوثيق كامل.", "KuCoin account with no limits.", "https://i.postimg.cc/VNxtXKxP/images-(24).jpg", 120, 160,
        "KuCoin No Limit: بيانات الدخول والـ 2FA، وثائق التوثيق، بلا قيود سحب، ودعم فني للربط.", ["2FA_READY", "FULL_KYC_DOCS"]),
      P("px6", "حساب Coinbase (أوروبي/أمريكي)", "Coinbase (EU/US)", "حساب Coinbase أوروبي أو أمريكي موثق بالكامل.", "Fully verified EU/US Coinbase account.", "https://i.postimg.cc/QtcTmpDy/images-(25).jpg", 220, 300,
        "Coinbase: بيانات الدخول والـ 2FA، وثائق KYC، حساب بنكي مربوط، حدود سحب عالية، ودليل الأمان.", ["2FA_READY", "FULL_KYC_DOCS"]),
    ],
  },

  /* 5 — التواصل الاجتماعي */
  {
    id: "social", short: A("التواصل"), name: A("التواصل الاجتماعي"),
    desc: A("حسابات تواصل اجتماعي «معتقة» (Aged Accounts) منشأة منذ سنوات ولها نشاط حقيقي سابق. مقاومة عالية للحظر (Anti-Ban) وقدرة على الوصول لميزات إعلانية وتقنية لا تتوفر في الحسابات الجديدة."),
    icon: "user", hero: "https://i.postimg.cc/htSRtghh/Screenshot-20260624-014246-Google.jpg",
    deliveryTitle: A("👤 القدم يعني الثقة — لماذا حساباتنا؟"),
    delivery: SOCIAL_DOCS,
    buyNote: A("أريد شراء حساب قديم - جاهز للدفع عبر (USDT/BTC)."),
    products: [
      P("s1", "حساب Telegram (رقم قديم + Session)", "Telegram (Aged + Session)", "حساب Telegram برقم قديم وجلسة جاهزة ضد الحظر.", "Aged Telegram account with ready session.", "https://i.postimg.cc/Hn7PBvxX/Screenshot-20260624-013528-Google.jpg", 25, 40,
        "Telegram قديم: رقم قديم + Session جاهزة، حماية ثنائية، تاريخ نشاط حقيقي، وإيميل OG المرتبط.", ["ANTI_BAN_SHIELD", "FULL_ACCESS"]),
      P("s2", "حساب Facebook (إنشاء 2010-2015)", "Facebook (2010-2015)", "حساب فيسبوك قديم جاهز للإعلانات (Ads Ready).", "Aged Facebook account, Ads Ready.", "https://i.postimg.cc/HsbTLB23/Screenshot-20260624-013639-Google.jpg", 40, 60,
        "Facebook قديم: تاريخ إنشاء 2010-2015، نشاط حقيقي، جاهز لإدارة الإعلانات، إيميل OG، وصول كامل.", ["ANTI_BAN_SHIELD", "FULL_ACCESS"]),
      P("s3", "حساب Instagram (متابعين حقيقيين)", "Instagram (Real Followers)", "حساب إنستغرام بمتابعين حقيقيين ونشاط قديم.", "Instagram with real followers and aged activity.", "https://i.postimg.cc/FHZmyzws/Screenshot-20260624-013741-Google.jpg", 55, 80,
        "Instagram: متابعون حقيقيون، موثوقية عالية، نشاط قديم، إيميل OG، وصول كامل.", ["ANTI_BAN_SHIELD", "FULL_ACCESS"]),
      P("s4", "حساب Twitter / X (قديم جداً)", "Twitter / X (Very Aged)", "حساب X قديم جداً يتجاوز فلاتر السبام بسهولة.", "Very aged X account bypassing spam filters.", "https://i.postimg.cc/nzsJfkrh/Screenshot-20260624-013827-Google.jpg", 30, 50,
        "X قديم جداً: تاريخ إنشاء مبكر، يتجاوز فلاتر السبام، نشاط حقيقي، إيميل OG، وصول كامل.", ["ANTI_BAN_SHIELD", "FULL_ACCESS"]),
      P("s5", "حساب TikTok (جاهز للبث + عملات)", "TikTok (Live + Coins)", "حساب TikTok قديم بمتابعين متفاعلين وجاهز للبث.", "Aged TikTok account ready for Live.", "https://i.postimg.cc/7P2kBmjB/Screenshot-20260624-014201-Google.jpg", 45, 70,
        "TikTok: جاهز للبث + عملات، متابعون متفاعلون، تاريخ قديم، إيميل OG، وصول كامل.", ["ANTI_BAN_SHIELD", "FULL_ACCESS"]),
      P("s6", "بكج (حساب من كل منصة - Elite)", "Elite Bundle (All Platforms)", "حساب من كل منصة للسيطرة الكاملة.", "One account from every platform.", "https://i.postimg.cc/htSRtghh/Screenshot-20260624-014246-Google.jpg", 160, 250,
        "بكج Elite: حساب من Telegram + Facebook + Instagram + X + TikTok مع Sessions وبيانات OG كاملة لكل حساب.", ["ANTI_BAN_SHIELD", "FULL_ACCESS"], "BUNDLE", true),
    ],
  },

  /* 6 — الإيميلات والأرقام */
  {
    id: "comms", short: A("الإيميلات"), name: A("الإيميلات والأرقام"),
    desc: A("القواعد الأساسية لأي عمل آمن: حسابات إيميل قديمة (Aged) وأرقام هواتف دولية حقيقية وافتراضية لاستقبال أكواد التفعيل (OTP). خط الدفاع الأول لإخفاء هويتك وتجنب تتبع أثرك الرقمي."),
    icon: "send", hero: "https://i.postimg.cc/yNnV9MN4/Screenshot-20260502-111945-Gallery.jpg",
    deliveryTitle: A("📧 أساس التحرك في الظل — لماذا تحتاج هذه الخدمة؟"),
    delivery: COMMS_DOCS,
    buyNote: A("أريد طلب (إيميلات/أرقام) بالنوع المحدد - جاهز للدفع."),
    products: [
      P("c1", "حسابات Gmail قديمة (Aged 2015-2020)", "Gmail Aged (2015-2020)", "بكج 5 حسابات Gmail قديمة مع Recovery.", "Pack of 5 aged Gmail accounts with recovery.", "https://i.postimg.cc/wMGgsGrc/images-(10).png", 15, 25,
        "بكج 5 حسابات Gmail منشأة 2015-2020 مع Recovery Email، أسئلة أمان، Clean IP، وموثوقية عالية لدى Google.", ["INSTANT_OTP", "NO_RECOVERY_RISK"], "×5 ACCOUNTS"),
      P("c2", "حسابات ProtonMail مشفرة (Premium)", "ProtonMail (Premium)", "إيميل سويسري مشفر بالكامل بباقة Premium.", "Swiss fully encrypted Premium email.", "https://i.postimg.cc/9FDWjcRH/images-(40).jpg", 30, 40,
        "ProtonMail Premium: تشفير سويسري من طرف إلى طرف، بلا سجلات، بيانات دخول كاملة، Recovery، ودليل الاستخدام الآمن.", ["INSTANT_OTP", "NO_RECOVERY_RISK"]),
      P("c3", "رقم أمريكي دائم (WhatsApp & Telegram)", "Permanent US Number", "رقم أمريكي صالح مدى الحياة للتفعيل.", "Lifetime US number for verification.", "https://i.postimg.cc/4d4g2GRR/Fake-US-number.jpg", 10, 20,
        "رقم أمريكي دائم: صالح مدى الحياة لاستقبال SMS/OTP، متوافق مع WhatsApp وTelegram، وصول كامل بلا انتهاء.", ["INSTANT_OTP", "NO_RECOVERY_RISK"]),
      P("c4", "رقم بريطاني/أوروبي لتفعيل البنوك", "UK/EU Bank OTP Number", "استقبال رسائل OTP بلا حدود لتفعيل البنوك.", "Unlimited OTP for bank verification.", "https://i.postimg.cc/1RjQBbW7/Fake-US-number-(1).jpg", 20, 35,
        "رقم بريطاني/أوروبي: استقبال OTP بلا حدود، مناسب لتفعيل الحسابات البنكية والمنصات، وصول دائم.", ["INSTANT_OTP", "NO_RECOVERY_RISK"]),
      P("c5", "حسابات Outlook/Hotmail (Bulk)", "Outlook/Hotmail (Bulk)", "بكج 20 حساب بالجملة.", "Bulk pack of 20 accounts.", "https://i.postimg.cc/pLDM2rPj/images-(11).png", 5, 15,
        "بكج 20 حساب Outlook/Hotmail بالجملة مع بيانات الدخول وRecovery، منشأة عبر Clean IP.", ["INSTANT_OTP", "NO_RECOVERY_RISK"], "×20 ACCOUNTS"),
      P("c6", "بكج (10 إيميلات + 2 رقم دولي)", "Pro Bundle (10 Emails + 2 Numbers)", "خيار المحترفين الشامل.", "All-in-one pro pack.", "https://i.postimg.cc/yxJ22Yfb/Screenshot-20260624-014705-Google.jpg", 45, 70,
        "بكج المحترفين: 10 إيميلات قديمة + رقمين دوليين دائمين مع Recovery وOTP بلا حدود.", ["INSTANT_OTP", "NO_RECOVERY_RISK"], "BUNDLE", true),
    ],
  },

  /* 7 — بوابات الدفع الموثقة */
  {
    id: "gateways", short: A("البوابات"), name: A("بوابات الدفع الموثقة"),
    desc: A("مجموعة مختارة من الحسابات التجارية والموثقة ذات الموثوقية العالية، جاهزة للاستخدام الفوري بأسعار اقتصادية. تسليم بيانات الدخول الكاملة + ملف التوثيق (KYC) خلال 30 دقيقة من إتمام الدفع."),
    icon: "lock", hero: "https://i.postimg.cc/SKF8MTFh/Screenshot-20260624-014319-Google.jpg",
    deliveryTitle: A("🛡️ لماذا حساباتنا هي الأفضل؟"),
    delivery: GATEWAY_DOCS,
    buyNote: A("أرغب في شراء حساب بسعر محدد - جاهز للدفع عبر (USDT/BTC)."),
    products: [
      P("g1", "PayPal Business", "PayPal Business", "قديم (+3 سنوات) + مفعل بالكامل.", "Aged 3+ years, fully active.", "https://i.postimg.cc/Rhrj5x2P/1782253427639.png", 150, undefined,
        "PayPal Business قديم +3 سنوات ومفعل: بيانات الدخول، وثائق KYC، حدود مرتفعة، ودليل تغيير إعدادات الأمان.", ["Verified"], "3+ YEARS", true),
      P("g2", "Binance Verified (Tier 3)", "Binance Verified", "توثيق Tier 3 + بدون قيود.", "Tier 3 verification, no limits.", "https://i.postimg.cc/zvSTzTPr/images-(33).jpg", 120, undefined,
        "Binance Tier 3: توثيق كامل بلا قيود، 2FA، وثائق KYC، وحدود سحب قصوى.", ["Verified"]),
      P("g3", "Wise Business", "Wise Business", "حساب أوروبي كامل الصلاحيات.", "Full-permission European account.", "https://i.postimg.cc/2SjgfwXN/images-(34).jpg", 180, undefined,
        "Wise Business أوروبي: IBAN وSWIFT، بيانات الداشبورد، وثائق الشركة، ووصول للهاتف والبريد.", ["Verified"]),
      P("g4", "Stripe Gateway", "Stripe Gateway", "حساب تجاري مفعل + جاهز للربط API.", "Active merchant account, API ready.", "https://i.postimg.cc/76zWNQb2/images-(8).png", 250, undefined,
        "Stripe: حساب تجاري مفعل، مفاتيح API، بيانات الداشبورد، وثائق التوثيق، وجاهز لاستقبال المدفوعات.", ["Verified"], "API READY"),
      P("g5", "Authorize.net", "Authorize.net", "حساب بوابة دفع احترافي.", "Professional payment gateway account.", "https://i.postimg.cc/c1QzgjpS/images-(35).jpg", 220, undefined,
        "Authorize.net: بيانات الدخول والم商户، وثائق KYC، بوابة جاهزة للربط، ودليل الأمان.", ["Verified"]),
      P("g6", "Shopify Store", "Shopify Store", "متجر مفعل + بوابات دفع مدمجة.", "Active store with integrated gateways.", "https://i.postimg.cc/hPs3MmPG/images-(36).jpg", 250, undefined,
        "Shopify Store: متجر مفعل، بوابات دفع مدمجة، بيانات الدخول، وثائق المالك، وصلاحيات كاملة.", ["Verified"]),
      P("g7", "Coinbase Pro", "Coinbase Pro", "حساب تداول احترافي.", "Professional trading account.", "https://i.postimg.cc/NjPCvwHW/images-(9).png", 190, undefined,
        "Coinbase Pro: حساب تداول احترافي موثق، 2FA، وثائق KYC، وحدود سحب مرتفعة.", ["Verified"]),
      P("g8", "Revolut Business", "Revolut Business", "حساب أعمال أوروبي.", "European business account.", "https://i.postimg.cc/Pqg6NzKm/images-(37).jpg", 200, undefined,
        "Revolut Business: IBAN أوروبي، بيانات الداشبورد، وثائق الشركة، ووصول كامل للهاتف والبريد.", ["Verified"]),
      P("g9", "N26 Business", "N26 Business", "حساب أعمال ألماني موثق.", "Verified German business account.", "https://i.postimg.cc/Kcr9vTTZ/images-(38).jpg", 150, undefined,
        "N26 Business ألماني: IBAN، بيانات الدخول، وثائق KYC، وتفويض كامل.", ["Verified"]),
      P("g10", "Amazon Seller", "Amazon Seller", "حساب بائع موثق + تقييمات.", "Verified seller account with ratings.", "https://i.postimg.cc/2897V7Sp/Screenshot-20260624-013353-Google.jpg", 250, undefined,
        "Amazon Seller: حساب بائع موثق بتقييمات وسجل مبيعات، بيانات الدخول، وثائق التوثيق، وصلاحيات كاملة.", ["Verified"]),
    ],
  },
];

export const accountSectionById = (id: string) => ACCOUNT_SECTIONS.find((s) => s.id === id);

/* ═══════════ أداة «حسابات أخرى» — اختيار الدولة ═══════════ */
export interface CountryAccount {
  id: string;
  flag: string;
  country: L;
  bank: L;
  domain: string;
  priceUsd: number;
  group: "global" | "vip";
  desc: L;
}

/** صورة البنك الحقيقية (favicon رسمي) مع بديل تلقائي في الواجهة */
export const bankLogo = (domain: string) => `https://www.google.com/s2/favicons?domain=${domain}&sz=128`;

const C = (id: string, flag: string, ar: string, en: string, bankAr: string, bankEn: string, domain: string, price: number, group: "global" | "vip"): CountryAccount => ({
  id, flag, country: A(ar, en), bank: A(bankAr, bankEn), domain, priceUsd: price, group,
  desc: A("حساب جاهز بكامل الصلاحيات، موثق بهوية حقيقية، مع تفويض كامل وبيانات الداشبورد والمالك والهاتف والبريد المرتبطين."),
});

/** القائمة الخام كما وردت — يُطبَّق عليها إزالة التكرار برمجياً */
const RAW_COUNTRIES: CountryAccount[] = [
  C("us", "🇺🇸", "الولايات المتحدة (US)", "United States (US)", "JPMorgan Chase", "JPMorgan Chase", "chase.com", 500, "global"),
  C("gb", "🇬🇧", "المملكة المتحدة (GB)", "United Kingdom (GB)", "Barclays", "Barclays", "barclays.co.uk", 400, "global"),
  C("sa", "🇸🇦", "السعودية (SA)", "Saudi Arabia (SA)", "Al Rajhi Bank (مصرف الراجحي)", "Al Rajhi Bank", "alrajhibank.com.sa", 800, "global"),
  C("ae", "🇦🇪", "الإمارات (AE)", "UAE (AE)", "Emirates NBD (بنك دبي الوطني)", "Emirates NBD", "emiratesnbd.com", 800, "global"),
  C("de", "🇩🇪", "ألمانيا (DE)", "Germany (DE)", "Deutsche Bank", "Deutsche Bank", "deutsche-bank.de", 650, "global"),
  C("ca", "🇨🇦", "كندا (CA)", "Canada (CA)", "RBC (Royal Bank of Canada)", "RBC", "rbc.com", 450, "global"),
  C("fr", "🇫🇷", "فرنسا (FR)", "France (FR)", "BNP Paribas", "BNP Paribas", "bnpparibas.com", 400, "global"),
  C("au", "🇦🇺", "أستراليا (AU)", "Australia (AU)", "Commonwealth Bank (CBA)", "Commonwealth Bank", "commbank.com.au", 400, "global"),
  C("mx", "🇲🇽", "المكسيك (MX)", "Mexico (MX)", "BBVA México", "BBVA México", "bbva.mx", 300, "global"),
  C("es", "🇪🇸", "إسبانيا (ES)", "Spain (ES)", "Banco Santander", "Banco Santander", "bancosantander.es", 250, "global"),
  C("ch", "🇨🇭", "سويسرا (CH)", "Switzerland (CH)", "UBS Group", "UBS Group", "ubs.com", 1200, "global"),
  C("it", "🇮🇹", "إيطاليا (IT)", "Italy (IT)", "Intesa Sanpaolo", "Intesa Sanpaolo", "intesasanpaolo.com", 1000, "global"),
  C("sg", "🇸🇬", "سنغافورة (SG)", "Singapore (SG)", "DBS Bank", "DBS Bank", "dbs.com.sg", 700, "global"),
  C("se", "🇸🇪", "السويد (SE)", "Sweden (SE)", "SEB Bank", "SEB Bank", "seb.se", 550, "global"),
  C("br", "🇧🇷", "البرازيل (BR)", "Brazil (BR)", "Itaú Unibanco", "Itaú Unibanco", "itau.com.br", 230, "global"),
  C("tr", "🇹🇷", "تركيا (TR)", "Türkiye (TR)", "Ziraat Bankası", "Ziraat Bankası", "ziraatbank.com.tr", 300, "global"),
  C("in", "🇮🇳", "الهند (IN)", "India (IN)", "State Bank of India (SBI)", "State Bank of India", "sbi.co.in", 150, "global"),
  C("cn", "🇨🇳", "الصين (CN)", "China (CN)", "ICBC", "ICBC", "icbc.com.cn", 200, "global"),
  C("za", "🇿🇦", "جنوب إفريقيا (ZA)", "South Africa (ZA)", "Standard Bank", "Standard Bank", "standardbank.com", 120, "global"),
  C("be", "🇧🇪", "بلجيكا (BE)", "Belgium (BE)", "KBC Bank", "KBC Bank", "kbc.be", 500, "global"),
  C("nl", "🇳🇱", "هولندا (NL)", "Netherlands (NL)", "ING Bank", "ING Bank", "ing.nl", 270, "global"),
  C("mx2", "🇲🇽", "المكسيك (MX)", "Mexico (MX)", "BBVA México", "BBVA México", "bbva.mx", 180, "global"),     // مكرر → يُحذف
  C("fr2", "🇫🇷", "فرنسا (FR)", "France (FR)", "BNP Paribas", "BNP Paribas", "bnpparibas.com", 500, "global"), // مكرر → يُحذف
  C("kw", "🇰🇼", "الكويت (KW)", "Kuwait (KW)", "Boubyan Bank (بنك بوبيان)", "Boubyan Bank", "boubyan.com", 800, "global"),
  C("jp", "🇯🇵", "اليابان (JP)", "Japan (JP)", "MUFG Bank (بنك ميتسوبيشي)", "MUFG Bank", "mufg.jp", 600, "global"),
  /* شبكات راقية وبنوك رقمية مشابهة */
  C("v-jcb", "🇯🇵", "اليابان (JP)", "Japan (JP)", "JCB International", "JCB International", "jcb.co.jp", 1200, "vip"),
  C("v-diners", "🇬🇧", "المملكة المتحدة (GB)", "United Kingdom (GB)", "Diners Club UK", "Diners Club UK", "dinersclub.com", 900, "vip"),
  C("v-swisscard", "🇨🇭", "سويسرا (CH)", "Switzerland (CH)", "Swisscard AECS", "Swisscard AECS", "swisscard.ch", 1500, "vip"),
  C("v-revolut", "🇬🇧", "المملكة المتحدة (GB)", "United Kingdom (GB)", "Revolut Bank", "Revolut Bank", "revolut.com", 800, "vip"),
  C("v-wise", "🇺🇸", "الولايات المتحدة (US)", "United States (US)", "Wise Bank", "Wise Bank", "wise.com", 700, "vip"),
  C("v-wio", "🇦🇪", "الإمارات (AE)", "UAE (AE)", "Wio Bank", "Wio Bank", "wio.io", 850, "vip"),
  C("v-n26", "🇩🇪", "ألمانيا (DE)", "Germany (DE)", "N26 Bank", "N26 Bank", "n26.com", 600, "vip"),
];

/** إزالة التكرار: لا بنك مكرر داخل الأداة، ولا حساب مطابق لعروض الأقسام */
const OFFER_KEYS = new Set(
  ACCOUNT_SECTIONS.flatMap((s) => s.products.map((p) => (p.name.en || p.name.ar || "").toLowerCase().replace(/[^a-z0-9]/g, ""))),
);
export const COUNTRY_ACCOUNTS: CountryAccount[] = (() => {
  const seen = new Set<string>();
  return RAW_COUNTRIES.filter((c) => {
    const key = `${c.country.en}::${c.bank.en}`;
    const norm = (c.bank.en || c.bank.ar || "").toLowerCase().replace(/[^a-z0-9]/g, "");
    if (seen.has(key)) return false;                       // تكرار داخل الأداة
    if (OFFER_KEYS.has(norm)) return false;                 // مطابق لعرض موجود
    seen.add(key);
    return true;
  });
})();

/** شرح «حساب جاهز بكامل الصلاحيات» الموحد */
export const COUNTRY_DELIVERY: L[] = [
  ...FULL_CONTROL,
  A("بيانات الدخول: البريد، الباسورد، اسم المستخدم، كود 2FA."),
  A("بيانات الـ IBAN وكود SWIFT، ووثائق التوثيق KYC، ودليل الدخول الآمن عبر Proxy/VPN."),
];

/* ═══════════ قالب الرسالة الموحد (كل أزرار الشراء) ═══════════ */
export function purchaseMessage(name: string, price: number, note?: string): string {
  return [
    "[🚨 طلب شراء جديد - BLACK MART]",
    "--------------------------------------",
    `💳 الخدمة المطلوبة: ${name}`,
    `💰 القيمة: ${price}$`,
    "--------------------------------------",
    "📝 نص الطلب: ",
    `أريد شراء ${name}. يرجى تزويدي بمحافظ الدفع المتاحة والتعليمات المطلوبة لإتمام المعاملة.`,
    ...(note ? [`📌 ${note}`] : []),
    "--------------------------------------",
    "[SYSTEM_ID: AUTO_GENERATED]",
  ].join("\n");
}
