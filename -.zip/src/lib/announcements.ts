/* ─────────────────────────────────────────────────────────────
   BLACK MART · إعلانات المنصة
   كل نصوص الإعلانات والرسائل الجاهزة هنا فقط — قابلة للتعديل 100%.
   ───────────────────────────────────────────────────────────── */
import type { L } from "./site";

/** إعلان المنتدى لجميع الزوار والوسطاء — يظهر تحت شبكة الأقسام */
export const FORUM_ANNOUNCEMENT: L = {
  ar: `📢 إعلان المنتدى لجميع الزوار والوسطاء::

سواء كنت منفذاً تبحث عن أشخاص تنفذ لهم مقابل نسبة، أو كنت عميلاً تريد منفذاً لطلبك، هذه المساحة مخصصة لكم لتسهيل جميع المعاملات التالية:

🔹 الخدمات والطلبات المتاحة:
• تفريغ البطاقات: لمن لديه ماكينة ومحتاج بطاقات لتفريغها عليها، أو لديه حسابات وبطاقات لمحتاج تسدد لينكات أو تفرغ عبر الماكينة.
• الروابط: لمن لديه رابط ومحتاج شخصاً يفرغ ويدفع عليه.
• الفواتير: لمن لديه فواتير يريد تسددها.
• حسابات السداد والفواتير: لمن لديه حسابات ومحتاج تسدد فواتير مقابل راجع (عائد).
• الحسابات البنكية: لمن يريد حساب مستقبل، أو من عنده حسابات تريد تستقبل.

🛡️ كيف تتم العملية؟
1. كل طلب خدمة وكل منفذ يريد العمل مقابل نسبة، كلمني على الخاص.
2. اكتب خدمتك أو طلبك في رسالة، وسأقوم أنا بنشر المنشور.
3. إذا طلبك أحد أو وجدنا الطرف المناسب، أجمعكم في قناة واحدة.
4. تتفقون وتخلصون شغلكم بواسطة ضمانات تضمن حقوقكم.`,
  en: `📢 Forum announcement for all visitors & brokers::

Whether you are an operator looking for people to work for a percentage, or a client who needs an operator for a request — this space is dedicated to facilitating all of the following transactions:

🔹 Available services & requests:
• Card draining: for those with a POS machine needing cards to drain, or those with accounts/cards needing someone to settle links or drain through the machine.
• Links: for those with a link needing someone to drain and pay on it.
• Bills: for those with bills they want settled.
• Payment & billing accounts: for those with accounts needing bill settlement in return for a yield.
• Bank accounts: for those needing a receiving account, or those with accounts that need to receive.

🛡️ How does it work?
1. Every service request and every operator wanting to work for a percentage — message me privately.
2. Write your service or request in a message, and I will publish the post.
3. If someone requests it or we find the right party, I bring you together in one channel.
4. You agree and finish your work with guarantees protecting both parties' rights.`,
  ru: `📢 Объявление форума для всех посетителей и посредников::

Исполнитель ли вы в поиске клиентов за процент, или клиент, которому нужен исполнитель — это пространство создано для следующих сделок:

🔹 Доступные услуги и запросы:
• Слив карт: для владельцев POS-терминалов, которым нужны карты, и для владельцев карт/аккаунтов, которым нужно погасить ссылки или слить через терминал.
• Ссылки: для тех, у кого есть ссылка и нужен человек, который сольёт и оплатит.
• Счета: для тех, чьи счета нужно оплатить.
• Аккаунты оплаты: для владельцев аккаунтов, которым нужно погашение счетов за вознаграждение.
• Банковские аккаунты: для ищущих принимающий счёт или предлагающих свои счета.

🛡️ Как это работает?
1. Каждый запрос и каждый исполнитель пишет мне в личные сообщения.
2. Опишите услугу или запрос — я опубликую пост.
3. Когда найдётся подходящая сторона, я соберу вас в одном канале.
4. Договоритесь и завершите работу с гарантиями прав обеих сторон.`,
};

/** الرسالة الجاهزة التي تفتح في حقل كتابة تيليجرام */
export const FORUM_ANNOUNCE_MESSAGE =
  "، بخصوص إعلان المنتدى العام، لدي طلب / خدمة وأرغب بالتواصل.";

/** عنوان زر الإعلان */
export const FORUM_ANNOUNCE_BUTTON: L = {
  ar: "📢 إعلان المنتدى لجميع الزوار",
  en: "📢 Forum announcement for all visitors",
  ru: "📢 Объявление форума для всех",
};

/** عنوان القائمة المنسدلة */
export const FORUM_ANNOUNCE_TITLE: L = {
  ar: "إعلان المنتدى لجميع الزوار والوسطاء",
  en: "Forum announcement for visitors & brokers",
  ru: "Объявление форума",
};
