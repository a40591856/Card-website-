/* ─────────────────────────────────────────────────────────────
   BLACK MART · ملف الإعدادات المركزي (قابل للتعديل 100%)
   الهيكل الرباعي: Market · Arsenal · Forum · Support + Pay
   كل المحتوى هنا — أضف/عدّل أي عنصر دون لمس الكود.
   ───────────────────────────────────────────────────────────── */

import type { Lang } from "./i18n";

/** نص متعدد اللغات — اكتب ما تملك، الباقي يُكمل من en */
export type L = Partial<Record<Lang, string>>;

export function pick<T = string>(lang: Lang, rec: Partial<Record<Lang, T>>): T {
  return (rec[lang] ?? rec.en) as T;
}

/* ── الروابط (استبدلها بروابطك الحقيقية) ── */
/**
 * الروابط الرسمية الموحدة — تُعدَّل من هنا فقط وتنتشر على كل الموقع.
 * لا تُعرض كنصوص في الواجهة (تُبنى لحظة الضغط).
 */
export const LINKS = {
  support: "https://t.me/custour?direct",
  manager: "https://t.me/blackmart_admin",
  group: "https://t.me/+3ji36yCsWRc2NTJk",
  channel: "https://t.me/+3ji36yCsWRc2NTJk",
  whatsapp: "https://whatsapp.com/channel/0029Vb8qVMgChq6GNcaUcd38",
};

/** صفحات داخلية مباشرة للأيقونات العلوية */
export const ROUTES = {
  pay: "/pay",
  cart: "/cart",
  channels: "/channels",
  disputes: "/disputes",
};

export const SITE = {
  name: "BLACK MART",
  version: "v2.1.0",
};

export const ENC_DURATION_MS = 5000;

export const TICKER_KEYS = ["tick.1", "tick.2", "tick.3", "tick.4", "tick.5", "tick.6"] as const;

/* ── شاشة الإعلانات (نص + صور + فيديو) ── */
export type AdDef = {
  id: string;
  type: "text" | "image" | "video";
  src?: string;
  poster?: string;
  title: L;
  body: L;
};

export const ADS: AdDef[] = [
  {
    id: "ad-1",
    type: "image",
    src: "/images/ads/ad-1.jpg",
    title: {
      ar: "افتتاح المنطقة — خصم 20% على باقات الدخول",
      en: "Zone opening — 20% off access packs",
      ru: "Открытие зоны — скидка 20% на пакеты",
    },
    body: {
      ar: "لفترة محدودة: ادخل مبكراً واحصل على أفضل أسعار الباقات الأساسية.",
      en: "For a limited time: enter early and get the best base-pack prices.",
      ru: "Ограниченное время: заходите раньше и получайте лучшие цены.",
    },
  },
  {
    id: "ad-2",
    type: "video",
    src: "https://videos.pexels.com/video-files/7534243/7534243-hd_1920_1080_25fps.mp4",
    poster: "/images/ads/ad-2.jpg",
    title: {
      ar: "جولة مباشرة داخل الخادم — حالة الشبكة",
      en: "Live tour inside the server — network status",
      ru: "Живой тур по серверу — состояние сети",
    },
    body: {
      ar: "بنية تحتية محصّنة · عقد متعددة · استجابة خلال ثوانٍ.",
      en: "Hardened infrastructure · multi-node · seconds of latency.",
      ru: "Укреплённая инфраструктура · мультинод · задержки в секунды.",
    },
  },
  {
    id: "ad-3",
    type: "image",
    src: "/images/ads/ad-2.jpg",
    title: {
      ar: "انضم للقناة الرسمية — كل جديد أولاً بأول",
      en: "Join the official channel — first to know",
      ru: "Подписывайся на официальный канал",
    },
    body: {
      ar: "الإعلانات، التحديثات، وأسماء مسؤليك — كلها هناك.",
      en: "Drops, updates, your managers — all there.",
      ru: "Дропы, обновления, менеджеры — всё там.",
    },
  },
];

/* ═══════════════ السوق — 7 أقسام × فروع (الهيكل العميق) ═══════════════ */
export interface MarketBranch {
  id: string;
  icon: string;
  name: L;
  desc: L;
}

export interface MarketSection {
  id: string;
  code: string;
  icon: string;
  name: L;
  desc: L;
  thumb: string;
  /** فارغ = بدون فروع (منتجات مباشرة) */
  branches: MarketBranch[];
  /** الفلترة الثلاثية: الكل / المحقونة / المسحوبة */
  filter?: "cards";
}

const d2 = (ar: string, en: string, ru?: string): L => (ru ? { ar, en, ru } : { ar, en });

export const MARKET_SECTIONS: MarketSection[] = [
  {
    id: "cards",
    code: "01",
    icon: "card",
    thumb: "/images/market/sec-cards.jpg",
    name: { ar: "البطاقات المحقونة", en: "Injected Cards", ru: "Инжект-карты" },
    desc: d2(
      "الفئة الأوسع في السوق: ثمانية فروع تخصصية من NOVBV إلى Platinum، مع فهرس فلترة ثلاثي (الكل / المحقونة / المسحوبة) للوصول الدقيق.",
      "The market's widest category: eight specialized branches from NOVBV to Platinum, plus a triple filter index (All / Injected / Drained) for precision.",
    ),
    filter: "cards",
    branches: [
      { id: "b-novbv", icon: "card", name: { ar: "بطاقات NOVBV CC محقونة", en: "NOVBV CC Cards (Injected)", ru: "NOVBV CC — инжект" }, desc: d2("بطاقات محقونة لتجاوز الـ OTP والسحب المباشر. البيانات كاملة (Fullz).", "Injected cards with OTP bypass and direct withdrawal. Fullz.") },
      { id: "b-amex-i", icon: "card", name: { ar: "بطاقات American Express محقونة", en: "AMEX Cards · Protocol 10.1", ru: "AMEX — протокол 10.1" }, desc: d2("بطاقات AMEX محقونة بروتوكول 10.1 مع بيانات تطبيق كاملة قابلة لفتح التطبيق.", "AMEX cards injected via Protocol 10.1 with full app data, ready to open the app.") },
      { id: "b-paypal-i", icon: "wallet", name: { ar: "حسابات PayPal محقونة", en: "PayPal Accounts (Injected)", ru: "PayPal — инжект" }, desc: d2("حسابات PayPal شخصية وتجارية محقونة برصيد، ببيانات كاملة، تم فتحها يدوياً.", "Personal & business PayPal accounts injected with balance, full data, opened manually.") },
      { id: "b-credit", icon: "card", name: { ar: "بطاقات Credit", en: "Credit Cards", ru: "Credit Cards" }, desc: d2("بطاقات مديونية بحدود مرتفعة (HIGH_LIMIT_VAULT) تمنحك وقتاً للعمل قبل الفواتير.", "High-limit credit cards (HIGH_LIMIT_VAULT) giving you working time before billing.") },
      { id: "b-debit", icon: "card", name: { ar: "بطاقات Debit", en: "Debit Cards", ru: "Debit Cards" }, desc: d2("بطاقات مرتبطة بالرصيد البنكي مباشرة. تتطلب دقة وتركيز عند الربط.", "Cards linked directly to bank balance. Require precision when linking.") },
      { id: "b-amex-c", icon: "card", name: { ar: "بطاقات American Express", en: "American Express (AMEX)", ru: "American Express" }, desc: d2("بطاقات AMEX شريحة وبروتوكول 10.1 — بطاقات النخبة: صرف مباشر، بوابات دفع، وتلامس NFC.", "AMEX chip + Protocol 10.1 cards — elite tier: direct withdrawal, gateways, NFC.") },
      { id: "b-classic", icon: "card", name: { ar: "بطاقات Classic", en: "Classic Cards", ru: "Classic" }, desc: d2("بيانات خام (Raw Data) غير مفحوصة، مخصصة لمن يمتلكون أدواتهم الخاصة.", "Raw unverified data, for those who bring their own tools.") },
      { id: "b-platinum", icon: "star", name: { ar: "بطاقات Platinum", en: "Platinum Cards", ru: "Platinum" }, desc: d2("بيانات خام عالية الصلابة — منطقة المحترفين والأذكياء.", "High-hardness raw data — the zone of professionals and the smart.") },
    ],
  },
  {
    id: "accounts",
    code: "04",
    icon: "user",
    thumb: "/images/market/sec-accounts.jpg",
    name: { ar: "الحسابات المستعارة", en: "Stolen Accounts", ru: "Удвоенные аккаунты" },
    desc: d2(
      "سبعة فروع تغطي كل أنواع الحسابات: من AMEX إلى بوابات الدفع الموثقة، مع فهرس علوي للتنقل السلس بين الفروع.",
      "Seven branches covering every account type: from AMEX to verified gateways, with a top index for smooth branch navigation.",
    ),
    branches: [
      { id: "a-amex", icon: "card", name: { ar: "حسابات American Express", en: "American Express Accounts", ru: "Аккаунты AMEX" }, desc: d2("حسابات AMEX بحالات متنوعة.", "AMEX accounts in various states.") },
      { id: "a-iban", icon: "shield", name: { ar: "الحسابات البنكية (IBAN)", en: "Bank Accounts (IBAN)", ru: "Банковские аккаунты (IBAN)" }, desc: d2("حسابات IBAN موثقة الرصيد.", "IBAN accounts with verified balance.") },
      { id: "a-wallets", icon: "wallet", name: { ar: "المحافظ الإلكترونية", en: "E-Wallets", ru: "Электронные кошельки" }, desc: d2("محافظ رقمية بحالات متعددة.", "Digital wallets in multiple states.") },
      { id: "a-digital", icon: "box", name: { ar: "المنصات الرقمية", en: "Digital Platforms", ru: "Цифровые платформы" }, desc: d2("حسابات منصات رقمية عالمية.", "Accounts from global digital platforms.") },
      { id: "a-social", icon: "chat", name: { ar: "التواصل الاجتماعي", en: "Social Media", ru: "Соцсети" }, desc: d2("حسابات تواصل اجتماعي بحجم متابعين موثق.", "Social accounts with documented followers.") },
      { id: "a-emails", icon: "send", name: { ar: "الإيميلات والأرقام", en: "Emails & Numbers", ru: "Почта и номера" }, desc: d2("صناديق إيميل وأرقام هواتف.", "Inbox emails and phone numbers.") },
      { id: "a-gateways", icon: "lock", name: { ar: "بوابات الدفع الموثقة", en: "Verified Payment Gateways", ru: "Проверенные платёжные шлюзы" }, desc: d2("حسابات بوابات دفع موثقة بالكامل.", "Fully verified payment-gateway accounts.") },
    ],
  },
  {
    id: "injection",
    code: "03",
    icon: "code",
    thumb: "/images/market/sec-injection.jpg",
    name: { ar: "حقن الحسابات", en: "Account Injection", ru: "Инжекция аккаунтов" },
    desc: d2(
      "قسم مباشر بدون فروع: منتجاته معروضة مباشرة بنظام شبكي (2×2 للهواتف و 3×3 للكمبيوتر) دون فهرس فروع.",
      "A direct section with no branches: products shown straight in a grid (2×2 mobile / 3×3 desktop) without a branch index.",
    ),
    branches: [],
  },
  {
    id: "transfer",
    code: "02",
    icon: "swap",
    thumb: "/images/market/sec-transfer.jpg",
    name: { ar: "التحويل والتبييض", en: "Transfer & Laundering", ru: "Переводы и отмывание" },
    desc: d2(
      "خمسة فروع لحركة الأموال: حقن AMEX وPayPal، تحويلات بنكية SWIFT/SEPA، وتحويلات Flash بالـ USDT وBitcoin.",
      "Five branches for money movement: AMEX & PayPal injection, SWIFT/SEPA bank transfers, and Flash USDT/BTC transfers.",
    ),
    branches: [
      { id: "t-amex", icon: "swap", name: { ar: "حقن American Express", en: "AMEX Injection", ru: "Инжекция AMEX" }, desc: d2("تحويل عبر AMEX بحالة حقن مباشر.", "Transfers via AMEX in direct injection state.") },
      { id: "t-paypal", icon: "swap", name: { ar: "حقن PayPal E-wallet", en: "PayPal E-wallet Injection", ru: "Инжекция PayPal" }, desc: d2("تحويل عبر محافظ PayPal الرقمية.", "Transfers via PayPal e-wallets.") },
      { id: "t-bank", icon: "shield", name: { ar: "التحويلات البنكية (SWIFT/SEPA)", en: "Bank Transfers (SWIFT/SEPA)", ru: "Банковские переводы (SWIFT/SEPA)" }, desc: d2("مسارات بنكية دولية SWIFT وSEPA.", "International SWIFT & SEPA bank routes.") },
      { id: "t-usdt", icon: "coin", name: { ar: "تحويلات Flash USDT", en: "Flash USDT Transfers", ru: "Flash-переводы USDT" }, desc: d2("تحويلات USDT فورية بدون تأكيد.", "Instant USDT transfers without confirmations.") },
      { id: "t-btc", icon: "coin", name: { ar: "تحويلات Flash Bitcoin", en: "Flash Bitcoin Transfers", ru: "Flash-переводы Bitcoin" }, desc: d2("تحويلات BTC فورية بلا انتظار التأكيدات.", "Instant BTC transfers without waiting confirmations.") },
    ],
  },
  {
    id: "gifts",
    code: "05",
    icon: "gift",
    thumb: "/images/market/sec-gifts.jpg",
    name: { ar: "بطاقات الهدايا والاشتراكات", en: "Gift Cards & Subscriptions", ru: "Подарочные карты" },
    desc: d2(
      "ستة فروع للهدايا والاشتراكات: من Binance إلى Amazon، مع خدمات الربط والشحن والاشتراكات الرقمية.",
      "Six branches for gifts & subs: from Binance to Amazon, plus linking/top-up services and digital subscriptions.",
    ),
    branches: [
      { id: "g-binance", icon: "coin", name: { ar: "بطاقات Binance", en: "Binance Cards", ru: "Карты Binance" }, desc: d2("بطاقات هدايا Binance بمقاييس متنوعة.", "Binance gift cards in various denominations.") },
      { id: "g-apple", icon: "gift", name: { ar: "بطاقات Apple / iTunes", en: "Apple / iTunes Cards", ru: "Apple / iTunes" }, desc: d2("بطاقات آبل بجميع المناطق.", "Apple cards across all regions.") },
      { id: "g-games", icon: "play", name: { ar: "بطاقات الألعاب", en: "Game Cards", ru: "Игровые карты" }, desc: d2("رزم الألعاب: Steam وPlayStation وXbox.", "Game packs: Steam, PlayStation, Xbox.") },
      { id: "g-amazon", icon: "box", name: { ar: "بطاقات Amazon", en: "Amazon Cards", ru: "Карты Amazon" }, desc: d2("بطاقات أمازون بمقاييس مختلفة.", "Amazon cards in different values.") },
      { id: "g-link", icon: "link", name: { ar: "خدمات الربط والشحن", en: "Linking & Top-up Services", ru: "Связка и пополнение" }, desc: d2("ربط البطاقات بحسابات وشحن فوري.", "Linking cards to accounts with instant top-up.") },
      { id: "g-digital", icon: "code", name: { ar: "الاشتراكات الرقمية", en: "Digital Subscriptions", ru: "Цифровые подписки" }, desc: d2("اشتراكات منصات رقمية موسمية.", "Seasonal digital platform subscriptions.") },
    ],
  },
  {
    id: "topup",
    code: "06",
    icon: "play",
    thumb: "/images/market/sec-topup.jpg",
    name: { ar: "شحن التطبيقات", en: "App Top-Ups", ru: "Пополнение приложений" },
    desc: d2(
      "فرعان أساسيان: شحن التطبيقات الصوتية وشحن التطبيقات المرئية — وصول فوري بعد التأكيد.",
      "Two core branches: audio app top-ups and video app top-ups — instant access after confirmation.",
    ),
    branches: [
      { id: "u-audio", icon: "play", name: { ar: "شحن التطبيقات الصوتية", en: "Audio App Top-ups", ru: "Пополнение аудио-приложений" }, desc: d2("رزم شحن للتطبيقات الصوتية.", "Top-up packs for audio apps.") },
      { id: "u-video", icon: "play", name: { ar: "شحن التطبيقات المرئية", en: "Video App Top-ups", ru: "Пополнение видео-приложений" }, desc: d2("رزم شحن للتطبيقات المرئية والبث.", "Top-up packs for video & streaming apps.") },
    ],
  },
  {
    id: "proxy",
    code: "07",
    icon: "code",
    thumb: "/images/market/sec-proxy.jpg",
    name: { ar: "بروكسي التشفير والكورسات", en: "Proxy & Encryption", ru: "Прокси и шифрование" },
    desc: d2(
      "خمسة فروع تقنية: بروكسيات الحماية، ذكاء اصطناعي بلا قيود، مواقع وروابط D2، أكاديمية النخبة، وخدمات النخبة التقنية.",
      "Five technical branches: protection proxies, unlimited AI, D2 sites & links, the elite academy, and elite tech services.",
    ),
    branches: [
      { id: "x-proxy", icon: "shield", name: { ar: "بروكسيات الحماية والتشفير", en: "Protection Proxies", ru: "Защитные прокси" }, desc: d2("عقد مشفّرة متعددة مع تبديل تلقائي.", "Multiple encrypted nodes with auto-rotation.") },
      { id: "x-ai", icon: "code", name: { ar: "ذكاء اصطناعي (AI) بلا قيود", en: "Unlimited AI", ru: "Безлимитный ИИ" }, desc: d2("وصول لأدوات ذكاء اصطناعي بلا حدود.", "Access to unlimited AI tools.") },
      { id: "x-d2", icon: "link", name: { ar: "مواقع وروابط D2", en: "D2 Sites & Links", ru: "Сайты и ссылки D2" }, desc: d2("روابط ومواقع D2 موثقة ومحدثة.", "Verified and updated D2 sites & links.") },
      { id: "x-academy", icon: "book", name: { ar: "أكاديمية النخبة للتفريغ", en: "Elite Draining Academy", ru: "Элитная академия" }, desc: d2("كورسات متقدمة بأدلة داخلية.", "Advanced courses with internal guides.") },
      { id: "x-elite", icon: "star", name: { ar: "خدمات النخبة التقنية", en: "Elite Tech Services", ru: "Элитные технические услуги" }, desc: d2("طلبات تقنية خاصة بأعلى جودة.", "Custom tech requests at the highest quality.") },
    ],
  },
];

export const marketById = (id: string) => MARKET_SECTIONS.find((s) => s.id === id);

/* ── الهيكل الهرمي: 3 أقسام + السوق المستقل ── */
export type PageId = "arsenal" | "forum" | "support";
export type Accent = "acid" | "blood" | "violet" | "amber";

export type ContentDef =
  | { type: "products"; catId: string }
  | { type: "comingSoon" }
  | { type: "wallets" }
  | { type: "channels" }
  | { type: "managers" }
  | { type: "form"; kind: "complaint" | "exchange" | "return" | "service" }
  | { type: "posts"; items: "work" | "site" }
  | { type: "notes" }
  | { type: "opinions" }
  | { type: "drainHub" }
  | { type: "autonomous" }
  | { type: "meetings" }
  | { type: "guideList" }
  | { type: "faq" }
  | { type: "replies" }
  | { type: "link"; route: string }
  | { type: "adminForms" }
  | { type: "percentOpps" }
  | { type: "ai" }
  | { type: "checker"; kind: "card" | "address" | "data" }
  | { type: "ideas" }
  | { type: "ratings" }
  | { type: "text"; ref?: "overview" | "terms" | "privacy"; body?: L }
  | { type: "post"; id: string };

/** فرع داخلي داخل قسم (نفس نمط فروع السوق) */
export interface SubBranch {
  id: string;
  icon: string;
  name: L;
  desc: L;
  content: ContentDef;
}

export interface SectionDef {
  id: string;
  icon: string;
  name: L;
  hint?: L;
  desc?: L;
  content: ContentDef;
  /** قسم به فروع داخلية (يفتح عرض فروع بدل الدرج) */
  branches?: SubBranch[];
}

export interface PageDef {
  id: PageId;
  route: string;
  icon: string;
  accent: Accent;
  hero: string;
  name: L;
  short: L;
  about: L;
  sections: SectionDef[];
}

const toolName = (n: number): L => ({
  ar: `أداة ${["٠١", "٠٢", "٠٣", "٠٤", "٠٥", "٠٦", "٠٧", "٠٨", "٠٩", "١٠"][n - 1]}`,
  en: `Tool ${String(n).padStart(2, "0")}`,
  ru: `Инструмент ${String(n).padStart(2, "0")}`,
});

/* ═══ القسم التقني الذاتي والخدمات الأمنية — Autonomous Section ═══ */
/**
 * ملف إعدادات مستقل 100%: أضف/عدّل أي خدمة أو أتمتة أو فحص
 * من هنا فقط — الواجهة تقرأ القائمة مباشرة دون تعديل الكود.
 */
export interface AutoServiceDef {
  id: string;
  icon: string;
  state: "active" | "standby" | "beta";
  name: L;
  desc: L;
  detail: L;
}

export const AUTONOMOUS_SERVICES: AutoServiceDef[] = [
  {
    id: "au-net",
    icon: "shield",
    state: "active",
    name: { ar: "عزل الشبكة الذاتي", en: "Autonomous Network Isolation", ru: "Автономная изоляция сети" },
    desc: { ar: "فصل تلقائي لجلسة العمل عن الشبكة العامة وتوجيهها عبر عقد مشفّرة دون تدخل يدوي.", en: "Automatic separation of the work session from the public network, routed through encrypted nodes without manual input.", ru: "Автоматическое отделение рабочей сессии от публичной сети через зашифрованные узлы." },
    detail: { ar: "الوحدة تعمل فور دخولك المنطقة: تعزل الكوكيز وبصمة المتصفح، وتُدير تبديل العقد كل 90 ثانية، وتُسجّل أي محاولة كشف في سجل داخلي مشفّر. الحالة: نشطة على كل الجلسات.", en: "The unit activates the moment you enter the zone: isolates cookies and browser fingerprint, rotates nodes every 90 seconds, and logs any detection attempt into an encrypted internal journal. Status: active on all sessions.", ru: "Модуль запускается при входе: изолирует кукис и отпечаток, ротирует узлы каждые 90 секунд, журналирует попытки обнаружения. Статус: активен." },
  },
  {
    id: "au-scan",
    icon: "code",
    state: "active",
    name: { ar: "الفحص الأمني الآلي", en: "Automated Security Sweep", ru: "Автоматическая проверка безопасности" },
    desc: { ar: "فحص مستمر للروابط والملفات والبيانات قبل عرضها داخل المنصة.", en: "Continuous scanning of links, files, and data before they surface inside the platform.", ru: "Непрерывная проверка ссылок, файлов и данных до показа внутри платформы." },
    detail: { ar: "محرك فحص ذاتي يمر على كل رابط وارد وكل ملف مرفوع: يطابق البصمات المعروفة، يكشف الروابط المزيفة، ويمنع أي وصول خارج القنوات الرسمية. التقرير النهائي يُرفع للإدارة تلقائياً.", en: "A self-driven engine reviews every inbound link and uploaded file: matches known fingerprints, detects spoofed links, and blocks any access outside official channels. The final report is delivered to admin automatically.", ru: "Движок проверяет каждую ссылку и файл: сопоставляет отпечатки, выявляет поддельные ссылки, блокирует доступ вне официальных каналов. Отчёт уходит админу автоматически." },
  },
  {
    id: "au-ai",
    icon: "terminal",
    state: "beta",
    name: { ar: "الاستجابة الذاتية للحوادث", en: "Autonomous Incident Response", ru: "Автономное реагирование" },
    desc: { ar: "استجابة تلقائية لأي خلل أو محاولة اختراق مع عزل فوري وتنبيه الإدارة.", en: "Automatic response to any fault or intrusion attempt with instant isolation and admin alerting.", ru: "Автоматический ответ на любой сбой или попытку взлома с мгновенной изоляцией и оповещением." },
    detail: { ar: "عند رصد أي سلوك غير معتاد تُجمَّد الجلسة تلقائياً، يُعاد توجيهها لعقدة نظيفة، وتُرسل إشعار داخل الموقع + تنبيه لمسؤول الموقع عبر تليجرام خلال ثوانٍ. الوحدة حالياً في طور الاختبار (BETA).", en: "On any unusual behaviour the session is frozen automatically, rerouted to a clean node, and an in-site notification plus a Telegram alert reach the manager within seconds. Currently in BETA.", ru: "При аномалии сессия замораживается, перенаправляется на чистый узел, уведомление уходит в Telegram за секунды. Сейчас BETA." },
  },
  {
    id: "au-vault",
    icon: "lock",
    state: "active",
    name: { ar: "خزنة المفاتيح المشفّرة", en: "Encrypted Key Vault", ru: "Зашифрованное хранилище ключей" },
    desc: { ar: "إدارة مفاتيح الجلسات والمحافظ داخل خزنة مشفّرة بصلاحيات محدودة.", en: "Managing session and wallet keys inside an encrypted, least-privilege vault.", ru: "Управление ключами сессий и кошельков в зашифрованном хранилище." },
    detail: { ar: "لا تُحفظ أي كلمة مرور أو عنوان محفظة بصورة مقروءة؛ تُجزّأ المفاتيح وتُشفَّر AES-256-GCM مع تدوير دوري، ولا تُفتح إلا بطلب من الإدارة أو عند إتمام الدفع الآمن.", en: "No password or wallet address is stored readably: keys are split, AES-256-GCM encrypted, rotated periodically, and unlocked only by admin request or on secure checkout completion.", ru: "Пароли и адреса не хранятся в открытом виде: ключи разделены, зашифрованы AES-256-GCM, ротируются, открываются только админом или при оплате." },
  },
  {
    id: "au-monitor",
    icon: "eye",
    state: "standby",
    name: { ar: "مراقبة السلامة والجاهزية", en: "Integrity & Uptime Monitor", ru: "Мониторинг целостности" },
    desc: { ar: "مراقبة حالة القنوات والخدمات على مدار الساعة مع مؤشر جاهزية لحظي.", en: "24/7 monitoring of channels and services with a live readiness indicator.", ru: "Круглосуточный мониторинг каналов и сервисов с живым индикатором готовности." },
    detail: { ar: "لوحة جاهزية تتابع حالة كل قسم (نشط / احتياطي / اختبار) وتُحدَّث عند أي صيانة. الوحدة في وضع الاحتياطي وتُفعَّل تلقائياً عند أول تنبيه صيانة.", en: "A readiness board tracks every section state (active / standby / beta) and updates on maintenance. The unit is on standby and auto-activates at the first maintenance alert.", ru: "Панель готовности отслеживает состояние разделов и обновляется при обслуживании. В резерве, активируется при первом алерте." },
  },
];


export const PAGES: Record<PageId, PageDef> = {
  /* 2 — التشفير وأدوات التفريغ: 10 أقسام فرعية */
  arsenal: {
    id: "arsenal",
    route: "/arsenal",
    icon: "tool",
    accent: "blood",
    hero: "/images/ads/ad-2.jpg",
    name: { ar: "التشفير وأدوات التفريغ", en: "Encryption & Draining Tools", ru: "Шифрование и инструменты" },
    short: { ar: "الترسانة", en: "Arsenal", ru: "Арсенал" },
    about: {
      ar: "المستودع التقني: عشرة خانات مخصصة لأدوات تفريغ وتشفير متخصصة. يُضاف اسم وشرح كل أداة في المرحلة الثانية، وكل أداة تأتي مع دليل استخدام داخلها.",
      en: "The technical vault: ten dedicated slots for specialized draining & encryption tools. Each tool's name and usage guide lands in Phase 2.",
      ru: "Технический хранилище: десять слотов для специализированных инструментов. Названия и гайды добавятся во второй фазе.",
    },
    sections: Array.from({ length: 10 }, (_, i) => ({
      id: `tool-${i + 1}`,
      icon: "tool" as string,
      name: toolName(i + 1),
      content: { type: "comingSoon" } as ContentDef,
    })),
  },

  /* 3 — المنتدى والمجتمع: 5 أقسام فرعية */
  forum: {
    id: "forum",
    route: "/forum",
    icon: "chat",
    accent: "violet",
    hero: "/images/ads/ad-2.jpg",
    name: { ar: "المنتدى والمجتمع", en: "Forum & Community", ru: "Форум и сообщество" },
    short: { ar: "المنتدى", en: "Forum", ru: "Форум" },
    about: {
      ar: "ساحة العمل: هَب لودر التفريغ والاستقبال، لوحة طلبات الخدمات التقنية والميدانية، العمل بالنسبة والعمولات، وتنسيق المقابلات.",
      en: "The work square: DRAIN & LOADER HUB, the technical & field service requests board, percent & affiliate work, and meeting coordination.",
      ru: "Рабочая площадь: хабы слива и приёма, доска запросов услуг, работа по проценту и координация встреч.",
    },
    sections: [
      { id: "f-drain", icon: "code", name: { ar: "لودر التفريغ والاستقبال", en: "DRAIN & LOADER HUB", ru: "Хаб слива и приёма" }, content: { type: "drainHub" } },
      { id: "f-service", icon: "gear", name: { ar: "طلب الخدمات التقنية والميدانية", en: "Service Requests Board", ru: "Доска запросов услуг" }, content: { type: "form", kind: "service" } },
      { id: "f-autonomous", icon: "shield", name: { ar: "القسم التقني الذاتي والخدمات الأمنية", en: "Autonomous Section", ru: "Автономный техотдел" }, desc: d2("وحدة مستقلة للخدمات الأمنية الذاتية: عزل الشبكة، الفحص الآلي، الاستجابة للحوادث، خزنة المفاتيح، ومراقبة الجاهزية.", "A standalone unit for autonomous security services: network isolation, automated sweeps, incident response, key vault, and uptime monitoring.", "Автономный блок: изоляция сети, автопроверки, реагирование, хранилище ключей, мониторинг."), content: { type: "autonomous" } },
      { id: "f-percent", icon: "coin", name: { ar: "العمل بالنسبة", en: "Percent & Affiliate Work", ru: "Работа по проценту" }, content: { type: "posts", items: "work" } },
      { id: "f-meet", icon: "user", name: { ar: "تنسيق المقابلات", en: "Meeting Coordination", ru: "Координация встреч" }, content: { type: "meetings" } },
    ],
  },

  /* 4 — الدعم والإرشادات: 10 أقسام رئيسية (بعضها بفروع داخلية) */
  support: {
    id: "support",
    route: "/support",
    icon: "headset",
    accent: "amber",
    hero: "/images/ads/ad-1.jpg",
    name: { ar: "الدعم والإرشادات", en: "Support & Guides", ru: "Поддержка и гайды" },
    short: { ar: "الدعم", en: "Support", ru: "Поддержка" },
    about: {
      ar: "عشرة ممرات متكاملة: الدفع، الشكاوى والدعم، فرص العمل بالنسبة، تنسيق المقابلات في خمس مدن، الأسئلة الشائعة، مساعد Black Mart AI، أدوات الفحص التفاعلية، الإرشادات والآراء، النبذة، والأخبار والتحديثات.",
      en: "Ten unified corridors: payment, complaints & support, percent & affiliate work, meeting coordination across five cities, FAQ, the Black Mart AI assistant, interactive check tools, guidelines & opinions, about, and news & updates.",
      ru: "Десять коридоров: оплата, жалобы, работа по проценту, координация встреч в пяти городах, FAQ, ИИ-ассистент, интерактивные чекеры, правила, о платформе и новости.",
    },
    sections: [
      {
        id: "sup-pay", icon: "wallet", name: { ar: "طرق الدفع", en: "Payment", ru: "Оплата" },
        desc: d2("يرتبط مباشرة بصفحة طرق الدفع الأصلية: المحافظ، الشروحات، والقنوات الرسمية.", "Links directly to the original payment page: wallets, guides, and official channels.", "Переход на оригинальную страницу оплаты."),
        content: { type: "link", route: "/pay" },
      },
      {
        id: "sup-complaints", icon: "warn", name: { ar: "الشكاوى والدعم", en: "Complaints & Support", ru: "Жалобы и поддержка" },
        desc: d2("شكاوى، استبدال، واسترجاع — كل طلب يصل الإدارة ويُتابع عبر تليجرام برقم مرجعي.", "Complaints, exchange, and returns — every ticket reaches the admin and is tracked on Telegram with a reference number."),
        content: { type: "adminForms" },
      },
      {
        id: "sup-faq", icon: "chat", name: { ar: "الأسئلة الشائعة", en: "FAQ", ru: "FAQ" },
        desc: d2("استعراض شامل لخدمات المنتدى وأدوات التفريغ والسوق — نظام Accordion منسدل.", "A comprehensive look at forum services, draining tools, and the market — accordion system."),
        content: { type: "faq" },
      },
      {
        id: "sup-ai", icon: "code", name: { ar: "Black Mart AI", en: "Black Mart AI", ru: "Black Mart AI" },
        desc: d2("مساعد تلقائي: شرائح أسئلة عامة ودليل، وأزرار وصول سريع لكل الأقسام والخدمات.", "An auto-reply assistant: general question & guide chips, plus quick-access buttons to every section and service."),
        content: { type: "ai" },
      },
      {
        id: "sup-tools", icon: "shield", name: { ar: "أدوات الفحص", en: "Check Tools", ru: "Инструменты проверки" },
        desc: d2("ثلاثة فواحص تفاعلية: البطاقات، العناوين، والبيانات — نتيجة لحظية قبل أي شراء.", "Three interactive checkers: cards, addresses, and data — instant results before any purchase."),
        content: { type: "comingSoon" },
        branches: [
          { id: "chk-card", icon: "card", name: { ar: "فحص البطاقات", en: "Card Checker", ru: "Card Checker" }, desc: d2("فحص حالة البطاقة وBIN ورصيدها قبل الشراء.", "Check card state, BIN, and balance before buying."), content: { type: "checker", kind: "card" } },
          { id: "chk-address", icon: "link", name: { ar: "فحص العناوين", en: "Address Checker", ru: "Address Checker" }, desc: d2("مطابقة الاسم والعنوان الوطني (AVS) لأي عنوان.", "Match name and national address (AVS) for any entry."), content: { type: "checker", kind: "address" } },
          { id: "chk-data", icon: "code", name: { ar: "فحص البيانات", en: "Data Validator", ru: "Data Validator" }, desc: d2("تحقق من صحة الإيميلات والأرقام وسن البيانات.", "Validate emails, numbers, and data age."), content: { type: "checker", kind: "data" } },
        ],
      },
      {
        id: "sup-guidelines", icon: "shield", name: { ar: "الإرشادات الأمنية", en: "Security Guidelines", ru: "Правила безопасности" },
        desc: d2("مجموعة الإرشادات والتوصيات الأمنية لحماية حساباتك ومعاملاتك الرقمية لضمان أعلى مستويات الأمان والسرية.", "Security guidelines and recommendations to protect your accounts and digital transactions."),
        content: { type: "comingSoon" },
        branches: [
          { id: "gl-rules", icon: "book", name: { ar: "دليل قواعد المنظومة", en: "Platform Guidelines", ru: "Правила платформы" }, desc: d2("القواعد الحاكمة للتجوال الآمن داخل المنصة.", "The rules governing safe navigation inside the platform."), content: { type: "guideList" } },
          { id: "gl-ideas", icon: "send", name: { ar: "صندوق الأفكار والمقترحات", en: "Submit Ideas", ru: "Ящик идей" }, desc: d2("قناة مفتوحة من عندك إلى إدارة المنصة مباشرة.", "An open channel from you straight to platform administration."), content: { type: "ideas" } },
          { id: "gl-ratings", icon: "star", name: { ar: "تقييم الخدمات واستطلاع الآراء", en: "Platform Ratings", ru: "Рейтинги платформы" }, desc: d2("قيّم المنصة وخدماتها بالنجوم — يُعرض بعد مراجعة الإدارة.", "Rate the platform and its services — displayed after admin review."), content: { type: "ratings" } },
        ],
      },
      {
        id: "sup-about", icon: "lock", name: { ar: "النبذة", en: "About", ru: "О платформе" },
        desc: d2("عن المنظومة والتزاماتنا، شروط الخدمة، وسياسة الخصوصية والأمان.", "Overview & commitments, terms of service, and the privacy & anonymity policy."),
        content: { type: "comingSoon" },
        branches: [
          { id: "ab-overview", icon: "shield", name: { ar: "عن المنظومة والتزاماتنا", en: "Overview & Commitments", ru: "О платформе и обязательства" }, desc: d2("ما نقدمه وما نلتزم به تجاه كل عضو.", "What we offer and our commitments to every member."), content: { type: "text", ref: "overview" } },
          { id: "ab-terms", icon: "book", name: { ar: "شروط الخدمة", en: "Terms of Service", ru: "Условия сервиса" }, desc: d2("الشروط الحاكمة لاستخدام المنصة والدفع داخلها.", "The terms governing platform use and payment."), content: { type: "text", ref: "terms" } },
          { id: "ab-privacy", icon: "lock", name: { ar: "سياسة الخصوصية والأمان", en: "Privacy & Anonymity Policy", ru: "Политика приватности" }, desc: d2("كيف نحافظ على هويتك وسلامتك الرقمية.", "How we protect your identity and digital safety."), content: { type: "text", ref: "privacy" } },
        ],
      },
      {
        id: "sup-news", icon: "megaphone", name: { ar: "الإعلانات والتحديثات", en: "News & Updates", ru: "Новости и обновления" },
        desc: d2("خمسة منشورات رسمية: سياسة المقابلات، الترويج مقابل نسبة، تعليمات الطلب، توثيق المعاملات، وعرض المنصة.", "Five official posts: meeting policy, promotion-for-percent, order instructions, verification, and platform overview."),
        content: { type: "comingSoon" },
        branches: [
          { id: "nw1", icon: "megaphone", name: { ar: "[01] سياسة تنسيق المقابلات", en: "[01] Meeting Coordination Policy", ru: "[01] Политика встреч" }, desc: d2("منظمة المقابلات في المدن المعتمدة.", "The organization of meetings in approved cities."), content: { type: "post", id: "nw1" } },
          { id: "nw2", icon: "megaphone", name: { ar: "[02] آلية الترويج مقابل نسبة", en: "[02] Promotion-for-Percent", ru: "[02] Продвижение за процент" }, desc: d2("كيف تعمل نسب الترويج ودورية دفعها.", "How promotion rates work and their payout cycle."), content: { type: "post", id: "nw2" } },
          { id: "nw3", icon: "megaphone", name: { ar: "[03] تعليمات إتمام الطلب", en: "[03] Order Completion", ru: "[03] Завершение заказа" }, desc: d2("خطوات إتمام الطلب من الدفع حتى التسليم.", "Order steps from payment to delivery."), content: { type: "post", id: "nw3" } },
          { id: "nw4", icon: "megaphone", name: { ar: "[04] توثيق المعاملات والقنوات", en: "[04] Verification & Channels", ru: "[04] Верификация и каналы" }, desc: d2("القنوات الرسمية وحماية المعاملات.", "Official channels and transaction protection."), content: { type: "post", id: "nw4" } },
          { id: "nw5", icon: "megaphone", name: { ar: "[05] ماذا يقدم موقع Black Mart", en: "[05] What Black Mart Offers", ru: "[05] Что предлагает" }, desc: d2("عرض شامل لمنظومة المنصة كاملة.", "A full overview of the whole platform."), content: { type: "post", id: "nw5" } },
        ],
      },
    ],
  },
};

/* ── الدفع الآمن المستقل: مسؤول الطلب + عناوين المحافظ ── */
export const BUY_MANAGER = "k22zzo"; // @k22zzo
export const PAY_WALLET: Record<"usdt" | "btc", { name: string; network: string; address: string }> = {
  usdt: { name: "USDT", network: "TRC20", address: "TQmBxMARKETdemo0001TRC20x9" },
  btc: { name: "Bitcoin", network: "BTC", address: "bc1qmarketdemo00000000000000x9k22" },
};

/* ── الأقسام الرئيسية الأربعة (الرئيسية + التبويبات + البحث) ── */
export interface HomeSectionDef {
  id: string;
  route: string;
  icon: string;
  name: L;
  short: L;
  accent: Accent;
  count: number;
  thumb?: string;
}

export const HOME_SECTIONS: HomeSectionDef[] = [
  {
    id: "market",
    route: "/market",
    icon: "bag",
    name: { ar: "سوق الكاردنق", en: "The Carding Market", ru: "Картинг-маркет" },
    short: { ar: "السوق", en: "Market", ru: "Маркет" },
    accent: "acid",
    count: MARKET_SECTIONS.length,
    thumb: "/images/market/sec-cards.jpg",
  },
  {
    id: "arsenal",
    route: "/arsenal",
    icon: "tool",
    name: PAGES.arsenal.name,
    short: PAGES.arsenal.short,
    accent: "blood",
    count: PAGES.arsenal.sections.length,
    thumb: "/images/ads/ad-2.jpg",
  },
  {
    id: "forum",
    route: "/forum",
    icon: "chat",
    name: PAGES.forum.name,
    short: PAGES.forum.short,
    accent: "violet",
    count: PAGES.forum.sections.length,
    thumb: "/images/ads/ad-2.jpg",
  },
  {
    id: "support",
    route: "/support",
    icon: "headset",
    name: PAGES.support.name,
    short: PAGES.support.short,
    accent: "amber",
    count: PAGES.support.sections.length,
    thumb: "/images/ads/ad-1.jpg",
  },
];

export const MARKET_NAME: L = { ar: "سوق الكاردنق", en: "The Carding Market", ru: "Картинг-маркет" };

/* ── الألوان حسب القسم ── */
export const ACCENT: Record<Accent, { text: string; border: string; bg: string; glow: string }> = {
  acid: { text: "text-acid", border: "border-acid/40", bg: "bg-acid/10", glow: "group-hover:shadow-[0_0_30px_rgba(184,239,128,0.12)]" },
  blood: { text: "text-blood", border: "border-blood/40", bg: "bg-blood/10", glow: "group-hover:shadow-[0_0_30px_rgba(232,123,125,0.12)]" },
  violet: { text: "text-violet", border: "border-violet/40", bg: "bg-violet/10", glow: "group-hover:shadow-[0_0_30px_rgba(163,139,243,0.12)]" },
  amber: { text: "text-amber", border: "border-amber/40", bg: "bg-amber/10", glow: "group-hover:shadow-[0_0_30px_rgba(232,178,112,0.12)]" },
};

/* ── المحافظ ─ */
export interface WalletDef { id: string; name: string; network?: string; explain: L }
export const WALLETS: WalletDef[] = [
  { id: "usdt", name: "USDT", network: "TRC20 / BEP20", explain: { ar: "أرسل TRC20 إلى محفظة المسؤول وأرفق لائحة الإرسال. لا تُرسل شبكات أخرى دون تنسيق.", en: "Send TRC20 to the manager's wallet and attach the receipt. Do not send other networks without coordination.", ru: "Отправьте TRC20 на кошелёк менеджера и приложите чек." } },
  { id: "btc", name: "Bitcoin (BTC)", network: "BTC", explain: { ar: "يدعم التحويل بـ BTC مع رسوم الشبكة. تأكد من عدد التأكيدات قبل إرسال الإيصال.", en: "BTC transfers supported with network fees. Confirm confirmations before sending the receipt.", ru: "Переводы в BTC с учётом комиссий сети." } },
  { id: "zcash", name: "Z Cash", network: "ZCASH", explain: { ar: "خيار الدفع المشفّر بالكامل. اطلب المحفظة من المسؤول عند الطلب.", en: "Fully encrypted payment option. Request the wallet from the manager at order time.", ru: "Полностью зашифрованный способ оплаты." } },
  { id: "stc", name: "STC Pay", network: "محفظة إلكترونية", explain: { ar: "دفع محلي سريع — يُحجز الطلب خلال دقائق من تأكيد الإيصال.", en: "Fast local payment — the order is reserved within minutes of receipt confirmation.", ru: "Быстрая локальная оплата." } },
  { id: "fawr", name: "مدى / فوري", network: "تحويل بنكي", explain: { ar: "يُقبل تحويل بنكي مباشر. أرسل صورة التحويل للتحقق فوراً.", en: "Direct bank transfer accepted. Send the transfer screenshot for instant verification.", ru: "Прямой банковский перевод." } },
];

/* ── القنوات ── */
export interface ChannelDef { id: string; name: L; handle: string; url: string }
export const CHANNELS: ChannelDef[] = [
  { id: "main", name: { ar: "القناة الرئيسية", en: "Main channel", ru: "Основной канал" }, handle: "@BlackMart_Main", url: "https://t.me/BlackMart_Main" },
  { id: "offers", name: { ar: "قناة العروض", en: "Offers channel", ru: "Канал акций" }, handle: "@BlackMart_Offers", url: "https://t.me/BlackMart_Offers" },
  { id: "help", name: { ar: "قناة الدعم", en: "Support channel", ru: "Канал поддержки" }, handle: "@BlackMart_Help", url: "https://t.me/BlackMart_Help" },
];

/* ── المسؤولون ── */
export interface ManagerDef { id: string; role: L; user: string; url: string; explain: L }
export const MANAGERS: ManagerDef[] = [
  { id: "admin", role: { ar: "المسؤول العام", en: "General manager", ru: "Главный менеджер" }, user: "@BlackMart_Admin", url: "https://t.me/BlackMart_Admin", explain: { ar: "المخوّل بفتح أي قضية داخل المنطقة.", en: "Authorized to open any case inside the zone.", ru: "Полномочия по всем вопросам." } },
  { id: "support", role: { ar: "مسؤول الدعم الفني", en: "Technical support", ru: "Техническая поддержка" }, user: "@BlackMart_Support", url: "https://t.me/BlackMart_Support", explain: { ar: "استقبال الطلبات ومتابعتها لحظياً.", en: "Order intake and live follow-up.", ru: "Приём и отслеживание заказов." } },
  { id: "deliver", role: { ar: "مسؤول التسليم", en: "Delivery officer", ru: "Оператор выдачи" }, user: "@BlackMart_Ship", url: "https://t.me/BlackMart_Ship", explain: { ar: "تسليم الطلبات بعد تأكيد الدفع.", en: "Delivers orders after payment confirmation.", ru: "Выдача заказов после оплаты." } },
];

/* ── جدول المقابلات — المدن المعتمدة: الرياض، دبي، تكساس، موسكو، برلين ── */
export interface MeetingDef { id: string; when: string; city: L; topic: L; host: string }
export const MEETINGS: MeetingDef[] = [
  { id: "m1", when: "2026-03-07 · 21:00 GMT", city: { ar: "الرياض", en: "Riyadh", ru: "Эр-Рияд" }, topic: { ar: "تنسيق باعة المرحلة الثانية", en: "Phase 2 sellers coordination", ru: "Координация продавцов фазы 2" }, host: "BlackMart_Admin" },
  { id: "m2", when: "2026-03-09 · 22:00 GMT", city: { ar: "دبي", en: "Dubai", ru: "Дубай" }, topic: { ar: "ندوة الصفقات الكبرى الميدانية", en: "Major field deals briefing", ru: "Брифинг крупных сделок" }, host: "BlackMart_Support" },
  { id: "m3", when: "2026-03-12 · 20:00 GMT", city: { ar: "تكساس", en: "Texas", ru: "Техас" }, topic: { ar: "اجتماع مسؤولي النسب والعمولات", en: "Affiliate & percent managers meeting", ru: "Встреча менеджеров по процентам" }, host: "BlackMart_Admin" },
  { id: "m4", when: "2026-03-15 · 23:00 GMT", city: { ar: "موسكو", en: "Moscow", ru: "Москва" }, topic: { ar: "تنسيق الصفقات الميدانية الشرقية", en: "Eastern field deals coordination", ru: "Координация восточных сделок" }, host: "BlackMart_Support" },
  { id: "m5", when: "2026-03-18 · 19:00 GMT", city: { ar: "برلين", en: "Berlin", ru: "Берлин" }, topic: { ar: "دورة التوثيق والأمان الأوروبي", en: "EU verification & security session", ru: "Семинар верификации и безопасности" }, host: "BlackMart_Admin" },
];

/* ── منشورات العمل ── */
export interface PostDef { id: string; date: string; title: L; body: L }
export const WORK_POSTS: PostDef[] = [
  { id: "wp1", date: "02.03.2026", title: { ar: "نبحث عن مسوّقين معتمدين", en: "Looking for approved marketers", ru: "Ищем сертифицированных маркетологов" }, body: { ar: "فرصة تعاون لروابط التحويل داخل المنصات الاجتماعية. الشروط: سجل نظيف، التزام بالجدولة، والتقرير الأسبوعي إلزامي.", en: "Collaboration opportunity for referral links across social platforms. Requirements: clean record, schedule discipline, weekly reports.", ru: "Сотрудничество по реферальным ссылкам. Требования: чистая история, соблюдение графика, еженедельные отчёты." } },
  { id: "wp2", date: "27.02.2026", title: { ar: "توسعة فريق الدعم الليلي", en: "Night support team expansion", ru: "Расширение ночной поддержки" }, body: { ar: "مطلوب أعضاء لتغطية الفترة من 12:00 حتى 06:00. أولوية لمن لديه خبرة سابقة في غرف الدعم.", en: "Members needed to cover 00:00–06:00. Priority for those with prior support-room experience.", ru: "Нужны участники на смену 00:00–06:00. Приоритет опытным." } },
  { id: "wp3", date: "19.02.2026", title: { ar: "مشروع ترجمة الشروحات", en: "Guide translation project", ru: "Проект перевода гайдов" }, body: { ar: "مبادرة لترجمة شروحات الدفع والإرشادات إلى لغات المنطقة الجديدة — الترجمات تُراجَع قبل النشر.", en: "A drive to translate payment guides and site guidelines into the zone's new languages — translations are reviewed before publishing.", ru: "Перевод гайдов оплаты и правил на новые языки — перед публикацией ревью." } },
];

/* ── إعلانات المنصة ── */
export const SITE_POSTS: PostDef[] = [
  { id: "sp1", date: "03.03.2026", title: { ar: "المرحلة الثانية قريباً", en: "Phase 2 coming soon", ru: "Вторая фаза скоро" }, body: { ar: "منتجات تفصيلية كاملة، شروحات داخل كل قسم، وروابط مباشرة — الهيكل جاهز والبناء جارٍ.", en: "Full detailed products, in-section guides, and direct links — the structure is ready, construction ongoing.", ru: "Полный каталог, гайды в разделах и прямые ссылки — каркас готов." } },
  { id: "sp2", date: "01.03.2026", title: { ar: "تحديث نظام الإشعارات", en: "Notification system update", ru: "Обновление уведомлений" }, body: { ar: "أصبح بإمكانك متابعة العروض والتحديثات من جرس الإشعارات مباشرة داخل الموقع.", en: "Follow offers and updates straight from the in-site notification bell.", ru: "Акции и обновления теперь в колокольчике уведомлений." } },
  { id: "sp3", date: "28.02.2026", title: { ar: "إطلاق وضع التخفّي", en: "Stealth mode launched", ru: "Запущен режим невидимки" }, body: { ar: "اضغط ESC في أي لحظة لإخفاء الموقع فوراً خلف شاشة عابرة — راحة البال ميزة أساسية.", en: "Hit ESC at any moment to instantly mask the site behind a transient screen — peace of mind is a core feature.", ru: "ESC в любой момент мгновенно скрывает сайт за перехватной страницей." } },
];

/* ── النبذات ── */
export const NOTES: PostDef[] = [
  { id: "n1", date: "03.03.2026", title: { ar: "ما معنى شارة «موثّق»؟", en: "What does the Verified badge mean?", ru: "Что значит значок «Подтверждено»?" }, body: { ar: "الخدمات الموثقة هي التي اختبرتها الإدارة شخصياً أو أكّدها مزوّد معتمد. لا تدفع خارج المنصة أبداً.", en: "Verified services are ones the admin personally tested or an approved supplier confirmed. Never pay outside the platform.", ru: "Подтверждённые услуги — те, что протестированы админом или одобренным поставщиком." } },
  { id: "n2", date: "02.03.2026", title: { ar: "لماذا عدّادات المشاهدات ظاهرة؟", en: "Why are view counters visible?", ru: "Почему счётчики просмотров открыты?" }, body: { ar: "الشفافية أداة ثقة: عدّاد المشاهدات والطلبات يُحدَّث فورياً ليقيّم الجميع حركة السوق بنفسه.", en: "Transparency builds trust: view and order counters update live so everyone gauges market movement themselves.", ru: "Прозрачность — инструмент доверия: счётчики обновляются в реальном времени." } },
  { id: "n3", date: "29.02.2026", title: { ar: "سياسة التصفح الآمن", en: "Safe browsing policy", ru: "Политика безопасного просмотра" }, body: { ar: "يُنصح بإخلاء الكوكيز خارج المنطقة، واستخدام المتصفح المخصّص للموقع، وعدم فتح الروابط من مصادر غير رسمية.", en: "We recommend clearing cookies outside the zone, using a dedicated browser for the site, and never opening links from unofficial sources.", ru: "Рекомендуем чистить кукис вне зоны, использовать отдельный браузер и не открывать неофициальные ссылки." } },
];

/* ── إرشادات ── */
export const GUIDE_ITEMS: { id: string; title: L; body: L }[] = [
  { id: "g1", title: { ar: "البدء: اختر لغتك ثم ادخل", en: "Getting started: pick a language, then enter", ru: "Старт: выберите язык и войдите" }, body: { ar: "شاشة اللغة هي البوابة الوحيدة. اختيارك يُحفظ ويُطبَّق على كل النصوص والاتجاه تلقائياً.", en: "The language screen is the only gate. Your choice is saved and applied to every text and direction automatically.", ru: "Экран языка — единственный вход. Выбор сохраняется и применяется автоматически." } },
  { id: "g2", title: { ar: "التحقق قبل الدفع", en: "Verify before paying", ru: "Проверяйте перед оплатой" }, body: { ar: "شاهد شارة التوثيق وعدّاد الطلبات. أي طلب يتم فقط عبر المحافظ المعتمدة في قسم طرق الدفع.", en: "Check the Verified badge and the order counter. Orders are only taken via approved wallets in the Payment section.", ru: "Смотрите значок подтверждения и счётчик заказов. Оплата только через одобренные кошельки." } },
  { id: "g3", title: { ar: "الإيصال إلزامي", en: "Receipts are mandatory", ru: "Чек обязателен" }, body: { ar: "بعد أي تحويل أرسل لائحة الإرسال فوراً إلى مسؤول الدفع — بدون إيصال لا يُفتح طلب.", en: "After any transfer, send the receipt to the payment manager immediately — no receipt, no order.", ru: "После перевода сразу отправьте чек менеджеру — без чека заказ не открывается." } },
  { id: "g4", title: { ar: "المتابعة عبر تليجرام", en: "Follow-up via Telegram", ru: "Связь через Telegram" }, body: { ar: "كل التفاعلات (شكاوى، استبدال، استرجاع، آراء) تُتابع رقمياً برقم مرجعي يصلك في تليجرام.", en: "All interactions (complaints, exchange, return, opinions) are tracked with a reference number delivered on Telegram.", ru: "Все обращения отслеживаются с референсным номером в Telegram." } },
  { id: "g5", title: { ar: "وضع التخفّي في المواقف الحساسة", en: "Stealth mode in sensitive situations", ru: "Режим невидимки в критичных ситуациях" }, body: { ar: "زر ESC (أو زر العين في الشريط العلوي) يخفي الموقع فوراً. تعود بضغطة واحدة على نقطة التفعيل.", en: "ESC (or the eye button in the top bar) masks the site instantly. Tap the activation dot to return.", ru: "ESC (или кнопка-глаз в шапке) мгновенно скрывает сайт. Вернитесь тапом по точке активации." } },
];

/* ── أسئلة شائعة ── */
export const FAQS: { id: string; q: L; a: L }[] = [
  { id: "f1", q: { ar: "كيف أضيف منتجاً إلى المفضلة؟", en: "How do I add a product to my wishlist?", ru: "Как добавить товар в избранное?" }, a: { ar: "اضغط زر القلب في أي بطاقة منتج — يُحفظ فورياً ويعود معك في زياراتك التالية.", en: "Tap the heart on any product card — saved instantly and it returns on your next visit.", ru: "Нажмите на сердце на карточке товара — сохранится и будет ждать вас." } },
  { id: "f2", q: { ar: "ما طرق الدفع المقبولة؟", en: "What payment methods are accepted?", ru: "Какие способы оплаты принимаются?" }, a: { ar: "USDT (TRC20/BEP20)، Bitcoin، Z Cash، STC Pay، وتحويل بنكي مباشر — التفاصيل والشروحات في قسم طرق الدفع.", en: "USDT (TRC20/BEP20), Bitcoin, Z Cash, STC Pay, and direct bank transfer — details in the Payment section.", ru: "USDT (TRC20/BEP20), Bitcoin, Z Cash, STC Pay и прямой банковский перевод — детали в разделе оплаты." } },
  { id: "f3", q: { ar: "كم يستغرق تنفيذ الطلب؟", en: "How long does order fulfilment take?", ru: "Сколько времени занимает выполнение заказа?" }, a: { ar: "يُفتح الطلب بعد تأكيد الإيصال، والتسليم المعتاد خلال 15 دقيقة إلى 3 ساعات حسب الخدمة.", en: "The order opens after receipt confirmation; typical delivery is 15 minutes to 3 hours depending on the service.", ru: "Заказ открывается после чека; обычно выдача от 15 минут до 3 часов." } },
  { id: "f4", q: { ar: "هل يمكنني الاسترجاع؟", en: "Can I request a return?", ru: "Можно ли вернуть услугу?" }, a: { ar: "نعم — عبر قسم الدعم > الاسترجاع. يُقبل الاسترجاع إذا لم يسلَّم المحتوى بعد التحويل.", en: "Yes — via Support > Return. Returns are accepted when content has not been delivered yet.", ru: "Да — через Поддержка > Возврат. Возврат принимается, если контент ещё не выдан." } },
  { id: "f5", q: { ar: "كيف أتواصل مع المسؤول مباشرة؟", en: "How do I contact the manager directly?", ru: "Как связаться с менеджером напрямую?" }, a: { ar: "زر الدعم في الشريط العلوي يفتح محادثة تليجرام مع خدمة العملاء، وقسم الدعم يغطي الشكاوى الرسمية.", en: "The support button in the top bar opens a Telegram chat with customer service; the Support section covers formal complaints.", ru: "Кнопка поддержки в шапке открывает Telegram; раздел поддержки — для официальных жалоб." } },
  { id: "f6", q: { ar: "كيف أستخدم Black Mart AI؟", en: "How do I use Black Mart AI?", ru: "Как использовать BM AI?" }, a: { ar: "من قسم الدعم ← Black Mart AI: اختر سؤالك من شرائح الاقتراحات، أو استخدم أزرار الوصول السريع للانتقال الفوري لأي قسم.", en: "From Support → Black Mart AI: pick a question from the quick chips, or use the navigation chips to jump to any section.", ru: "Из Поддержки → BM AI: выберите вопрос из чипов или используйте кнопки быстрого перехода." } },
  { id: "f7", q: { ar: "ما هي المدن المعتمدة للمقابلات؟", en: "Which cities are approved for meetings?", ru: "Какие города одобрены для встреч?" }, a: { ar: "الرياض، دبي، تكساس، موسكو، برلين — راجع قسم تنسيق المقابلات للمواعيد والمواضيع.", en: "Riyadh, Dubai, Texas, Moscow, Berlin — see Meeting Coordination for dates and topics.", ru: "Эр-Рияд, Дубай, Техас, Москва, Берлин — смотрите Координацию встреч." } },
  { id: "f8", q: { ar: "هل أدوات الفحص فعّالة الآن؟", en: "Are the checkers live now?", ru: "Инструменты проверки уже работают?" }, a: { ar: "الفواحص الثلاثة (بطاقات، عناوين، بيانات) تعمل حالياً بنتائج تجريبية، والفحص الحقيقي يُفعَّل في المرحلة الثانية.", en: "The three checkers (cards, addresses, data) currently return demo results; live checking activates in Phase 2.", ru: "Три чекера пока возвращают демо-результаты; реальная проверка — во второй фазе." } },
  { id: "f9", q: { ar: "كيف أعمل بالنسبة؟", en: "How do I work on percent?", ru: "Как работать по проценту?" }, a: { ar: "راجع قسم الدعم ← العمل بالنسبة: شرح شامل لكل فرص العمل (سفير، مسوّق، وسيط، منشئ محتوى) ونسبها ودورية الدفع.", en: "See Support → Percent & Affiliate Work: a full overview of every opportunity (ambassador, marketer, broker, creator) with rates and payout cycles.", ru: "Смотрите Поддержка → Работа по проценту: полный обзор возможностей с комиссиями." } },
];

/* ── سجل الردود ── */
export const REPLIES: { id: string; name: string; text: L }[] = [
  { id: "r1", name: "support", text: { ar: "مستخدم لم يصله الطلب بعد 4 ساعات → جاري الفتح من جديد، التزموا بالإيصال الفوري.", en: "User whose order didn't arrive after 4h → re-opening now, always attach the receipt instantly.", ru: "Заказ не пришёл за 4 часа → перевыдаём, всегда прикрепляйте чек сразу." } },
  { id: "r2", name: "support", text: { ar: "سؤال عن شبكات USDT → TRC20 فقط حتى إشعار آخر لتقليل الرسوم.", en: "Question about USDT networks → TRC20 only until further notice to cut fees.", ru: "Вопрос о сетях USDT → пока только TRC20 для экономии на комиссиях." } },
  { id: "r3", name: "admin", text: { ar: "تم تفعيل شارة التوثيق على كل خدمة اختبرها الفريق — راقبوا البادج قبل الشراء.", en: "Verified badge activated on every service the team tested — watch the badge before buying.", ru: "Значок подтверждения теперь на каждой протестированной команде — следите за бейджем." } },
];

/* ── فرص العمل بالنسبة ── */
export const PERCENT_OPPS: { id: string; title: L; body: L; bonus: string }[] = [
  {
    id: "po1",
    title: { ar: "سفير المنصة — نسبة 20%", en: "Platform Ambassador — 20%", ru: "Посол платформы — 20%" },
    body: { ar: "تعريف أعضاء جدد عبر رابطك الشخصي؛ تحصل على 20% من قيمة أول طلب لكل عضو تعرفه. تُحسب النسبة أسبوعياً وتدفع عبر USDT.", en: "Refer new members via your personal link; earn 20% of each referred member's first order. Calculated weekly, paid via USDT.", ru: "Приводите новых участников по личной ссылке; 20% от первого заказа. Расчёт еженедельно, выплата в USDT." },
    bonus: "20% · WEEKLY",
  },
  {
    id: "po2",
    title: { ar: "مسوّق القنوات — نسبة 15%", en: "Channel Marketer — 15%", ru: "Маркетер каналов — 15%" },
    body: { ar: "ترويج للقنوات الرسمية عبر منصاتك مقابل 15% من كل عملية مكتملة خلال حملتك. يُشترط سجل نظيف وتقرير أسبوعي.", en: "Promote official channels on your platforms for 15% of every completed order during your campaign. Clean record and weekly report required.", ru: "Продвижение официальных каналов за 15% каждого завершённого заказа. Чистая история и еженедельный отчёт." },
    bonus: "15% · PER CAMPAIGN",
  },
  {
    id: "po3",
    title: { ar: "وسيط الصفقات الميدانية — نسبة 10%", en: "Field Deal Broker — 10%", ru: "Брокер полевых сделок — 10%" },
    body: { ar: "تنسيق الصفقات الميدانية في المدن المعتمدة (الرياض، دبي، تكساس، موسكو، برلين) مقابل 10% من قيمة كل صفقة.", en: "Coordinate field deals in approved cities (Riyadh, Dubai, Texas, Moscow, Berlin) for 10% of each deal.", ru: "Координация полевых сделок в одобренных городах за 10% каждой сделки." },
    bonus: "10% · PER DEAL",
  },
  {
    id: "po4",
    title: { ar: "منشئ محتوى للمنصة — نسبة 12%", en: "Content Creator — 12%", ru: "Контент-мейкер — 12%" },
    body: { ar: "إنتاج محتوى موثق (شروحات، لقطات، مراجعات) مقابل نسبة 12% شهرية ثابتة من أداء المحتوى المعتمد.", en: "Produce verified content (guides, clips, reviews) for a fixed 12% monthly rate based on approved content performance.", ru: "Создание верифицированного контента за фиксированные 12% ежемесячно." },
    bonus: "12% · MONTHLY",
  },
];

/* ── أسئلة Black Mart AI (شرائح الاقتراحات السريعة) ── */
export const AI_QA: { id: string; q: L; a: L }[] = [
  { id: "aq1", q: { ar: "كيف أبدأ؟", en: "How do I start?", ru: "С чего начать?" }, a: { ar: "اختر لغتك في شاشة الدخول ثم ادخل للسوق واختر قسماً. كل طلب يبدأ بزر شراء وينتهي بتأكيد عبر تليجرام مع مسؤول الطلب.", en: "Pick your language on the entry screen, then enter the market. Every order starts with a Buy button and ends with a Telegram confirmation from the order manager.", ru: "Выберите язык на экране входа и зайдите на рынок. Каждый заказ начинается кнопкой «Купить» и заканчивается подтверждением в Telegram." } },
  { id: "aq2", q: { ar: "ما معنى شارة «موثّق»؟", en: "What does Verified mean?", ru: "Что значит «Подтверждено»?" }, a: { ar: "الخدمة اختبرها فريقنا أو أكدها مزود معتمد. لا تدفع خارج المنصة أبداً — أي طلب خارج القنوات الرسمية مخالفة.", en: "The service was team-tested or approved by a verified supplier. Never pay outside the platform — any off-platform request is a violation.", ru: "Услуга протестирована командой или одобрена поставщиком. Никогда не платите вне платформы." } },
  { id: "aq3", q: { ar: "كيف أدفع؟", en: "How do I pay?", ru: "Как оплатить?" }, a: { ar: "عبر USDT (TRC20) أو Bitcoin من صفحة الدفع الآمنة، ثم أرسل الإيصال لمسؤول الطلب @k22zzo ليُسلَّم طلبك مباشرة.", en: "Via USDT (TRC20) or Bitcoin from the secure checkout page, then send the receipt to order manager @k22zzo for direct delivery.", ru: "Через USDT (TRC20) или Bitcoin со страницы безопасной оплаты, затем чек менеджеру @k22zzo." } },
  { id: "aq4", q: { ar: "كيف أستخدم أدوات الفحص؟", en: "How do I use the checkers?", ru: "Как использовать чекеры?" }, a: { ar: "من قسم الدعم ← أدوات الفحص: اختر الفاحص، أدخل البيانات، واضغط تشغيل. النتائج تجريبية حالياً ويُفعَّل الفحص الحقيقي في المرحلة الثانية.", en: "From Support → Check Tools: pick a checker, enter the data, and run. Results are demo for now; live checking lands in Phase 2.", ru: "Из Поддержки → Инструменты проверки: выберите чекер, введите данные, запустите. Пока демо-результаты." } },
  { id: "aq5", q: { ar: "كيف أقدم شكوى؟", en: "How do I file a complaint?", ru: "Как подать жалобу?" }, a: { ar: "من قسم الدعم ← الشكاوى والدعم: اختر التبويب المناسب (شكاوى/استبدال/استرجاع) واكتب التفاصيل. تصل الإدارة مباشرة ويُتابع معك برقم مرجعي عبر تليجرام.", en: "From Support → Complaints & Support: pick the right tab (complaint/exchange/return) and write the details. It reaches the admin directly with a Telegram reference number.", ru: "Из Поддержки → Жалобы: выберите вкладку и опишите детали. Жалоба доходит до админа с референсным номером." } },
  { id: "aq6", q: { ar: "ما هي المدن المعتمدة للمقابلات؟", en: "Which cities are approved?", ru: "Какие города одобрены?" }, a: { ar: "الرياض، دبي، تكساس، موسكو، برلين. كل مقابلة تُنسَّق مسبقاً بـ48 ساعة عبر قسم تنسيق المقابلات فقط.", en: "Riyadh, Dubai, Texas, Moscow, Berlin. Every meeting is coordinated 48h in advance via the Meeting Coordination section only.", ru: "Эр-Рияд, Дубай, Техас, Москва, Берлин. Каждая встреча координируется за 48 часов." } },
];

/* ── نبذة المنصة (3 وثائق) ── */
export const ABOUT_TEXTS = {
  overview: {
    ar: "BLACK MART منظومة آمنة مغلقة تجمع السوق والترسانة والمنتدى والدعم خلف قناة مشفرة واحدة.\nالتزاماتنا: توثيق قبل الترويج، إيصال قبل التأكيد، وتشفير على مدار الساعة. كل تعامل يُوثق برقم مرجعي، وكل طلب يُتابع حتى تأكيد التسليم من طرفك.\nلا وسيط عشوائي، لا دفع خارج المنصة، ولا تسليم بدون فحص — هذه قواعدنا الحاكمة.",
    en: "BLACK MART is a closed, secure system uniting market, arsenal, forum, and support behind one encrypted channel.\nOur commitments: verification before promotion, delivery before confirmation, encryption around the clock. Every transaction is documented with a reference number, and every order is tracked until you confirm delivery.\nNo random middlemen, no off-platform payments, no undelivered goods — these are our governing rules.",
  },
  terms: {
    ar: "١) الدفع فقط عبر المحافظ المعتمدة في صفحة الدفع الآمنة.\n٢) الإيصال إلزامي — لا يُفتح أي طلب دون إيصال.\n٣) أي طلب تحويل خارج القنوات الرسمية مخالفة تُغلق الحساب فوراً.\n٤) استرجاع مقبول ما لم يسلَّم المحتوى بعد التحويل.\n٥) يُحتفظ بحقوق تعديل هذه الشروط مع إشعار عبر الإشعارات.",
    en: "1) Payment only via approved wallets on the secure checkout page.\n2) Receipt is mandatory — no order opens without a receipt.\n3) Any transfer request outside official channels is a violation and closes the account instantly.\n4) Returns are accepted as long as content has not been delivered after transfer.\n5) We reserve the right to amend these terms with a notification.",
  },
  privacy: {
    ar: "هويتك أمانة: لا نجمع بيانات أكثر من الاسم المستعار وكلمة المرور المشفرة.\nتُخزن كلمات المرور مجمعة SHA-256 ولا تصل إلى أي طرف ثالث. سجلات الطلبات مرئية للإدارة فقط لغرض المتابعة والتسليم.\nننصح دائماً: متصفح مخصص للمنصة، وكوكيز معزولة، ووضع التخفّي (ESC) في المواقف الحساسة.",
    en: "Your identity is a trust: we collect nothing beyond your alias and hashed password.\nPasswords are stored SHA-256 hashed and never reach third parties. Order logs are visible to the admin only, for follow-up and delivery.\nAlways recommended: a dedicated browser for the platform, isolated cookies, and stealth mode (ESC) in sensitive situations.",
  },
};

/* ── الأخبار والتحديثات (5 منشورات) ── */
export const NEWS_POSTS: PostDef[] = [
  { id: "nw1", date: "05.03.2026", title: { ar: "[01] سياسة تنسيق المقابلات", en: "[01] Meeting Coordination Policy", ru: "[01] Политика координации встреч" }, body: { ar: "كل المقابلات تُنظَّم عبر قسم التنسيق فقط، في المدن المعتمدة (الرياض، دبي، تكساس، موسكو، برلين)، وبموعد لا يقل عن 48 ساعة سلفاً. لا تُعتمد أي صفقة ميدانية خارج هذا المسار، ويُشترط وصول الطرفين قبل الموعد بـ10 دقائق مع إثبات هوية داخلي.", en: "All meetings are coordinated through the Coordination section only, in approved cities (Riyadh, Dubai, Texas, Moscow, Berlin), scheduled at least 48h in advance. No field deal is approved outside this route; both parties must arrive 10 minutes early with internal ID verification.", ru: "Все встречи координируются только через раздел Координации, в одобренных городах, за 48 часов заранее. Любая полевая сделка вне этого маршрута не одобрена." } },
  { id: "nw2", date: "04.03.2026", title: { ar: "[02] آلية الترويج مقابل نسبة", en: "[02] Promotion-for-Percent Mechanism", ru: "[02] Механизм продвижения за процент" }, body: { ar: "لكل عضو رابط شخصي ثابت. النسبة ثابتة حسب الدور (10–20%) وتُحتسب على كل عملية مكتملة فقط. تُحسب النسب أسبوعياً كل يوم أحد وتدفع عبر USDT بعد 48 ساعة من الإغلاق، مع كشف تفصيلي لكل عملية.", en: "Every member has a fixed personal link. The rate is fixed by role (10–20%) and counts on completed orders only. Rates are calculated weekly every Sunday and paid via USDT 48h after close, with a detailed statement per order.", ru: "У каждого участника фиксированная личная ссылка. Комиссия фиксирована по роли (10–20%) и учитывается только завершённые заказы. Расчёт еженедельно, выплата в USDT через 48 часов." } },
  { id: "nw3", date: "03.03.2026", title: { ar: "[03] تعليمات إتمام الطلب", en: "[03] Order Completion Instructions", ru: "[03] Инструкции по завершению заказа" }, body: { ar: "١) شراء فوري أو إضافة للسلة ثم تأكيد.\n٢) صفحة الدفع الآمنة: اختر USDT أو BTC وانسخ العنوان.\n٣) حوّل وأرسل الإيصال فوراً إلى @k22zzo.\n٤) التسليم ثم التأكيد منك. لا يُغلق أي طلب قبل تأكيد التسليم من طرفك.", en: "1) Instant buy or cart, then confirm.\n2) Secure checkout: pick USDT or BTC and copy the address.\n3) Transfer and send the receipt to @k22zzo immediately.\n4) Delivery, then your confirmation. No order closes before you confirm receipt.", ru: "1) Мгновенная покупка или корзина.\n2) Безопасная оплата: USDT или BTC, скопируйте адрес.\n3) Переведите и сразу отправьте чек @k22zzo.\n4) Выдача и ваше подтверждение. Заказ не закрывается до вашего подтверждения." } },
  { id: "nw4", date: "02.03.2026", title: { ar: "[04] توثيق المعاملات والقنوات", en: "[04] Transaction & Channel Verification", ru: "[04] Верификация транзакций и каналов" }, body: { ar: "القنوات الرسمية الثلاث (الرئيسية، العروض، الدعم) هي المسار الوحيد للتواصل. أي شخص يطلب منك التحويل إلى عنوان مختلف — محقق. أي مخالفة تُغلق الحساب فوراً دون استرجاع، وتُدرج البصمة في قائمة الحظر الداخلية.", en: "The three official channels (Main, Offers, Support) are the only communication route. Anyone asking you to transfer to a different address is verified as fraudulent. Violations close the account instantly without refund, and the fingerprint joins the internal blocklist.", ru: "Три официальных канала — единственный путь связи. Кто-либо, просящий перевести на другой адрес — мошенник. Нарушение закрывает аккаунт без возврата." } },
  { id: "nw5", date: "01.03.2026", title: { ar: "[05] ماذا يقدم موقع Black Mart", en: "[05] What Black Mart Offers", ru: "[05] Что предлагает Black Mart" }, body: { ar: "سوق من 7 أقسام و31 فرعاً، ترسانة أدوات، منتدى عمل كامل، ودعم متكامل: مساعد AI، فواحص تفاعلية، تنسيق مقابلات في 5 مدن، وتقييمات موثقة — كلها خلف قناة مشفرة واحدة ودفع آمن متعدد (USDT/BTC/STC/مدى).", en: "A market of 7 sections and 31 branches, a tool arsenal, a full work forum, and complete support: AI assistant, interactive checkers, meeting coordination across 5 cities, and verified ratings — all behind one encrypted channel with multi-safe payment (USDT/BTC/STC/Mada).", ru: "Рынок из 7 разделов и 31 ветви, арсенал инструментов, полноценный форум и полная поддержка: ИИ-ассистент, интерактивные чекеры, координация встреч в 5 городах — всё за одним зашифрованным каналом." } },
];

/* ── أدوات الفحص ── */
export const CHECKERS: {
  kind: "card" | "address" | "data";
  name: L;
  desc: L;
  fieldLabel: L;
  fieldPh: string;
}[] = [
  { kind: "card", name: { ar: "فحص البطاقات", en: "Card Checker", ru: "Проверка карт" }, desc: { ar: "فحص حالة البطاقة وBIN ورصيدها قبل الشراء.", en: "Check card state, BIN, and balance before buying.", ru: "Проверка состояния, BIN и баланса карты." }, fieldLabel: { ar: "رقم البطاقة", en: "Card number", ru: "Номер карты" }, fieldPh: "4556 7812 3456 1890" },
  { kind: "address", name: { ar: "فحص العناوين", en: "Address Checker", ru: "Проверка адресов" }, desc: { ar: "مطابقة الاسم والعنوان الوطني (AVS) لأي عنوان.", en: "Match name and national address (AVS) for any entry.", ru: "Совпадение имени и адреса (AVS)." }, fieldLabel: { ar: "الاسم + العنوان", en: "Name + Address", ru: "Имя + адрес" }, fieldPh: "J. SMITH / 123 MAIN ST" },
  { kind: "data", name: { ar: "فحص البيانات", en: "Data Validator", ru: "Проверка данных" }, desc: { ar: "تحقق من صحة الإيميلات والأرقام وسن البيانات.", en: "Validate emails, numbers, and data age.", ru: "Проверка почты, номеров и возраста данных." }, fieldLabel: { ar: "البيانات", en: "Data", ru: "Данные" }, fieldPh: "user@mail.com · +1 555 0100" },
];

/* ═══════ قسم البطاقات المحقونة — الإعدادات الكاملة ═══════ */
export interface CardCatDef {
  id: string; // branchId في قاعدة البيانات
  short: string; // الاسم المختصر في الشريط: VBV / Pal / AME / Cre / Deb / AX / Clc / Plm
  chip: L; // اسم الزر الفرعي تحت التابات
  kind: "injected" | "drained";
  name: L;
  img: string;
  productImg: string;
  productTitle: L;
  productDesc: L;
  sub: L;
  detailTitle: L;
  intro: L;
  sections: { icon: string; title: string; lines: { k: string; v: string }[] }[];
  extras: L[];
}

export const CARD_CATS: CardCatDef[] = [
  {
    id: "b-novbv",
    short: "VBV",
    chip: { ar: "NOVBV", en: "NOVBV", ru: "NOVBV" },
    kind: "injected",
    name: { ar: "بطاقات NOVBV CC محقونة", en: "NOVBV CC Cards (Injected)", ru: "NOVBV CC — инжект" },
    img: "https://i.postimg.cc/FKXmcqr1/Screenshot-20260624-040940-Telegram.jpg",
    productImg: "https://i.postimg.cc/FKXmcqr1/Screenshot-20260624-040940-Telegram.jpg",
    productTitle: { ar: "Visa & Mastercard NON-VBV CC", en: "Visa & Mastercard NON-VBV CC", ru: "Visa & Mastercard NON-VBV CC" },
    productDesc: { ar: "بطاقات محقونة لتجاوز الـ OTP والسحب المباشر. البيانات كاملة (Fullz).", en: "Injected cards with OTP bypass and direct withdrawal. Full data (Fullz).", ru: "Инжект-карты: обход OTP и прямой вывод. Полные данные." },
    sub: { ar: "بطاقات Visa & MasterCard بنظام (NOVBV)", en: "Visa & MasterCard — NOVBV System", ru: "Visa & MasterCard — система NOVBV" },
    detailTitle: { ar: "بطاقات Visa & MasterCard بنظام (NOVBV)", en: "Visa & MasterCard (NOVBV) Cards", ru: "Visa & MasterCard (NOVBV)" },
    intro: {
      ar: "النوع: بدون تحقق ثنائي (No 3D Secure / OTP). المصدر: يتم فتحها يدوياً وتجهيزها بأعلى معايير الأمان. الرصيد: محقونة بأرصدة حقيقية وجاهزة للاستخدام الفوري. الأمان: آمنة تماماً من البلاغات (Anti-Chargeback) من قبل المالك. التسليم: تسلم بكامل بياناتها (Fullz) مع شروحات ودلائل حصرية لطرق الربط، الكاش أوت (Cashout)، وتفعيل أنظمة التشفير والحماية.",
      en: "Type: No 2FA (No 3D Secure / OTP). Source: opened manually and prepared to the highest security standards. Balance: injected with real funds, ready for instant use. Safety: fully protected from chargebacks by the owner. Delivery: full data (Fullz) with exclusive guides for linking, cashout, and enabling encryption & protection.",
    },
    sections: [
      { icon: "user", title: "البيانات الشخصية", lines: [{ k: "الاسم الكامل", v: "J*** S****" }, { k: "تاريخ الميلاد", v: "199*-**-**" }, { k: "الـ SSN", v: "***-**-1234" }, { k: "البريد الإلكتروني", v: "j***@*****.com" }, { k: "الجوال", v: "+1 (***) ***-****" }] },
      { icon: "card", title: "بيانات البطاقة", lines: [{ k: "رقم البطاقة", v: "**** **** **** 4567" }, { k: "تاريخ الانتهاء", v: "**/**" }, { k: "CVV", v: "***" }, { k: "النوع", v: "Credit" }, { k: "المستوى", v: "Platinum" }, { k: "البنك", v: "********** Bank" }, { k: "الرصيد المحقون", v: "{BAL} USD" }] },
      { icon: "shield", title: "بيانات العنوان (Billing Address)", lines: [{ k: "الشارع", v: "**** ***** St" }, { k: "المدينة", v: "*******" }, { k: "الولاية/المنطقة", v: "**" }, { k: "الرمز البريدي", v: "*****" }, { k: "الدولة", v: "United States" }] },
      { icon: "code", title: "بيانات الجهاز والشبكة (للربط الآمن)", lines: [{ k: "IP Address", v: "***.***.***.**" }, { k: "User-Agent", v: "Mozilla/5.0 (Windows NT 10.0; Win64...) *****" }] },
    ],
    extras: [
      { ar: "دليل الربط الآمن: الخطوات الفنية لربط البطاقة دون إغلاق.", en: "Safe linking guide: technical steps to attach the card without closure." },
      { ar: "ملفات PDF / فيديوهات تشرح طريقة الصرف الآمنة دون إغلاق البطاقة.", en: "PDFs / videos explaining safe cashout without card closure." },
      { ar: "استراتيجية الصرف (Cashout): طرق صرف الرصيد المحقون بأمان تام.", en: "Cashout strategy: fully safe ways to spend the injected balance." },
      { ar: "أنظمة الحماية: كيفية تفعيل التشفير وتجاوز البلاغات.", en: "Protection systems: enabling encryption and bypassing chargebacks." },
    ],
  },
  {
    id: "b-amex-i",
    short: "Pal",
    chip: { ar: "American Express Protocol 10.1", en: "AMEX · Protocol 10.1", ru: "AMEX · протокол 10.1" },
    kind: "injected",
    name: { ar: "بطاقات American Express محقونة", en: "AMEX Cards · Protocol 10.1", ru: "AMEX — протокол 10.1" },
    img: "https://i.postimg.cc/yY23MQNy/images-(31).jpg",
    productImg: "https://i.postimg.cc/yY23MQNy/images-(31).jpg",
    productTitle: { ar: "بطاقات محقونة American Express Protocol 10.1", en: "Injected American Express — Protocol 10.1", ru: "Инжект AMEX — протокол 10.1" },
    productDesc: { ar: "بطاقات American Express محقونة بروتوكول 10.1 مع بيانات تطبيق كاملة قابلة لفتح التطبيق.", en: "AMEX cards injected via Protocol 10.1 with full app data, ready to open the app.", ru: "AMEX инжект по протоколу 10.1 с полными данными приложения." },
    sub: { ar: "بطاقات American Express — شريحة وبروتوكول 10.1", en: "American Express — Chip & Protocol 10.1", ru: "American Express — чип и протокол 10.1" },
    detailTitle: { ar: "بطاقات محقونة American Express — بيانات بروتوكول 10.1 المتقدم", en: "Injected American Express — Advanced Protocol 10.1 Data", ru: "Инжект AMEX — данные протокола 10.1" },
    intro: {
      ar: "تأتي هذه البطاقة ببيانات شخصية كاملة (Fullz) تم إعدادها وفتح حسابها يدوياً وحقنها بمبالغ مختلفة عبر ثغرات الاسترداد. تُسلَّم بكامل بيانات البطاقة وبيانات المالك لفتح التطبيق. تقنية التلامس (NFC): إمكانية محاكاة الصرف عبر أجهزة الدفع المادي. البروتوكول: 10.1 المطور. محتويات الحزمة: تسليم ملف بيانات شخصي كامل لفتح التطبيق، يتيح لك التحويل، الاستقبال، وربط البطاقة بكل سهولة.",
      en: "Delivered with full personal data (Fullz), prepared manually, account opened and injected with varying amounts via refund exploits. Full card + owner data delivered to open the app. NFC touch technology: simulate withdrawal via physical terminals. Protocol: advanced 10.1. Pack contents: complete personal data file to open the app — transfer, receive, and link with ease.",
    },
    sections: [
      { icon: "shield", title: "بيانات الإصدار", lines: [{ k: "موقع الجهة المصدرة", v: "USA - 840" }, { k: "نوع البطاقة", v: "American Express Corporate (Platinum/Grey)" }] },
      { icon: "card", title: "بيانات البطاقة (مشوشة للعرض)", lines: [{ k: "اسم حامل البطاقة", v: "**** * *****" }, { k: "رقم البطاقة (PAN)", v: "3792 **** **** ***" }, { k: "تاريخ الانتهاء", v: "**/**" }, { k: "الرمز الأمامي (CID/CVV)", v: "****" }] },
      { icon: "user", title: "بيانات الدخول للتطبيق", lines: [{ k: "اسم المستخدم (User ID)", v: "*****_Corp_Admin" }, { k: "البريد الإلكتروني", v: "****@****.com" }, { k: "كلمة المرور", v: "*************" }] },
      { icon: "shield", title: "بيانات الشركة والعنوان", lines: [{ k: "اسم الشركة", v: "******* ***" }, { k: "العنوان", v: "308 ****** **" }, { k: "المدينة", v: "********" }, { k: "الولاية", v: "*****" }, { k: "الرمز البريدي", v: "78***" }, { k: "الدولة", v: "United States" }, { k: "الهاتف", v: "(***) ***-****" }] },
    ],
    extras: [
      { ar: "كورس التهيئة الفنية: تجهيز البيئة — تغيير بصمة الهاتف، تنظيف المتصفح، وخطوات فتح التطبيق والحساب بروتوكول 10.1 بأمان تام.", en: "Technical setup course: environment prep — phone fingerprint change, browser cleanup, app & account opening steps via Protocol 10.1 with total safety." },
      { ar: "دليل الربط والتشغيل: الربط المباشر ببوابات الدفع عالمياً دون وسيط + تقنيات الحفاظ على نشاط البطاقة (Live) لأطول فترة.", en: "Linking & operation guide: direct linking to global gateways without middlemen + techniques to keep the card Live the longest." },
      { ar: "استراتيجيات الصرف (Cashout): ملفات فيديو وPDF لطرق تفريغ الرصيد بأمان + أنظمة الحماية (تجاوز البلاغات Anti-Chargeback).", en: "Cashout strategies: video & PDF files for safe draining + protection systems (Anti-Chargeback bypass)." },
    ],
  },
  {
    id: "b-paypal-i",
    short: "AME",
    chip: { ar: "PayPal", en: "PayPal", ru: "PayPal" },
    kind: "injected",
    name: { ar: "حسابات PayPal محقونة", en: "PayPal Accounts (Injected)", ru: "PayPal — инжект" },
    img: "https://i.postimg.cc/26js7NgP/images-(32).jpg",
    productImg: "https://i.postimg.cc/26js7NgP/images-(32).jpg",
    productTitle: { ar: "PayPal Accounts (Personal & Business)", en: "PayPal Accounts (Personal & Business)", ru: "Аккаунты PayPal (личные и бизнес)" },
    productDesc: { ar: "حسابات PayPal شخصية وتجارية محقونة برصيد، ببيانات كاملة، تم فتحها يدوياً.", en: "Personal & business PayPal accounts injected with balance, full data, opened manually.", ru: "Личные и бизнес-аккаунты PayPal с инжектом, полные данные, открыты вручную." },
    sub: { ar: "حسابات PayPal — محقونة ومفتوحة يدوياً", en: "PayPal — Injected & Manually Opened", ru: "PayPal — инжект и ручное открытие" },
    detailTitle: { ar: "تفاصيل الحساب — PayPal محقون", en: "Account Details — Injected PayPal", ru: "Детали аккаунта — PayPal инжект" },
    intro: { ar: "حسابات PayPal محقونة برصيد حقيقي، بيانات كاملة، حالة Verified، وبطاقة مربوطة مخفية. التسليم يشمل بيانات الجهاز والشبكة للربط الآمن دون تقييد.", en: "PayPal accounts injected with real balance, full data, Verified status, hidden linked card. Delivery includes device & network data for safe linking without restriction.", ru: "Аккаунты PayPal с реальным балансом, полные данные, статус Verified, скрытая привязанная карта." },
    sections: [
      { icon: "user", title: "بيانات صاحب الحساب", lines: [{ k: "الاسم الكامل", v: "M******* A*******" }, { k: "تاريخ الميلاد", v: "198*-**-**" }, { k: "البريد الإلكتروني (Login)", v: "u**********@email.com" }, { k: "كلمة المرور", v: "**************" }, { k: "الجوال المربوط", v: "+1-***-***-****" }] },
      { icon: "wallet", title: "بيانات الحساب المالي", lines: [{ k: "نوع الحساب", v: "Personal / Business" }, { k: "حالة الحساب", v: "Verified" }, { k: "الرصيد المحقون", v: "{BAL} USD" }, { k: "البطاقة المربوطة (مخفية)", v: "Visa **** 4242" }] },
      { icon: "shield", title: "بيانات العنوان (Billing)", lines: [{ k: "العنوان المسجل", v: "**** ****** Rd, City, State, ZIP" }, { k: "الدولة", v: "United States" }] },
      { icon: "code", title: "بيانات الجهاز والشبكة (للربط الآمن)", lines: [{ k: "IP Address", v: "***.***.***.**" }, { k: "User-Agent", v: "Mozilla/5.0 (Windows NT 10.0; Win64...) *****" }, { k: "COOKIE", v: "[مُشفر - اضغط للنسخ]" }] },
    ],
    extras: [
      { ar: "دليل الدخول الآمن: كيفية استخدام الـ IP والـ Cookie لتجنب التقييد الأمني.", en: "Safe entry guide: how to use the IP & Cookie to avoid security restriction." },
      { ar: "إدارة الحساب: طريقة التعامل مع الحساب دون إثارة الرقابة أو البلاغات.", en: "Account management: handling the account without triggering monitoring or reports." },
      { ar: "تشفير الحماية: تفعيل الـ VPN/Proxy المناسب لبيانات الحساب.", en: "Protection encryption: activating the proper VPN/Proxy for the account data." },
    ],
  },
  {
    id: "b-credit",
    short: "Cre",
    chip: { ar: "Credit", en: "Credit", ru: "Credit" },
    kind: "drained",
    name: { ar: "بطاقات Credit", en: "Credit Cards", ru: "Credit Cards" },
    img: "https://i.postimg.cc/vTr2JqR5/pngtree-credit-card-mastercard-clipping-retail-vector-png-image-7235644.jpg",
    productImg: "https://i.postimg.cc/vTr2JqR5/pngtree-credit-card-mastercard-clipping-retail-vector-png-image-7235644.jpg",
    productTitle: { ar: "Credit Visa and Mastercard — HIGH_LIMIT_VAULT", en: "Credit Visa & Mastercard — HIGH_LIMIT_VAULT", ru: "Credit Visa & Mastercard — HIGH_LIMIT_VAULT" },
    productDesc: { ar: "بطاقات مديونية بحدود مرتفعة، تمنحك وقتاً للعمل قبل صدور الفواتير أو اكتشاف العملية.", en: "High-limit credit cards giving you working time before billing or detection.", ru: "Кредитные карты с высокими лимитами — время на работу до выставления счетов." },
    sub: { ar: "خزنة المديونية — HIGH_LIMIT_VAULT", en: "The Debt Vault — HIGH_LIMIT_VAULT", ru: "Хранилище задолженности — HIGH_LIMIT_VAULT" },
    detailTitle: { ar: "Credit Cards (HIGH_LIMIT_VAULT) — بيانات البطاقة", en: "Credit Cards (HIGH_LIMIT_VAULT) — Card Data", ru: "Credit (HIGH_LIMIT_VAULT) — данные карты" },
    intro: { ar: "فئة مديونية بحدود مرتفعة تصل إلى 50,000$. الطابع: قوة وسرعة — اعمل في «الوقت الذهبي» قبل إصدار الفاتورة. الحقول (CC, CVC, Address) بموضع تشويش افتراضي.", en: "A credit category with high limits up to $50,000. Character: power and speed — work in the golden window before the invoice issues. Fields (CC, CVC, Address) blurred by default.", ru: "Кредитная категория с лимитами до 50,000$. Работайте в золотое окно до выставления счёта." },
    sections: [
      { icon: "card", title: "بيانات البطاقة الأساسية", lines: [{ k: "CC", v: "XXXX-XXXX-XXXX-XXXX" }, { k: "EXP", v: "XX/XX" }, { k: "CVC", v: "***" }, { k: "CH (الاسم)", v: "*********" }, { k: "VENDOR", v: "Visa / Mastercard" }, { k: "TYPE", v: "Credit" }, { k: "LEVEL", v: "Platinum / Signature" }, { k: "BANK", v: "[*********]" }, { k: "حد المديونية", v: "{BAL} USD" }] },
    ],
    extras: [
      { ar: "استراتيجية التوقيت: كيفية الاستفادة من «الوقت الذهبي» قبل إصدار فاتورة المديونية.", en: "Timing strategy: how to use the golden window before the credit invoice issues." },
      { ar: "بروتوكول الصرف: دليل تفريغ الـ Credit Line (يصل إلى 50,000$) بأمان تام.", en: "Draining protocol: guide to draining the credit line (up to $50,000) with total safety." },
      { ar: "التجاوز الأمني: شروحات لتجاوز بوابات التحقق وتجنب الإغلاق التلقائي.", en: "Security bypass: guides to skip verification gateways and avoid auto-closure." },
    ],
  },
  {
    id: "b-debit",
    short: "Deb",
    chip: { ar: "Debit", en: "Debit", ru: "Debit" },
    kind: "drained",
    name: { ar: "بطاقات Debit", en: "Debit Cards", ru: "Debit Cards" },
    img: "https://i.postimg.cc/CK9vzTS4/images-(41).jpg",
    productImg: "https://i.postimg.cc/CK9vzTS4/images-(41).jpg",
    productTitle: { ar: "Visa and Mastercard Debit", en: "Visa and Mastercard Debit", ru: "Visa и Mastercard Debit" },
    productDesc: { ar: "بطاقات مرتبطة بالرصيد البنكي مباشرة. تتطلب دقة وتركيز عند الربط.", en: "Cards linked directly to the bank balance. Require precision and focus when linking.", ru: "Карты, привязанные напрямую к банковскому балансу. Требуют точности при привязке." },
    sub: { ar: "بطاقات Debit — ربط مباشر بالرصيد البنكي", en: "Debit — Direct Bank Balance Link", ru: "Debit — прямая привязка к балансу" },
    detailTitle: { ar: "بطاقات Debit — البيانات والتنبيه الفني", en: "Debit Cards — Data & Technical Alert", ru: "Debit — данные и техническое предупреждение" },
    intro: { ar: "تنبيه فني: بطاقات الديبت هي بطاقات مرتبطة بالحساب البنكي مباشرة، مما يجعل عمليات الصرف قابلة للملاحظة والمراقبة اللحظية من قبل النظام البنكي. نصيحة الاستخدام: تتطلب «تركيزاً عالياً» عند عملية الربط والتنفيذ، لأن أي خطأ في الإجراءات قد يؤدي إلى تنبيه النظام البنكي فوراً.", en: "Technical alert: debit cards link directly to the bank account, making withdrawals observable in real time by the banking system. Usage tip: they demand high focus during linking and execution — any procedural mistake can alert the banking system instantly.", ru: "Технический сигнал: дебетовые карты привязаны напрямую к счёту — операции наблюдаются в реальном времени. Требуют высокой концентрации." },
    sections: [
      { icon: "card", title: "بيانات البطاقة", lines: [{ k: "CC", v: "XXXX-XXXX-XXXX-XXXX" }, { k: "EXP", v: "XX/XX" }, { k: "CVC", v: "***" }, { k: "CH", v: "*********" }, { k: "VENDOR", v: "Visa / Mastercard" }, { k: "TYPE", v: "Debit" }, { k: "LEVEL", v: "Classic / Gold" }, { k: "BANK", v: "[*********]" }, { k: "الرصيد", v: "{BAL} USD" }] },
      { icon: "shield", title: "العنوان (Billing)", lines: [{ k: "COUNTRY", v: "United States" }, { k: "ZIP", v: "*****" }, { k: "STATE", v: "*****" }, { k: "CITY", v: "*****" }, { k: "ADDRESS", v: "*******************" }, { k: "PHONE", v: "+1-***-***-****" }, { k: "EMAIL", v: "******@*****.com" }] },
    ],
    extras: [
      { ar: "دليل التعامل الحذر: كيف تربط البطاقة دون إثارة الشبهات.", en: "Cautious handling guide: how to link the card without raising suspicion." },
      { ar: "بروتوكول الربط: الخطوات التقنية اللازمة لمطابقة البيانات (بصمة المتصفح + IP).", en: "Linking protocol: technical steps for data matching (browser fingerprint + IP)." },
      { ar: "تجنب التنبيهات: نصائح لمنع النظام البنكي من تجميد العملية عند بدء الصرف.", en: "Alert avoidance: tips to stop the banking system from freezing the operation at withdrawal start." },
    ],
  },
  {
    id: "b-amex-c",
    short: "AX",
    chip: { ar: "American Express", en: "American Express", ru: "American Express" },
    kind: "drained",
    name: { ar: "بطاقات American Express", en: "American Express (AMEX)", ru: "American Express" },
    img: "https://i.postimg.cc/wjWcRcx5/images-(7).png",
    productImg: "https://i.postimg.cc/wjWcRcx5/images-(7).png",
    productTitle: { ar: "American Express — شريحة وبروتوكول 10.1", en: "American Express — Chip & Protocol 10.1", ru: "American Express — чип и протокол 10.1" },
    productDesc: { ar: "بطاقات American Express شريحة وبروتوكول 10.1. بطاقات النخبة: تدعم الصرف المباشر، بوابات الدفع، وتقنية التلامس NFC.", en: "AMEX chip & Protocol 10.1 cards. Elite tier: direct withdrawal, payment gateways, and NFC touch.", ru: "AMEX чип и протокол 10.1. Элитный уровень: прямой вывод, платёжные шлюзы, NFC." },
    sub: { ar: "بطاقات American Express شريحة وبروتوكول 10.1", en: "American Express — Chip & Protocol 10.1", ru: "AMEX — чип и протокол 10.1" },
    detailTitle: { ar: "American Express — بيانات بروتوكول 10.1 المتقدم", en: "American Express — Advanced Protocol 10.1 Data", ru: "AMEX — данные протокола 10.1" },
    intro: { ar: "توفر هذه البطاقات مرونة عالية في الصرف من خلال: دعم الشريحة (EMV) ببيانات مشفرة للتعامل المادي، الصرف المباشر وبوابات الدفع بتوافق تام مع المعالجات العالمية، وتقنية التلامس (NFC) لمحاكاة الصرف عبر أجهزة الدفع المادي.", en: "High withdrawal flexibility: EMV chip support with encrypted data for physical transactions, direct withdrawal and gateways with full processor compatibility, and NFC touch to simulate withdrawal via physical terminals.", ru: "Высокая гибкость вывода: поддержка чипа EMV, прямой вывод и шлюзы, NFC для имитации на терминалах." },
    sections: [
      { icon: "card", title: "بيانات البطاقة الشاملة", lines: [{ k: "CC", v: "XXXX-XXXX-XXXX-XXXX" }, { k: "EXP", v: "XX/XX" }, { k: "CID", v: "****" }, { k: "شفرات الشريحة (EMV Data)", v: "[مُشفر - مُتاح للتصدير]" }, { k: "النوع", v: "AMEX" }, { k: "المستوى", v: "Platinum/Centurion" }] },
      { icon: "user", title: "بيانات المالك (Fullz)", lines: [{ k: "الاسم", v: "*********" }, { k: "الجوال", v: "+1-***-***-****" }, { k: "البريد", v: "******@*****.com" }, { k: "SSN/Tax ID", v: "***-**-****" }] },
      { icon: "shield", title: "العنوان (Billing)", lines: [{ k: "العنوان", v: "*******************" }, { k: "المدينة", v: "*****" }, { k: "الولاية/الرمز", v: "** / *****" }, { k: "الدولة", v: "United States" }] },
      { icon: "code", title: "بيانات الجهاز والشبكة", lines: [{ k: "IP", v: "XXX.XXX.XXX.XXX" }, { k: "USERAGENT", v: "Mozilla/5.0..." }, { k: "PURCHASED", v: "[تاريخ التفعيل]" }] },
    ],
    extras: [
      { ar: "دليل بروتوكول 10.1: كيفية تفعيل خيارات الـ (NFC) واستخدام البيانات المشفرة للشريحة.", en: "Protocol 10.1 guide: enabling NFC options and using the chip's encrypted data." },
      { ar: "استراتيجية الصرف المتقدمة: الخطوات الآمنة للصرف عبر البوابات المباشرة.", en: "Advanced withdrawal strategy: safe steps via direct gateways." },
      { ar: "التجاوز الأمني: إعدادات خاصة لضمان عدم رفض المعاملات من نظام AMEX الصارم.", ru: "Безопасный байпас: специальные настройки против отказов строгой системы AMEX.", en: "Security bypass: special settings to prevent rejection by AMEX's strict system." },
    ],
  },
  {
    id: "b-classic",
    short: "Clc",
    chip: { ar: "Classic", en: "Classic", ru: "Classic" },
    kind: "drained",
    name: { ar: "بطاقات Classic", en: "Classic Cards", ru: "Classic" },
    img: "https://i.postimg.cc/QxS0cWj0/Corporate-Classic-Card-Image.png",
    productImg: "https://i.postimg.cc/QxS0cWj0/Corporate-Classic-Card-Image.png",
    productTitle: { ar: "Classic Visa Mastercard — Raw Data", en: "Classic Visa Mastercard — Raw Data", ru: "Classic Visa Mastercard — сырые данные" },
    productDesc: { ar: "بيانات خام (Raw Data) غير مفحوصة، مخصصة لمن يمتلكون أدواتهم الخاصة.", en: "Raw unverified data, for those who bring their own tools.", ru: "Сырые данные без проверки — для тех, кто приносит свои инструменты." },
    sub: { ar: "منطقة المحترفين والأذكياء (Pro Zone)", en: "The Professionals & Smart Zone (Pro Zone)", ru: "Зона профессионалов (Pro Zone)" },
    detailTitle: { ar: "منطقة «المحترفين والأذكياء» (كلاسيك وبلاتينيوم)", en: "The «Professionals & Smart» Zone (Classic & Platinum)", ru: "Зона «Профессионалы и умные»" },
    intro: { ar: "نحن نوفر هذه الفئات أيضاً، لكنها ليست للهواة! تحدي الأمان: هذه البطاقات تمتلك «صلابة» وحماية مشفرة عالية جداً. الغموض: لا يمكننا الجزم بالرصيد أو كشف كافة البيانات بسبب قوة أنظمة البنوك المصدرة لها. لمن هذه؟ نوفرها فقط لمن يمتلك «الخبرة العالية» والقدرة التقنية على فك التعقيد واختراق أنظمتها. إذا كنت ترى في نفسك الذكاء لتجاوز حماية البنك، فهذه ساحتك للتجربة.", en: "We offer these tiers too — but not for amateurs! Security challenge: these cards have extreme hardness and heavy encrypted protection. Mystery: we cannot guarantee the balance or reveal all data due to the issuing banks' strong systems. Who is this for? Only for those with high experience and the technical ability to decode and breach their systems. If you see the intelligence in yourself to bypass bank protection — this is your ground.", ru: "Эти уровни тоже в наличии — но не для новичков! Карты с экстремальной защитой. Баланс гарантировать не можем из-за мощных систем банков. Только для опытных с технической возможностью." },
    sections: [],
    extras: [{ ar: "لا تُرفق بيانات إضافية — التحدي التقني هو المنتج نفسه.", en: "No extra data attached — the technical challenge is the product itself.", ru: "Дополнительных данных нет — технический вызов и есть продукт." }],
  },
  {
    id: "b-platinum",
    short: "Plm",
    chip: { ar: "Platinum", en: "Platinum", ru: "Platinum" },
    kind: "drained",
    name: { ar: "بطاقات Platinum", en: "Platinum Cards", ru: "Platinum" },
    img: "https://i.postimg.cc/RhBXL73g/images-(42).jpg",
    productImg: "https://i.postimg.cc/RhBXL73g/images-(42).jpg",
    productTitle: { ar: "Platinum Visa Mastercard — Raw Data", en: "Platinum Visa Mastercard — Raw Data", ru: "Platinum Visa Mastercard — сырые данные" },
    productDesc: { ar: "بيانات خام (Raw Data) غير مفحوصة، مخصصة لمن يمتلكون أدواتهم الخاصة.", en: "Raw unverified data, for those who bring their own tools.", ru: "Сырые данные без проверки — для опытных." },
    sub: { ar: "منطقة المحترفين والأذكياء (Pro Zone)", en: "The Professionals & Smart Zone (Pro Zone)", ru: "Зона профессионалов (Pro Zone)" },
    detailTitle: { ar: "منطقة «المحترفين والأذكياء» (كلاسيك وبلاتينيوم)", en: "The «Professionals & Smart» Zone (Classic & Platinum)", ru: "Зона «Профессионалы и умные»" },
    intro: { ar: "نحن نوفر هذه الفئات أيضاً، لكنها ليست للهواة! تحدي الأمان: هذه البطاقات تمتلك «صلابة» وحماية مشفرة عالية جداً. الغموض: لا يمكننا الجزم بالرصيد أو كشف كافة البيانات بسبب قوة أنظمة البنوك المصدرة لها. لمن هذه؟ نوفرها فقط لمن يمتلك «الخبرة العالية» والقدرة التقنية على فك التعقيد واختراق أنظمتها. إذا كنت ترى في نفسك الذكاء لتجاوز حماية البنك، فهذه ساحتك للتجربة.", en: "We offer these tiers too — but not for amateurs! Security challenge: these cards have extreme hardness and heavy encrypted protection. Mystery: we cannot guarantee the balance or reveal all data due to the issuing banks' strong systems. Who is this for? Only for those with high experience and the technical ability to decode and breach their systems. If you see the intelligence in yourself to bypass bank protection — this is your ground.", ru: "Эти уровни тоже в наличии — но не для новичков! Карты с экстремальной защитой. Только для опытных с технической возможностью." },
    sections: [],
    extras: [{ ar: "لا تُرفق بيانات إضافية — التحدي التقني هو المنتج نفسه.", en: "No extra data attached — the technical challenge is the product itself.", ru: "Дополнительных данных нет — технический вызов и есть продукт." }],
  },
];

/* ── الفرق بين المحقونة والمسحوبة ── */
export const CARD_DIFF = {
  injected: {
    ar: "بطاقات محقونة برصيد حقيقي جاهز للسحب الفوري — تُفتح وتجهَّز يدوياً وتُسلَّم بكامل بياناتها (Fullz) مع الشروحات. الأنسب لمن يريد استخداماً مباشراً وسريعاً.",
    en: "Cards injected with a real balance, ready for instant withdrawal — opened and prepared manually, delivered with full data (Fullz) and guides. Best for direct, fast usage.",
  },
  drained: {
    ar: "بطاقات مسحوبة/مديونية بدون رصيد محقون — تعمل على الحدود الائتمانية وتحتاج توقيتاً دقيقاً قبل صدور الفواتير. الأنسب للمحترفين وأصحاب الأدوات.",
    en: "Drained/credit cards with no injected balance — they work on credit limits and need precise timing before billing. Best for professionals and tool owners.",
  },
};

/* ── صندوق الثقة أسفل التفاصيل ── */
export const BLACKMART_TRUST = {
  title1: { ar: "لماذا بوابة Black Mart مصدرك الموثوق؟", en: "Why is Black Mart your trusted source?", ru: "Почему Black Mart — ваш надёжный источник?" },
  why: [
    { ar: "الداتا الكاملة: نوفر (الاسم، العنوان، الإيميل، الرقم الضريبي) لضمان المطابقة.", en: "Full data: we provide (name, address, email, tax ID) to guarantee matching." },
    { ar: "سياسة التعويض: استبدال فوري لأي بطاقة معطلة «عند الاستلام».", en: "Compensation policy: instant replacement for any dead card «on delivery»." },
    { ar: "شروحات سرية: فيديوهات حصرية لضمان نجاح تفريغ البطاقة.", en: "Secret guides: exclusive videos to guarantee a successful drain." },
  ],
  title2: { ar: "المميزات المرفقة مع الخدمة", en: "Features included with the service", ru: "Возможности, входящие в сервис" },
  features: [
    { ar: "الحماية والتشفير: تأمين العمليات بأحدث أساليب التشفير المتقدمة.", en: "Protection & encryption: operations secured with the latest advanced encryption." },
    { ar: "الربط والحقن: شرح آليات الربط والحقن عبر بوابات الدفع العالمية.", en: "Linking & injection: mechanics of linking and injection through global gateways." },
    { ar: "بوابات الدفع الذكية: شروحات احترافية لـ (Apple Pay & Google Play).", en: "Smart gateways: pro guides for (Apple Pay & Google Play)." },
    { ar: "تجاوز الأنظمة: طرق تخطي الحماية لضمان نجاح العملية.", en: "Bypass systems: ways to skip protection and guarantee success." },
  ],
};
export const BRANDS = ["Apple Pay", "Google Play", "AMEX", "Visa", "Mastercard", "PayPal"];

/* ── منتجات المرحلة الأولى (عروض تجريبية — تُستبدل في المرحلة الثانية) ── */
export interface SeedProduct {
  slug: string;
  nameAr: string;
  nameEn: string;
  nameRu: string;
  descAr: string;
  descEn: string;
  descRu: string;
  catId: string;
  priceUsd: number;
  verified: boolean;
  featured: boolean;
  views: number;
  orders: number;
}

export const SEED_PRODUCTS: SeedProduct[] = [
  { slug: "basic-access", nameAr: "باقة الدخول الأساسية", nameEn: "Basic Access Pack", nameRu: "Базовый пакет доступа", descAr: "نقطة البداية داخل المنطقة: وصول كامل للسوق مع شرح أولي موثّق.", descEn: "Your starting point inside the zone: full market access with an intro briefing.", descRu: "Точка входа: полный доступ к рынку с вводным брифом.", catId: "cards", priceUsd: 25, verified: true, featured: true, views: 1284, orders: 214 },
  { slug: "vip-channel", nameAr: "قناة VIP المشفّرة", nameEn: "Encrypted VIP Channel", nameRu: "Зашифрованный VIP-канал", descAr: "قناة خاصة بمحتوى أولوية ودعم مباشر من المسؤول.", descEn: "Private channel with priority content and direct manager support.", descRu: "Приватный канал с приоритетным контентом и прямой связью.", catId: "transfers", priceUsd: 40, verified: true, featured: true, views: 942, orders: 151 },
  { slug: "gift-starter", nameAr: "باقة هدايا البداية", nameEn: "Gift Starter Pack", nameRu: "Стартовый подарочный пакет", descAr: "تشكيلة بطاقات هدايا مختارة بعناية مع شرح استبدال.", descEn: "A curated gift-card assortment with an exchange guide.", descRu: "Отборный набор подарочных карт с гайдом обмена.", catId: "gifts", priceUsd: 15, verified: true, featured: false, views: 763, orders: 98 },
  { slug: "stream-plus", nameAr: "اشتراك البث الموسمي", nameEn: "Seasonal Stream Subscription", nameRu: "Сезонная стрим-подписка", descAr: "شحن موسمي كامل للتطبيقات المرئية والصوتية مع تحديث تلقائي.", descEn: "Full seasonal top-up for audio/video apps with auto-renew.", descRu: "Полное сезонное пополнение аудио/видео приложений.", catId: "topup", priceUsd: 30, verified: false, featured: true, views: 1105, orders: 176 },
  { slug: "proxy-suite", nameAr: "حزمة بروكسي آمنة (شهر)", nameEn: "Secure Proxy Suite (Month)", nameRu: "Безопасный прокси-набор (месяц)", descAr: "عقد مشفّرة متعددة مع تبديل تلقائي ودعم إعداد الجهاز.", descEn: "Multiple encrypted nodes with auto-rotation and device setup help.", descRu: "Несколько шифрованных нод с авто-ротацией и настройкой устройства.", catId: "courses", priceUsd: 18, verified: true, featured: false, views: 889, orders: 122 },
  { slug: "course-basics", nameAr: "كورس الأساسيات — دفعة مجانية", nameEn: "Basics Course — Free Cohort", nameRu: "Курс основ — бесплатный поток", descAr: "أساسيات التصفح الآمن والتعامل مع المنطقة من الصفر.", descEn: "The fundamentals of safe browsing and zone operations from zero.", descRu: "Основы безопасной навигации и работы в зоне с нуля.", catId: "courses", priceUsd: 0, verified: true, featured: true, views: 2210, orders: 340 },
  { slug: "boost-pack", nameAr: "باقة تعزيز الحساب", nameEn: "Account Boost Pack", nameRu: "Пакет усиления аккаунта", descAr: "عناصر تعزيز جاهزة مع تسليم فوري بعد التأكيد.", descEn: "Ready boost elements with instant delivery after confirmation.", descRu: "Готовые элементы усиления с моментальной выдачей.", catId: "borrowed", priceUsd: 22, verified: false, featured: false, views: 611, orders: 87 },
  { slug: "wallet-plus", nameAr: "رزمة محافظ متقدم", nameEn: "Advanced Wallet Bundle", nameRu: "Продвинутый набор кошельков", descAr: "تجهيز محافظ متعددة مع دليل الأمان خطوة بخطوة.", descEn: "Multi-wallet setup with a step-by-step security manual.", descRu: "Настройка мультикошельков с пошаговым мануалом.", catId: "cards", priceUsd: 45, verified: true, featured: false, views: 734, orders: 95 },
  { slug: "injection-demo", nameAr: "حقن حساب — عرض تجريبي", nameEn: "Account Injection — Demo", nameRu: "Инжекция аккаунта — демо", descAr: "عرض تجريبي لقسم حقن الحسابات — التفاصيل الفعلية في المرحلة الثانية.", descEn: "Demo entry for the Account Injection section — real details in Phase 2.", descRu: "Демо-запись раздела — реальные детали во второй фазе.", catId: "injection", priceUsd: 35, verified: false, featured: false, views: 412, orders: 57 },
];

export const SEED_NOTIFICATIONS = [
  {
    kind: "offer",
    titleAr: "خصم افتتاحي 20% على باقات الدخول",
    titleEn: "Opening offer: 20% off access packs",
    titleRu: "Открытие: скидка 20% на пакеты",
    bodyAr: "لفترة محدودة حتى إشعار آخر — الباقات المميزة فقط.",
    bodyEn: "For a limited time until further notice — featured packs only.",
    bodyRu: "Ограниченное время — только фирменные пакеты.",
  },
  {
    kind: "update",
    titleAr: "المرحلة الثانية قيد البناء",
    titleEn: "Phase 2 under construction",
    titleRu: "Вторая фаза в разработке",
    bodyAr: "منتجات تفصيلية + شروحات داخل كل قسم + روابط مباشرة.",
    bodyEn: "Detailed products + in-section guides + direct links.",
    bodyRu: "Полный каталог + гайды в разделах + прямые ссылки.",
  },
  {
    kind: "alert",
    titleAr: "صيانة مجدولة للقناة الآمنة",
    titleEn: "Scheduled maintenance on the secure channel",
    titleRu: "Плановое обслуживание канала",
    bodyAr: "توقف قصير متوقع — تُحفظ بياناتكم مشفّرة على مدار الوقت.",
    bodyEn: "Brief downtime expected — your data stays encrypted at all times.",
    bodyRu: "Короткий простой — данные зашифрованы круглосуточно.",
  },
];
