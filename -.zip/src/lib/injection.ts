/* ─────────────────────────────────────────────────────────────
   BLACK MART · INJECTION HUB (قسم حقن الحسابات)
   كل البنوك / العروض / قواعد التسعير / الرسائل / الشروحات هنا فقط.
   أضف بنكاً أو غيّر سعراً من هذا الملف دون لمس الواجهة.
   ───────────────────────────────────────────────────────────── */
import type { L } from "./site";

const A = (ar: string, en = ar): L => ({ ar, en });

/** صورة القسم (ترويسة العرض) */
export const INJ_HERO = "https://i.postimg.cc/YCWtm2Y0/1791842642338.jpg";

export interface InjectionBank {
  id: string;
  badge: string;
  name: L;
  country: L;
  flag: string;
  creditLimit: string;
  injectedBalance: string;
  injectionType: L;
  priceUsd: number;
  currency: "USD" | "EUR";
  symbol: "$" | "€";
  img: string;
}

/** البنوك الخمسة — العروض الثابتة الجاهزة */
export const INJECTION_BANKS: InjectionBank[] = [
  {
    id: "amex", badge: "💳", name: A("American Express"), country: A("🇺🇸 أمريكا", "🇺🇸 USA"), flag: "🇺🇸",
    creditLimit: "$25,000", injectedBalance: "$1,000", injectionType: A("حقيقي / بروتوكول", "Real / Protocol"),
    priceUsd: 200, currency: "USD", symbol: "$",
    img: "https://i.postimg.cc/yxxH677V/images-(3).jpg",
  },
  {
    id: "nomo", badge: "🏛️", name: A("Nomo Bank"), country: A("🇬🇧 بريطانيا", "🇬🇧 United Kingdom"), flag: "🇬🇧",
    creditLimit: "€15,000", injectedBalance: "€1,000", injectionType: A("حقيقي / بروتوكول", "Real / Protocol"),
    priceUsd: 150, currency: "EUR", symbol: "€",
    img: "https://i.postimg.cc/QxB3RN6f/nomo-upgrades-its-sharia-compliant-international-bank.jpg",
  },
  {
    id: "revolut", badge: "🌐", name: A("Revolut"), country: A("🇪🇺 أوروبا", "🇪🇺 Europe"), flag: "🇪🇺",
    creditLimit: "$10,000", injectedBalance: "$1,000", injectionType: A("حقيقي / بروتوكول", "Real / Protocol"),
    priceUsd: 180, currency: "USD", symbol: "$",
    img: "https://i.postimg.cc/XYd0YH6f/images-(1).jpg",
  },
  {
    id: "wise", badge: "💱", name: A("Wise Multi-Currency"), country: A("🌍 دولي", "🌍 Global"), flag: "🌍",
    creditLimit: "$10,000", injectedBalance: "$1,000", injectionType: A("حقيقي / بروتوكول", "Real / Protocol"),
    priceUsd: 140, currency: "USD", symbol: "$",
    img: "https://i.postimg.cc/Gpjwk42w/Wise-Business-Debit-new.png",
  },
  {
    id: "wio", badge: "🏛️", name: A("Wio Bank"), country: A("🇦🇪 الإمارات", "🇦🇪 UAE"), flag: "🇦🇪",
    creditLimit: "$8,000", injectedBalance: "$1,000", injectionType: A("حقيقي / بروتوكول", "Real / Protocol"),
    priceUsd: 120, currency: "USD", symbol: "$",
    img: INJ_HERO,
  },
];

/* ═══ أداة الحقن المباشر ═══ */
export type InjectionKind = "api" | "real";

export interface InjectionRule {
  kind: InjectionKind;
  title: L;
  short: L;
  min: number;
  basePrice: number;
  unitRate: number;
  rateLabel: L;
  fields: { id: string; label: L; ph: L; type?: "text" | "number"; maxLength?: number }[];
}

export const INJECTION_RULES: Record<InjectionKind, InjectionRule> = {
  api: {
    kind: "api",
    title: A("حقن بروتوكول (API)", "Protocol Injection (API)"),
    short: A("حقن بروتوكول (API)", "Protocol (API)"),
    min: 5000,
    basePrice: 300,
    unitRate: 0.06,
    rateLabel: A("الحد الأدنى 5,000 وحدة بـ 300$ (معدل $0.06 للوحدة)", "Min 5,000 units for $300 ($0.06 / unit)"),
    fields: [
      { id: "token", label: A("معرف البطاقة البرمجي (Card Token / ID)", "Card Token / ID"), ph: A("tok_XXXXXXXXXXXX", "tok_XXXXXXXXXXXX") },
    ],
  },
  real: {
    kind: "real",
    title: A("حقن حقيقي (بطاقات مباشرة)", "Real Injection (Card)"),
    short: A("حقن حقيقي عبر بطاقة", "Real (Card)"),
    min: 1000,
    basePrice: 250,
    unitRate: 0.25,
    rateLabel: A("الحد الأدنى 1,000 وحدة بـ 250$ (معدل $0.25 للوحدة)", "Min 1,000 units for $250 ($0.25 / unit)"),
    fields: [
      { id: "cardNumber", label: A("رقم البطاقة (16 رقم)", "Card number (16 digits)"), ph: A("4556 7812 3456 1890", "4556 7812 3456 1890"), type: "number", maxLength: 16 },
      { id: "expiry", label: A("تاريخ الانتهاء (MM/YY)", "Expiry (MM/YY)"), ph: A("12/28", "12/28") },
      { id: "cvv", label: A("رمز الأمان (CVV)", "Security code (CVV)"), ph: A("***", "***"), type: "number", maxLength: 4 },
    ],
  },
};

/** السعر الإجمالي الحي = الكمية × سعر الوحدة */
export const injectionTotal = (kind: InjectionKind, qty: number) =>
  Math.round(qty * INJECTION_RULES[kind].unitRate * 100) / 100;

/* ═══ الشرح المنسدل ═══ */
export const INJECTION_GUIDE: { title: L; body: L }[] = [
  {
    title: A("🔌 ما هو حقن البروتوكول (API)؟"),
    body: A("يتم الحقن عبر واجهة برمجية (API) باستخدام معرف البطاقة Token فقط، دون بيانات فيزيائية. مناسب للكميات الكبيرة: الحد الأدنى 5,000 وحدة، والسعر $0.06 للوحدة ($300 لكل 5,000 وحدة)."),
  },
  {
    title: A("💳 ما هو الحقن الحقيقي عبر بطاقة؟"),
    body: A("يتم الحقن على بطاقة فعلية باستخدام رقم البطاقة وتاريخ الانتهاء و CVV. مناسب للكميات الأصغر: الحد الأدنى 1,000 وحدة، والسعر $0.25 للوحدة ($250 لكل 1,000 وحدة)."),
  },
  {
    title: A("💱 العملة والدفع"),
    body: A("تتغير العملة تلقائياً إلى اليورو (€) عند اختيار Nomo Bank، وتبقى الدولار ($) لباقي البنوك. بعد تجهيز الطلب تُنسخ الرسالة تلقائياً وتُفتح محادثة المسؤول لتأكيد وسيلة الدفع."),
  },
];

/* ═══ قوالب الرسائل ═══ */
export function readyAccountMessage(b: InjectionBank): string {
  return [
    "مرحبا Black Mart ارغب ب شراء حساب محقون جاهز",
    "",
    `📌 اسم الحساب: ${b.name.ar}`,
    `🌍 الدولة: ${b.country.ar}`,
    `💳 الحد الائتماني: ${b.creditLimit}`,
    `💰 الرصيد المحقون: ${b.injectedBalance}`,
    `🏷️ السعر المطلوب: ${b.priceUsd}$`,
    "",
    "مرحبا كيف يمكنني الدفع لتسلم الحساب؟",
  ].join("\n");
}

export function directInjectionMessage(o: {
  kind: InjectionKind;
  bank: InjectionBank;
  qty: number;
  total: number;
  data: string;
}): string {
  return [
    "مرحبا Black Mart ارغب ب حقن حسابي",
    "",
    `📌 نوع الحقن: ${o.kind === "api" ? "حقن بروتوكول (API)" : "حقن حقيقي عبر بطاقة"}`,
    `💳 البنك / البطاقة: ${o.bank.name.ar}`,
    `📊 الكمية المطلوبة: ${o.qty} ${o.bank.symbol}`,
    `💰 السعر الإجمالي: ${o.total}$`,
    "",
    "📝 البيانات المدخلة:",
    o.data,
    "",
    "مرحبا كيف يمكنني الدفع لتنفيذ عملية الحقن؟",
  ].join("\n");
}
