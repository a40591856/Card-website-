/* ─────────────────────────────────────────────────────────────
   BLACK MART · GIFT CARDS VAULT (بطاقات الهدايا والاشتراكات)
   كل الأقسام / المنتجات / الصور / الأسعار / الشروحات هنا فقط.
   أضف بطاقة = سطر واحد، والواجهة تتحدث تلقائياً (100% extensible).
   ───────────────────────────────────────────────────────────── */
import type { L } from "./site";

const A = (ar: string, en = ar): L => ({ ar, en });

export interface GiftProduct {
  id: string;
  name: L;
  desc: L;
  details: L;
  img: string;
  balance: L;          // الرصيد / القيمة
  priceUsd: number;    // السعر الجديد
  oldPriceUsd?: number;// القيمة الاسمية المشطوبة
  badges: string[];
  featured?: boolean;
}

export interface GiftSection {
  id: string;
  short: L;
  name: L;
  desc: L;
  icon: string;
  hero: string;
  guideTitle: L;
  guide: L[];
  products: GiftProduct[];
}

const P = (
  id: string, ar: string, en: string, descAr: string, descEn: string,
  img: string, balance: string, price: number, old: number | undefined,
  detailsAr: string, badges: string[], featured?: boolean,
): GiftProduct => ({
  id, name: A(ar, en), desc: A(descAr, descEn), img, balance: A(balance),
  priceUsd: price, oldPriceUsd: old, details: A(detailsAr), badges, featured,
});

/** التحذير الأحمر الإلزامي في كل نافذة تفاصيل */
export const TRAP_WARNING: L = A(
  "⚠️ أكواد مصيدة: يجب الشحن خلال 24 ساعة من الاستلام وإلا ستفقد صلاحيتها.",
  "⚠️ Trap codes: redeem within 24 hours of delivery or they expire.",
);

const BINANCE_DETAILS = `لضمان سلامة الأصول وتجنب أي ملاحقة أو حظر، يجب اتباع مسار العمليات التالي بدقة:
• سحب الكود: البدء بسحب القيمة الأصلية من بطاقة الهدايا.
• التحويل البيني: تبديل العملة من USDT إلى BTC داخل منصة «باينانس».
• النقل الآمن: إرسال رصيد البيتكوين إلى محفظة «تراست وليت» (Trust Wallet) الخارجية.
• إعادة التبديل: تحويل البيتكوين مجدداً إلى USDT داخل المحفظة.
• التصفية النهائية: إرسال USDT إلى أي منصة تدعم بيع P2P لإتمام عملية البيع بشكل نظيف.

⚠️ تنبيه أمني (آلية الخلاط): تعتبر هذه الدورة بمثابة «خلاط رقمي»؛ حيث تهدف إلى تشتيت مصدر الأموال وكسر تتبعها. الهدف الأساسي: حماية حسابك من البلاغات، الحظر، أو أي ملاحقة تقنية قد تنتج عن أصل البطاقة.`;

const APPLE_DETAILS = `أكواد «مصيدة»؛ اشحن فوراً. لا تترك الكود أكثر من 24 ساعة. صالح للمتجر الأمريكي/الدولي.
• يُسلَّم الكود كاملاً مع تعليمات الاستخدام.
• يُمنع تخزين الكود أو مشاركته قبل الشحن.
• في حال عدم الشحن خلال 24 ساعة تفقد صلاحيته ولا يُستبدل.`;

const AMAZON_DETAILS = `أكواد «مصيدة» لمتجر Amazon Gift Card؛ للاستخدام المباشر فقط.
• يُمنع شراء بطاقات أخرى بها.
• اشحن خلال 24 ساعة من الاستلام.
• تطابق Region مطلوب قبل التفعيل.`;

const GAMING_DETAILS = `أكواد «مصيدة»؛ اشحن فوراً (24 ساعة). تأكد من تطابق الريجون قبل التفعيل.
• صالحة للمتجر المحدد لكل بطاقة فقط.
• يُسلَّم الكود مع Region المطابق.
• أي تأخير يتجاوز 24 ساعة يُفقد الصلاحية.`;

const SUBS_DETAILS = `حسابات «مصيدة»؛ يمنع تغيير الإيميل أو الباسورد لضمان الضمان. اشحنها فوراً.
• الاشتراك فعّال لمدة سنة كاملة من تاريخ التسليم.
• بيانات الدخول تُسلَّم جاهزة دون تعديل.
• أي تغيير في الإيميل/الباسورد يُلغي الضمان.`;

const SERVICES_DETAILS = `خدمة توثيق؛ تتطلب تنفيذاً فورياً لضمان قبول وسيلة الدفع قبل التبليغ.
• ربط Apple Pay / Google Pay بحسابك عبر بوابة معتمدة.
• يُشترط التنفيذ الفوري بعد الاستلام.
• تُسلَّم مع الخدمة تعليمات الربط الآمن.`;

const BINANCE_IMG = "https://i.postimg.cc/d0G4gZmk/images.png";
const APPLE_IMG = "https://i.postimg.cc/Wz59XR6R/e9cdd1eb980a9c3a090a94008f4bdf360cf988a86158c35fae8b2d505c09e82c.jpg";
const AMAZON_IMG = "https://i.postimg.cc/FH76CKBq/images-(1).png";
const GAMING_IMG = "https://i.postimg.cc/YCnX1w2x/1782251397122.png";
const SUBS_IMG = "https://i.postimg.cc/yN3wxNhh/1782251253760.png";
const SERVICES_IMG = "https://i.postimg.cc/hPSWscgW/Screenshot-20260624-004536-Google.jpg";

export const GIFT_SECTIONS: GiftSection[] = [
  /* 1 — Binance */
  {
    id: "binance", short: A("Binance"), name: A("بطاقات بينانس (Binance Cards)"),
    desc: A("أكواد «مصيدة» Gift Card Binance بفئات متعددة، مع دورة الخلاط الرقمي الكاملة لحماية الأصول وكسر التتبع."),
    icon: "coin", hero: BINANCE_IMG,
    guideTitle: A("⚙️ دورة التشغيل الآمنة — Binance Gift Card"),
    guide: [
      A("سحب الكود: البدء بسحب القيمة الأصلية من بطاقة الهدايا."),
      A("التحويل البيني: تبديل العملة من USDT إلى BTC داخل منصة «باينانس»."),
      A("النقل الآمن: إرسال رصيد البيتكوين إلى محفظة «تراست وليت» (Trust Wallet) الخارجية."),
      A("إعادة التبديل: تحويل البيتكوين مجدداً إلى USDT داخل المحفظة."),
      A("التصفية النهائية: إرسال USDT إلى أي منصة تدعم بيع P2P لإتمام البيع بشكل نظيف."),
      A("⚠️ تنبيه أمني (آلية الخلاط): الدورة بمثابة «خلاط رقمي» لتشتيت مصدر الأموال وكسر تتبعها؛ حماية حسابك من البلاغات والحظر أو أي ملاحقة تقنية قد تنتج عن أصل البطاقة."),
    ],
    products: [
      P("bn1", "Binance Gift Card — 200$", "Binance Gift Card — $200", "أكواد «مصيدة»؛ Gift card Binance.", "Trap codes; Binance Gift Card.", BINANCE_IMG, "200$", 50, 200, BINANCE_DETAILS, ["GIFT_CODE", "24H_REDEEM"], true),
      P("bn2", "Binance Gift Card — 400$", "Binance Gift Card — $400", "أكواد «مصيدة»؛ Gift card Binance.", "Trap codes; Binance Gift Card.", BINANCE_IMG, "400$", 99, 400, BINANCE_DETAILS, ["GIFT_CODE", "24H_REDEEM"]),
      P("bn3", "Binance Gift Card — 600$", "Binance Gift Card — $600", "أكواد «مصيدة»؛ Gift card Binance.", "Trap codes; Binance Gift Card.", BINANCE_IMG, "600$", 199, 600, BINANCE_DETAILS, ["GIFT_CODE", "24H_REDEEM"]),
      P("bn4", "Binance Gift Card — 800$", "Binance Gift Card — $800", "أكواد «مصيدة»؛ Gift card Binance.", "Trap codes; Binance Gift Card.", BINANCE_IMG, "800$", 399, 800, BINANCE_DETAILS, ["GIFT_CODE", "24H_REDEEM"]),
      P("bn5", "Binance Gift Card — 1000$", "Binance Gift Card — $1000", "أكواد «مصيدة»؛ Gift card Binance.", "Trap codes; Binance Gift Card.", BINANCE_IMG, "1000$", 499, 1000, BINANCE_DETAILS, ["GIFT_CODE", "24H_REDEEM"], true),
    ],
  },

  /* 2 — Apple / iTunes */
  {
    id: "apple", short: A("Apple"), name: A("بطاقات آبل (Apple / iTunes)"),
    desc: A("أكواد «مصيدة» Apple/iTunes صالحة للمتجر الأمريكي والدولي. اشحن فوراً ولا تترك الكود أكثر من 24 ساعة."),
    icon: "gift", hero: APPLE_IMG,
    guideTitle: A("🍎 تعليمات بطاقات Apple / iTunes"),
    guide: [
      A("أكواد «مصيدة»؛ اشحن فوراً. لا تترك الكود أكثر من 24 ساعة."),
      A("صالح للمتجر الأمريكي/الدولي."),
      A("يُسلَّم الكود كاملاً مع تعليمات الاستخدام، ويُمنع تخزينه أو مشاركته قبل الشحن."),
      A("في حال عدم الشحن خلال 24 ساعة تفقد صلاحيته ولا يُستبدل."),
    ],
    products: [
      P("ap1", "Apple / iTunes — 50$", "Apple / iTunes — $50", "أكواد «مصيدة»؛ Gift card Apple/iTunes.", "Trap codes; Apple/iTunes Gift Card.", APPLE_IMG, "50$", 30, 50, APPLE_DETAILS, ["US/INTL", "24H_REDEEM"]),
      P("ap2", "Apple / iTunes — 100$", "Apple / iTunes — $100", "أكواد «مصيدة»؛ Gift card Apple/iTunes.", "Trap codes; Apple/iTunes Gift Card.", APPLE_IMG, "100$", 65, 100, APPLE_DETAILS, ["US/INTL", "24H_REDEEM"], true),
      P("ap3", "Apple / iTunes — 200$", "Apple / iTunes — $200", "أكواد «مصيدة»؛ Gift card Apple/iTunes.", "Trap codes; Apple/iTunes Gift Card.", APPLE_IMG, "200$", 120, 200, APPLE_DETAILS, ["US/INTL", "24H_REDEEM"]),
      P("ap4", "Apple / iTunes — 500$", "Apple / iTunes — $500", "أكواد «مصيدة»؛ Gift card Apple/iTunes.", "Trap codes; Apple/iTunes Gift Card.", APPLE_IMG, "500$", 280, 500, APPLE_DETAILS, ["US/INTL", "24H_REDEEM"], true),
    ],
  },

  /* 3 — Amazon */
  {
    id: "amazon", short: A("Amazon"), name: A("بطاقات أمازون (Amazon)"),
    desc: A("أكواد «مصيدة» لمتجر Amazon Gift Card للاستخدام المباشر فقط، ويُمنع شراء بطاقات أخرى بها. اشحن خلال 24 ساعة."),
    icon: "box", hero: AMAZON_IMG,
    guideTitle: A("📦 تعليمات بطاقات Amazon"),
    guide: [
      A("أكواد «مصيدة»؛ للاستخدام المباشر فقط."),
      A("يُمنع شراء بطاقات أخرى بها."),
      A("اشحن خلال 24 ساعة من الاستلام."),
      A("تطابق Region مطلوب قبل التفعيل."),
    ],
    products: [
      P("az1", "Amazon Gift Card — 100$", "Amazon Gift Card — $100", "أكواد «مصيدة» لمتجر Amazon Gift Card.", "Trap codes for Amazon Gift Card.", AMAZON_IMG, "100$", 60, 100, AMAZON_DETAILS, ["DIRECT_USE", "24H_REDEEM"]),
      P("az2", "Amazon Gift Card — 300$", "Amazon Gift Card — $300", "أكواد «مصيدة» لمتجر Amazon Gift Card.", "Trap codes for Amazon Gift Card.", AMAZON_IMG, "300$", 170, 300, AMAZON_DETAILS, ["DIRECT_USE", "24H_REDEEM"]),
      P("az3", "Amazon Gift Card — 500$", "Amazon Gift Card — $500", "أكواد «مصيدة» لمتجر Amazon Gift Card.", "Trap codes for Amazon Gift Card.", AMAZON_IMG, "500$", 260, 500, AMAZON_DETAILS, ["DIRECT_USE", "24H_REDEEM"], true),
      P("az4", "Amazon Gift Card — 1000$", "Amazon Gift Card — $1000", "أكواد «مصيدة» لمتجر Amazon Gift Card.", "Trap codes for Amazon Gift Card.", AMAZON_IMG, "1000$", 500, 1000, AMAZON_DETAILS, ["DIRECT_USE", "24H_REDEEM"], true),
    ],
  },

  /* 4 — Gaming */
  {
    id: "gaming", short: A("Gaming"), name: A("بطاقات الألعاب (Gaming)"),
    desc: A("بطاقات ألعاب «مصيدة»: PlayStation · Xbox · Steam · Google Play · Razer Gold · Roblox · eBay · Microsoft. اشحن فوراً وتأكد من تطابق الريجون."),
    icon: "play", hero: GAMING_IMG,
    guideTitle: A("🎮 تعليمات بطاقات الألعاب"),
    guide: [
      A("أكواد «مصيدة»؛ اشحن فوراً (24 ساعة)."),
      A("تأكد من تطابق الريجون قبل التفعيل."),
      A("صالحة للمتجر المحدد لكل بطاقة فقط، ويُسلَّم الكود مع Region المطابق."),
      A("أي تأخير超过 24 ساعة يُفقد الصلاحية."),
    ],
    products: [
      P("g1", "PlayStation — 100$", "PlayStation — $100", "بطاقة ألعاب «مصيدة» PlayStation.", "PlayStation trap gift card.", "https://i.postimg.cc/GpDkH04H/images-(20).jpg", "100$", 35, 100, GAMING_DETAILS, ["REGION_MATCH", "24H_REDEEM"]),
      P("g2", "Xbox — 100$", "Xbox — $100", "بطاقة ألعاب «مصيدة» Xbox.", "Xbox trap gift card.", "https://i.postimg.cc/6pkZsHYP/51T1yq-Um-A1L-SL1000-(1).jpg", "100$", 35, 100, GAMING_DETAILS, ["REGION_MATCH", "24H_REDEEM"]),
      P("g3", "Steam — 100$", "Steam — $100", "بطاقة ألعاب «مصيدة» Steam.", "Steam trap gift card.", "https://i.postimg.cc/9Q74BdCb/635496122.png", "100$", 35, 100, GAMING_DETAILS, ["REGION_MATCH", "24H_REDEEM"]),
      P("g4", "Google Play — 100$", "Google Play — $100", "بطاقة «مصيدة» Google Play.", "Google Play trap gift card.", "https://i.postimg.cc/nVSCbRLY/images-(2).png", "100$", 45, 100, GAMING_DETAILS, ["REGION_MATCH", "24H_REDEEM"]),
      P("g5", "Razer Gold — 100$", "Razer Gold — $100", "بطاقة ألعاب «مصيدة» Razer Gold.", "Razer Gold trap gift card.", "https://i.postimg.cc/MTKKgVJ2/images-(21).jpg", "100$", 45, 100, GAMING_DETAILS, ["REGION_MATCH", "24H_REDEEM"]),
      P("g6", "Roblox — 100$", "Roblox — $100", "بطاقة ألعاب «مصيدة» Roblox.", "Roblox trap gift card.", "https://i.postimg.cc/7Z3H6mqd/images-(22).jpg", "100$", 35, 100, GAMING_DETAILS, ["REGION_MATCH", "24H_REDEEM"]),
      P("g7", "eBay — 100$", "eBay — $100", "بطاقة «مصيدة» eBay.", "eBay trap gift card.", "https://i.postimg.cc/mrVT3k1f/images-(23).jpg", "100$", 30, 100, GAMING_DETAILS, ["REGION_MATCH", "24H_REDEEM"]),
      P("g8", "Microsoft — 100$", "Microsoft — $100", "بطاقة «مصيدة» Microsoft.", "Microsoft trap gift card.", "https://i.postimg.cc/HLLkhbgm/images-(24).jpg", "100$", 30, 100, GAMING_DETAILS, ["REGION_MATCH", "24H_REDEEM"]),
    ],
  },

  /* 5 — Subscriptions */
  {
    id: "subs", short: A("Subscriptions"), name: A("الاشتراكات الرقمية (Subscriptions)"),
    desc: A("حسابات «مصيدة» باشتراكات سنوية كاملة: Netflix · Spotify · YouTube · Disney+/Crunchyroll · Canva · VPN. يُمنع تغيير الإيميل أو الباسورد لضمان الضمان."),
    icon: "star", hero: SUBS_IMG,
    guideTitle: A("📺 تعليمات الاشتراكات الرقمية"),
    guide: [
      A("حسابات «مصيدة»؛ يمنع تغيير الإيميل أو الباسورد لضمان الضمان."),
      A("اشحنها فوراً؛ الاشتراك فعّال لمدة سنة كاملة من تاريخ التسليم."),
      A("بيانات الدخول تُسلَّم جاهزة دون تعديل."),
      A("أي تغيير في الإيميل/الباسورد يُلغي الضمان."),
    ],
    products: [
      P("s1", "Netflix Premium — سنة", "Netflix Premium — 1 Year", "حساب «مصيدة» باشتراك سنة كامل.", "Trap account, full-year subscription.", "https://i.postimg.cc/HxcspHn9/images-(3).png", "سنة كاملة", 50, undefined, SUBS_DETAILS, ["1 YEAR", "NO CHANGE"], true),
      P("s2", "Spotify Family — سنة", "Spotify Family — 1 Year", "حساب «مصيدة» باشتراك سنة كامل.", "Trap account, full-year subscription.", "https://i.postimg.cc/Jzp1ZtBp/images-(4).png", "سنة كاملة", 30, undefined, SUBS_DETAILS, ["1 YEAR", "NO CHANGE"]),
      P("s3", "YouTube Premium — سنة", "YouTube Premium — 1 Year", "حساب «مصيدة» باشتراك سنة كامل.", "Trap account, full-year subscription.", "https://i.postimg.cc/L4j2vx1S/images-(26).jpg", "سنة كاملة", 30, undefined, SUBS_DETAILS, ["1 YEAR", "NO CHANGE"]),
      P("s4", "Disney+ / Crunchyroll — سنة", "Disney+ / Crunchyroll — 1 Year", "حساب «مصيدة» باشتراك سنة كامل.", "Trap account, full-year subscription.", "https://i.postimg.cc/Nf4YvLb0/crunchyrolldisney.png", "سنة كاملة", 25, undefined, SUBS_DETAILS, ["1 YEAR", "NO CHANGE"]),
      P("s5", "Canva Pro — سنة", "Canva Pro — 1 Year", "حساب «مصيدة» باشتراك سنة كامل.", "Trap account, full-year subscription.", "https://i.postimg.cc/VNSctgwL/642cf193d2c9f.png", "سنة كاملة", 20, undefined, SUBS_DETAILS, ["1 YEAR", "NO CHANGE"]),
      P("s6", "NordVPN / ExpressVPN — سنة", "NordVPN / ExpressVPN — 1 Year", "حساب «مصيدة» باشتراك سنة كامل.", "Trap account, full-year subscription.", "https://i.postimg.cc/vTvRySrV/images-(27).jpg", "سنة كاملة", 25, undefined, SUBS_DETAILS, ["1 YEAR", "NO CHANGE"]),
    ],
  },

  /* 6 — Services */
  {
    id: "services", short: A("Services"), name: A("خدمات الربط والشحن (Services)"),
    desc: A("خدمة توثيق وربط Apple/Google Pay؛ تتطلب تنفيذاً فورياً لضمان قبول وسيلة الدفع قبل التبليغ."),
    icon: "link", hero: SERVICES_IMG,
    guideTitle: A("🔗 تعليمات خدمات الربط والشحن"),
    guide: [
      A("خدمة توثيق؛ تتطلب تنفيذاً فورياً لضمان قبول وسيلة الدفع قبل التبليغ."),
      A("ربط Apple Pay / Google Pay بحسابك عبر بوابة معتمدة."),
      A("يُشترط التنفيذ الفوري بعد الاستلام، وتُسلَّم تعليمات الربط الآمن مع الخدمة."),
    ],
    products: [
      P("sv1", "Apple / Google Pay Binding", "Apple / Google Pay Binding", "خدمة توثيق وربط فوري لوسيلة الدفع.", "Instant payment-method verification & binding.", SERVICES_IMG, "خدمة توثيق", 40, undefined, SERVICES_DETAILS, ["INSTANT", "BINDING_SERVICE"], true),
    ],
  },
];

export const giftSectionById = (id: string) => GIFT_SECTIONS.find((s) => s.id === id);

/** رسالة الشراء الموحدة لبطاقات الهدايا */
export function giftOrderMessage(p: GiftProduct): string {
  return [
    "طلب شراء جديد:",
    `🔹 اسم المنتج: ${p.name.ar || ""}`,
    `🔹 الرصيد: ${p.balance.ar || ""}`,
    `🔹 السعر: ${p.priceUsd}$`,
    "الرجاء تزويدي بمحفظة الدفع لإتمام العملية فوراً.",
  ].join("\n");
}
