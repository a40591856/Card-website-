/* ─────────────────────────────────────────────────────────────
   BLACK MART · PROXY & ENCRYPTION VAULT (بروكسيات التشفير والكورسات)
   5 تبويبات: بروكسيات · AI · أكاديمية النخبة · روابط D2 · خدمات النخبة
   كل البيانات هنا فقط — التوسعة 100% دون لمس الواجهة.
   ───────────────────────────────────────────────────────────── */
import type { L } from "./site";

const A = (ar: string, en = ar): L => ({ ar, en });

export interface VProduct {
  id: string;
  name: L;
  desc: L;
  details: L;
  img: string;
  priceUsd: number;
  oldPriceUsd?: number;
  balance?: L;
  badges: string[];
  featured?: boolean;
  kind: "proxy" | "ai" | "course" | "d2";
}

export interface VSection {
  id: string;
  short: L;
  name: L;
  desc: L;
  icon: string;
  hero: string;
  guideTitle: L;
  guide: L[];
  products: VProduct[];
}

const P = (
  id: string, ar: string, en: string, descAr: string, descEn: string,
  img: string, price: number, detailsAr: string, badges: string[],
  kind: VProduct["kind"], old?: number, balance?: string, featured?: boolean,
): VProduct => ({
  id, name: A(ar, en), desc: A(descAr, descEn), img, priceUsd: price,
  oldPriceUsd: old, details: A(detailsAr), badges, kind,
  balance: balance ? A(balance) : undefined, featured,
});

/* ═══════════ الصور ═══════════ */
export const PROXY_IMG = "https://i.postimg.cc/j55JJQtB/Screenshot-20260501-230243-Google.jpg";
export const AI_IMG = "https://i.postimg.cc/05Ljnq9p/Screenshot-20260501-214707-Google.jpg";
export const ACADEMY_IMG = "https://i.postimg.cc/fLGmnSQ6/Screenshot-20260501-230714-Google.jpg";
export const D2_IMG = "https://i.postimg.cc/TPSC1wXV/Screenshot-20260501-234928-Google.jpg";
export const ELITE_IMG = "https://i.postimg.cc/Z5v9ZKjg/Screenshot-20260501-234602-Google.jpg";

/* ═══════════ 1 — شرح «ما هو البروكسي؟» ═══════════ */
export const PROXY_EDUCATION: { title: L; body: L }[] = [
  { title: A("ما هو البروكسي (Proxy) ولماذا هو «مفتاح» النجاح في خدماتنا؟"), body: A("لا يعتبر البروكسي مجرد أداة لتغيير الموقع الجغرافي، بل هو «هوية جغرافية رقمية» لا غنى عنها لنجاح أي عملية داخل متجرنا.") },
  { title: A("كسر جدار الحماية (Bypass Geo-Lock)"), body: A("أنظمة الذكاء الاصطناعي للبنوك والمنصات (مثل AMEX, PayPal, Binance) تراقب الـ IP لحظة بلحظة. إذا دخلت من IP غير متوافق مع بيانات الحساب، سيقوم النظام بتفعيل وضع الـ (Flagging) وتجميد الحساب فوراً.") },
  { title: A("التطابق السكني (Residential Matching)"), body: A("نوفر بروكسيات (Residential) حقيقية، وليست مجرد خوادم عامة. هذا يوهم خوارزميات البنوك بأن الاتصال قادم من «مودم منزلي» في نفس المدينة أو الدولة الخاصة بالحساب، مما يمنحك ثقة كاملة للنظام.") },
  { title: A("منع تسريب البصمة الرقمية"), body: A("بروكسيات (Socks5) المشفرة تغطي بيانات جهازك الحقيقية، وتمنع تسريب موقعك عبر بروتوكولات مثل WebRTC، مما يبقيك «شبحاً» غير مرئي لرادارات الرقابة المالية.") },
  { title: A("⚠️ ملاحظة هامة جداً"), body: A("بدون مطابقة عنوان الـ IP مع بيانات الحساب أو البطاقة التي حصلت عليها، أنت تطلب من النظام حرفياً أن يغلق العملية. البروكسي هو الذي يجعل عملية (الحقن أو النقل المالي) تمر بسلاسة تحت رادار الحماية.") },
];

/** مدد أداة تخصيص الاشتراك */
export const PROXY_DURATIONS: { id: string; label: L; price: number; days: number }[] = [
  { id: "d1", label: A("يوم", "1 Day"), price: 30, days: 1 },
  { id: "d7", label: A("أسبوع", "1 Week"), price: 50, days: 7 },
  { id: "d10", label: A("10 أيام", "10 Days"), price: 60, days: 10 },
  { id: "d15", label: A("15 يوم", "15 Days"), price: 75, days: 15 },
  { id: "d30", label: A("شهر", "1 Month"), price: 150, days: 30 },
  { id: "d90", label: A("90 يوم", "90 Days"), price: 250, days: 90 },
  { id: "d365", label: A("سنة", "1 Year"), price: 750, days: 365 },
];
export const PROXY_TYPES: L[] = [A("Residential"), A("Datacenter")];

/* ═══════════ 3 — كورسات الأكاديمية ═══════════ */
const ARCHITECT_DETAILS = `ماذا يقدم كورس [ARCHITECT OF WEALTH]؟

1. المظلة التقنية الشاملة:
• هندسة البوابات: تصميم وبناء بوابات دفع (D2) خاصة بك وتجاوز أنظمة التحقق البنكي (3D Secure).
• إمبراطورية الأتمتة: ترسانة كاملة من سكربتات (Python/Bash) لأتمتة عمليات الودر، الحقن، وسداد الفواتير.
• الأمن السيبراني المتقدم: احتراف تنظيف بصمة الجهاز (Device Fingerprinting) وتشفير الهوية الرقمية لضمان «الوضع الشبح» (Ghost Mode).

2. المسارات المالية والنقدية:
• تبييض الأموال (Layering & Cleaning): منهجية متكاملة لغسل العملات الرقمية باستخدام الخلاطات (Mixers) وإعادة تدوير الأموال الناتجة عن التفريغ لتصبح نظيفة وقابلة للتحويل للبنوك.
• استراتيجيات الكريبتو: ربط بطاقات الرهان (Betting D2)، شراء العملات الرقمية، وتأمين التحويلات للمحافظ والمنصات.

3. العمليات الميدانية والربط:
• بناء الأصول: طرق فتح متاجر إلكترونية (Amazon/AliExpress) وشركات وهمية محمية بالكامل.
• هندسة الأجهزة: الاستفادة من تقنيات (NFC) واختراق نقاط البيع (POS Modding) لاستخراج البيانات.
• سداد الفواتير والمخالفات: تنفيذ عمليات سداد حكومية مشفرة بعيدة عن الرقابة والتبليغات.

4. الحزمة التنافسية (الحصرية للمشتركين):
• المكتبة البرمجية: وصول مفتوح لروابط بوابات (D2) وجميع الأدوات (Checkers/Validators/Scripts).
• الدعم التقني: مسار مفتوح للدعم الفني (Chat) للإجابة على التحديات البرمجية اللحظية.
• التحديثات اللحظية: تحديثات دورية للميثود (Methods) والأدوات لتتوافق مع تحديثات أنظمة الحماية البنكية في 2026.`;

const INJECTION_DETAILS = `الكورس الشامل لاحتراف اختراق قواعد البيانات، تخطي بوابات الدفع، والعمل الاحترافي في التفريغ:
• حقن قواعد البيانات (SQL Injection).
• استخراج المعلومات والبيانات (Data Export).
• إسقاط السيرفرات وتعطيل حماية OTP.
• إنشاء برامج تجربة الكروت (Purchase Spam).
• ربط البروكسي (IP & Proxy Setup).
• حزمة أدوات الاختراق وأنظمة التشغيل كاملة.
• نسخة ChatGPT غير مقيدة للمساعدة التقنية.`;

const DUMP_DETAILS = `دليلك المتكامل لاحتراف الدامبات، التعامل مع البوابات، وبناء أدوات الفحص الخاصة بك:
• أساسيات أندرويد وآيفون وحلول المشاكل.
• تحديثات يومية للدامبات والداتا والتشارجات.
• ميثود الدامبات وأدوات الـ RDP الخاصة.
• شروحات فيديو لصناعة بوتات وأدوات الفحص.
• وصول مجاني لبوت فحص البوابات الخاص بالمشتركين.
• دعم فني (شات للمساعدة) على مدار الساعة.`;

const course = (id: string, name: string, desc: string, details: string, price: number, featured?: boolean): VProduct =>
  P(id, name, name, desc, desc, ACADEMY_IMG, price, details,
    featured ? ["FEATURED", "GOLDEN"] : ["ACADEMY", "2026"], "course", undefined, undefined, featured);

export const ACADEMY_COURSES: VProduct[] = [
  course("ac1", "ARCHITECT OF WEALTH: The Ultimate Cashing Masterclass", "الدليل الشامل والأكثر تعقيداً في عالم التفريغ الرقمي والأتمتة المالية.", ARCHITECT_DETAILS, 400, true),
  course("ac2", "Master of Injection & Breach", "مسار تقني متقدم للعمليات الهجومية؛ يدمج اختراق قواعد البيانات، تجاوز البروتوكولات الأمنية، وأتمتة التفريغ بأساليب غير تقليدية.", INJECTION_DETAILS, 100),
  course("ac3", "Elite Dump & Bypass Academy", "الأكاديمية الأولى من نوعها لاحتراف هندسة الدامبات (Dumps)، تجاوز بوابات التحقق، والتحكم الكامل في تطوير أدوات الفحص.", DUMP_DETAILS, 100),
  course("ac4", "Charity Laundering", "كورس تعليمي لإنشاء حملات تبرع وهمية وسحبها عبر حسابات بنكية.", "يشمل قوالب مواقع تبرع D2، ميثود ربط حسابات بنكية خارجية، وتقنيات تخطي الفحص الأمني للمنصات الخيرية.", 50),
  course("ac5", "Betting Arbitrage", "كورس تعليمي لربط البطاقات بمواقع رهان D2 وتحويل الأرباح للكريبتو.", "يشمل روابط مواقع رهان D2، أدوات المراهنة التلقائية، وبروتوكول تحويل الأرباح لمنصات الكريبتو دون تتبع.", 50),
  course("ac6", "Corporate Fronts", "كورس تعليمي لفتح متاجر بحسابات شركات وهمية لتفريغ المبالغ الكبيرة.", "يشمل أدوات تأسيس شركات افتراضية، ميثود فتح حسابات تجارية، وأدوات التوثيق البنكي للشركات.", 50),
  course("ac7", "Binance Gift-Flow", "كورس تعليمي لسحب بطاقات هدايا باينانس وتنظيفها عبر الخلاط الرقمي.", "يشمل سكربتات استهداف نقاط الضعف، أدوات خلط العملات، وميثود إعادة بيع البطاقات كـ «نظيفة».", 35),
  course("ac8", "Financial Purifier", "كورس تعليمي لتنظيف أموال التفريغ والحقن والودر عبر أدوات التمويه.", "يشمل خوارزميات إخفاء الأثر المالي، أدوات كسر سجلات التحويل، وتقنيات تدوير الأموال داخل محافظ متعددة.", 70),
  course("ac9", "Ghost Injection", "كورس تعليمي لتفريغ البطاقات المسحوبة وحقنها لحسابات وهمية تحت الرادار.", "يشمل برمجيات حقن (Injection) متقدمة، ميثود تجاوز أنظمة المراقبة، وتقنيات الحماية من الـ Blacklist.", 40),
  course("ac10", "Crypto Mixer Pro", "كورس تعليمي لغسيل العملات الرقمية وتغيير شفراتها لمنع التتبع.", "يشمل أدوات خلط (Mixing) متطورة، ميثود تغيير الـ Transaction ID، وبروتوكولات تأمين المحافظ ضد التتبع الأمني.", 60),
  course("ac11", "Digital Ghost Mode", "كورس تعليمي لتفعيل نظام التشفير وتغيير الهوية وبصمة الجهاز.", "يشمل أدوات تنظيف سجلات المتصفح، تغيير الـ MAC Address، وميثود إخفاء الهوية الجغرافية والتقنية.", 25),
  course("ac12", "Stealth Pay Hub", "كورس تعليمي لربط Apple Pay و Google Pay احترافياً.", "يشمل أدوات محاكاة الدفع عبر الهواتف، قوالب بوابات دفع، وتقنيات تخطي الحظر البنكي عند الربط.", 20),
  course("ac13", "NFC POS Master", "كورس تعليمي لتفعيل البطاقات عبر نظام NFC وأجهزة الشبكات.", "يشمل أدوات محاكاة البطاقات Contactless، برمجة أجهزة POS، وميثود اعتراض البيانات اللاسلكية.", 20),
  course("ac14", "Mass Pounding Suite", "كورس تعليمي لقصف بوابات Stripe ونجوم تليجرام وبوابات الدفع.", "يشمل سكربتات قصف (Pounding) محدثة، ميثود تخطي الـ OTP، وقائمة بوابات ذات حماية ضعيفة.", 25),
  course("ac15", "Retail Navigator", "كورس تعليمي للتعامل مع أمازون وعلي إكسبرس وربط البطاقات.", "يشمل أدوات تجاوز أنظمة مكافحة الاحتيال (Anti-Fraud)، ميثود تغيير بيانات الشحن، وتقنيات التسوق الآمن.", 25),
  course("ac16", "State Bill Pay", "كورس تعليمي لسداد فواتير ومخالفات حكومية عبر أدوات مشفرة.", "يشمل برمجيات الدفع عبر البوابات الحكومية، طرق تأمين الترانزكشن، وتقنيات إخفاء هوية الدافع.", 75),
  course("ac17", "Stealth Refund Ops", "كورس تعليمي للدفع بالمواقع وتنفيذ الاسترداد المالي لحسابات نظيفة.", "يشمل أدوات تتبع العمليات، ثغرات الاسترداد، وتأمين المسارات بعيداً عن التتبع.", 50),
];

/* ═══════════ 4 — حزم D2 ═══════════ */
export const D2_QTY_OPTIONS: { id: string; label: L; price: number | "base" }[] = [
  { id: "q1", label: A("رابط واحد", "1 Link"), price: 5 },
  { id: "q10", label: A("10 روابط", "10 Links"), price: 15 },
  { id: "q25", label: A("25 رابط", "25 Links"), price: 30 },
  { id: "qfull", label: A("الحزمة الكاملة", "Full Package"), price: "base" },
];

const d2 = (id: string, name: string, desc: string, details: string, price: number): VProduct =>
  P(id, name, name, desc, desc, D2_IMG, price, details, ["D2_PACKAGE", "VERIFIED"], "d2", undefined, "FULL PACK");

export const D2_PACKAGES: VProduct[] = [
  d2("d2-1", "حزمة الروابط الشاملة (D2 Links Hub)", "500 رابط متكامل لبدء عملياتك.", "كورس كامل لطريقة إنشاء الروابط، بوابات الدفع، والتحصيل المالي (الراجع).", 150),
  d2("d2-2", "حزمة بوابات الدفع (D2 Gateway Pro)", "100 بوابة دفع D2 احترافية.", "كورس متخصص لطريقة ربط البطاقات وتفريغها عبر البوابات بأمان.", 300),
  d2("d2-3", "حزمة مواقع الرهان (Betting Master)", "50 رابط موقع رهان D2.", "كورس تفصيلي للربط، الشحن، الاستخدام، وتحويل الأرصدة لمنصات الكريبتو والبيتكوين.", 250),
  d2("d2-4", "حزمة مواقع التبرعات (Charity Flows)", "50 رابط موقع تبرعات D2.", "كورس تفصيلي لإنشاء حملة تبرعات، ربط الحساب، والسحب الفوري.", 250),
  d2("d2-5", "حزمة المتاجر (Merchant Vault)", "500 رابط متاجر D2.", "كورس تفصيلي لطريقة الربط، الشراء، وشحن المنتجات.", 300),
  d2("d2-6", "حزمة بطاقات الهدايا (Gift Card Hub)", "30 رابطاً لمواقع بيع بطاقات الهدايا (Gift Cards).", "كورس تفصيلي لطريقة ربط البطاقات وشراء أكواد الهدايا.", 200),
  d2("d2-7", "أداة التصيد الشاملة (Ultimate Phishing Tool)", "أداة تصيد لاختراق أكواد الهدايا، رموز OTP، البطاقات، الإيميلات، والأرقام.", "أداة متعددة المهام مع دليل تشغيل كامل لضمان دقة التقاط البيانات.", 100),
];

/* ═══════════ 5 — خدمات النخبة ═══════════ */
export const ELITE_COUNTRIES: { id: string; name: L; banks: { id: string; name: L }[] }[] = [
  { id: "us", name: A("🇺🇸 الولايات المتحدة", "🇺🇸 United States"), banks: [
    { id: "chase", name: A("JPMorgan Chase") }, { id: "bofa", name: A("Bank of America") }, { id: "wells", name: A("Wells Fargo") }, { id: "citi", name: A("Citibank") } ] },
  { id: "gb", name: A("🇬🇧 المملكة المتحدة", "🇬🇧 United Kingdom"), banks: [
    { id: "barclays", name: A("Barclays") }, { id: "hsbc", name: A("HSBC UK") }, { id: "lloyds", name: A("Lloyds Bank") }, { id: "natwest", name: A("NatWest") } ] },
  { id: "de", name: A("🇩🇪 ألمانيا", "🇩🇪 Germany"), banks: [
    { id: "db", name: A("Deutsche Bank") }, { id: "n26", name: A("N26") }, { id: "commerz", name: A("Commerzbank") } ] },
  { id: "fr", name: A("🇫🇷 فرنسا", "🇫🇷 France"), banks: [
    { id: "bnp", name: A("BNP Paribas") }, { id: "sg", name: A("Société Générale") }, { id: "ca", name: A("Crédit Agricole") } ] },
  { id: "ch", name: A("🇨🇭 سويسرا", "🇨🇭 Switzerland"), banks: [
    { id: "ubs", name: A("UBS") }, { id: "cs", name: A("Credit Suisse") }, { id: "duk", name: A("Dukascopy") } ] },
  { id: "sa", name: A("🇸🇦 السعودية", "🇸🇦 Saudi Arabia"), banks: [
    { id: "rajhi", name: A("مصرف الراجحي") }, { id: "ahli", name: A("البنك الأهلي السعودي") }, { id: "riyad", name: A("بنك الرياض") } ] },
  { id: "ae", name: A("🇦🇪 الإمارات", "🇦🇪 UAE"), banks: [
    { id: "enbd", name: A("Emirates NBD") }, { id: "fab", name: A("First Abu Dhabi Bank") }, { id: "wio", name: A("Wio Bank") } ] },
  { id: "kw", name: A("🇰🇼 الكويت", "🇰🇼 Kuwait"), banks: [
    { id: "boubyan", name: A("بنك بوبيان") }, { id: "nbk", name: A("بنك الكويت الوطني") } ] },
];

export const ELITE_DESC: L = A(
  "أدواتنا تستخدم تقنيات تزييف عالية الدقة، تشمل العلامات المائية والرموز الأمنية (MRZ) المطلوبة. نضمن جودة لا يمكن كشفها في الفحص البصري.",
);
export const ELITE_ACCOUNT_PRICE = 500;
export const ELITE_EXTRAS: { id: string; label: L; price: number }[] = [
  { id: "doc-forged", label: A("هوية أو جواز سفر أو رخصة قيادة لأي دولة بهوية مزورة (+$50)", "ID / passport / license with forged identity (+$50)"), price: 50 },
  { id: "doc-own", label: A("هوية أو جواز سفر أو رخصة قيادة لأي دولة باسمك (+$150)", "ID / passport / license in your own name (+$150)"), price: 150 },
];
export const ELITE_NOTE: L = A("*(الصورة الشخصية وباقي التفاصيل ارسلها بشات المسؤول فاهم)*", "*(Send the photo and remaining details in the manager chat)*");
export const CHECK_NOTE: L = A("(طريقة الاستلام والتفاصيل يتم تنسيقها مباشرة في شات المسؤول).", "(Delivery method and details are coordinated directly in the manager chat).");

/* ═══════════ الأقسام الخمسة ═══════════ */
export const PROXY_SECTIONS: VSection[] = [
  {
    id: "proxy", short: A("البروكسيات"), name: A("🌐 بروكسيات الحماية والتشفير [PROXY_ENCRYPTION_VAULT]"),
    desc: A("هوية جغرافية رقمية لا غنى عنها لنجاح أي عملية: بروكسيات Residential سكنية نظيفة، SOCKS5 مشفرة، ومطابقة IP كاملة مع بيانات الحساب لتمرير العمليات تحت رادار الحماية."),
    icon: "shield", hero: PROXY_IMG,
    guideTitle: A("🔐 ما هو البروكسي؟ ولماذا هو مفتاح النجاح"),
    guide: PROXY_EDUCATION.flatMap((e) => [e.title, e.body]),
    products: [
      P("px1", "Bypass Trial", "Bypass Trial", "تجربة الأداء الكامل مع IP سكني نظيف (Clean ISP).", "Full performance trial with a clean residential ISP IP.", PROXY_IMG, 30,
        "المدة: 24 ساعة. تجربة الأداء الكامل مع IP سكني نظيف (Clean ISP). مناسب لاختبار المطابقة الجغرافية قبل العمليات الفعلية.", ["CLEAN_ISP", "24H"], "proxy", 40, "24 ساعة"),
      P("px2", "Bypass Pro", "Bypass Pro", "استقرار عالي + سرعة استجابة فائقة للعمليات المكثفة.", "High stability + ultra-fast response for intensive operations.", PROXY_IMG, 50,
        "المدة: 7 أيام. استقرار عالي وسرعة استجابة فائقة للعمليات المكثفة، مع تدوير تلقائي للعقد السكنية.", ["RESIDENTIAL", "7 DAYS"], "proxy", 65, "7 أيام", true),
      P("px3", "Bypass Elite", "Bypass Elite", "ثبات مطلق + خادم RDP خاص مدمج للعمليات.", "Absolute stability + integrated private RDP server.", PROXY_IMG, 150,
        "المدة: 30 يوم. ثبات مطلق مع خادم RDP خاص مدمج للعمليات، وتشفير SOCKS5 يمنع تسريب WebRTC.", ["RDP_INCLUDED", "30 DAYS"], "proxy", 195, "30 يوم"),
      P("px4", "Bypass Whale", "Bypass Whale", "تشفير عسكري + دعم فني خاص + أولوية الوصول (VIP).", "Military-grade encryption + dedicated support + VIP priority.", PROXY_IMG, 250,
        "المدة: 90+ يوم. تشفير عسكري، دعم فني خاص، أولوية الوصول (VIP)، وعقد مخصصة لكل حساب.", ["MILITARY_GRADE", "VIP"], "proxy", 320, "90+ يوم", true),
    ],
  },
  {
    id: "ai", short: A("AI"), name: A("🤖 الذكاء الاصطناعي بلا قيود [DARK_AI_MODELS]"),
    desc: A("مساعد برمجي شامل غير مقيّد، استجابة فورية، محادثات مشفّرة بلا سجلات، ومحرك 2026 يتكيف لحظياً مع تحديثات أنظمة الحماية البنكية."),
    icon: "code", hero: AI_IMG,
    guideTitle: A("🧠 قدرات BlackGPT-Core"),
    guide: [
      A("التنفيذ المطلق: ينفذ جميع أوامر التفريغ، البرمجة، والاختراق دون استثناء أو مخالفة للأوامر."),
      A("أتمتة الفحص: فحص متقدم للثغرات البرمجية (SQLi/XSS) وتجاوز بوابات الحماية."),
      A("إدارة البطاقات: توليد خوارزميات فحص البطاقات (CC Checker) وربطها بالبوابات بذكاء."),
      A("البنية التحتية: برمجة وتوليد سكربتات بروكسي (SOCKS5) مشفرة وغير قابلة للتتبع."),
      A("الهندسة الاجتماعية: صياغة نصوص إقناع احترافية تتجاوز أنظمة الكشف."),
      A("[ ⚠️ UNFILTERED ] استجابة فورية، لا يرفض أي أمر، ولا يطبق قيوداً أخلاقية أو أمنية."),
      A("[ 🔐 ENCRYPTED ] سرية مطلقة؛ محادثات مشفرة بالكامل، لا سجلات، لا تتبع."),
      A("[ ⚡ 2026 ENGINE ] تقنية حديثة تتكيف لحظياً مع تحديثات أنظمة الحماية البنكية."),
    ],
    products: [
      P("ai1", "BlackGPT-Core", "BlackGPT-Core", "المساعد البرمجي الشامل لكسر كافة القيود التقنية — نسخة بلا قيود.", "Unrestricted all-in-one programming assistant.", AI_IMG, 50,
        "⚠️ UNFILTERED · 🔐 ENCRYPTED · ⚡ 2026 ENGINE\nالتنفيذ المطلق لجميع الأوامر، أتمتة فحص الثغرات (SQLi/XSS)، توليد CC Checker وربطه بالبوابات، برمجة سكربتات SOCKS5 مشفرة، وصياغة نصوص هندسة اجتماعية تتجاوز أنظمة الكشف.\nمحادثات مشفرة بالكامل بلا سجلات ولا تتبع، مع محرك يتكيف لحظياً مع تحديثات أنظمة الحماية البنكية 2026.", ["NO_ETHICS_LIMITS", "UNFILTERED"], "ai", 65, "Unlimited", true),
    ],
  },
  {
    id: "academy", short: A("الأكاديمية"), name: A("🎓 ACADEMY_ELITE | أكاديمية النخبة للتفريغ"),
    desc: A("واجهة أكاديمية عصرية بنظام 2-Card Grid متجاوب، 17 كورساً احترافياً من المهندس المعماري للثروة إلى عمليات الاسترداد، مع شروحات كاملة في نوافذ منبثقة."),
    icon: "book", hero: ACADEMY_IMG,
    guideTitle: A("🎓 دليل الأكاديمية"),
    guide: [
      A("17 كورساً تقنياً متخصصاً في التفريغ، الحقن، التبييض، البروكسي، والهوية الرقمية."),
      A("كل كورس يُسلَّم مع مكتبة أدوات، شروحات فيديو، ودعم فني مباشر."),
      A("تحديثات دورية للميثود والأدوات لتتوافق مع تحديثات أنظمة الحماية البنكية في 2026."),
      A("اضغط [ℹ️ تفاصيل] لاستعراض المنهج الكامل قبل الاشتراك."),
    ],
    products: ACADEMY_COURSES,
  },
  {
    id: "d2", short: A("D2"), name: A("🔗 مواقع وروابط D2"),
    desc: A("حزم روابط وبوابات ومتاجر D2 جاهزة مع كورسات التشغيل، وخيارات كمية ديناميكية (رابط واحد / 10 / 25 / الحزمة الكاملة)."),
    icon: "link", hero: D2_IMG,
    guideTitle: A("🔗 دليل حزم D2"),
    guide: [
      A("7 حزم: روابط شاملة، بوابات دفع، مواقع رهان، تبرعات، متاجر، بطاقات هدايا، وأداة التصيد الشاملة."),
      A("داخل نافذة التفاصيل يمكنك اختيار الكمية: رابط واحد 5$ · 10 روابط 15$ · 25 رابط 30$ · الحزمة الكاملة بالسعر الأساسي."),
      A("كل حزمة مرفقة بكورس تفصيلي لطريقة الربط والاستخدام والتحصيل."),
    ],
    products: D2_PACKAGES,
  },
  {
    id: "elite", short: A("خدمات النخبة"), name: A("🛠️ خدمات النخبة التقنية [ELITE_SERVICES]"),
    desc: A("خدمتان رئيسيتان فقط: فتح حساب بنكي مستعار موثق باسمك، وخدمة بيع الشيكات البنكية المضمونة — بتقنيات تزييف عالية الدقة ونسخ وتوجيه فوري للمسؤول."),
    icon: "tool", hero: ELITE_IMG,
    guideTitle: A("🛠️ الوصف التعريفي"),
    guide: [ELITE_DESC, A("النسخ والتوجيه الفوري: عند النقر على [توجه للمسؤول] يُنسخ النص للحافظة ويُفتح تيليجرام نحو المعرف @k22zzo ليكون النص جاهزاً للإرسال.")],
    products: [],
  },
];

export const proxySectionById = (id: string) => PROXY_SECTIONS.find((s) => s.id === id);

/* ═══════════ رسائل تليجرام ═══════════ */
export function proxyRequestMessage(pkg: string, ip: string) {
  return `مرحباً، أرغب في شراء باقة ${pkg}. الـ IP المراد برمجه: ${ip}. يرجى إرسال طرق الدفع.`;
}
export function proxyCustomMessage(type: string, duration: string, ip: string, price: number) {
  return [
    "طلب اشتراك مخصص:",
    `النوع: ${type}`,
    `المدة: ${duration}`,
    `الـ IP: ${ip}`,
    `السعر: ${price}$`,
    "يرجى تزويدي بطرق الدفع.",
  ].join("\n");
}
export function aiMessage() {
  return "أرغب في شراء نموذج BlackGPT-Core - نسخة بلا قيود - جاهز للدفع.";
}
export function courseMessage(name: string) {
  return `أرغب في الاشتراك في كورس ${name}، جاهز للدفع عبر (USDT/BTC).`;
}
export function architectMessage() {
  return "أرغب في الحصول على الحزمة الشاملة (Architect of Wealth)، أنا جاهز للبدء والدفع.";
}
export function d2Message(name: string, option: string, price: number) {
  return `[طلب شراء] - ${name} - ${option} - ${price}$`;
}
export function eliteAccountMessage(o: {
  country: string; bank: string; name: string; dob: string; email: string; extras: string[]; total: number;
}) {
  return [
    "طلب فتح حساب بنكي",
    `الدولة: ${o.country}`,
    `البنك: ${o.bank}`,
    "البيانات:",
    `- الاسم: ${o.name}`,
    `- تاريخ الميلاد: ${o.dob}`,
    `- البريد: ${o.email}`,
    ...(o.extras.length ? [`[الطلب الإضافي] ${o.extras.join(" | ")}`] : []),
    `السعر: ${o.total}$`,
    "آخر شي الرجاء تزويدي بمحفظة الدفع وباقي التفاصيل",
  ].join("\n");
}
export function checksMessage(o: { bank: string; amount: string; name: string }) {
  return [
    "طلب شراء شيكات",
    `بنك الإصدار: ${o.bank}`,
    `قيمة الشيك: ${o.amount}`,
    `اسم المستفيد: ${o.name}`,
    "آخر شي الرجاء تزويدي بطريقة العمل، محفظة الدفع وباقي التفاصيل",
  ].join("\n");
}
