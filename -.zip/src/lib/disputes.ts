/* ─────────────────────────────────────────────────────────────
   BLACK MART · البلاغات / خدمة العملاء / حل النزاعات
   كل النصوص والنماذج والشبكات والروابط هنا فقط (100% قابل للتوسعة).
   ───────────────────────────────────────────────────────────── */
import type { L } from "./site";
import { LINKS } from "./site";
import { adminMail } from "./support";

const A = (ar: string, en = ar): L => ({ ar, en });

export const DISPUTE_LINKS = {
  support: "http://t.me/custour?direct",
  channel: LINKS.channel,
  email: adminMail(), // a40591856@gmail.com (مخفي في الكود)
};

export const DISPUTE_TITLE: L = A("البلاغات / خدمة العملاء / حل النزاعات 🛡️");
export const DISPUTE_SUBTITLE: L = A(
  "مركز التحكيم والأرشيف · تشفير محلي · سجلات داخل متصفحك فقط",
);
export const AUTH_ALERT: L = A(
  "تنبيه أمني: يلزم تسجيل الدخول أو إنشاء حساب بالموقع أولاً لتمكين رفع التذاكر وتوثيق البلاغات.",
  "Security alert: sign in or create an account first to enable ticket submission.",
);

/* ═══════════ الأرشيف المحلي ═══════════ */
export const TICKETS_KEY = "bm_dispute_tickets";
export interface LocalTicket {
  hash: string;
  kind: string;
  subject: string;
  summary: string;
  at: string;
  encrypted: boolean;
  attachments: string[];
}
export const makeTicketHash = () =>
  `#TK-${Math.floor(1000 + Math.random() * 9000)}-SEC`;
export const ticketDate = () => {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
};

/* ═══════════ محلل المحافظ ═══════════ */
export interface WalletNetwork {
  id: string;
  name: L;
  hint: L;
  test: (v: string) => boolean;
}
export const WALLET_NETWORKS: WalletNetwork[] = [
  { id: "trc20", name: A("TRC20 · Tron"), hint: A("يبدأ بـ T ويتكوّن من 34 حرفاً"), test: (v) => /^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(v.trim()) },
  { id: "bep20", name: A("BEP20 · Binance Smart Chain"), hint: A("يبدأ بـ 0x ويتكوّن من 42 حرفاً"), test: (v) => /^0x[a-fA-F0-9]{40}$/.test(v.trim()) },
  { id: "erc20", name: A("ERC20 · Ethereum"), hint: A("يبدأ بـ 0x ويتكوّن من 42 حرفاً"), test: (v) => /^0x[a-fA-F0-9]{40}$/.test(v.trim()) },
  { id: "btc", name: A("BTC · Bitcoin"), hint: A("يبدأ بـ 1 أو 3 أو bc1q / bc1p"), test: (v) => /^(1|3|bc1[qp])[1-9A-HJ-NP-Za-km-z]{20,}$/.test(v.trim()) },
];
export const validateWallet = (network: string, address: string) => {
  const n = WALLET_NETWORKS.find((x) => x.id === network);
  if (!address.trim()) return { ok: false, msg: "أدخل عنوان المحفظة" };
  if (!n) return { ok: false, msg: "اختر الشبكة أولاً" };
  return n.test(address)
    ? { ok: true, msg: "✅ العنوان مطابق للشبكة المختارة" }
    : { ok: false, msg: `⚠️ العنوان غير مطابق — ${n.hint.ar}` };
};

/* ═══════════ نماذج التذاكر ═══════════ */
export interface TicketField {
  id: string;
  label: L;
  ph: L;
  type: "text" | "textarea" | "select";
  required?: boolean;
  options?: { value: string; label: L }[];
}

export interface TicketFormDef {
  id: string;
  kind: L;
  subject: string;
  icon: string;
  desc: L;
  fields: TicketField[];
}

const f = (id: string, ar: string, en: string, ph: string, type: TicketField["type"] = "text", required = true): TicketField => ({
  id, label: A(ar, en), ph: A(ph), type, required,
});

export const TICKET_FORMS: TicketFormDef[] = [
  {
    id: "refund", kind: A("طلب استرجاع", "Refund"), subject: "استرجاع", icon: "refresh",
    desc: A("للخدمات التالفة أو غير المُسلَّمة — تُرسل حصرياً للبريد الرسمي."),
    fields: [
      f("product", "اسم المنتج / الخدمة", "Product / Service", "مثال: حساب AMEX"),
      f("problem", "شرح المشكلة", "Problem description", "اشرح ما حدث بالتفصيل…", "textarea"),
      { id: "network", label: A("اختيار الشبكة"), ph: A("—"), type: "select", required: true,
        options: WALLET_NETWORKS.map((n) => ({ value: n.id, label: n.name })) },
      f("wallet", "عنوان المحفظة", "Wallet address", "T… / 0x… / bc1…"),
    ],
  },
  {
    id: "exchange", kind: A("طلب استبدال", "Exchange"), subject: "استبدال", icon: "swap",
    desc: A("استبدال خدمة تالفة بخدمة مطابقة للقيمة السعرية."),
    fields: [
      f("damaged", "اسم المنتج الحالي التالف", "Damaged product", "اسم الخدمة الحالية"),
      f("problem", "شرح المشكلة", "Problem description", "اشرح سبب الاستبدال…", "textarea"),
      f("desired", "اسم المنتج البديل المطلوب", "Replacement product", "الخدمة البديلة"),
    ],
  },
  {
    id: "dispute", kind: A("بلاغ أمني / نزاع مالي", "Fraud & Security Report"), subject: "بلاغ", icon: "warn",
    desc: A("يُحال فوراً لقسم الأمن السيبراني مع تجميد المعاملة."),
    fields: [
      f("party", "اسم / معرف الطرف المشكو في حقه", "Reported party", "@username / ID"),
      f("tx", "حساب عمله أو رقم المعاملة", "Account / Transaction ID", "TX Hash / معرف الحساب"),
      f("details", "شرح النزاع", "Dispute details", "اشرح الواقعة كاملة…", "textarea"),
    ],
  },
  {
    id: "inquiry", kind: A("تذكرة استفسار / اقتراح", "Inquiry / Suggestion"), subject: "استفسار", icon: "chat",
    desc: A("لشروحات الأدوات، المقترحات، والاستفسارات العامة."),
    fields: [
      f("topic", "موضوع الاستفسار", "Subject", "بماذا تحتاج المساعدة؟"),
      f("details", "التفاصيل", "Details", "اكتب استفسارك أو اقتراحك…", "textarea"),
    ],
  },
];

/* ═══════════ النص الرسمي لسياسة النزاعات ═══════════ */
export const DISPUTE_POLICY: { title: L; items: L[] }[] = [
  {
    title: A("1. الاسترجاع والاستبدال (عبر البريد الرسمي حصراً):"),
    items: [
      A("• الخدمات والأدوات التالفة: إذا قمت بشراء بطاقة تالفة، أو تعذر حقن بطاقتك، أو لم يتم تسليمك الحساب المطلوب، أو واجهتك مشكلة تقنية، يحق لك رفع «تذكرة استرجاع أو استبدال»."),
      A("• آلية معالجة الاسترجاع: يتم رفع الطلب عبر نموذج البريد مرفقاً به عنوان محفظتك وشرح الأسباب. يخضع الطلب للفحص الفني، وفي حال صحة البيانات، يتم تحويل أموالك إلى محفظتك خلال (3 إلى 6 أيام عمل)."),
      A("• آلية معالجة الاستبدال: يتم فحص الخدمة القديمة، وفي حال ثبوت تلفها أو توقفها، يتم استبدالها بخدمة بديلة مطابقة للقيمة السعرية خلال (3 إلى 6 أيام عمل)."),
    ],
  },
  {
    title: A("2. بلاغات الاحتيال والنزاعات المالية (Fraud & Escalation):"),
    items: [
      A("• التعرض للاحتيال أو المماطلة: في حال تعرضك لأي حالة احتيال أو عدم التزام من قبل أي منفذ، لودر (Loader)، أو مستقبل تحويلات داخل المنصة: قم فوراً برفع «تذكرة بلاغ» عبر البريد تتضمن (اسم الطرف المشكو في حقه + حساب عمله + شرح التذكرة مع الإثباتات)."),
      A("• التحقيق الأمني: فور استلام التذكرة على البريد، يتم تكليف فريق الأمن السيبراني بالتحقيق وتجميد المعاملة لحين حل النزاع وإعادة الحقوق."),
    ],
  },
  {
    title: A("3. عدم تجاوب المسؤولين وتأخر الطلبات:"),
    items: [
      A("• في حال تأخر طلبك أو لم يتم تقديم المساعدة لك من قبل أحد المسؤولين، قم برفع اسمه ورقم طلبك في تذكرة بريدية، وسيتم تصعيد الموضوع للإدارة العليا ومراجعة كافة السجلات فوراً."),
    ],
  },
  {
    title: A("4. المساعدة العامة والاقتراحات:"),
    items: [
      A("• إذا لم تفهم طريقة استخدام أداة معينة، أو رغبت بتقديم اقتراحات لتطوير الموقع، يمكنك رفع تذكرة استفسار ليصل صوتك للإدارة مباشرة."),
    ],
  },
];
export const POLICY_FOOTER: L[] = [
  A("💡 التزامنا الأمني معك: بمجرد اختيارك لخدمتك، ترافقك شروحاتنا المجانية. وفي حال واجهت أي تحدٍ، فإن فريق الدعم والتحكيم متواجد لضمان إتمام مهمتك بنجاح."),
  A("📞 مركز الدعم والاتصال اللحظي: فريقنا متواجد على مدار الساعة. للحصول على استفسارات سريعة، مساعدة في التفريغ، أو توجيه مباشر، يمكنك التواصل مع مسؤولي خدمة العملاء عبر قناة ورمز التيليجرام المخصص."),
];

/* ═══════════ بنّاء الروابط ═══════════ */
export const supportLink = (text: string) =>
  `https://t.me/custour?direct&text=${encodeURIComponent(text)}`;

export const mailtoLink = (subject: string, body: string) =>
  `mailto:${DISPUTE_LINKS.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

export const ticketSubject = (prefix: string, hash: string) =>
  `${prefix} - [${hash}] - ${ticketDate()}`;

export const ticketBody = (o: {
  hash: string; kind: string; fields: { label: string; value: string }[];
  attachments: string[]; videoLink: string; encrypted: boolean;
}) => [
  `[ BLACK MART · ${o.kind} ]`,
  `رقم التذكرة: ${o.hash}`,
  `التاريخ: ${ticketDate()}`,
  "--------------------------------------",
  ...o.fields.map((x) => `${x.label}: ${x.value || "—"}`),
  ...(o.attachments.length ? [`المرفقات (بعد مسح الميتاداتا): ${o.attachments.join(" | ")}`] : []),
  ...(o.videoLink ? [`رابط فيديو الإثبات: ${o.videoLink}`] : []),
  "--------------------------------------",
  "البيانات بصيغة نصية واضحة (Plain Text) لتتمكن الإدارة من قراءتها فوراً.",
  ...(o.encrypted ? ["🔐 نسخة العميل المحلية مشفّرة على جهازه (لا تؤثر على وضوح هذه الرسالة)."] : []),
  "[SYSTEM_ID: AUTO_GENERATED]",
].join("\n");

export const SUPPORT_QUICK_MSG =
  "مرحباً Black Mart، أحتاج إلى مساعدة / استفسار عبر مركز البلاغات وحل النزاعات.";
