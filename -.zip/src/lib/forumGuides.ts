/* ─────────────────────────────────────────────────────────────
   BLACK MART · دليل الأوصاف والشروحات التشغيلية (Guide Boxes Catalog)
   كل شرح مرتبط بـ id الخدمة — يُعرض تلقائياً في صندوق التعليمات.
   أضف/عدّل أي شرح من هنا فقط دون لمس كود الواجهة.
   ───────────────────────────────────────────────────────────── */
import type { L } from "./site";

const G = (ar: string, en: string): L => ({ ar, en });

export interface GuideEntry {
  guide: L;
  extra?: L; // الشرح الإضافي الطويل (يظهر خلف زر منسدل)
}

export const FORUM_GUIDES: Record<string, GuideEntry> = {
  /* ═══ 🟢 المجموعة 1: لودر التفريغ والاستقبال — أ) طلب منفذ ═══ */
  "d-in-1": {
    guide: G(
      "خدمة مخصصة لربط أصحاب البطاقات بالوسطاء المعتمدين لتنفيذ عمليات السحب المباشر عبر مكائن نقاط البيع (POS). يرجى تحديد نوع الجهاز (Pax, Verifone...)، الدولة، ونسبتك المطلوبة.",
      "Links card owners with approved brokers for direct POS withdrawals. Specify the device type (Pax, Verifone…), country, and your requested percentage.",
    ),
    extra: G(
      "تفاصيل إضافية: يُفضَّل ذكر طراز الجهاز بدقة، وعدد المكائن المطلوبة، وساعات التشغيل، وما إذا كنت تحتاج وسيطاً ميدانياً أو رقماً عن بُعد. لا تُدرج أي معرفات تواصل مكشوفة — التوجيه يتم عبر القناة المشفرة فقط.",
      "Extra: state the exact device model, number of terminals, operating hours, and whether you need a field broker or remote routing. Never include exposed contact handles.",
    ),
  },
  "d-in-2": {
    guide: G(
      "توفير وربط سيرفرات عالية الأداء مخصصة لتلقي ومعالجة البيانات والسيولة بشكل سريع وآمن. يُرجى كتابة مواصفات السيرفر المطلوب ودولة الاستضافة.",
      "Providing and linking high-performance servers to receive and process data and liquidity quickly and safely. Write the required server specs and hosting country.",
    ),
  },
  "d-in-3": {
    guide: G(
      "استقبال وتجهيز بوابات دفع إلكترونية مرنة لتمرير الشحنات المالية والبطاقات. يرجى إرفاق بروتوكول البوابة المطلوب والدول المدعومة.",
      "Receiving and preparing flexible payment gateways to pass financial charges and cards. Attach the required gateway protocol and supported countries.",
    ),
    extra: G(
      "تفاصيل إضافية: حدّد البروتوكول (API / 3DS / No-3DS)، العملات المدعومة، الحد اليومي للمعاملات، وسرعة التسوية المطلوبة. تُرفق أي ملفات لوج بعد مسح ميتاداتاها تلقائياً.",
      "Extra: specify the protocol (API / 3DS / No-3DS), supported currencies, daily limit, and required settlement speed. Any log files are EXIF-stripped automatically.",
    ),
  },
  "d-in-4": {
    guide: G(
      "توفير روابط شراء وتفريغ وتجهيز متاجر إلكترونية (D2 Direct) لتسوية السيولة بشكل فوري. يُرجى توضيح نوع المنتجات أو الخدمات المطلوبة في المتجر.",
      "Providing purchase/drain links and preparing D2 Direct stores for instant liquidity settlement. Clarify the products or services required in the store.",
    ),
  },
  "d-in-5": {
    guide: G(
      "توفير حسابات بنكية تجارية أو شخصية موثوقة (IBAN) لاستقبال التحويلات المالية والسحوبات. يرجى توضيح دولة البنك ونوع العملة.",
      "Providing trusted business or personal bank accounts (IBAN) to receive transfers and withdrawals. Clarify the bank country and currency.",
    ),
  },
  "d-in-6": {
    guide: G(
      "طلب بطاقات مخصصة لشحن وتفعيل البروتوكولات والسكربتات التلقائية. يُرجى تحديد نوع البروتوكول ونوع الفئة المطلوب شحنها.",
      "Requesting cards dedicated to charging and activating protocols and automated scripts. Specify the protocol type and the tier to be charged.",
    ),
  },
  "d-in-7": {
    guide: G(
      "استقبال السيولة الرقمية وتوجيهها مباشرة إلى محافظ باردة محصنة (Hard Wallets) لضمان عدم التتبع والسرية المطلقة. يرجى تحديد الشبكة (TRC20, ERC20, BTC).",
      "Receiving digital liquidity and routing it straight into hardened cold wallets for absolute privacy. Specify the network (TRC20, ERC20, BTC).",
    ),
  },
  "d-in-8": {
    guide: G(
      "إذا كان لديك طلب استقبال أو تفريغ خاص لا يندرج تحت القوائم أعلاه، اكتب كافة تفاصيل الشروط والآلية المطلوبة ليتم توجيهها للجهة المختصة.",
      "For any special receiving or draining request outside the lists above, write all conditions and the required mechanism so it reaches the right party.",
    ),
  },

  /* ═══ 🟢 المجموعة 1: ب) طلب مستقبل (Outbound Drain) ═══ */
  "d-out-1": {
    guide: G(
      "أدوات وسكربتات تفريغ تلقائي للبطاقات والبيانات المالية. يرجى توضيح نوع البطاقات (Credit/Debit)، الدولة، والآلية المفضلة للتفريغ.",
      "Automated card-draining tools and scripts. Clarify card type (Credit/Debit), country, and preferred draining mechanism.",
    ),
  },
  "d-out-2": {
    guide: G(
      "تفريغ أرصيدات الحسابات البنكية والإلكترونية بشكل فوري ونقل السيولة إلى نقطة مجمعة آمنة. يرجى توضيح نوع الحساب والحد الأدنى للرصيد.",
      "Instant draining of bank and e-wallet balances into a secure aggregation point. Clarify account type and minimum balance.",
    ),
  },
  "d-out-3": {
    guide: G(
      "توفير منافذ مستقبلة للتحويلات المالية السريعة (Wire Transfer / Swift / SEPA) مع ضمان سرعة المعالجة والإيداع. يرجى كتابة تفاصيل العملة والمبلغ المتوقع.",
      "Providing receiving endpoints for fast Wire / Swift / SEPA transfers with guaranteed processing speed. Write currency details and expected amount.",
    ),
  },
  "d-out-4": {
    guide: G(
      "تحويل وتفريغ الأرصدة إلى أكواد سحب بدون بطاقة من صرافات الآلي (Cardless Cashout) لتوفير سيولة كاش سريعة وميدانية. يرجى تحديد الدولة والبنك المنفذ.",
      "Converting balances into cardless ATM cashout codes for fast field liquidity. Specify the country and executing bank.",
    ),
  },
  "d-out-5": {
    guide: G(
      "تفريغ وسحب أرصدة المحافظ الرقمية والشعبية (PayPal, Skrill, Wise, etc.). يرجى كتابة اسم المحفظة والنسبة المحددة للتفريغ.",
      "Draining balances from popular e-wallets (PayPal, Skrill, Wise…). Write the wallet name and the agreed drain percentage.",
    ),
  },
  "d-out-6": {
    guide: G(
      "استبدال وتفريغ نقاط المكافآت والولاء الخاصة بالبنوك والشركات وتحويلها إلى قيم مالية أو عملات رقمية. يرجى تحديد جهة النقاط وقيمتها.",
      "Redeeming bank and corporate reward/loyalty points into financial value or crypto. Specify the issuer and point value.",
    ),
  },
  "d-out-7": {
    guide: G(
      "اكتب المتطلبات الخاصة بعمليات التفريغ الخارجي غير المدرجة مع توضيح الشروط والضمانات المطلوبة.",
      "Write requirements for outbound draining operations not listed, including conditions and required guarantees.",
    ),
  },

  /* ═══ 🟡 المجموعة 2: طلب الخدمات التقنية والميدانية ═══ */
  "b-1": {
    guide: G(
      "استقبال وتمرير السيولة النقدية أو الرقمية بين الدول والمحافظ بنسب محددة ووساطة آمنة. يرجى توضيح دول البداية والنهاية والوسيلة المستخدمة.",
      "Receiving and routing cash or digital liquidity between countries and wallets at agreed rates with safe brokerage. Specify origin, destination, and method.",
    ),
  },
  "b-2": {
    guide: G(
      "تسوية وتسديد الفواتير الحكومية والتجارية والخدمية بنسب تخفيض أو عبر وساطة تنفيذية. يرجى ذكر نوع الفاتورة والمبلغ المطلوب تسديده.",
      "Settling government, commercial, and utility bills at reduced rates or via an executing broker. Mention the bill type and amount.",
    ),
  },
  "b-3": {
    guide: G(
      "تنفيذ ودفع لينكات وشحنات الدفع الإلكتروني المباشرة المرفقة من المتاجر أو الأفراد. يرجى تحديد بوابة الدفع ورابط الشحنة.",
      "Executing direct payment links and charges supplied by stores or individuals. Specify the gateway and charge link.",
    ),
  },
  "b-4": {
    guide: G(
      "تقديم وتأجير سيرفرات مخصصة أو بروتوكولات برمجية معالجة لتنفيذ المهام المعقدة بدون انقطاع. يرجى كتابة مواصفات البروتوكول/السيرفر.",
      "Providing and renting dedicated servers or processing protocols for uninterrupted complex tasks. Write the protocol/server specifications.",
    ),
  },
  "b-5": {
    guide: G(
      "عرض أو طلب بوابات دفع تجارية وحسابات بنكية موثوقة وجاهزة للعمل الفوري. يرجى توضيح حدود السحب اليومي ونوع البوابة.",
      "Offering or requesting verified commercial gateways and bank accounts ready for instant work. Clarify daily withdrawal limits and gateway type.",
    ),
    extra: G(
      "تفاصيل إضافية: «حقن حساب» ضمن هذه الخدمة يعني إضافة وتعديل البيانات أو شحن وتغذية الحسابات بطرق تقنية مخصصة — يرجى توضيح المنصة ونوع الحقن المطلوب عند اختيار هذا المسار.",
      "Extra: account injection here means adding/modifying data or charging accounts via custom technical methods — specify the platform and injection type.",
    ),
  },
  "b-6": {
    guide: G(
      "تصميم وتطوير صفحات هبوط (Landing Pages) متجاوبة، سريعة، ومحمية من الفحص والتتبع. يرجى توضيح الواجهة والسكربت المطلوبة.",
      "Designing responsive, fast landing pages protected from scanning and tracking. Clarify the interface and required script.",
    ),
  },
  "b-7": {
    guide: G(
      "خدمات تشفير الملفات والسكربتات لتجاوز أنظمة الفحص والـ Antivirus بنسبة 100%. يرجى إرفاق تفاصيل نوع الملف المستهدف.",
      "File and script encryption services to bypass scanning and Antivirus systems. Attach details of the target file type.",
    ),
    extra: G(
      "تفاصيل إضافية: اذكر اللغة/الصيغة (EXE, JS, PHP, DLL)، نظام التشغيل المستهدف، ودورة التحديث المطلوبة. أي ملف مرفق يُمسح من الميتاداتا قبل الحفظ المحلي.",
      "Extra: state the format (EXE, JS, PHP, DLL), target OS, and required refresh cycle. Any attached file is metadata-stripped before local saving.",
    ),
  },
  "b-8": {
    guide: G(
      "تقديم خدمات استشارية وتنفيذية واستراتيجيات التواصل لإقناع الأهداف واستخلاص البيانات المحددة. يرجى توضيح الهدف ونوع المهمة.",
      "Consulting and execution services plus communication strategies to persuade targets and extract defined data. Clarify the target and task type.",
    ),
  },
  "b-9": {
    guide: G(
      "تقديم خدمات التوثيق الرقمي وتجاوز اختبارات KYC للمنصات والبنوك الإلكترونية بهويات موثوقة. يرجى ذكر اسم المنصة المطلوبة.",
      "Digital verification and KYC bypass services for platforms and e-banks with trusted identities. Mention the target platform.",
    ),
    extra: G(
      "تفاصيل إضافية: حدّد مستوى التحقق المطلوب (Basic / Advanced / Business)، الدولة، ونوع المستندات المتاحة — دون إرفاق بيانات حساسة مكشوفة.",
      "Extra: specify the verification level (Basic / Advanced / Business), country, and available document types — without exposing sensitive data.",
    ),
  },
  "b-10": {
    guide: G(
      "توفير استضافات وسيرفرات محمية ضد بلاغات الإزالة (DMCA Ignore) وتضمن الاستمرارية ومقاومة الهجمات. يرجى تحديد المواصفات المطلوبة.",
      "Providing hosting and servers protected against DMCA takedowns with continuity and attack resistance. Specify required specifications.",
    ),
  },
  "b-11": {
    guide: G(
      "للخدمات التقنية والميدانية الخاصة غير المدرجة بالقائمة، يرجى كتابة تفاصيل الخدمة وشروط التنفيذ.",
      "For custom technical and field services not listed, write the service details and execution conditions.",
    ),
  },

  /* ═══ 🟣 المجموعة 3: العمل بالنسبة وتنسيق المقابلات ═══ */
  "af-1": {
    guide: G(
      "قسم مخصص للشركاء والمسوقين لتوليد روابط إحالة مشفرة (Alias Generator). يتيح لك العمل بنسبة مئوية على العمليات دون الكشف عن هوية أي طرف.",
      "A hub for partners and marketers to generate encrypted affiliate links (Alias Generator) and earn a percentage on operations without exposing any party's identity.",
    ),
  },
  "m-riyadh": {
    guide: G(
      "ترتيب وتنسيق المقابلات الميدانية الرسمية والرقمية لتسليم السيولة أو الصفقات الكبرى في المدن الرئيسية (الرياض، دبي، تكساس، موسكو، برلين). يرجى ذكر المدينة ونوع الصفقات المطلوب إبرامها.",
      "Arranging official field and digital meetings to hand over liquidity or major deals in key cities (Riyadh, Dubai, Texas, Moscow, Berlin). Mention the city and deal type.",
    ),
  },
  "m-dubai": {
    guide: G(
      "ترتيب وتنسيق المقابلات الميدانية الرسمية والرقمية لتسليم السيولة أو الصفقات الكبرى في المدن الرئيسية (الرياض، دبي، تكساس، موسكو، برلين). يرجى ذكر المدينة ونوع الصفقات المطلوب إبرامها.",
      "Arranging official field and digital meetings for liquidity handover or major deals in key cities. Mention the city and deal type.",
    ),
  },
  "m-texas": {
    guide: G(
      "ترتيب وتنسيق المقابلات الميدانية الرسمية والرقمية لتسليم السيولة أو الصفقات الكبرى في المدن الرئيسية (الرياض، دبي، تكساس، موسكو، برلين). يرجى ذكر المدينة ونوع الصفقات المطلوب إبرامها.",
      "Arranging official field and digital meetings for liquidity handover or major deals in key cities. Mention the city and deal type.",
    ),
  },
  "m-moscow": {
    guide: G(
      "ترتيب وتنسيق المقابلات الميدانية الرسمية والرقمية لتسليم السيولة أو الصفقات الكبرى في المدن الرئيسية (الرياض، دبي، تكساس، موسكو، برلين). يرجى ذكر المدينة ونوع الصفقات المطلوب إبرامها.",
      "Arranging official field and digital meetings for liquidity handover or major deals in key cities. Mention the city and deal type.",
    ),
  },
  "m-berlin": {
    guide: G(
      "ترتيب وتنسيق المقابلات الميدانية الرسمية والرقمية لتسليم السيولة أو الصفقات الكبرى في المدن الرئيسية (الرياض، دبي، تكساس، موسكو، برلين). يرجى ذكر المدينة ونوع الصفقات المطلوب إبرامها.",
      "Arranging official field and digital meetings for liquidity handover or major deals in key cities. Mention the city and deal type.",
    ),
  },

  /* ═══ 🔵 المجموعة 4: المتخصصون والخبراء — الأمن السيبراني ═══ */
  "cy-1": {
    guide: G(
      "إجراء اختبارات اختراق شاملة على السيرفرات والشبكات واكتشاف الثغرات وتأمينها قبل استغلالها. اكتب اسم/نوع النظام والمجال المستهدف.",
      "Comprehensive penetration testing of servers and networks, discovering and patching vulnerabilities before exploitation. Write the system type and target domain.",
    ),
    extra: G(
      "تفاصيل إضافية: حدّد نطاق الفحص (Black / Grey / White Box)، النافذة الزمنية المسموحة، وصيغة التقرير المطلوبة (PDF / جدول ثغرات / لوج خام).",
      "Extra: specify test scope (Black / Grey / White Box), allowed time window, and required report format.",
    ),
  },
  "cy-2": {
    guide: G(
      "بناء وتشفير قنوات الاتصال والسكربتات لحماية البيانات المنقولة من التجسس والتتبع. يرجى كتابة بروتوكول التشفير المطلوب.",
      "Building and encrypting communication channels and scripts to protect transferred data from surveillance. Write the required encryption protocol.",
    ),
  },
  "cy-3": {
    guide: G(
      "التعامل الفوري مع الهجمات والحد من تسريب البيانات وتنظيف قواعد البيانات المتضررة وتأمينها. يرجى توضيح حالة النظام الحالية.",
      "Immediate incident response, containing data leaks, cleaning and securing affected databases. Clarify the current system state.",
    ),
  },
  "cy-4": {
    guide: G(
      "تحليل الأكواد والـ APIs الخاصة بتطبيقات الويب والهواتف لاكتشاف الثغرات الأمنية وإغلاقها. يرجى توضيح بيئة العمل (iOS / Android / Web).",
      "Analyzing web/mobile code and APIs to find and close security flaws. Clarify the environment (iOS / Android / Web).",
    ),
  },
  "cy-5": {
    guide: G(
      "تقديم خطط واستراتيجيات أمنية متكاملة للمشاريع الرقمية لحمايتها من الاستهداف الخارجي والداخلي. اكتب استفساراتك التقنية بدقة.",
      "Delivering complete security strategies for digital projects against external and internal threats. Write your technical queries precisely.",
    ),
  },

  /* ═══ 🔵 المبرمجون وتطوير الأنظمة ═══ */
  "dv-1": {
    guide: G(
      "تطوير وتصميم بوتات وتطبيقات مصغرة داخل تيليجرام بأداء عالي، مع ربطها بقواعد بيانات محلية ولوحات تحكم. اكتب وظيفة البوت المطلوبة.",
      "Developing high-performance Telegram bots and Mini-Apps linked to local databases and dashboards. Write the required bot functionality.",
    ),
  },
  "dv-2": {
    guide: G(
      "برمجة ودمج بوابات الدفع الإلكتروني وتطوير واجهات برمجة التطبيقات (APIs) لتمرير المعاملات التلقائية. يرجى تحديد البوابة أو الـ API.",
      "Building and integrating payment gateways and APIs for automated transactions. Specify the gateway or API.",
    ),
    extra: G(
      "تفاصيل إضافية: اذكر صيغة الـ Webhook، طرق التوقيع/التشفير، بيئة الاختبار (Sandbox)، والحد المتوقع للمعاملات في الدقيقة.",
      "Extra: state webhook format, signing/encryption methods, sandbox environment, and expected transactions per minute.",
    ),
  },
  "dv-3": {
    guide: G(
      "بناء واجهات مستخدم فائقة السرعة بدون خادم (Stateless Single Page Applications) باستخدام أحدث تقنيات الويب. اكتب متطلبات الواجهة والميزات المطلوبة.",
      "Building ultra-fast stateless SPAs with modern web technologies. Write the UI requirements and needed features.",
    ),
  },
  "dv-4": {
    guide: G(
      "كتابة سكربتات مخصصة لأتمتة المهام اليومية، وسحب البيانات، والتفاعل التلقائي مع المواقع. يرجى توضيح الموقع والعملية المطلوبة.",
      "Writing custom scripts to automate daily tasks, scrape data, and interact with sites. Clarify the target site and operation.",
    ),
  },
  "dv-5": {
    guide: G(
      "إصلاح الثغرات وتعديل وتطوير الأكواد المصدريّة الجاهزة بجميع لغات البرمجة (Python, JS, PHP, C++...). يرجى إرفاق أو شرح الكود المستهدف.",
      "Fixing, modifying, and extending existing source code in all languages (Python, JS, PHP, C++…). Attach or describe the target code.",
    ),
  },

  /* ═══ 🔵 خدمات تقنية متخصصة أخرى ═══ */
  "ot-1": {
    guide: G(
      "حلول واستشارات متقدمة لتجاوز وإكمال إجراءات التحقق من الهوية على المنصات العالمية الممتنعة. اكتب اسم الخدمة أو البنك المستهدف.",
      "Advanced solutions and consulting for completing identity verification on restrictive global platforms. Write the target service or bank.",
    ),
  },
  "ot-2": {
    guide: G(
      "تقديم دراسات حالة وسيناريوهات محاكاة لاختبار مدى وعي طاقم العمل أو حماية الأهداف الحساسة. اكتب نطاق الاستشارة.",
      "Case studies and simulation scenarios to test staff awareness or protect sensitive targets. Write the consultation scope.",
    ),
  },
  "ot-3": {
    guide: G(
      "توجيه زوار ومستهلكين حقيقيين ومستهدفين نحو المنصات والبوتات المخصصة عبر شبكات توجيه آمنة. يرجى تحديد فئة الجمهور والدولة.",
      "Routing real, targeted visitors to dedicated platforms and bots through safe traffic networks. Specify audience segment and country.",
    ),
    extra: G(
      "تفاصيل إضافية: حدّد الميزانية اليومية، مصادر الزيارات المفضلة، ومؤشر التحويل المستهدف لتُبنى لك خطة التوجيه بدقة.",
      "Extra: specify daily budget, preferred traffic sources, and target conversion metric to build an accurate routing plan.",
    ),
  },
  "ot-4": {
    guide: G(
      "بناء الهياكل التشغيلية للمشاريع وتنظيم خطوط سير البيانات والمالية بما يضمن أقصى درجات السرية والإنتاجية. اكتب تفاصيل مشروعك الحالي.",
      "Building operational structures and organizing data/financial flows for maximum privacy and productivity. Write your current project details.",
    ),
  },
};
