"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  ACCOUNT_SECTIONS,
  COUNTRY_ACCOUNTS,
  COUNTRY_DELIVERY,
  bankLogo,
  purchaseMessage,
  type AccountProduct,
  type AccountSection,
  type CountryAccount,
} from "@/lib/accounts";
import { BUY_MANAGER, pick, type L } from "@/lib/site";
import { copyText, dispatchToTelegram, buildWebFallback } from "@/lib/forumClient";
import { useT, useLang, toast } from "@/lib/client";
import { Icon } from "./Icon";
import Shell from "./Shell";

const A = (ar: string, en = ar): L => ({ ar, en });
type Cart = Record<string, number>;

const LB = {
  sections: A("الأقسام", "Sections"),
  back: A("رجوع", "Back"),
  products: A("المنتجات", "Products"),
  details: A("عرض التفاصيل", "Details"),
  buy: A("شراء", "Buy"),
  cart: A("السلة", "Cart"),
  addCart: A("إضافة للسلة", "Add to cart"),
  total: A("الإجمالي", "Total"),
  sendCart: A("إرسال طلب السلة", "Send cart order"),
  preview: A("معاينة الرسالة", "Message preview"),
  copy: A("نسخ الرسالة", "Copy message"),
  open: A("فتح المحادثة", "Open chat"),
  otherTool: A("🏦 حسابات أخرى — اختر الدولة", "🏦 Other accounts — pick a country"),
  otherNote: A("حسابات إضافية حصرية لا تظهر في العروض: اختر الدولة ليظهر الحساب الخاص بها مع بياناته كاملة.", "Exclusive extra accounts not shown in offers: pick a country to reveal its account."),
  selectCountry: A("اختر الدولة", "Choose a country"),
  global: A("بنوك عالمية (IBAN)", "Global banks (IBAN)"),
  vip: A("شبكات راقية وبنوك رقمية", "Premium networks & neobanks"),
  quickOrder: A("⚡ أداة الطلب السريع", "⚡ Quick order tool"),
  quickNote: A("اختر الحساب وأضف سبب الاستخدام اختيارياً، ثم أرسل الطلب للمسؤول.", "Pick an account, optionally add a reason, then route the request."),
  reason: A("سبب الاستخدام (اختياري)", "Reason (optional)"),
  sendReq: A("طلب الحساب ⚡", "Request account ⚡"),
  close: A("إغلاق", "Close"),
  badges: A("الوسوم", "Badges"),
  delivery: A("ماذا تستلم؟", "What you receive"),
  noAcc: A("لا توجد حسابات إضافية مكررة — القائمة منقّاة تلقائياً.", "No duplicate accounts — list auto-cleaned."),
};

/** ═══ DIGITAL_BANK_VAULT — الحسابات المستعارة ═══ */
export default function AccountsHub() {
  const t = useT();
  const lang = useLang();
  const router = useRouter();

  const [active, setActive] = useState<string | null>(null);
  const [modal, setModal] = useState<AccountProduct | null>(null);
  const [cart, setCart] = useState<Cart>({});
  const [cartOpen, setCartOpen] = useState(false);
  const [relay, setRelay] = useState("");
  const [copied, setCopied] = useState(false);

  /* رابط عميق ?b=... من البحث/الروابط القديمة */
  useEffect(() => {
    const b = new URLSearchParams(window.location.search).get("b");
    if (b && ACCOUNT_SECTIONS.some((s) => s.id === b)) setActive(b);
  }, []);

  useEffect(() => {
    if (!modal) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setModal(null);
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [modal]);

  const sec = active ? ACCOUNT_SECTIONS.find((s) => s.id === active) : undefined;

  /** نسخ + توجيه للمسؤول @k22zzo (اليوزر مخفي تماماً) */
  const send = useCallback(
    (msg: string) => {
      void copyText(msg);
      void dispatchToTelegram(msg, BUY_MANAGER);
      setRelay(msg);
      setCopied(true);
      toast(t("fa.copied"));
      window.scrollTo({ top: 0, behavior: "smooth" });
    },
    [t],
  );

  const buy = (p: AccountProduct, note?: string) =>
    send(purchaseMessage(p.name.ar || "", p.priceUsd, note ?? (sec ? sec.buyNote.ar || "" : undefined)));

  const addCart = (id: string) => {
    setCart((c) => ({ ...c, [id]: (c[id] || 0) + 1 }));
    toast(t("p.added"));
  };

  const allProducts = useMemo(
    () => ACCOUNT_SECTIONS.flatMap((s) => s.products.map((p) => ({ p, s }))),
    [],
  );
  const cartItems = Object.entries(cart)
    .map(([id, qty]) => ({ ...allProducts.find((x) => x.p.id === id), qty }))
    .filter((x): x is { p: AccountProduct; s: AccountSection; qty: number } => !!x.p);
  const cartCount = cartItems.reduce((a, x) => a + x.qty, 0);
  const cartTotal = cartItems.reduce((a, x) => a + x.p.priceUsd * x.qty, 0);

  const sendCart = () => {
    if (cartItems.length === 0) return;
    const lines = cartItems
      .map((x) => `• ${x.p.name.ar} × ${x.qty} — ${x.p.priceUsd * x.qty}$`)
      .join("\n");
    send(
      [
        "[🚨 طلب شراء جديد - BLACK MART]",
        "--------------------------------------",
        `💳 الخدمة المطلوبة: سلة حسابات (${cartCount} عنصر)`,
        `💰 القيمة: ${cartTotal}$`,
        "--------------------------------------",
        "📝 نص الطلب: ",
        lines,
        "أريد إتمام شراء هذه الحسابات. يرجى تزويدي بمحافظ الدفع المتاحة والتعليمات المطلوبة لإتمام المعاملة.",
        "--------------------------------------",
        "[SYSTEM_ID: AUTO_GENERATED]",
      ].join("\n"),
    );
    setCartOpen(false);
  };

  const open = (id: string) => {
    setActive(id);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const back = () => {
    if (modal) setModal(null);
    else if (active) { setActive(null); router.replace("/market/accounts"); window.scrollTo({ top: 0, behavior: "smooth" }); }
    else router.push("/market");
  };

  return (
    <Shell>
      <div className="space-y-5 pt-4">
        {/* ═══ شريط علوي ثابت ═══ */}
        <div className="sticky top-[96px] z-20 -mx-3 border-b border-line bg-void/95 px-3 py-2 backdrop-blur-md sm:-mx-5 sm:px-5">
          <div className="flex items-center gap-2.5">
            <button onClick={back} className="btn-ghost shrink-0 px-3 py-1.5 text-[9px]">
              <Icon name="back" size={11} className="rtl:rotate-180" />
              🔙 {active ? pick(lang, LB.sections) : t("c.back")}
            </button>
            <span className="mono-label hidden sm:block">DIGITAL_BANK_VAULT :: 07 SECTIONS</span>
            <span className="ms-auto font-mono text-[9px] tracking-widest text-acid">
              {sec ? `${sec.products.length} ITEMS` : "46 PRODUCTS"}
            </span>
          </div>
          {active && (
            <div className="no-scrollbar -mx-1 mt-2 flex gap-1.5 overflow-x-auto px-1">
              {ACCOUNT_SECTIONS.map((s) => (
                <button
                  key={s.id}
                  onClick={() => open(s.id)}
                  className={`shrink-0 border px-3 py-1.5 font-mono text-[10px] font-bold tracking-wider transition-all ${
                    active === s.id
                      ? "border-acid bg-acid text-void shadow-[0_0_16px_rgba(184,239,128,0.3)]"
                      : "border-line bg-abyss/60 text-mute hover:text-fog"
                  }`}
                >
                  {pick(lang, s.short)}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* ═══ معاينة الرسالة ═══ */}
        {relay && (
          <div className="panel animate-fade-up">
            <div className="mono-label flex items-center justify-between border-b border-line px-4 py-2.5">
              <span>📤 {pick(lang, LB.preview)}</span>
              <span className="text-acid">✓ {t("op.copied")}</span>
            </div>
            <pre className="max-h-52 overflow-auto whitespace-pre-wrap p-4 font-mono text-[11px] leading-6 text-fog/90" dir="auto">{relay}</pre>
            <div className="grid grid-cols-3 gap-2 border-t border-line p-3">
              <button onClick={async () => { if (await copyText(relay)) { setCopied(true); toast(t("op.copied")); } }} className="btn-ghost py-2 text-[9px]">
                <Icon name={copied ? "check" : "link"} size={11} />{pick(lang, LB.copy)}
              </button>
              <button onClick={() => window.open(buildWebFallback(relay, BUY_MANAGER), "_blank", "noreferrer")} className="btn-acid py-2 text-[9px]">
                <Icon name="plane" size={11} />{pick(lang, LB.open)}
              </button>
              <button onClick={() => setRelay("")} className="btn-ghost py-2 text-[9px]">
                <Icon name="close" size={11} />{pick(lang, LB.close)}
              </button>
            </div>
          </div>
        )}

        {/* ═══ شبكة الأقسام: 2×2 / 3×3 ═══ */}
        {!sec && (
          <section>
            <div className="mono-label mb-3">// {pick(lang, LB.sections)} · 07</div>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
              {ACCOUNT_SECTIONS.map((s, i) => (
                <button key={s.id} onClick={() => open(s.id)} className="panel panel-hover corners group flex flex-col overflow-hidden text-start">
                  <div className="relative h-24 overflow-hidden sm:h-32">
                    <img src={s.hero} alt="" loading="lazy" decoding="async" className="h-full w-full object-cover opacity-80 transition-transform duration-500 group-hover:scale-105" />
                    <span className="absolute top-2 end-2 border border-line bg-void/85 px-1.5 py-0.5 font-mono text-[9px] text-acid">
                      {String(i + 1).padStart(2, "0")} · {s.products.length}
                    </span>
                  </div>
                  <div className="acc-strip h-[3px] w-full" />
                  <div className="flex flex-1 flex-col p-3">
                    <div className="text-[13px] font-bold leading-snug sm:text-sm">{pick(lang, s.name)}</div>
                    <p className="mt-1 line-clamp-2 text-[10px] leading-relaxed text-mute sm:text-[11px]">{pick(lang, s.desc)}</p>
                    <div className="btn-acid mt-3 w-full !py-2 text-[10px]">{t("c.enter")}</div>
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* ═══ محتوى القسم (عزل) ═══ */}
        {sec && (
          <div key={sec.id} className="animate-fade-up space-y-4">
            <header className="panel relative overflow-hidden p-5 sm:p-7">
              <img src={sec.hero} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-20" />
              <div className="relative">
                <div className="mono-label mb-2 flex items-center gap-2 text-acid">
                  <Icon name="lock" size={12} className="acc-lock" />
                  {sec.id.toUpperCase()} :: VERIFIED VAULT
                </div>
                <h1 className="display-2 font-bold">{pick(lang, sec.name)}</h1>
                <p className="mt-2 max-w-3xl text-sm leading-relaxed text-mute">{pick(lang, sec.desc)}</p>
              </div>
            </header>

            {/* المنتجات 2×2 / 3×3 */}
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
              {sec.products.map((p) => (
                <ProductCard key={p.id} p={p} sec={sec} onBuy={() => buy(p)} onCart={() => addCart(p.id)} onDetails={() => setModal(p)} />
              ))}
            </div>

            {/* صندوق الشرح / ماذا تستلم */}
            <div className="border border-acid/40 bg-acid/5 p-4 shadow-[0_0_30px_rgba(184,239,128,0.1)]">
              <div className="mono-label mb-2.5 flex items-center gap-2 text-acid">
                <Icon name="book" size={13} />{pick(lang, sec.deliveryTitle)}
              </div>
              <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                {sec.delivery.map((d, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs leading-relaxed text-fog/85">
                    <Icon name="check" size={11} className="mt-0.5 shrink-0 text-acid" />{pick(lang, d)}
                  </li>
                ))}
              </ul>
            </div>

            {/* أداة «حسابات أخرى» — قسم IBAN فقط */}
            {sec.id === "iban" && <CountryTool onBuy={(c) => send(purchaseMessage(`${c.bank.ar} — ${c.country.ar}`, c.priceUsd, "حساب جاهز بكامل الصلاحيات من أداة الدول."))} onCart={addCart} onDetails={(c) => setModal(countryToProduct(c))} />}

            {/* أداة الطلب السريع — بوابات الدفع */}
            {sec.id === "gateways" && (
              <QuickOrder section={sec} onSend={(p, reason) => send(purchaseMessage(p.name.ar || "", p.priceUsd, reason ? `سبب الاستخدام: ${reason}` : sec.buyNote.ar || ""))} />
            )}
          </div>
        )}
      </div>

      {/* زر رجوع عائم */}
      {active && (
        <button onClick={back} title={pick(lang, LB.sections)} aria-label={pick(lang, LB.sections)} className="glass glass-hover fixed bottom-16 start-4 z-40 flex h-11 w-11 items-center justify-center border-acid/50 text-acid">
          <Icon name="back" size={18} className="rtl:rotate-180" />
        </button>
      )}

      {/* السلة العائمة */}
      {cartCount > 0 && (
        <button onClick={() => setCartOpen((v) => !v)} title={pick(lang, LB.cart)} aria-label={pick(lang, LB.cart)} className="glass glass-hover fixed bottom-16 end-4 z-40 flex h-11 w-11 items-center justify-center border-acid/50 text-acid">
          <Icon name="cart" size={18} />
          <span className="absolute -top-1 -end-1 flex h-4 min-w-4 items-center justify-center bg-acid px-1 font-mono text-[9px] font-bold text-void">{cartCount}</span>
        </button>
      )}
      {cartOpen && cartCount > 0 && (
        <div className="panel fixed bottom-28 end-4 z-[55] w-[min(92vw,340px)] p-3 shadow-[0_24px_60px_-20px_rgba(0,0,0,0.9)]">
          <div className="mb-2 flex items-center gap-2 border-b border-line pb-2">
            <Icon name="cart" size={14} className="text-acid" />
            <span className="mono-label flex-1">{pick(lang, LB.cart)}</span>
            <button onClick={() => setCartOpen(false)} aria-label={t("c.close")} className="text-mute hover:text-fog"><Icon name="close" size={14} /></button>
          </div>
          <div className="max-h-56 space-y-2 overflow-auto">
            {cartItems.map(({ p, qty }) => (
              <div key={p.id} className="flex items-center gap-2 border border-line bg-abyss/60 p-2">
                <div className="min-w-0 flex-1"><div className="truncate text-[11px] font-bold">{p.name.ar}</div><div className="font-mono text-[10px] text-acid">${p.priceUsd * qty}</div></div>
                <button onClick={() => setCart((c) => ({ ...c, [p.id]: Math.max(0, c[p.id] - 1) }))} className="flex h-7 w-7 items-center justify-center border border-line text-mute"><Icon name="minus" size={10} /></button>
                <span className="w-5 text-center font-mono text-xs">{qty}</span>
                <button onClick={() => setCart((c) => ({ ...c, [p.id]: c[p.id] + 1 }))} className="flex h-7 w-7 items-center justify-center border border-line text-mute"><Icon name="plus" size={10} /></button>
              </div>
            ))}
          </div>
          <div className="mt-3 flex items-center justify-between border-t border-line pt-2">
            <span className="mono-label">{pick(lang, LB.total)}</span>
            <span className="font-mono text-lg font-bold text-acid">${cartTotal}</span>
          </div>
          <button onClick={sendCart} className="btn-acid mt-3 w-full py-2.5 text-[10px]"><Icon name="send" size={12} />{pick(lang, LB.sendCart)}</button>
        </div>
      )}

      {/* نافذة التفاصيل */}
      {modal && <DetailModal p={modal} sec={sec} onClose={() => setModal(null)} onBuy={() => { buy(modal); setModal(null); }} onCart={() => { addCart(modal.id); setModal(null); }} />}
    </Shell>
  );
}

/** ═══ بطاقة المنتج ═══ */
function ProductCard({ p, sec, onBuy, onCart, onDetails }: {
  p: AccountProduct; sec: AccountSection;
  onBuy: () => void; onCart: () => void; onDetails: () => void;
}) {
  const lang = useLang();
  const [imgErr, setImgErr] = useState(false);
  return (
    <div className="panel panel-hover corners group flex h-full flex-col overflow-hidden">
      <div className={`relative h-24 overflow-hidden sm:h-28 ${sec.id === "amex" ? "acc-shiny" : ""}`}>
        {!imgErr ? (
          <img src={p.img} alt="" loading="lazy" decoding="async" onError={() => setImgErr(true)} className="h-full w-full object-cover opacity-85 transition-transform duration-500 group-hover:scale-105" />
        ) : (
          <div className="grid-bg-fine flex h-full w-full items-center justify-center"><Icon name={sec.icon} size={34} className="text-dim" /></div>
        )}
        {p.featured && (
          <span className="absolute top-2 start-2 border border-acid/50 bg-void/85 px-1.5 py-0.5 font-mono text-[8px] tracking-widest text-acid">★ Verified</span>
        )}
      </div>
      <div className="acc-strip h-[3px] w-full" />
      <div className="flex min-h-0 flex-1 flex-col p-2.5 sm:p-3">
        <h3 className="line-clamp-2 text-[11px] font-bold leading-snug sm:text-[13px]">{pick(lang, p.name)}</h3>
        <p className="mt-1 line-clamp-2 text-[10px] leading-relaxed text-mute sm:text-[11px]">{pick(lang, p.desc)}</p>

        {p.credit && (
          <div className="mt-1.5 font-mono text-[9px] text-acid">💳 {pick(lang, p.credit)}</div>
        )}
        <div className="mt-1 flex flex-wrap gap-1">
          {p.badges.map((b) => (
            <span key={b} className="border border-line2/60 bg-abyss/70 px-1.5 py-0.5 font-mono text-[8px] tracking-wider text-mute">{b}</span>
          ))}
        </div>

        <div className="mt-auto pt-2">
          <div className="flex items-baseline gap-2">
            {p.oldPriceUsd && <span className="font-mono text-[10px] text-blood line-through" dir="ltr">${p.oldPriceUsd}</span>}
            <span className="font-mono text-lg font-bold text-fog text-glow sm:text-xl" dir="ltr">${p.priceUsd}</span>
          </div>
          <div className="mt-2 grid grid-cols-2 gap-1.5">
            <button onClick={onBuy} className="btn-acid !px-1 !py-2 !text-[9px]">{pick(lang, LB.buy)}</button>
            <button onClick={onDetails} className="btn-ghost !px-1 !py-2 !text-[9px]"><Icon name="eye" size={10} />{pick(lang, LB.details)}</button>
          </div>
          <button onClick={onCart} className="btn-ghost mt-1.5 w-full !px-1 !py-1.5 !text-[9px]"><Icon name="cart" size={10} />{pick(lang, LB.addCart)}</button>
        </div>
      </div>
    </div>
  );
}

/** ═══ نافذة التفاصيل الكاملة ═══ */
function DetailModal({ p, sec, onClose, onBuy, onCart }: {
  p: AccountProduct; sec?: AccountSection;
  onClose: () => void; onBuy: () => void; onCart: () => void;
}) {
  const lang = useLang();
  const [imgErr, setImgErr] = useState(false);
  return (
    <div className="fixed inset-0 z-[65] flex items-center justify-center p-4" role="dialog" aria-modal>
      <div className="absolute inset-0 bg-void/85 backdrop-blur-sm" onClick={onClose} />
      <div className="panel animate-fade-up relative flex max-h-[88vh] w-full max-w-xl flex-col">
        <div className="flex items-center justify-between border-b border-line px-4 py-3">
          <span className="mono-label">ℹ️ {pick(lang, LB.details)} :: DETAILS</span>
          <button onClick={onClose} className="btn-icon h-8 w-8" aria-label="close"><Icon name="close" size={15} /></button>
        </div>
        <div className="flex-1 overflow-y-auto">
          <div className="relative h-44 sm:h-56">
            {!imgErr ? (
              <img src={p.img} alt="" onError={() => setImgErr(true)} className="h-full w-full object-cover opacity-90" />
            ) : (
              <div className="grid-bg-fine flex h-full w-full items-center justify-center"><Icon name="shield" size={64} className="text-dim" /></div>
            )}
          </div>
          <div className="acc-strip h-[3px] w-full" />
          <div className="p-5">
            <h2 className="text-xl font-bold sm:text-2xl">{pick(lang, p.name)}</h2>
            <p className="mt-2 text-sm leading-relaxed text-mute">{pick(lang, p.desc)}</p>
            {p.credit && <div className="mt-2 font-mono text-xs text-acid">💳 {pick(lang, p.credit)}</div>}
            <div className="mt-2 flex flex-wrap gap-1.5">
              {p.badges.map((b) => <span key={b} className="border border-acid/40 bg-acid/10 px-2 py-0.5 font-mono text-[9px] tracking-widest text-acid">{b}</span>)}
            </div>
            <div className="mt-3 flex items-baseline gap-3">
              {p.oldPriceUsd && <span className="font-mono text-base text-blood line-through" dir="ltr">${p.oldPriceUsd}</span>}
              <span className="font-mono text-3xl font-bold text-fog text-glow" dir="ltr">${p.priceUsd}</span>
            </div>

            <div className="mt-4 max-h-56 overflow-y-auto border border-line bg-abyss/60 p-4">
              <div className="mono-label mb-2">📜 {pick(lang, LB.delivery)}</div>
              <p className="whitespace-pre-line text-xs leading-loose text-fog/90">{pick(lang, p.details)}</p>
            </div>

            {sec && (
              <div className="mt-4 border border-acid/40 bg-acid/5 p-4">
                <div className="mono-label mb-2.5 flex items-center gap-2 text-acid"><Icon name="check" size={12} />{pick(lang, sec.deliveryTitle)}</div>
                <ul className="space-y-1.5">
                  {sec.delivery.map((d, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs leading-relaxed text-mute"><Icon name="check" size={10} className="mt-0.5 shrink-0 text-acid" />{pick(lang, d)}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 border-t border-line p-3">
          <button onClick={onBuy} className="btn-primary"><Icon name="cart" size={15} />{pick(lang, LB.buy)}</button>
          <button onClick={onCart} className="btn-acid"><Icon name="plus" size={14} />{pick(lang, LB.addCart)}</button>
        </div>
      </div>
    </div>
  );
}

const countryToProduct = (c: CountryAccount): AccountProduct => ({
  id: c.id, name: A(`${c.bank.ar} — ${c.country.ar}`), desc: c.desc,
  details: A(`${c.bank.ar} — ${c.country.ar}\n\nحساب جاهز بكامل الصلاحيات:\n• تفويض كامل للتحكم بالحساب.\n• بيانات الداشبورد (لوحة التحكم) كاملة.\n• بيانات المالك كاملة.\n• وصول كامل لرقم الهاتف والبريد الإلكتروني المرتبطين.\n• بيانات الدخول: البريد، الباسورد، اسم المستخدم، كود 2FA.\n• بيانات الـ IBAN وكود SWIFT ووثائق KYC.\n• دليل الدخول الآمن عبر Proxy/VPN.`),
  img: bankLogo(c.domain), priceUsd: c.priceUsd, badges: ["FULL_DOCS_INCLUDED", "IBAN_READY"],
});

/** ═══ أداة «حسابات أخرى» — اختيار الدولة ═══ */
function CountryTool({ onBuy, onCart, onDetails }: {
  onBuy: (c: CountryAccount) => void;
  onCart: (id: string) => void;
  onDetails: (c: CountryAccount) => void;
}) {
  const lang = useLang();
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);
  const [imgErr, setImgErr] = useState(false);
  const c = selected ? COUNTRY_ACCOUNTS.find((x) => x.id === selected) : undefined;

  return (
    <div id="custom-tool" className="panel acc-cta-panel scroll-mt-32 overflow-hidden p-0">
      {/* ترويسة بارزة */}
      <div className="acc-cta-head flex items-center justify-between gap-2 px-4 py-2.5">
        <span className="mono-label !text-acid">◈ EXCLUSIVE ACCOUNTS · حسابات حصرية</span>
        <span className="shrink-0 border border-acid/50 bg-void/70 px-2 py-0.5 font-mono text-[10px] font-bold text-acid">
          {COUNTRY_ACCOUNTS.length} BANKS
        </span>
      </div>

      {/* الزر البارز جداً */}
      <button
        onClick={() => { setOpen((v) => !v); setSelected(null); }}
        className="acc-cta flex w-full items-center gap-3 px-4 py-5 text-start sm:px-5"
      >
        <span className="acc-cta-icon"><Icon name="globe" size={27} /></span>
        <span className="min-w-0 flex-1">
          <span className="block text-base font-extrabold leading-snug sm:text-lg">
            🏦 حسابات أخرى — اختر الدولة
          </span>
          <span className="mt-1 block text-[11px] font-medium leading-relaxed opacity-80 sm:text-xs">
            {COUNTRY_ACCOUNTS.length} بنكاً حصرياً لا تظهر في العروض · اضغط هنا لاستعراض الدول والأعلام
          </span>
        </span>
        <span className="acc-cta-dot hidden sm:block" />
        <Icon
          name="chevron"
          size={20}
          className={`shrink-0 transition-transform ${open ? "rotate-180" : ""}`}
        />
      </button>

      {open && (
        <div className="animate-fade-up border-t border-line p-4">
          <p className="mb-3 flex items-start gap-2 border border-line bg-abyss/60 p-3 text-xs leading-relaxed text-mute">
            <Icon name="warn" size={12} className="mt-0.5 shrink-0 text-acid" />{pick(lang, LB.otherNote)}
          </p>
          <div className="mono-label mb-2">{pick(lang, LB.selectCountry)} · {COUNTRY_ACCOUNTS.length}</div>
          {(["global", "vip"] as const).map((g) => (
            <div key={g} className="mb-3">
              <div className="mono-label mb-1.5 border-b border-line pb-1 text-acid">{pick(lang, g === "global" ? LB.global : LB.vip)}</div>
              <div className="flex flex-wrap gap-1.5">
                {COUNTRY_ACCOUNTS.filter((x) => x.group === g).map((x) => (
                  <button
                    key={x.id}
                    onClick={() => { setSelected(x.id); setImgErr(false); }}
                    className={`border px-2.5 py-1.5 font-mono text-[10px] transition-all ${
                      selected === x.id ? "border-acid bg-acid text-void" : "border-line bg-abyss/60 text-mute hover:border-line2 hover:text-fog"
                    }`}
                  >
                    {x.flag} {x.country.ar}
                  </button>
                ))}
              </div>
            </div>
          ))}

          {/* لا يظهر أي حساب إضافي إلا بعد اختيار الدولة */}
          {c && (
            <div className="panel animate-fade-up mt-4 overflow-hidden">
              <div className="flex items-center gap-3 border-b border-line p-4">
                <div className="flex h-16 w-16 shrink-0 items-center justify-center border border-line bg-fog/5 p-2">
                  {!imgErr ? (
                    <img src={bankLogo(c.domain)} alt="" onError={() => setImgErr(true)} className="h-full w-full object-contain" />
                  ) : (
                    <Icon name="shield" size={30} className="text-acid" />
                  )}
                </div>
                <div className="min-w-0">
                  <div className="mono-label">{c.flag} {pick(lang, c.country)}</div>
                  <div className="mt-1 text-lg font-bold">{pick(lang, c.bank)}</div>
                  <div className="mt-1 font-mono text-xl font-bold text-fog text-glow">${c.priceUsd}</div>
                </div>
              </div>
              <div className="acc-strip h-[3px] w-full" />
              <div className="p-4">
                <div className="mono-label mb-2">📜 حساب جاهز بكامل الصلاحيات</div>
                <ul className="space-y-1.5">
                  {COUNTRY_DELIVERY.map((d, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs leading-relaxed text-mute"><Icon name="check" size={10} className="mt-0.5 shrink-0 text-acid" />{pick(lang, d)}</li>
                  ))}
                </ul>
                <div className="mt-4 grid grid-cols-3 gap-1.5">
                  <button onClick={() => onBuy(c)} className="btn-acid !px-1 !py-2 !text-[9px]">{pick(lang, LB.buy)}</button>
                  <button onClick={() => onCart(c.id)} className="btn-ghost !px-1 !py-2 !text-[9px]"><Icon name="cart" size={10} />{pick(lang, LB.cart)}</button>
                  <button onClick={() => onDetails(c)} className="btn-ghost !px-1 !py-2 !text-[9px]"><Icon name="eye" size={10} />{pick(lang, LB.details)}</button>
                </div>
              </div>
            </div>
          )}
          <p className="mt-3 text-center font-mono text-[9px] text-mute/70">{pick(lang, LB.noAcc)}</p>
        </div>
      )}
    </div>
  );
}

/** ═══ أداة الطلب السريع (بوابات الدفع) ═══ */
function QuickOrder({ section, onSend }: { section: AccountSection; onSend: (p: AccountProduct, reason: string) => void }) {
  const lang = useLang();
  const [open, setOpen] = useState(false);
  const [id, setId] = useState(section.products[0].id);
  const [reason, setReason] = useState("");
  const p = section.products.find((x) => x.id === id) ?? section.products[0];

  return (
    <div className="panel p-4">
      <button onClick={() => setOpen((v) => !v)} className={`btn-ghost w-full py-2.5 ${open ? "!border-acid/50 !text-acid" : ""}`}>
        <Icon name="send" size={13} />{pick(lang, LB.quickOrder)}
        <Icon name="chevron" size={12} className={open ? "rotate-180 transition-transform" : "transition-transform"} />
      </button>
      {open && (
        <div className="animate-fade-up mt-3 space-y-3">
          <p className="text-xs leading-relaxed text-mute">{pick(lang, LB.quickNote)}</p>
          <div>
            <label className="mono-label mb-1.5 block">اسم الحساب</label>
            <select className="inp" value={id} onChange={(e) => setId(e.target.value)}>
              {section.products.map((x) => <option key={x.id} value={x.id}>{x.name.ar} — ${x.priceUsd}</option>)}
            </select>
          </div>
          <div>
            <label className="mono-label mb-1.5 block">{pick(lang, LB.reason)}</label>
            <textarea className="inp min-h-[80px] resize-y" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="—" />
          </div>
          <div className="flex items-center justify-between border border-line bg-abyss/60 px-3 py-2">
            <span className="mono-label">{pick(lang, LB.total)}</span>
            <span className="font-mono text-lg font-bold text-acid">${p.priceUsd}</span>
          </div>
          <button onClick={() => onSend(p, reason.trim())} className="btn-acid w-full py-2.5">
            <Icon name="send" size={13} />{pick(lang, LB.sendReq)}
          </button>
          <button onClick={() => setOpen(false)} className="btn-ghost w-full py-2 text-[9px]"><Icon name="close" size={11} />{pick(lang, LB.close)}</button>
        </div>
      )}
    </div>
  );
}
