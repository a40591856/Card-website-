"use client";

import { useEffect, useState } from "react";
import {
  MEETING_POLICY,
  MEETING_FIELDS,
  MEETING_CITY_PRESETS,
  MEETING_TOP_TABS,
  MEETING_GUIDE,
  FORUM_SECTIONS,
} from "@/lib/forum";
import {
  saveDraft,
  loadDraft,
  clearDraft,
  buildForumMessage,
  buildTrackLink,
  buildTrackWebFallback,
  MEETING_DIRECT_MESSAGE,
  copyText,
  timestamp,
  type DraftData,
} from "@/lib/forumClient";
import { useT, useLang, toast } from "@/lib/client";
import { pick } from "@/lib/site";
import { Icon } from "./Icon";

/** هَب تنسيق المقابلات — تيوبات + السياسة + زر مباشر + أداة الحقول */
export default function MeetingHub({
  onSwitchSection,
}: {
  onSwitchSection: (id: string) => void;
}) {
  const t = useT();
  const lang = useLang();
  const [fields, setFields] = useState<DraftData>({});
  const [message, setMessage] = useState("");
  const [copied, setCopied] = useState(false);
  const [err, setErr] = useState(false);
  const [saved, setSaved] = useState(false);

  const KEY_SEC = "meetings";
  const KEY_SVC = "coordination";

  useEffect(() => {
    const d = loadDraft(KEY_SEC, KEY_SVC);
    setFields(d);
    setSaved(Object.keys(d).length > 0);
  }, []);

  const change = (id: string, v: string) => {
    setFields((f) => {
      const next = { ...f, [id]: v };
      saveDraft(KEY_SEC, KEY_SVC, next);
      setSaved(true);
      return next;
    });
    setMessage("");
    setErr(false);
  };

  const applyPreset = (country: string, city: string) => {
    setFields((f) => {
      const next = { ...f, country, city };
      saveDraft(KEY_SEC, KEY_SVC, next);
      setSaved(true);
      return next;
    });
  };

  /* زر التوجه المباشر — رسالة جاهزة دون إظهار اليوزر */
  const direct = () => {
    try {
      window.location.href = buildTrackLink(MEETING_DIRECT_MESSAGE);
    } catch {
      /* noop */
    }
    window.open(buildTrackWebFallback(MEETING_DIRECT_MESSAGE), "_blank", "noreferrer");
  };

  /* إرسال التنسيق — العنوان الديناميكي = اسم الخدمة المكتوب */
  const submit = () => {
    const missing = MEETING_FIELDS.some((f) => f.required && !(fields[f.id] || "").trim());
    if (missing) {
      setErr(true);
      toast(t("fh.required"), "warn");
      return;
    }
    const serviceName = fields.serviceName.trim();
    const msg = buildForumMessage({
      section: pick(lang, MEETING_TOP_TABS.find((x) => x.id === "meetings")!.label),
      service: serviceName, // ← العنوان المتحول
      fields: MEETING_FIELDS.map((f) => ({
        label: pick(lang, f.label),
        value: fields[f.id] || "—",
      })),
    });
    setMessage(msg);
    setCopied(false);
    toast(t("fh.sent"));
    try {
      window.location.href = buildTrackLink(msg);
    } catch {
      /* noop */
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="space-y-4">
      {/* 1 — تيوب التنقل العلوي */}
      <div className="panel p-2.5">
        <div className="mono-label mb-2 px-1">{t("meet.tabs")}</div>
        <div className="no-scrollbar flex gap-1.5 overflow-x-auto">
          {MEETING_TOP_TABS.map((tab) => {
            const target = FORUM_SECTIONS.find((s) => s.id === tab.id);
            return (
              <button
                key={tab.id}
                onClick={() => onSwitchSection(tab.id)}
                className={`shrink-0 border px-3 py-2 font-mono text-[10px] font-bold tracking-wider transition-all ${
                  tab.id === "meetings"
                    ? "border-acid bg-acid text-void shadow-[0_0_16px_rgba(184,239,128,0.3)]"
                    : "border-line bg-abyss/60 text-mute hover:text-fog"
                }`}
              >
                {pick(lang, tab.label)}
                {target && <span className="ms-1 opacity-60">[{target.services?.length ?? target.specialties?.length ?? 0}]</span>}
              </button>
            );
          })}
        </div>
      </div>

      {/* 2 — صندوق الشرح والسياسة (فوق الحقول) */}
      <div className="border border-acid/50 bg-acid/5 p-4 shadow-[0_0_30px_rgba(184,239,128,0.12)] sm:p-5">
        <div className="mono-label mb-3 flex items-center gap-2 text-acid">
          <Icon name="shield" size={13} />
          {t("meet.policy")}
        </div>
        <div className="max-h-[420px] overflow-y-auto whitespace-pre-line text-xs leading-loose text-fog/90 sm:text-[13px]">
          {pick(lang, MEETING_POLICY)}
        </div>
      </div>

      {/* 3 — زر التوجه المباشر للمسؤول */}
      <button onClick={direct} className="btn-primary w-full">
        <Icon name="chat" size={16} />
        {t("meet.direct")}
      </button>

      {/* الدليل التشغيلي — يظهر أولاً بشكل بارز */}
      <div className="border border-acid/50 bg-acid/5 p-4 shadow-[0_0_30px_rgba(184,239,128,0.12)]">
        <div className="mono-label mb-2 flex items-center gap-2 text-acid">
          <Icon name="book" size={13} />
          {t("fh.guide")}
        </div>
        <p className="text-xs leading-loose text-fog/90">{pick(lang, MEETING_GUIDE)}</p>
      </div>

      {/* 4 — أداة تنسيق المقابلات */}
      <div className="panel p-4">
        <div className="mono-label mb-3 flex items-center gap-2">
          <Icon name="user" size={13} className="text-acid" />
          {t("meet.form")}
        </div>

        {/* تعبئة سريعة */}
        <div className="mb-4">
          <div className="mono-label mb-1.5">{t("meet.presets")}</div>
          <div className="no-scrollbar flex gap-1.5 overflow-x-auto">
            {MEETING_CITY_PRESETS.map((c, i) => (
              <button
                key={i}
                onClick={() => applyPreset(pick(lang, c.country), pick(lang, c.city))}
                className="shrink-0 border border-line bg-abyss/60 px-3 py-1.5 font-mono text-[10px] text-mute transition-colors hover:border-acid/50 hover:text-acid"
              >
                {pick(lang, c.city)}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {MEETING_FIELDS.map((f) => (
            <div key={f.id} className={f.id === "serviceName" ? "sm:col-span-2" : ""}>
              <label className="mono-label mb-1.5 block">
                {pick(lang, f.label)}{f.required && <span className="text-blood"> *</span>}
              </label>
              <input
                className="inp"
                type={f.type === "number" ? "number" : "text"}
                inputMode={f.type === "number" ? "numeric" : undefined}
                value={fields[f.id] || ""}
                onChange={(e) => change(f.id, e.target.value)}
                placeholder={f.ph ? pick(lang, f.ph) : ""}
              />
            </div>
          ))}
        </div>

        {saved && (
          <div className="mt-3 flex items-center justify-between gap-2 font-mono text-[9px] text-mute">
            <span className="flex items-center gap-1.5"><Icon name="lock" size={11} className="text-acid" />{t("fh.draft")}</span>
            <button
              onClick={() => { clearDraft(KEY_SEC, KEY_SVC); setFields({}); setSaved(false); }}
              className="text-mute hover:text-blood"
            >
              {t("fh.draftClear")}
            </button>
          </div>
        )}
      </div>

      {err && (
        <div className="flex items-center gap-2 border border-blood/40 bg-blood/10 px-3 py-2 text-xs text-blood">
          <Icon name="warn" size={13} />
          {t("fh.required")}
        </div>
      )}

      {/* 5 — زر الإرسال */}
      <button onClick={submit} className="btn-acid w-full py-3.5">
        <Icon name="send" size={15} />
        📤 {t("meet.submit")}
      </button>

      {/* معاينة الرسالة المؤرخة */}
      {message && (
        <div className="panel animate-fade-up">
          <div className="mono-label border-b border-line px-4 py-2.5">{t("fh.preview")} · {timestamp()}</div>
          <pre className="max-h-64 overflow-auto whitespace-pre-wrap p-4 font-mono text-[11px] leading-6 text-fog/90" dir="auto">
            {message}
          </pre>
          <div className="grid gap-2 border-t border-line p-3 sm:grid-cols-2">
            <button
              onClick={async () => { if (await copyText(message)) { setCopied(true); toast(t("fh.copied")); } }}
              className="btn-acid py-2.5 text-[10px]"
            >
              <Icon name={copied ? "check" : "link"} size={12} />
              {copied ? t("fh.copied") : t("fh.copy")}
            </button>
            <button
              onClick={() => window.open(buildTrackWebFallback(message), "_blank", "noreferrer")}
              className="btn-primary"
            >
              <Icon name="plane" size={15} />
              {t("fh.openRelay")}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
