"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  INJ_HERO,
  INJECTION_BANKS,
  INJECTION_RULES,
  INJECTION_GUIDE,
  injectionTotal,
  readyAccountMessage,
  directInjectionMessage,
  type InjectionBank,
  type InjectionKind,
} from "@/lib/injection";
import { BUY_MANAGER, pick, type L } from "@/lib/site";
import { copyText, dispatchToTelegram, buildWebFallback } from "@/lib/forumClient";
import { useT, useLang, toast, prefersReducedMotion } from "@/lib/client";
import { Icon } from "./Icon";
import Shell from "./Shell";
import SectionToolCTA from "./SectionToolCTA";

const A = (ar: string, en = ar): L => ({ ar, en });

/** ═══ Injection Hub — قسم حقن الحسابات ═══ */
export default function InjectionHub() {
  const t = useT();
  const lang = useLang();
  const router = useRouter();
  const toolRef = useRef<HTMLDivElement>(null);

  const [slide, setSlide] = useState(0);
  const [relay, setRelay] = useState("");
  const [copied, setCopied] = useState(false);

  /* شاشة العرض التفاعلية */
  useEffect(() => {
    if (prefersReducedMotion()) return;
    const iv = window.setInterval(() => setSlide((s) => (s + 1) % INJECTION_BANKS.length), 5500);
    return () => window.clearInterval(iv);
  }, []);

  /** نسخ + توجيه للمسؤول (اليوزر مخفي) */
  const send = useCallback(
    (msg: string) => {
      void copyText(msg);
      void dispatchToTelegram(msg, BUY_MANAGER);
      setRelay(msg);
      setCopied(true);
      toast(t("fa.copied"));
      window.scrollTo({ top: 0, behavior: "smooth" });
    },
    [t],
  );

  const jumpToTool = () => toolRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });

  return (
    <Shell>
      <div className="space-y-5 pt-4">
        {/* ═══ الترويسة + زر الانتقال السريع الثابت ═══ */}
        <div className="sticky top-[96px] z-20 -mx-3 border-b border-line bg-void/95 px-3 py-2 backdrop-blur-md sm:-mx-5 sm:px-5">
          <div className="flex flex-wrap items-center gap-2">
            <button onClick={() => router.push("/market")} className="btn-ghost shrink-0 px-3 py-1.5 text-[9px]">
              <Icon name="back" size={11} className="rtl:rotate-180" />
              {t("c.back")}
            </button>
            <span className="mono-label hidden sm:block">INJECTION HUB :: 05 BANKS</span>
            <button onClick={jumpToTool} className="btn-acid ms-auto shrink-0 px-3.5 py-2 text-[10px]">
              <Icon name="code" size={12} />
              ⚡ الحقن المباشر (الأداة)
            </button>
          </div>
        </div>

        {/* ═══ معاينة الرسالة المُنسوخة ═══ */}
        {relay && (
          <div className="inj-panel inj-glow animate-fade-up">
            <div className="mono-label flex items-center justify-between border-b border-line px-4 py-2.5">
              <span>📤 {t("fh.preview")}</span>
              <span className="inj-green">✓ {t("op.copied")}</span>
            </div>
            <pre className="max-h-52 overflow-auto whitespace-pre-wrap p-4 font-mono text-[11px] leading-6 text-fog/90" dir="auto">
              {relay}
            </pre>
            <div className="grid grid-cols-2 gap-2 border-t border-line p-3 sm:grid-cols-3">
              <button
                onClick={async () => { if (await copyText(relay)) { setCopied(true); toast(t("op.copied")); } }}
                className="btn-ghost py-2 text-[9px]"
              >
                <Icon name={copied ? "check" : "link"} size={11} />
                {t("op.copy")}
              </button>
              <button
                onClick={() => window.open(buildWebFallback(relay, BUY_MANAGER), "_blank", "noreferrer")}
                className="inj-tg"
              >
                <Icon name="plane" size={12} />
                {t("op.open")}
              </button>
              <button onClick={() => setRelay("")} className="btn-ghost py-2 text-[9px] sm:col-span-1">
                <Icon name="close" size={11} />
                {t("c.close")}
              </button>
            </div>
          </div>
        )}

        {/* ═══ 1 — شاشة العرض البصرية (Slider) ═══ */}
        <section className="inj-shell inj-glow relative overflow-hidden">
          <div className="relative h-52 sm:h-72 md:h-80">
            <img
              key={INJECTION_BANKS[slide].id}
              src={INJECTION_BANKS[slide].img}
              alt=""
              loading="lazy"
              decoding="async"
              className="inj-slide absolute inset-0 h-full w-full object-cover opacity-75"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#090d16] via-[#090d16]/55 to-[#090d16]/20" />
            <div className="grid-bg-fine pointer-events-none absolute inset-0 opacity-40" />
            <div className="absolute inset-x-0 bottom-0 p-4 sm:p-6">
              <div className="mono-label mb-2 flex items-center gap-2 inj-cyan">
                <span className="inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full bg-[#06b6d4]" />
                CARD SHOWCASE :: {String(slide + 1).padStart(2, "0")}/{String(INJECTION_BANKS.length).padStart(2, "0")}
              </div>
              <h1 className="display-2 font-bold text-fog">
                {pick(lang, INJECTION_BANKS[slide].name)}
              </h1>
              <p className="mt-1.5 text-xs leading-relaxed text-mute sm:text-sm">
                {pick(lang, INJECTION_BANKS[slide].country)} · {INJECTION_BANKS[slide].creditLimit} · {INJECTION_BANKS[slide].injectedBalance}
              </p>
            </div>
            <button
              onClick={() => setSlide((s) => (s - 1 + INJECTION_BANKS.length) % INJECTION_BANKS.length)}
              aria-label="prev"
              className="absolute start-2 top-1/2 hidden h-9 w-9 -translate-y-1/2 items-center justify-center border border-line bg-void/70 text-mute hover:text-[#06b6d4] sm:flex"
            >
              <Icon name="back" size={15} className="rtl:rotate-180" />
            </button>
            <button
              onClick={() => setSlide((s) => (s + 1) % INJECTION_BANKS.length)}
              aria-label="next"
              className="absolute end-2 top-1/2 hidden h-9 w-9 -translate-y-1/2 items-center justify-center border border-line bg-void/70 text-mute hover:text-[#06b6d4] sm:flex"
            >
              <Icon name="back" size={15} className="rotate-180 rtl:rotate-0" />
            </button>
          </div>
          <div className="flex justify-center gap-1.5 border-t border-line px-4 py-2.5">
            {INJECTION_BANKS.map((b, i) => (
              <button
                key={b.id}
                onClick={() => setSlide(i)}
                aria-label={b.name.ar}
                className={`h-1.5 transition-all ${i === slide ? "w-7 bg-[#06b6d4]" : "w-3 bg-line2"}`}
              />
            ))}
          </div>
        </section>

        {/* ═══ 2 — جدول الحسابات المحقونة الجاهزة ═══ */}
        <section>
          <div className="mono-label mb-3 flex items-center gap-2">
            <Icon name="table" size={12} className="inj-cyan" />
            // PRE-INJECTED ACCOUNTS · 05
          </div>

          {/* كمبيوتر: جدول */}
          <div className="inj-panel hidden overflow-hidden md:block">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-line bg-[#0d1420] text-start">
                  {[
                    A("الملصق"), A("اسم البطاقة/الحساب"), A("الدولة"), A("الحد الائتماني"),
                    A("الرصيد المحقون"), A("نوع الحقن"), A("السعر"), A("إجراء الشراء"),
                  ].map((h, i) => (
                    <th key={i} className="mono-label px-3 py-3 text-start font-normal">{pick(lang, h)}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {INJECTION_BANKS.map((b) => (
                  <tr key={b.id} className="border-b border-line/60 last:border-0">
                    <td className="px-3 py-3 text-lg">{b.badge}</td>
                    <td className="px-3 py-3 font-bold">{pick(lang, b.name)}</td>
                    <td className="px-3 py-3 text-xs text-mute">{pick(lang, b.country)}</td>
                    <td className="px-3 py-3 font-mono text-xs inj-cyan">{b.creditLimit}</td>
                    <td className="px-3 py-3 font-mono text-xs inj-green">{b.injectedBalance}</td>
                    <td className="px-3 py-3 text-xs text-mute">{pick(lang, b.injectionType)}</td>
                    <td className="px-3 py-3 font-mono font-bold text-acid">${b.priceUsd}</td>
                    <td className="px-3 py-3">
                      <button onClick={() => send(readyAccountMessage(b))} className="inj-tg whitespace-nowrap !text-[10px]">
                        <Icon name="plane" size={11} />
                        شراء عبر المسؤول
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* هاتف: بطاقات بلا تمرير أفقي */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 md:hidden">
            {INJECTION_BANKS.map((b) => (
              <ReadyAccountCard key={b.id} bank={b} onBuy={() => send(readyAccountMessage(b))} />
            ))}
          </div>
        </section>

        {/* ═══ 3 — أداة الحقن المباشر ═══ */}
        <SectionToolCTA
          label={A("⚡ أداة الحقن المباشر — طلب مخصص")}
          hint={A("اختر نوع الحقن، أدخل الكمية والبيانات، وسيُحتسب السعر ويُوجَّه الطلب للمسؤول من داخل هذا القسم.")}
          badge="2 MODES"
        />
        <div id="custom-tool" ref={toolRef} className="acc-cta-panel scroll-mt-32">
          <InjectionTool onSend={send} />
        </div>
      </div>
    </Shell>
  );
}

/** بطاقة الحساب الجاهز (الهاتف) */
function ReadyAccountCard({ bank, onBuy }: { bank: InjectionBank; onBuy: () => void }) {
  const lang = useLang();
  return (
    <div className="inj-panel flex flex-col gap-2 p-3.5">
      <div className="flex items-center gap-2">
        <span className="text-xl">{bank.badge}</span>
        <span className="flex-1 text-sm font-bold">{pick(lang, bank.name)}</span>
        <span className="font-mono text-base font-bold text-acid">${bank.priceUsd}</span>
      </div>
      <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[11px]">
        <span className="text-mute">الدولة</span><span>{pick(lang, bank.country)}</span>
        <span className="text-mute">الحد الائتماني</span><span className="inj-cyan font-mono">{bank.creditLimit}</span>
        <span className="text-mute">الرصيد المحقون</span><span className="inj-green font-mono">{bank.injectedBalance}</span>
        <span className="text-mute">نوع الحقن</span><span>{pick(lang, bank.injectionType)}</span>
      </div>
      <button onClick={onBuy} className="inj-tg mt-1 w-full">
        <Icon name="plane" size={12} />
        شراء عبر المسؤول
      </button>
    </div>
  );
}

/** ═══ أداة الحقن المباشر التفاعلية ═══ */
function InjectionTool({ onSend }: { onSend: (msg: string) => void }) {
  const t = useT();
  const lang = useLang();

  const [bankId, setBankId] = useState("amex");
  const [kind, setKind] = useState<InjectionKind>("api");
  const [qty, setQty] = useState(String(INJECTION_RULES.api.min));
  const [data, setData] = useState<Record<string, string>>({});
  const [guide, setGuide] = useState(false);

  const bank = useMemo(() => INJECTION_BANKS.find((b) => b.id === bankId) ?? INJECTION_BANKS[0], [bankId]);
  const rule = INJECTION_RULES[kind];
  const qtyNum = Number(qty) || 0;
  const total = injectionTotal(kind, qtyNum);
  const belowMin = qtyNum < rule.min;
  const missing = rule.fields.some((f) => !(data[f.id] || "").trim());
  const disabled = belowMin || missing || qtyNum <= 0;

  const switchKind = (k: InjectionKind) => {
    setKind(k);
    setQty(String(INJECTION_RULES[k].min));
    setData({});
  };

  const submit = () => {
    if (disabled) return;
    const details = rule.fields.map((f) => `${f.label.ar}: ${data[f.id] || "—"}`).join("\n");
    onSend(
      directInjectionMessage({
        kind,
        bank,
        qty: qtyNum,
        total,
        data: details,
      }),
    );
  };

  return (
    <section className="inj-shell inj-glow space-y-4 p-4 sm:p-6">
      <div>
        <div className="mono-label mb-2 inj-cyan">// DIRECT INJECTION TOOL</div>
        <h2 className="text-xl font-bold sm:text-2xl">⚡ الحقن المباشر (الأداة)</h2>
      </div>

      {/* شريط ملصقات البنوك */}
      <div className="flex flex-wrap gap-1.5">
        {INJECTION_BANKS.map((b) => (
          <button
            key={b.id}
            onClick={() => setBankId(b.id)}
            className={`inj-badge ${bankId === b.id ? "active" : ""}`}
          >
            {b.badge} {b.name.ar}
          </button>
        ))}
      </div>

      {/* نوع الحقن */}
      <div>
        <div className="mono-label mb-2">{pick(lang, A("نوع الحقن", "Injection type"))}</div>
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
          {(["api", "real"] as InjectionKind[]).map((k) => (
            <button
              key={k}
              onClick={() => switchKind(k)}
              className={`border px-3 py-3 text-start transition-all ${
                kind === k ? "border-[#10b981] bg-[#10b981]/10" : "border-line bg-[#111827] hover:border-[#06b6d4]/50"
              }`}
            >
              <div className={`text-sm font-bold ${kind === k ? "inj-green" : ""}`}>{pick(lang, INJECTION_RULES[k].title)}</div>
              <div className="mt-1 font-mono text-[10px] text-mute">{pick(lang, INJECTION_RULES[k].rateLabel)}</div>
            </button>
          ))}
        </div>
      </div>

      {/* الحقول */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div>
          <label className="mono-label mb-1.5 block">{pick(lang, A("البنك / البطاقة", "Bank / Card"))}</label>
          <select className="inp" value={bankId} onChange={(e) => setBankId(e.target.value)}>
            {INJECTION_BANKS.map((b) => (
              <option key={b.id} value={b.id}>{b.name.ar}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="mono-label mb-1.5 flex items-center justify-between">
            <span>{pick(lang, A("الكمية المطلوبة", "Quantity"))}</span>
            <span className="inj-cyan" dir="ltr">{bank.symbol} · {bank.currency}</span>
          </label>
          <input
            className="inp font-mono"
            type="number"
            inputMode="numeric"
            min={rule.min}
            value={qty}
            onChange={(e) => setQty(e.target.value)}
          />
        </div>
        {rule.fields.map((f) => (
          <div key={f.id} className={rule.fields.length === 1 ? "sm:col-span-2" : ""}>
            <label className="mono-label mb-1.5 block">{pick(lang, f.label)}</label>
            <input
              className="inp font-mono"
              dir="ltr"
              type={f.type === "number" ? "text" : "text"}
              inputMode={f.type === "number" ? "numeric" : undefined}
              maxLength={f.maxLength}
              value={data[f.id] || ""}
              onChange={(e) => setData((d) => ({ ...d, [f.id]: e.target.value }))}
              placeholder={pick(lang, f.ph)}
            />
          </div>
        ))}
      </div>

      {/* التنبيه + الحاسبة الحية */}
      {belowMin && (
        <div className="flex items-center gap-2 border border-[#ef4444]/50 bg-[#ef4444]/10 px-3 py-2.5 text-xs inj-err">
          <Icon name="warn" size={13} />
          الحد الأدنى لهذا النوع {rule.min.toLocaleString()} وحدة — لا يمكن الإرسال قبل تجاوزه.
        </div>
      )}
      <div className="flex flex-wrap items-center justify-between gap-2 border border-line bg-[#0d1420] px-4 py-3">
        <span className="mono-label">💰 {pick(lang, A("السعر الإجمالي", "Total price"))}</span>
        <span className="font-mono text-2xl font-bold inj-green" dir="ltr">${total.toLocaleString()}</span>
      </div>

      {/* زر الإرسال */}
      <button onClick={submit} disabled={disabled} className="inj-tg w-full !py-3 !text-xs">
        <Icon name="send" size={14} />
        📤 إرسال الطلب عبر تليجرام
      </button>

      {/* القائمة المنسدلة للشرح */}
      <div>
        <button
          onClick={() => setGuide((v) => !v)}
          className={`btn-ghost w-full py-2.5 ${guide ? "!border-[#06b6d4]/60 !text-[#06b6d4]" : ""}`}
        >
          <Icon name="book" size={13} />
          💡 ما هو الحقن الحقيقي وحقن البروتوكول؟
          <Icon name="chevron" size={12} className={guide ? "rotate-180 transition-transform" : "transition-transform"} />
        </button>
        {guide && (
          <div className="inj-panel animate-fade-up mt-2">
            <div className="mono-label flex items-center justify-between border-b border-line px-4 py-2.5">
              <span>◈ {pick(lang, A("دليل أنواع الحقن", "Injection guide"))}</span>
              <button onClick={() => setGuide(false)} className="flex items-center gap-1 text-mute hover:text-[#06b6d4]">
                <Icon name="close" size={11} />
                ✖ إغلاق الشرح
              </button>
            </div>
            <div className="divide-y divide-line">
              {INJECTION_GUIDE.map((g, i) => (
                <div key={i} className="p-4">
                  <div className="text-sm font-bold inj-cyan">{pick(lang, g.title)}</div>
                  <p className="mt-1.5 text-xs leading-loose text-mute">{pick(lang, g.body)}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
