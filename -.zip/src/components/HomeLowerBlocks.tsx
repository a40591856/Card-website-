"use client";

import { ProductRow } from "@/lib/types";
import { BestSellers } from "./HomeBlocks";

/** الجزء السفلي من الرئيسية — «التقييمات والآراء» نُقلا إلى قسم الدعم والإرشادات */
export default function HomeLowerBlocks({ onPick }: { onPick: (p: ProductRow) => void }) {
  return <BestSellers onPick={onPick} />;
}
