"use client";

import { useEffect, useState } from "react";
import { ADS, pick } from "@/lib/site";
import { useT, useLang, prefersReducedMotion } from "@/lib/client";
import { Icon } from "./Icon";

/** 📺 شاشة الإعلانات: نص + صور + فيديو — تتبدل تلقائياً */
export default function AdCarousel({ compact = false }: { compact?: boolean }) {
  const t = useT();
  const lang = useLang();
  const [i, setI] = useState(0);
  const [hold, setHold] = useState(false);
  const [playing, setPlaying] = useState(false);
  const ad = ADS[i];

  useEffect(() => {
    setPlaying(false);
  }, [i]);

  useEffect(() => {
    if (hold || ADS.length < 2) return;
    const iv = window.setInterval(() => setI((v) => (v + 1) % ADS.length), 6000);
    return () => window.clearInterval(iv);
  }, [hold]);

  const prev = () => setI((v) => (v - 1 + ADS.length) % ADS.length);
  const next = () => setI((v) => (v + 1) % ADS.length);

  return (
    <section className="panel corners relative overflow-hidden" onMouseEnter={() => setHold(true)} onMouseLeave={() => setHold(false)}>
      <div
        key={ad.id + i}
        className={compact ? "relative h-40 sm:h-44" : "relative h-60 sm:h-80"}
      >
        {/* الخلفية */}
        {ad.type === "image" && ad.src && (
          <img src={ad.src} alt="" className="absolute inset-0 h-full w-full object-cover opacity-70" loading="lazy" decoding="async" />
        )}
        {/* فيديو: لا تحميل تلقائي — يُحمَّل فقط عند الضغط (خفيف للهواتف القديمة) */}
        {ad.type === "video" && (
          playing ? (
            <video
              src={ad.src}
              poster={ad.poster}
              muted
              loop
              autoPlay
              playsInline
              className="absolute inset-0 h-full w-full object-cover opacity-70"
            />
          ) : (
            <button
              onClick={() => setPlaying(true)}
              aria-label="play"
              className="group absolute inset-0"
            >
              {ad.poster && (
                <img src={ad.poster} alt="" className="h-full w-full object-cover opacity-60" loading="lazy" decoding="async" />
              )}
              <span className="absolute inset-0 flex items-center justify-center">
                <span className="flex h-14 w-14 items-center justify-center rounded-full border border-acid/60 bg-void/70 text-acid transition-transform group-hover:scale-110">
                  <Icon name="play" size={22} />
                </span>
              </span>
            </button>
          )
        )}
        {ad.type === "text" && <div className="absolute inset-0 grid-bg-fine" />}
        <div className="absolute inset-0 bg-gradient-to-t from-void via-void/55 to-void/15" />
        <div className="absolute inset-0 scanlines opacity-40" />

        {/* المحتوى */}
        <div className={`absolute inset-x-0 bottom-0 p-4 sm:p-6 ${compact ? "" : "animate-fade-up"}`}>
          <div className="mb-2 inline-flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 border border-acid/40 bg-void/70 px-2 py-0.5 font-mono text-[9px] tracking-[0.25em] text-acid">
              <span className="inline-block h-1.5 w-1.5 animate-blink rounded-full bg-acid" />
              {t("home.ads")}
            </span>
            <span className="font-mono text-[9px] tracking-[0.2em] text-mute">
              {String(i + 1).padStart(2, "0")}/{String(ADS.length).padStart(2, "0")}
            </span>
          </div>
          <h3 className={`font-extrabold leading-snug ${compact ? "text-lg" : "text-xl sm:text-2xl"}`}>
            {pick(lang, ad.title)}
          </h3>
          {!compact && (
            <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-mute">{pick(lang, ad.body)}</p>
          )}
        </div>

        {/* أزرار التنقل */}
        <button
          onClick={prev}
          aria-label="prev"
          className="absolute start-2 top-1/2 hidden h-9 w-9 -translate-y-1/2 items-center justify-center border border-line bg-void/70 text-mute transition-colors hover:border-dim hover:text-acid sm:flex"
        >
          <Icon name="back" size={16} className="rtl:rotate-180" />
        </button>
        <button
          onClick={next}
          aria-label="next"
          className="absolute end-2 top-1/2 hidden h-9 w-9 -translate-y-1/2 items-center justify-center border border-line bg-void/70 text-mute transition-colors hover:border-dim hover:text-acid sm:flex"
        >
          <Icon name="back" size={16} className="rotate-180 rtl:rotate-0" />
        </button>
      </div>

      {/* نقاط */}
      <div className="absolute bottom-2 end-4 flex gap-1.5">
        {ADS.map((a, idx) => (
          <button
            key={a.id}
            onClick={() => setI(idx)}
            aria-label={`slide ${idx + 1}`}
            className={`h-1 transition-all ${idx === i ? "w-6 bg-acid" : "w-2.5 bg-line2"}`}
          />
        ))}
      </div>
    </section>
  );
}
