"use client";

import { Suspense, useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import {
  PAGES,
  WALLETS,
  CHANNELS,
  MANAGERS,
  GUIDE_ITEMS,
  FAQS,
  REPLIES,
  MEETINGS,
  LINKS,
  SITE_POSTS,
  WORK_POSTS,
  NOTES,
  PERCENT_OPPS,
  AI_QA,
  CHECKERS,
  ABOUT_TEXTS,
  NEWS_POSTS,
  HOME_SECTIONS,
  AUTONOMOUS_SERVICES,
  ACCENT,
  pick,
  type PageId,
  type SectionDef,
  type SubBranch,
  type ContentDef,
  type PostDef,
  type L,
} from "@/lib/site";
import { useT, useLang, api, langDef, prefersReducedMotion } from "@/lib/client";
import { ProductRow } from "@/lib/types";
import { Icon } from "./Icon";
import Shell from "./Shell";
import Decryption from "./Decryption";
import ProductCard, { ProductModal } from "./ProductCard";
/* التقييمات والآراء تظهر حصراً في SupportHub */

type BodySrc = { content: ContentDef };

/* ═══════════════ بلوكات المحتوى ═══════════════ */

export function ProductsGridBlock({ catId, onPick }: { catId: string; onPick: (p: ProductRow) => void }) {
  const [rows, setRows] = useState<ProductRow[] | null>(null);
  useEffect(() => {
    api<ProductRow[]>(`/api/products?cat=${catId}`).then(setRows).catch(() => setRows([]));
  }, [catId]);

  if (rows === null)
    return (
      <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="panel h-56 animate-pulse-soft bg-panel2/40" />
        ))}
      </div>
    );
  if (rows.length === 0) return <div className="panel p-8 text-center font-mono text-xs text-mute">PHASE-2 :: LOADING CONTENT</div>;
  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
      {rows.map((p) => (
        <ProductCard key={p.id} p={p} onOpen={onPick} />
      ))}
    </div>
  );
}

function ComingSoonBlock() {
  const t = useT();
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3 border border-amber/30 bg-amber/5 p-4">
        <Icon name="warn" size={20} className="shrink-0 text-amber" />
        <p className="text-sm leading-relaxed">{t("page.soon")}</p>
      </div>
      <div className="space-y-2">
        {[0, 1, 2].map((i) => (
          <div key={i} className="flex items-center gap-3 border border-line bg-abyss/50 p-3 opacity-60">
            <Icon name="tool" size={16} className="text-mute" />
            <div className="h-2 flex-1 bg-line/70" />
            <span className="font-mono text-[9px] tracking-widest text-mute">PHASE-2</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function WalletsBlock() {
  const t = useT();
  const lang = useLang();
  const [open, setOpen] = useState<string | null>(null);
  return (
    <div>
      <div className="hidden border border-line md:block">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-line bg-panel2/40 text-start">
              <th className="mono-label px-4 py-3 text-start font-normal">{t("pay.wallets")}</th>
              <th className="mono-label px-4 py-3 text-start font-normal">{t("pay.network")}</th>
              <th className="mono-label px-4 py-3 text-start font-normal">{t("pay.state")}</th>
              <th className="mono-label px-4 py-3 text-start font-normal">{t("pay.how")}</th>
            </tr>
          </thead>
          <tbody>
            {WALLETS.map((w) => (
              <tr key={w.id} className="border-b border-line/60 last:border-0">
                <td className="px-4 py-3.5 font-bold">{w.name}</td>
                <td className="px-4 py-3.5 font-mono text-xs text-mute">{w.network}</td>
                <td className="px-4 py-3.5">
                  <span className="inline-flex items-center gap-1.5 border border-acid/40 bg-acid/10 px-2 py-0.5 font-mono text-[9px] tracking-widest text-acid">
                    <span className="h-1.5 w-1.5 animate-pulse-soft rounded-full bg-acid" />
                    {t("pay.active")}
                  </span>
                </td>
                <td className="px-4 py-3.5 text-xs leading-relaxed text-mute">{pick(lang, w.explain)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="space-y-2.5 md:hidden">
        {WALLETS.map((w) => (
          <div key={w.id} className="border border-line bg-abyss/60">
            <div className="flex items-center gap-3 p-3.5">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center border border-line2 bg-panel text-acid">
                <Icon name="wallet" size={17} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-sm font-bold">{w.name}</div>
                {w.network && <div className="font-mono text-[9px] tracking-widest text-mute">{w.network}</div>}
              </div>
              <button onClick={() => setOpen(open === w.id ? null : w.id)} className="btn-ghost px-3 py-1.5 text-[10px]">
                {t("pay.how")}
                <Icon name="chevron" size={11} className={open === w.id ? "rotate-180 transition-transform" : "transition-transform"} />
              </button>
            </div>
            {open === w.id && (
              <div className="animate-fade-up border-t border-line p-3.5 text-xs leading-relaxed text-mute">{pick(lang, w.explain)}</div>
            )}
          </div>
        ))}
      </div>
      <p className="mt-3 flex items-center gap-2 border border-line bg-panel p-3 font-mono text-[10px] leading-5 text-mute">
        <Icon name="shield" size={13} className="shrink-0 text-dim" />
        {t("pay.note")}
      </p>
    </div>
  );
}

export function ChannelsBlock() {
  const t = useT();
  const lang = useLang();
  return (
    <div className="space-y-2.5">
      {CHANNELS.map((ch) => (
        <div key={ch.id} className="flex items-center gap-3 border border-line bg-abyss/60 p-3.5">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center border border-line2 bg-panel text-acid">
            <Icon name="megaphone" size={17} />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-sm font-bold">{pick(lang, ch.name)}</div>
            <div className="font-mono text-[10px] text-mute" dir="ltr">{ch.handle}</div>
          </div>
          <a href={ch.url} target="_blank" rel="noreferrer" className="btn-acid px-3.5 py-2 text-[10px]">
            <Icon name="external" size={12} />
            {t("pay.join")}
          </a>
        </div>
      ))}
    </div>
  );
}

export function ManagersBlock() {
  const t = useT();
  const lang = useLang();
  return (
    <div className="grid grid-cols-1 gap-2.5 md:grid-cols-3">
      {MANAGERS.map((m) => (
        <div key={m.id} className="border border-line bg-abyss/60 p-3.5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center border border-acid/40 bg-panel text-acid">
              <Icon name="headset" size={17} />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-sm font-bold">{pick(lang, m.role)}</div>
              <div className="font-mono text-[10px] text-acid" dir="ltr">{m.user}</div>
            </div>
          </div>
          <p className="mt-2.5 text-xs leading-relaxed text-mute">{pick(lang, m.explain)}</p>
          <a href={m.url} target="_blank" rel="noreferrer" className="btn-acid mt-3 inline-flex px-3.5 py-2 text-[10px]">
            <Icon name="plane" size={12} />
            {t("c.open")}
          </a>
        </div>
      ))}
    </div>
  );
}

function FormBlock({ kind }: { kind: "complaint" | "exchange" | "return" | "service" }) {
  const t = useT();
  const [name, setName] = useState("");
  const [text, setText] = useState("");
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!text.trim() || busy) return;
    setBusy(true);
    try {
      await api("/api/opinions", { method: "POST", body: JSON.stringify({ name: name.trim() || "—", kind, text: text.trim() }) });
      setSent(true);
    } finally {
      setBusy(false);
    }
  };

  if (sent)
    return (
      <div className="flex flex-col items-center gap-3 border border-acid/40 bg-acid/5 p-10 text-center">
        <Icon name="check" size={34} className="text-acid" />
        <p className="text-sm font-bold">{t("form.sent")}</p>
        <p className="font-mono text-[10px] tracking-widest text-mute">TG_RELAY :: {kind.toUpperCase()}</p>
      </div>
    );

  return (
    <div className="space-y-3">
      <label className="mono-label block">{t("form.name")}</label>
      <input className="inp" value={name} onChange={(e) => setName(e.target.value)} placeholder={t("ratings.name.ph")} />
      <label className="mono-label block">{t("form.text")}</label>
      <textarea className="inp min-h-[120px] resize-y" value={text} onChange={(e) => setText(e.target.value)} placeholder={t("form.text.ph")} />
      <button onClick={submit} disabled={!text.trim() || busy} className="btn-acid w-full py-3 disabled:opacity-40">
        <Icon name="send" size={14} />
        {busy ? t("c.sending") : t("form.send")}
      </button>
    </div>
  );
}

/* الشكاوى + الاستبدال + الاسترجاع بتبويبات (مُexport ليُعاد استخدامه كما هو) */
export function AdminFormsBlock() {
  const t = useT();
  const lang = useLang();
  const [tab, setTab] = useState<"complaint" | "exchange" | "return">("complaint");
  const TABS: { k: "complaint" | "exchange" | "return"; l: L }[] = [
    { k: "complaint", l: { ar: "الشكاوى", en: "Complaints", ru: "Жалобы" } },
    { k: "exchange", l: { ar: "الاستبدال", en: "Exchange", ru: "Обмен" } },
    { k: "return", l: { ar: "الاسترجاع", en: "Return", ru: "Возврат" } },
  ];
  return (
    <div>
      <div className="mb-4 grid grid-cols-3 gap-1.5">
        {TABS.map((x) => (
          <button
            key={x.k}
            onClick={() => setTab(x.k)}
            className={`border px-2 py-2 font-mono text-[10px] tracking-wider transition-colors ${
              tab === x.k ? "border-acid bg-acid/10 font-bold text-acid" : "border-line bg-abyss/60 text-mute hover:border-line2"
            }`}
          >
            {pick(lang, x.l)}
          </button>
        ))}
      </div>
      <FormBlock key={tab} kind={tab} />
    </div>
  );
}

function PostsBlock({ items }: { items: "work" | "site" }) {
  const lang = useLang();
  const list: PostDef[] = items === "work" ? WORK_POSTS : SITE_POSTS;
  return (
    <div className="space-y-3">
      {list.map((p) => (
        <article key={p.id} className="border border-line bg-abyss/60 p-4">
          <div className="flex items-center justify-between gap-2">
            <h4 className="text-sm font-bold">{pick(lang, p.title)}</h4>
            <span className="shrink-0 font-mono text-[9px] text-mute">{p.date}</span>
          </div>
          <p className="mt-2 whitespace-pre-line text-xs leading-relaxed text-mute">{pick(lang, p.body)}</p>
        </article>
      ))}
    </div>
  );
}

function NotesBlock() {
  const lang = useLang();
  return (
    <div className="space-y-3">
      {NOTES.map((p) => (
        <article key={p.id} className="border border-line bg-abyss/60 p-4">
          <div className="flex items-center justify-between gap-2">
            <h4 className="text-sm font-bold">{pick(lang, p.title)}</h4>
            <span className="shrink-0 font-mono text-[9px] text-mute">{p.date}</span>
          </div>
          <p className="mt-2 text-xs leading-relaxed text-mute">{pick(lang, p.body)}</p>
        </article>
      ))}
    </div>
  );
}

function DrainHubBlock() {
  const t = useT();
  const Slot = ({ label, icon }: { label: string; icon: string }) => (
    <div className="border border-line bg-abyss/60 p-4 opacity-85">
      <div className="mono-label mb-3 flex items-center gap-2 text-violet">
        <Icon name={icon} size={12} />
        {label}
      </div>
      <div className="space-y-2">
        {[0, 1].map((i) => (
          <div key={i} className="flex items-center gap-2 border border-line p-2.5">
            <Icon name="box" size={13} className="text-mute" />
            <div className="h-2 flex-1 bg-line/70" />
            <span className="font-mono text-[8px] tracking-widest text-mute">PHASE-2</span>
          </div>
        ))}
      </div>
    </div>
  );
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3 border border-violet/30 bg-violet/5 p-4">
        <Icon name="code" size={20} className="shrink-0 text-violet" />
        <p className="text-sm leading-relaxed">{t("page.soon")}</p>
      </div>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <Slot label="LOADERS :: LIST" icon="tool" />
        <Slot label="RECEIVED :: INBOX" icon="box" />
      </div>
      <a href={LINKS.support} target="_blank" rel="noreferrer" className="btn-acid flex w-full items-center justify-center py-2.5 text-[10px]">
        <Icon name="plane" size={12} />
        {t("nav.support")}
      </a>
    </div>
  );
}

/* ═══ القسم التقني الذاتي والخدمات الأمنية — Autonomous Section ═══ */
function AutonomousBlock() {
  const t = useT();
  const lang = useLang();
  const [open, setOpen] = useState<string | null>(null);

  const stateStyle: Record<string, string> = {
    active: "border-acid/50 bg-acid/10 text-acid",
    standby: "border-amber/50 bg-amber/10 text-amber",
    beta: "border-violet/50 bg-violet/10 text-violet",
  };

  return (
    <div className="space-y-3">
      {/* ترويسة الوحدة */}
      <div className="flex items-center gap-3 border border-violet/40 bg-violet/5 p-4">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center border border-violet/50 bg-panel text-violet">
          <Icon name="shield" size={20} />
        </div>
        <div className="min-w-0 flex-1">
          <div className="mono-label">AUTONOMOUS :: SELF-RUN</div>
          <div className="mt-0.5 text-sm font-bold">{t("auto.title")}</div>
        </div>
        <span className="shrink-0 border border-violet/40 bg-void/70 px-2 py-1 font-mono text-[10px] text-violet" dir="ltr">
          {String(AUTONOMOUS_SERVICES.length).padStart(2, "0")} {t("auto.count")}
        </span>
      </div>

      {/* الوحدات الخمس — accordion */}
      {AUTONOMOUS_SERVICES.map((s, i) => (
        <div key={s.id} className="border border-line bg-abyss/60">
          <button
            onClick={() => setOpen(open === s.id ? null : s.id)}
            className="flex w-full items-start gap-3 p-3.5 text-start"
          >
            <div className="flex h-10 w-10 shrink-0 items-center justify-center border border-line2 bg-panel text-violet">
              <Icon name={s.icon} size={18} />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-sm font-bold">{pick(lang, s.name)}</span>
                <span className={`border px-1.5 py-0.5 font-mono text-[8px] tracking-widest ${stateStyle[s.state]}`}>
                  {t(`auto.state.${s.state}`)}
                </span>
              </div>
              <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-mute">{pick(lang, s.desc)}</p>
            </div>
            <span className="shrink-0 font-mono text-[10px] text-mute/60">{String(i + 1).padStart(2, "0")}</span>
          </button>

          {open === s.id && (
            <div className="animate-fade-up border-t border-line p-3.5">
              <p className="text-xs leading-loose text-mute">{pick(lang, s.detail)}</p>
              <button onClick={() => setOpen(null)} className="btn-ghost mt-3 px-3 py-1.5 text-[9px]">
                <Icon name="close" size={11} />
                {t("auto.hide")}
              </button>
            </div>
          )}
        </div>
      ))}

      {/* مؤشر الجاهزية */}
      <div className="flex items-center gap-2 border border-line bg-panel p-3 font-mono text-[9px] tracking-[0.2em] text-mute">
        <span className="inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full bg-acid" />
        SYSTEM :: ONLINE · AES-256 · SELF-MONITORED
      </div>
    </div>
  );
}

/* تنسيق المقابلات: المدن المعتمدة + المواعيد */
function MeetingsBlock() {
  const t = useT();
  const lang = useLang();
  return (
    <div className="space-y-4">
      <div>
        <div className="mono-label mb-2">{t("meet.cities")}</div>
        <div className="flex flex-wrap gap-1.5">
          {MEETINGS.map((m) => (
            <span key={m.id} className="border border-line bg-abyss/60 px-3 py-1.5 font-mono text-[10px] text-fog">
              ◆ {pick(lang, m.city)}
            </span>
          ))}
        </div>
      </div>
      <div className="space-y-3">
        {MEETINGS.map((m) => (
          <div key={m.id} className="border border-line bg-abyss/60 p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="font-mono text-[10px] tracking-wider text-acid" dir="ltr">{m.when}</span>
              <span className="flex items-center gap-2">
                <span className="border border-amber/40 bg-amber/10 px-2 py-0.5 font-mono text-[9px] text-amber">◆ {pick(lang, m.city)}</span>
                <span className="font-mono text-[9px] text-mute" dir="ltr">@{m.host}</span>
              </span>
            </div>
            <h4 className="mt-2 text-sm font-bold">{pick(lang, m.topic)}</h4>
            <a href={`https://t.me/${m.host}`} target="_blank" rel="noreferrer" className="btn-acid mt-3 inline-flex px-3.5 py-2 text-[10px]">
              <Icon name="plane" size={12} />
              {t("c.open")}
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}

/* العمل بالنسبة: شرح شامل لفرص العمل */
function PercentOppsBlock() {
  const t = useT();
  const lang = useLang();
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        {PERCENT_OPPS.map((o) => (
          <div key={o.id} className="border border-line bg-abyss/60 p-4">
            <h4 className="text-sm font-bold">{pick(lang, o.title)}</h4>
            <p className="mt-2 text-xs leading-relaxed text-mute">{pick(lang, o.body)}</p>
            <div className="mt-3 inline-block border border-acid/40 bg-acid/10 px-2.5 py-1 font-mono text-[9px] tracking-widest text-acid" dir="ltr">
              {o.bonus}
            </div>
          </div>
        ))}
      </div>
      <div>
        <div className="mono-label mb-2">{t("posts.title")}</div>
        <PostsBlock items="work" />
      </div>
    </div>
  );
}

/* Black Mart AI — شرائح أسئلة + وصول سريع */
function AiBlock() {
  const t = useT();
  const lang = useLang();
  const router = useRouter();
  const [lines, setLines] = useState<{ q?: string; a: string }[]>([{ a: t("ai.welcome") }]);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    boxRef.current?.scrollTo({ top: boxRef.current.scrollHeight });
  }, [lines]);

  const ask = (qa: (typeof AI_QA)[number]) =>
    setLines((l) => [...l, { q: pick(lang, qa.q), a: pick(lang, qa.a) }]);

  const navChips = [
    { label: pick(lang, HOME_SECTIONS[0].short), route: "/market", icon: "bag" },
    { label: pick(lang, HOME_SECTIONS[1].short), route: "/arsenal", icon: "tool" },
    { label: pick(lang, HOME_SECTIONS[2].short), route: "/forum", icon: "chat" },
    { label: t("pages.pay.short"), route: "/pay", icon: "wallet" },
    { label: t("menu.orders"), route: "/account", icon: "user" },
  ];

  const chip = "border border-line bg-abyss/60 px-3 py-1.5 font-mono text-[10px] text-mute transition-colors hover:border-acid/50 hover:text-acid";

  return (
    <div className="space-y-4">
      {/* نافذة الطرفية */}
      <div className="panel">
        <div className="flex items-center gap-1.5 border-b border-line px-4 py-2.5">
          <span className="h-2.5 w-2.5 rounded-full bg-blood/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-amber/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-acid/70" />
          <span className="mono-label ms-3">BM-AI :: AUTO-REPLY v1</span>
        </div>
        <div ref={boxRef} className="max-h-64 space-y-3 overflow-y-auto p-4">
          {lines.map((l, i) => (
            <div key={i}>
              {l.q && (
                <div className="mb-1 flex items-start gap-2">
                  <span className="font-mono text-xs text-violet">◈</span>
                  <span className="text-xs font-bold">{l.q}</span>
                </div>
              )}
              <div className="flex items-start gap-2 ps-4">
                <span className="font-mono text-xs text-acid">▸</span>
                <p className="text-xs leading-relaxed text-mute">{l.a}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div>
        <div className="mono-label mb-2">{t("ai.chips.q")}</div>
        <div className="flex flex-wrap gap-1.5">
          {AI_QA.map((qa) => (
            <button key={qa.id} onClick={() => ask(qa)} className={chip}>
              {pick(lang, qa.q)}
            </button>
          ))}
        </div>
      </div>
      <div>
        <div className="mono-label mb-2">{t("ai.chips.nav")}</div>
        <div className="flex flex-wrap gap-1.5">
          {navChips.map((nc) => (
            <button key={nc.route} onClick={() => router.push(nc.route)} className={`${chip} !border-acid/40 !text-acid`}>
              <Icon name={nc.icon} size={11} className="me-1.5 inline" />
              {nc.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

/* أدوات الفحص — نتيجة تجريبية */
function CheckerBlock({ kind }: { kind: "card" | "address" | "data" }) {
  const t = useT();
  const lang = useLang();
  const cfg = CHECKERS.find((c) => c.kind === kind);
  const [val, setVal] = useState("");
  const [busy, setBusy] = useState(false);
  const [warn, setWarn] = useState(false);
  const [res, setRes] = useState<{ k: string; v: string; ok: boolean }[] | null>(null);

  if (!cfg) return null;

  const run = () => {
    if (!val.trim()) {
      setWarn(true);
      return;
    }
    setWarn(false);
    setBusy(true);
    setRes(null);
    const h = [...val].reduce((a, c) => a + c.charCodeAt(0), 7);
    const finish = () => {
      setRes(
        kind === "card"
          ? [
              { k: "BIN", v: val.replace(/\D/g, "").slice(0, 6) || "455678", ok: true },
              { k: "STATUS", v: "ACTIVE ✓", ok: true },
              { k: "BALANCE", v: `$${(h % 1800) + 150}`, ok: true },
              { k: "AVS", v: "MATCH", ok: true },
              { k: "RISK", v: "LOW", ok: true },
            ]
          : kind === "address"
            ? [
                { k: "NAME", v: "MATCH ✓", ok: true },
                { k: "CITY", v: ["RIYADH", "DUBAI", "AUSTIN", "MOSCOW", "BERLIN"][h % 5], ok: true },
                { k: "AVS", v: "MATCH", ok: true },
                { k: "RISK", v: "LOW", ok: true },
              ]
            : [
                { k: "FORMAT", v: "VALID ✓", ok: true },
                { k: "VERIFIED", v: "YES", ok: true },
                { k: "AGE", v: `${(h % 9) + 1}D`, ok: true },
                { k: "RISK", v: "LOW", ok: true },
              ],
      );
      setBusy(false);
    };
    if (prefersReducedMotion()) finish();
    else setTimeout(finish, 900);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3 border border-line bg-abyss/60 p-4">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center border border-acid/40 bg-panel text-acid">
          <Icon name={cfg.kind === "card" ? "card" : cfg.kind === "address" ? "link" : "code"} size={20} />
        </div>
        <div>
          <div className="text-sm font-bold">{pick(lang, cfg.name)}</div>
          <p className="mt-0.5 text-xs text-mute">{pick(lang, cfg.desc)}</p>
        </div>
      </div>

      <label className="mono-label block">{pick(lang, cfg.fieldLabel)}</label>
      <input
        className="inp font-mono"
        dir="ltr"
        value={val}
        onChange={(e) => setVal(e.target.value)}
        placeholder={cfg.fieldPh}
        onKeyDown={(e) => e.key === "Enter" && run()}
      />
      {warn && <p className="font-mono text-[10px] text-blood">! {t("chk.empty")}</p>}
      <button onClick={run} disabled={busy} className="btn-acid w-full py-3 disabled:opacity-50">
        <Icon name="search" size={14} />
        {busy ? t("chk.running") : t("chk.run")}
      </button>

      {res && (
        <div className="animate-fade-up border border-acid/30 bg-abyss/60">
          <div className="mono-label border-b border-line px-4 py-2">SCAN :: RESULT</div>
          <div className="divide-y divide-line/60">
            {res.map((r) => (
              <div key={r.k} className="flex items-center justify-between px-4 py-2.5 font-mono text-xs">
                <span className="tracking-widest text-mute">{r.k}</span>
                <span className={r.ok ? "text-acid" : "text-blood"} dir="ltr">{r.v}</span>
              </div>
            ))}
          </div>
          <div className="flex items-center gap-2 border-t border-line px-4 py-2.5 font-mono text-[10px] text-amber">
            <Icon name="warn" size={12} />
            {t("chk.demo")}
          </div>
        </div>
      )}
    </div>
  );
}

/* صندوق الأفكار */
function IdeasBlock() {
  const t = useT();
  const [name, setName] = useState("");
  const [text, setText] = useState("");
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!text.trim() || busy) return;
    setBusy(true);
    try {
      await api("/api/opinions", { method: "POST", body: JSON.stringify({ name: name.trim() || "—", kind: "idea", text: text.trim() }) });
      setSent(true);
    } finally {
      setBusy(false);
    }
  };

  if (sent)
    return (
      <div className="flex flex-col items-center gap-3 border border-acid/40 bg-acid/5 p-10 text-center">
        <Icon name="check" size={34} className="text-acid" />
        <p className="text-sm font-bold">{t("idea.sent")}</p>
      </div>
    );

  return (
    <div className="space-y-3">
      <label className="mono-label block">{t("form.name")}</label>
      <input className="inp" value={name} onChange={(e) => setName(e.target.value)} placeholder={t("ratings.name.ph")} />
      <label className="mono-label block">IDEA</label>
      <textarea className="inp min-h-[120px] resize-y" value={text} onChange={(e) => setText(e.target.value)} placeholder={t("idea.ph")} />
      <button onClick={submit} disabled={!text.trim() || busy} className="btn-acid w-full py-3 disabled:opacity-40">
        <Icon name="send" size={14} />
        {busy ? t("c.sending") : t("form.send")}
      </button>
    </div>
  );
}

/* نص وثائقي (النبذة) */
function TextBlock({ content }: { content: Extract<ContentDef, { type: "text" }> }) {
  const lang = useLang();
  const body = content.body ?? ABOUT_TEXTS[content.ref ?? "overview"];
  return (
    <div className="space-y-3">
      {pick(lang, body)
        .split("\n")
        .filter(Boolean)
        .map((p, i) => (
          <p key={i} className="text-sm leading-loose text-mute">
            {p}
          </p>
        ))}
    </div>
  );
}

/* منشور إخباري */
function PostBlock({ id }: { id: string }) {
  const lang = useLang();
  const p = NEWS_POSTS.find((x) => x.id === id);
  if (!p) return null;
  return (
    <article className="border border-line bg-abyss/60 p-4">
      <div className="flex items-center justify-between gap-2">
        <h4 className="text-sm font-bold">{pick(lang, p.title)}</h4>
        <span className="shrink-0 font-mono text-[9px] text-mute">{p.date}</span>
      </div>
      <p className="mt-2 whitespace-pre-line text-xs leading-loose text-mute">{pick(lang, p.body)}</p>
    </article>
  );
}

function FaqBlock() {
  const lang = useLang();
  const [open, setOpen] = useState<string | null>(null);
  return (
    <div className="space-y-2.5">
      {FAQS.map((f, i) => (
        <div key={f.id} className="border border-line bg-abyss/60">
          <button onClick={() => setOpen(open === f.id ? null : f.id)} className="flex w-full items-center gap-3 p-3.5 text-start">
            <span className="font-mono text-[10px] text-amber">Q{String(i + 1).padStart(2, "0")}</span>
            <span className="flex-1 text-sm font-bold">{pick(lang, f.q)}</span>
            <Icon name="chevron" size={13} className={`text-mute transition-transform ${open === f.id ? "rotate-180" : ""}`} />
          </button>
          {open === f.id && <div className="animate-fade-up border-t border-line p-3.5 text-xs leading-relaxed text-mute">{pick(lang, f.a)}</div>}
        </div>
      ))}
    </div>
  );
}

function GuideListBlock() {
  const lang = useLang();
  const [open, setOpen] = useState<string | null>(null);
  return (
    <div className="space-y-2.5">
      {GUIDE_ITEMS.map((g, i) => (
        <div key={g.id} className="border border-line bg-abyss/60">
          <button onClick={() => setOpen(open === g.id ? null : g.id)} className="flex w-full items-center gap-3 p-3.5 text-start">
            <span className="font-mono text-[10px] text-amber">{String(i + 1).padStart(2, "0")}</span>
            <span className="flex-1 text-sm font-bold">{pick(lang, g.title)}</span>
            <Icon name="chevron" size={13} className={`text-mute transition-transform ${open === g.id ? "rotate-180" : ""}`} />
          </button>
          {open === g.id && <div className="animate-fade-up border-t border-line p-3.5 text-xs leading-relaxed text-mute">{pick(lang, g.body)}</div>}
        </div>
      ))}
    </div>
  );
}

function RepliesBlock() {
  const lang = useLang();
  return (
    <div className="space-y-3">
      {REPLIES.map((r) => (
        <div key={r.id} className="flex gap-3 border border-line bg-abyss/60 p-3.5">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center border border-line2 bg-panel text-amber">
            <Icon name="send" size={14} />
          </div>
          <div className="min-w-0 flex-1">
            <div className="font-mono text-[10px] tracking-wider text-amber">@{r.name}</div>
            <p className="mt-1 text-xs leading-relaxed text-mute">{pick(lang, r.text)}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ═══════════════ موجّه المحتوى ═══════════════ */
function SectionBody({ src, onPick }: { src: BodySrc; onPick: (p: ProductRow) => void }) {
  const c = src.content;
  switch (c.type) {
    case "products":
      return <ProductsGridBlock catId={c.catId} onPick={onPick} />;
    case "comingSoon":
      return <ComingSoonBlock />;
    case "wallets":
      return <WalletsBlock />;
    case "channels":
      return <ChannelsBlock />;
    case "managers":
      return <ManagersBlock />;
    case "form":
      return <FormBlock kind={c.kind} key={c.kind} />;
    case "adminForms":
      return <AdminFormsBlock />;
    case "percentOpps":
      return <PercentOppsBlock />;
    case "ai":
      return <AiBlock />;
    case "checker":
      return <CheckerBlock kind={c.kind} key={c.kind} />;
    case "ideas":
      return <IdeasBlock />;
    case "ratings":
      return <div className="panel p-6 text-center font-mono text-xs text-mute">RATINGS :: SUPPORT HUB</div>;
    case "text":
      return <TextBlock content={c} />;
    case "post":
      return <PostBlock id={c.id} />;
    case "posts":
      return <PostsBlock items={c.items} key={c.items} />;
    case "notes":
      return <NotesBlock />;
    case "opinions":
      return <ComingSoonBlock />;
    case "drainHub":
      return <DrainHubBlock />;
    case "autonomous":
      return <AutonomousBlock />;
    case "meetings":
      return <MeetingsBlock />;
    case "guideList":
      return <GuideListBlock />;
    case "faq":
      return <FaqBlock />;
    case "replies":
      return <RepliesBlock />;
    default:
      return null;
  }
}

/* ═══════════════ درج القسم (أقسام بدون فروع) ═══════════════ */
function SectionDrawer({
  sec,
  page,
  onClose,
  onPick,
}: {
  sec: SectionDef;
  page: (typeof PAGES)[PageId];
  onClose: () => void;
  onPick: (p: ProductRow) => void;
}) {
  const t = useT();
  const lang = useLang();
  const dir = langDef(lang).dir;
  const accent = ACCENT[page.accent];

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-[60]">
      <div className="absolute inset-0 bg-[#000000b8]" onClick={onClose} />
      <aside
        className="panel animate-drawer absolute inset-y-0 end-0 flex w-[min(94vw,440px)] flex-col border-s border-line shadow-[-40px_0_80px_rgba(0,0,0,0.6)]"
        style={{ "--drawer-from": dir === "rtl" ? "-100%" : "100%" } as React.CSSProperties}
      >
        <div className={`flex items-center gap-3 border-b border-line px-4 py-3.5 ${accent.bg}`}>
          <div className={`flex h-10 w-10 items-center justify-center border ${accent.border} bg-panel ${accent.text}`}>
            <Icon name={sec.icon} size={18} />
          </div>
          <div className="min-w-0 flex-1">
            <div className="mono-label">{pick(lang, page.short)} · SEC</div>
            <h3 className="truncate text-base font-bold">
              <Decryption text={pick(lang, sec.name)} />
            </h3>
          </div>
          <button onClick={onClose} aria-label={t("c.close")} className="btn-icon h-8 w-8">
            <Icon name="close" size={15} />
          </button>
        </div>
        <div className="flex-1 overflow-auto p-4">
          <SectionBody src={sec} onPick={onPick} />
        </div>
        <div className="border-t border-line px-4 py-2.5 text-center font-mono text-[9px] tracking-[0.3em] text-mute/60">
          {page.id.toUpperCase()} :: {sec.id.toUpperCase()}
        </div>
      </aside>
    </div>
  );
}

/* ═══════════════ بطاقات ═══════════════ */
function MainCard({ s, index, onOpen }: { s: SectionDef; index: number; onOpen: () => void }) {
  const t = useT();
  const lang = useLang();
  const isLink = s.content.type === "link";
  return (
    <button onClick={onOpen} className="panel panel-hover corners group flex flex-col overflow-hidden text-start">
      <div className="grid-bg-fine flex h-20 items-center justify-center sm:h-24">
        <Icon name={s.icon} size={30} className="text-dim transition-colors group-hover:text-acid" />
      </div>
      <div className="h-[3px] w-full bg-gradient-to-l from-blood via-blood/60 to-transparent" />
      <div className="flex flex-1 flex-col p-3">
        <div className="flex items-start justify-between gap-2">
          <div className="text-sm font-bold leading-snug">{pick(lang, s.name)}</div>
          <span className="font-mono text-[10px] text-mute/60">{String(index + 1).padStart(2, "0")}</span>
        </div>
        <div className="mt-1.5 font-mono text-[9px] tracking-[0.2em] text-mute/70">
          {s.branches ? `BR::${String(s.branches.length).padStart(2, "0")}` : isLink ? "PAGE::LINK" : "DIRECT"}
        </div>
        <div className="btn-acid mt-3 w-full !py-2 text-[10px]">{isLink ? t("sup.open") : t("c.enter")}</div>
      </div>
    </button>
  );
}

function BranchCard({ b, index, onOpen }: { b: SubBranch; index: number; onOpen: () => void }) {
  const t = useT();
  const lang = useLang();
  return (
    <button onClick={onOpen} className="panel panel-hover corners group flex flex-col overflow-hidden text-start">
      <div className="grid-bg-fine flex h-20 items-center justify-center sm:h-24">
        <Icon name={b.icon} size={30} className="text-dim transition-colors group-hover:text-acid" />
      </div>
      <div className="h-[3px] w-full bg-gradient-to-l from-blood via-blood/60 to-transparent" />
      <div className="flex flex-1 flex-col p-3">
        <div className="flex items-start justify-between gap-2">
          <div className="text-sm font-bold leading-snug">{pick(lang, b.name)}</div>
          <span className="font-mono text-[10px] text-mute/60">{String(index + 1).padStart(2, "0")}</span>
        </div>
        <div className="btn-acid mt-3 w-full !py-2 text-[10px]">{t("c.enter")}</div>
      </div>
    </button>
  );
}

/* ═══════════════ صفحة القسم (أقسام ← فروع داخلية ← محتوى) ═══════════════ */
function SectionInner({ id }: { id: PageId }) {
  const t = useT();
  const lang = useLang();
  const router = useRouter();
  const sp = useSearchParams();
  const page = PAGES[id];
  const accent = ACCENT[page.accent];

  const [view, setView] = useState<{ secId: string; branchId: string | null } | null>(null);
  const [drawer, setDrawer] = useState<SectionDef | null>(null);
  const [details, setDetails] = useState(false);
  const [picked, setPicked] = useState<ProductRow | null>(null);

  useEffect(() => {
    const s = sp.get("s");
    if (!s) return;
    const sec = page.sections.find((x) => x.id === s);
    if (!sec) return;
    if (sec.branches?.length) setView({ secId: sec.id, branchId: null });
    else if (sec.content.type !== "link") setDrawer(sec);
    else router.push(sec.content.route);
  }, [sp, page, router]);

  const viewSec = view ? (page.sections.find((s) => s.id === view.secId) ?? null) : null;
  const viewBranch = viewSec && view?.branchId ? (viewSec.branches?.find((b) => b.id === view.branchId) ?? null) : null;

  const openSec = (s: SectionDef) => {
    if (s.content.type === "link") {
      router.push(s.content.route);
      return;
    }
    if (s.branches?.length) {
      setView({ secId: s.id, branchId: null });
      setDetails(false);
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    setDrawer(s);
  };

  const back = () => {
    if (viewBranch && viewSec) {
      setView({ secId: viewSec.id, branchId: null });
      window.scrollTo({ top: 0 });
      return;
    }
    if (viewSec) {
      setView(null);
      window.scrollTo({ top: 0 });
      return;
    }
    router.push("/");
  };

  const openBranch = (branchId: string) => {
    if (!viewSec) return;
    setView({ secId: viewSec.id, branchId });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <Shell>
      <div className="space-y-5 pt-4">
        {/* زر الرجوع التدريجي الثابت + الفهرس */}
        <div className="sticky top-[96px] z-10 -mx-3 border-b border-line bg-void/95 px-3 py-2 backdrop-blur-md sm:-mx-5 sm:px-5">
          <div className="flex items-center gap-2.5">
            <button onClick={back} className="btn-ghost shrink-0 px-3 py-1.5">
              <Icon name="back" size={13} className="rtl:rotate-180" />
              {viewBranch ? pick(lang, viewSec!.name) : viewSec ? pick(lang, page.short) : t("c.home")}
            </button>
            <span className="mono-label hidden sm:block">{t("mkt.index")}</span>
            {viewBranch && (
              <span className="truncate font-mono text-[10px] tracking-wider text-acid">▸ {pick(lang, viewBranch.name)}</span>
            )}
          </div>
          {viewSec && !viewBranch && viewSec.branches && (
            <div className="no-scrollbar -mx-1 mt-2 flex gap-1.5 overflow-x-auto px-1">
              {viewSec.branches.map((b) => (
                <button
                  key={b.id}
                  onClick={() => openBranch(b.id)}
                  className="shrink-0 border border-line bg-abyss/60 px-3 py-1.5 font-mono text-[10px] tracking-wider text-mute transition-colors hover:border-acid/50 hover:text-acid"
                >
                  {pick(lang, b.name)}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Hero */}
        {viewSec ? (
          <header className="panel corners relative overflow-hidden">
            <img src={page.hero} alt="" className="absolute inset-0 h-full w-full object-cover opacity-25" loading="lazy" />
            <div className="absolute inset-0 bg-gradient-to-t from-void via-void/75 to-void/30" />
            <div className="relative p-5 sm:p-8">
              <div className="mono-label mb-3 flex items-center gap-2">
                <span className={`inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full ${page.accent === "amber" ? "bg-amber" : "bg-acid"}`} />
                // {pick(lang, page.short)} · SEC
              </div>
              <h1 className="display-2 font-bold">
                <Decryption text={pick(lang, viewSec.name)} />
              </h1>
              {viewSec.desc && (
                <p className="mt-3 max-w-2xl text-sm leading-relaxed text-mute sm:text-base">{pick(lang, viewSec.desc)}</p>
              )}
              {viewSec.branches && (
                <div className="mt-4 font-mono text-[10px] tracking-[0.25em] text-mute/70">
                  {t("mkt.branches")} :: {String(viewSec.branches.length).padStart(2, "0")}
                </div>
              )}
            </div>
          </header>
        ) : (
          <header className="panel grid-bg-fine relative overflow-hidden p-5 sm:p-8">
            <div className="mono-label mb-3 flex items-center gap-2">
              <span className={`inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full ${page.accent === "amber" ? "bg-amber" : "bg-acid"}`} />
              // {pick(lang, page.short)}
            </div>
            <h1 className="display-2 font-bold">
              <Decryption text={pick(lang, page.name)} />
            </h1>
            <p className="mt-3 max-w-2xl text-sm leading-relaxed text-mute sm:text-base">{pick(lang, page.about)}</p>
            <div className="mt-4 font-mono text-[10px] tracking-[0.25em] text-mute/70">
              {t("page.sections")} :: {String(page.sections.length).padStart(2, "0")}
            </div>
          </header>
        )}

        {/* المحتوى */}
        {viewBranch && viewSec ? (
          <div key={viewBranch.id} className="animate-fade-up">
            <SectionBody src={viewBranch} onPick={setPicked} />
          </div>
        ) : viewSec && viewSec.branches ? (
          <section>
            <div className="mono-label mb-3">// {t("mkt.branches")}</div>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
              {viewSec.branches.map((b, i) => (
                <BranchCard key={b.id} b={b} index={i} onOpen={() => openBranch(b.id)} />
              ))}
            </div>
          </section>
        ) : (
          <section>
            <div className="mono-label mb-3">// {t("page.sections")}</div>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
              {page.sections.map((s, i) => (
                <MainCard key={s.id} s={s} index={i} onOpen={() => openSec(s)} />
              ))}
            </div>
          </section>
        )}

        {/* تفاصيل الأقسام / الفروع — منسدلة مع ✕ */}
        {!viewBranch && (
          <div>
            <button
              onClick={() => setDetails((v) => !v)}
              className={`btn-ghost w-full py-2.5 ${details ? "!border-acid/50 !text-acid" : ""}`}
            >
              <Icon name="book" size={13} />
              {viewSec ? t("mkt.branchDetails") : t("mkt.detailsAll")}
              <Icon name="chevron" size={12} className={details ? "rotate-180 transition-transform" : "transition-transform"} />
            </button>
            {details && (
              <div className="panel animate-fade-up mt-2">
                <div className="mono-label flex items-center justify-between border-b border-line px-4 py-2.5">
                  <span>◈ {viewSec ? t("mkt.branchDetails") : t("mkt.detailsAll")}</span>
                  <button onClick={() => setDetails(false)} className="flex items-center gap-1 text-mute hover:text-acid">
                    <Icon name="close" size={11} />
                    {t("c.close")}
                  </button>
                </div>
                <div className="divide-y divide-line">
                  {viewSec && viewSec.branches
                    ? viewSec.branches.map((b, i) => (
                        <div key={b.id} className="flex gap-3 px-4 py-3">
                          <span className="font-mono text-[10px] font-bold text-blood">{String(i + 1).padStart(2, "0")}</span>
                          <div className="min-w-0">
                            <div className="text-sm font-bold">{pick(lang, b.name)}</div>
                            <p className="mt-1 text-xs leading-relaxed text-mute">{pick(lang, b.desc)}</p>
                          </div>
                        </div>
                      ))
                    : page.sections.map((s, i) => (
                        <div key={s.id} className="flex gap-3 px-4 py-3">
                          <span className="font-mono text-[10px] font-bold text-blood">{String(i + 1).padStart(2, "0")}</span>
                          <div className="min-w-0">
                            <div className="text-sm font-bold">{pick(lang, s.name)}</div>
                            <p className="mt-1 text-xs leading-relaxed text-mute">{s.desc ? pick(lang, s.desc) : t("page.soon")}</p>
                          </div>
                        </div>
                      ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {drawer && (
        <SectionDrawer sec={drawer} page={page} onClose={() => setDrawer(null)} onPick={setPicked} />
      )}
      {picked && <ProductModal p={picked} onClose={() => setPicked(null)} />}
    </Shell>
  );
}

function SectionSkeleton() {
  return (
    <Shell>
      <div className="space-y-5 pt-4">
        <div className="panel h-48 animate-pulse-soft bg-panel2/40" />
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="panel h-52 animate-pulse-soft bg-panel2/40" />
          ))}
        </div>
      </div>
    </Shell>
  );
}

export default function SectionPage({ id }: { id: PageId }) {
  return (
    <Suspense fallback={<SectionSkeleton />}>
      <SectionInner id={id} />
    </Suspense>
  );
}
