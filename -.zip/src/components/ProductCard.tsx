"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useT, useLang, addToCart, toast, api, fmtMoney } from "@/lib/client";
import { ProductRow, pName, pDesc } from "@/lib/types";
import { Icon } from "./Icon";

/* ── شبكة المنتجات: 2/صف هاتف · 3/صف كمبيوتر ──
   بطاقة: [مصغرة] + [شريط أحمر] + [اسم + وصف] + [رصيد 🟢] + [سعران] + [3 أزرار] */
export default function ProductCard({ p, onOpen }: { p: ProductRow; onOpen: (p: ProductRow) => void }) {
  const t = useT();
  const lang = useLang();
  const router = useRouter();

  return (
    <div className="panel panel-hover corners group flex flex-col overflow-hidden">
      {/* الصورة المصغرة */}
      <div className="relative">
        {p.img ? (
          <img src={p.img} alt="" className="h-24 w-full object-cover sm:h-28" loading="lazy" />
        ) : (
          <div className="grid-bg-fine flex h-24 items-center justify-center sm:h-28">
            <Icon name="card" size={34} className="text-dim transition-colors group-hover:text-acid" />
          </div>
        )}
        {p.verified && (
          <span className="absolute top-2 start-2 inline-flex items-center gap-1 border border-acid/50 bg-void/85 px-1.5 py-0.5 font-mono text-[9px] tracking-widest text-acid">
            <Icon name="shieldCheck" size={10} />
            {t("p.verified")}
          </span>
        )}
      </div>
      {/* الشريط الأحمر النحيف */}
      <div className="h-[3px] w-full bg-gradient-to-l from-blood via-blood/60 to-transparent" />

      <div className="flex flex-1 flex-col p-3">
        <button onClick={() => onOpen(p)} className="truncate text-start text-sm font-bold hover:text-acid">
          {pName(p, lang)}
        </button>
        <p className="mt-1 line-clamp-2 text-[11px] leading-relaxed text-mute">{pDesc(p, lang)}</p>

        {/* مؤشر الرصيد */}
        {p.balanceUsd > 0 && (
          <div className="mt-2 flex items-center gap-1.5 font-mono text-[10px] text-acid">
            <span className="inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full bg-acid" />
            <span dir="ltr">{t("mkt.balance")} ${p.balanceUsd}</span>
          </div>
        )}

        {/* السعران */}
        <div className="mt-2 flex items-baseline gap-2">
          {p.oldPriceUsd > 0 && (
            <span className="font-mono text-[11px] text-blood line-through" dir="ltr">
              ${p.oldPriceUsd}
            </span>
          )}
          <span className="font-mono text-lg font-bold text-acid text-glow" dir="ltr">
            {fmtMoney(p.priceUsd)}
          </span>
        </div>

        {/* الأزرار الثلاثة */}
        <div className="mt-3 grid grid-cols-3 gap-1.5">
          <button onClick={() => onOpen(p)} className="btn-ghost !px-1 !py-2 !text-[9px]">
            {t("c.details")}
          </button>
          <button
            onClick={() => {
              addToCart(p.id);
              toast(t("p.added"));
            }}
            className="btn-ghost !px-1 !py-2 !text-[9px]"
          >
            <Icon name="cart" size={11} />
            {t("nav.cart")}
          </button>
          <button
            onClick={() => router.push(`/pay?buy=${p.id}`)}
            className="btn-acid !px-1 !py-2 !text-[9px]"
          >
            {t("p.buy")}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ── 65 — وضع التركيز (Focus & Fullscreen) ──
   يخفي كل شيء ويعرض بيانات المنتج فقط + شريط أزرار ثابت أسفل الشاشة.
   الإغلاق يعيد العميل فوراً دون فقدان تمريره. */
export function ProductModal({ p, onClose }: { p: ProductRow; onClose: () => void }) {
  const t = useT();
  const lang = useLang();
  const router = useRouter();

  useEffect(() => {
    // عدّاد المشاهدات: مرة واحدة لكل جلسة
    try {
      const seen: number[] = JSON.parse(sessionStorage.getItem("bm_viewed") || "[]");
      if (!seen.includes(p.id)) {
        seen.push(p.id);
        sessionStorage.setItem("bm_viewed", JSON.stringify(seen));
        api("/api/products", { method: "POST", body: JSON.stringify({ view: p.id }) }).catch(() => {});
      }
    } catch {
      /* noop */
    }
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [p.id, onClose]);

  return (
    <div className="fixed inset-0 z-[65] flex flex-col bg-void" role="dialog" aria-modal>
      <div className="grid-bg pointer-events-none absolute inset-0" />
      <div className="vignette pointer-events-none absolute inset-0" />
      <div className="scanlines pointer-events-none absolute inset-0 opacity-30" />

      {/* ترويسة وضع التركيز */}
      <div className="relative z-10 flex items-center justify-between border-b border-line bg-void/90 px-4 py-3">
        <span className="mono-label flex items-center gap-2">
          <span className="inline-block h-1.5 w-1.5 animate-blink rounded-full bg-blood" />
          FOCUS MODE :: {p.slug.toUpperCase()}
        </span>
        <button onClick={onClose} className="btn-icon" aria-label={t("c.close")}>
          <Icon name="close" size={16} />
        </button>
      </div>

      {/* المحتوى — قابل للتمرير */}
      <div className="relative z-10 flex-1 overflow-y-auto">
        <div className="mx-auto w-full max-w-2xl p-4 sm:p-6">
          <div className="relative overflow-hidden border border-line">
            {p.img ? (
              <img src={p.img} alt="" className="h-48 w-full object-cover sm:h-64" />
            ) : (
              <div className="grid-bg-fine flex h-48 items-center justify-center sm:h-64">
                <Icon name="card" size={76} className="text-dim" />
              </div>
            )}
            <div className="h-[3px] w-full bg-gradient-to-l from-blood via-blood/60 to-transparent" />
            {p.verified && (
              <span className="absolute top-3 start-3 inline-flex items-center gap-1.5 border border-acid/50 bg-void/85 px-2 py-1 font-mono text-[10px] tracking-widest text-acid">
                <Icon name="shieldCheck" size={12} />
                {t("p.verified")}
              </span>
            )}
          </div>

          <h2 className="mt-4 text-2xl font-bold leading-snug sm:text-3xl">{pName(p, lang)}</h2>

          {p.balanceUsd > 0 && (
            <div className="mt-2 flex items-center gap-2 font-mono text-sm text-acid">
              <span className="inline-block h-2 w-2 animate-pulse-soft rounded-full bg-acid" />
              <span dir="ltr">{t("mkt.balance")} ${p.balanceUsd}</span>
            </div>
          )}

          <div className="mt-3 flex items-baseline gap-3">
            {p.oldPriceUsd > 0 && (
              <span className="font-mono text-lg text-blood line-through" dir="ltr">
                ${p.oldPriceUsd}
              </span>
            )}
            <span className="font-mono text-4xl font-bold text-acid text-glow" dir="ltr">
              {fmtMoney(p.priceUsd)}
            </span>
          </div>

          <div className="mt-3 flex gap-5 font-mono text-xs text-mute">
            <span className="flex items-center gap-1.5">
              <Icon name="eye" size={13} /> {p.views.toLocaleString()} {t("p.views")}
            </span>
            <span className="flex items-center gap-1.5">
              <Icon name="box" size={13} /> {p.orders.toLocaleString()} {t("p.orders")}
            </span>
          </div>

          {/* صندوق التفاصيل الكاملة — مع تمرير داخلي */}
          <div className="mt-5 max-h-56 overflow-y-auto border border-line bg-abyss p-4 text-sm leading-loose text-mute">
            {pDesc(p, lang)}
            <p className="mt-3 border-t border-line/60 pt-3 font-mono text-[11px] leading-5 text-mute/80">
              {t("c.demoNote")}
            </p>
          </div>
        </div>
      </div>

      {/* شريط الأزرار الثابت — لا يختفي */}
      <div className="relative z-10 border-t border-line bg-void/95 p-3 backdrop-blur-md">
        <div className="mx-auto grid max-w-2xl grid-cols-3 gap-2">
          <button onClick={() => router.push(`/pay?buy=${p.id}`)} className="btn-primary !h-11 !px-2 !text-xs sm:!h-12 sm:!text-sm">
            {t("p.continue")}
          </button>
          <button
            onClick={() => {
              addToCart(p.id);
              toast(t("p.added"));
              onClose();
            }}
            className="btn-acid !h-11 !px-2 !text-[11px] sm:!h-12 sm:!text-xs"
          >
            <Icon name="cart" size={14} />
            <span className="hidden sm:inline">{t("nav.cart")}</span>
          </button>
          <button onClick={onClose} className="btn-ghost !h-11 !px-2 !text-[11px] sm:!h-12 sm:!text-xs">
            <Icon name="close" size={14} />
            <span className="hidden sm:inline">{t("c.close")}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
