"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  PAYMENT_COINS, PAY_LINKS, PAY_TITLE, PAY_INTRO, NETWORK_WARNING,
  ORDER_DETAILS, PAY_FEATURES, ALT_NOTE, MSG_SUPPORT, MSG_ALT, continueMessage,
  type PaymentCoin,
} from "@/lib/paymentMethods";
import { BUY_MANAGER, pick } from "@/lib/site";
import { copyText, dispatchToTelegram } from "@/lib/forumClient";
import { openExternal, useT, useLang, toast, langDef } from "@/lib/client";
import { Icon } from "./Icon";

/** ═══ صفحة طرق الدفع الرسمية — مستقلة بالكامل (بلا Shell) ═══ */
export default function PaymentMethodsPage() {
  const t = useT();
  const lang = useLang();
  const router = useRouter();
  const [open, setOpen] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const [details, setDetails] = useState(false);

  useEffect(() => {
    document.documentElement.dir = langDef(lang).dir;
    document.documentElement.lang = lang;
  }, [lang]);

  /** نسخ + فتح تيليجرام على المسؤول برسالة جاهزة */
  const contact = useCallback((msg: string) => {
    void copyText(msg);
    void dispatchToTelegram(msg, BUY_MANAGER);
    toast(t("fa.copied"));
  }, [t]);

  const copyAddress = async (coin: PaymentCoin) => {
    const text = coin.address;
    let ok = false;
    try {
      await navigator.clipboard.writeText(text);
      ok = true;
    } catch {
      // بديل للأجهزة القديمة
      try {
        const el = document.createElement("textarea");
        el.value = text;
        el.style.position = "fixed";
        el.style.opacity = "0";
        document.body.appendChild(el);
        el.select();
        ok = document.execCommand("copy");
        document.body.removeChild(el);
      } catch { /* noop */ }
    }
    if (ok) {
      setCopied(coin.id);
      toast("✅ تم نسخ العنوان");
      window.setTimeout(() => setCopied((c) => (c === coin.id ? null : c)), 3500);
    }
  };

  const selected = PAYMENT_COINS.find((c) => c.id === open) ?? PAYMENT_COINS[0];
  const close = () => router.push("/");

  return (
    <div className="min-h-screen bg-void text-fog">
      <div className="grid-bg pointer-events-none fixed inset-0" />
      <div className="vignette pointer-events-none fixed inset-0" />
      <div className="scanlines pointer-events-none fixed inset-0 opacity-30" />

      {/* ═══ 1 — الشريط العلوي المصغّر ═══ */}
      <div className="sticky top-0 z-30 border-b border-line bg-void/95 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-[1190px] items-center gap-2 px-3 sm:px-5">
          <span className="mono-label hidden sm:block">◈ PAYMENT METHODS</span>
          <div className="flex-1" />
          {/* 🎧 خدمة العملاء: نسخ رسالة + فتح تيليجرام المسؤول */}
          <button onClick={() => contact(MSG_SUPPORT)} className="btn-icon" title="خدمة العملاء" aria-label="خدمة العملاء">
            <Icon name="headset" size={17} />
          </button>
          {/* 📢 قناة الموقع */}
          <button onClick={() => openExternal(PAY_LINKS.channel)} className="btn-icon" title="قناة الموقع" aria-label="قناة الموقع">
            <Icon name="megaphone" size={17} />
          </button>
          {/* ✕ إغلاق */}
          <button onClick={close} className="btn-icon hover:!text-blood" title="إغلاق" aria-label="إغلاق">
            <Icon name="close" size={17} />
          </button>
        </div>
      </div>

      <main className="relative z-10 mx-auto w-full max-w-[900px] space-y-5 px-3 pb-24 pt-8 sm:px-5">
        {/* ═══ 2 — الترويسة ═══ */}
        <header className="text-center">
          <div className="mono-label mb-2 flex items-center justify-center gap-2 text-acid">
            <span className="inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full bg-acid" />
            SECURE · ENCRYPTED · TLS 1.3
          </div>
          <h1 className="display-1 font-mono font-bold tracking-tight">{pick(lang, PAY_TITLE)}</h1>
          <div className="panel mt-5 border-acid/30 p-4 text-start sm:p-5">
            <div className="mono-label mb-2 flex items-center gap-2 text-acid">
              <Icon name="lock" size={12} />// SYSTEM_MESSAGE
            </div>
            <p className="text-sm leading-loose text-fog/90">{pick(lang, PAY_INTRO)}</p>
          </div>
        </header>

        {/* ═══ 3 — أزرار العملات (طولي جوال / عرضي كمبيوتر) ═══ */}
        <section>
          <div className="mono-label mb-3">// اختر العملة</div>
          <div className="grid grid-cols-1 gap-2 md:grid-cols-3">
            {PAYMENT_COINS.map((coin) => {
              const active = open === coin.id;
              return (
                <button
                  key={coin.id}
                  onClick={() => setOpen(active ? null : coin.id)}
                  className={`panel panel-hover corners flex items-center gap-3 p-4 text-start transition-all ${
                    active ? "!border-acid/60 bg-acid/5 shadow-[0_0_24px_rgba(184,239,128,0.14)]" : ""
                  }`}
                >
                  <span
                    className="flex h-11 w-11 shrink-0 items-center justify-center border font-mono text-xl font-bold"
                    style={{ borderColor: coin.color, color: coin.color }}
                  >
                    {coin.badge}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm font-bold">{coin.symbol} {pick(lang, coin.name)}</span>
                    <span className="mt-0.5 block truncate font-mono text-[10px] text-mute">{pick(lang, coin.network)}</span>
                  </span>
                  <Icon name="chevron" size={14} className={`shrink-0 text-mute transition-transform ${active ? "rotate-180" : ""}`} />
                </button>
              );
            })}
          </div>

          {/* ═══ 4 — القائمة المنسدلة للشبكة والعنوان ═══ */}
          {open && (
            <div className="panel animate-fade-up mt-3 overflow-hidden border-acid/40">
              <div className="flex items-center justify-between gap-2 border-b border-line bg-panel2/40 px-4 py-3">
                <span className="mono-label flex items-center gap-2 text-acid">
                  <Icon name="link" size={12} />{pick(lang, selected.networkTag)}
                </span>
                <button onClick={() => setOpen(null)} className="flex items-center gap-1 text-mute hover:text-acid">
                  <Icon name="close" size={11} />إغلاق
                </button>
              </div>
              <div className="space-y-3 p-4">
                <div>
                  <div className="mono-label mb-1.5">اسم الشبكة</div>
                  <div className="flex items-center gap-2 border border-line bg-abyss p-3">
                    <span className="font-mono text-sm font-bold" style={{ color: selected.color }}>{selected.badge}</span>
                    <span className="text-sm">{pick(lang, selected.network)}</span>
                  </div>
                </div>
                <div>
                  <div className="mono-label mb-1.5">عنوان المحفظة (النسخ عبر الزر فقط)</div>
                  <div className="flex flex-col gap-2 sm:flex-row">
                    <code className="no-select min-w-0 flex-1 select-none break-all border border-line bg-abyss p-3 font-mono text-[12px] leading-5 text-fog/90" dir="ltr">
                      {selected.address}
                    </code>
                    <button
                      onClick={() => copyAddress(selected)}
                      className={`shrink-0 px-4 py-3 font-mono text-[11px] font-bold transition-colors ${
                        copied === selected.id
                          ? "bg-acid text-void"
                          : "border border-acid/50 bg-acid/10 text-acid hover:bg-acid/20"
                      }`}
                    >
                      {copied === selected.id ? "✔️ تم النسخ" : "📋 نسخ"}
                    </button>
                  </div>
                  {selected.note && (
                    <p className="mt-2 font-mono text-[10px] text-amber">{pick(lang, selected.note)}</p>
                  )}
                </div>
                <p className="flex items-center gap-2 border border-blood/40 bg-blood/10 p-3 text-xs font-bold text-blood">
                  <Icon name="warn" size={13} className="shrink-0" />{pick(lang, NETWORK_WARNING)}
                </p>
              </div>
            </div>
          )}
        </section>

        {/* ═══ 5 — تفاصيل إتمام الطلب والمميزات ═══ */}
        <section>
          <button
            onClick={() => setDetails((v) => !v)}
            className={`btn-ghost w-full py-3 ${details ? "!border-acid/50 !text-acid" : ""}`}
          >
            <Icon name="book" size={13} />تفاصيل إتمام الطلب
            <Icon name="chevron" size={12} className={details ? "rotate-180 transition-transform" : "transition-transform"} />
          </button>
          {details && (
            <div className="panel animate-fade-up mt-2">
              <div className="border-b border-line p-4">
                <p className="text-sm leading-loose text-fog/90">{pick(lang, ORDER_DETAILS)}</p>
              </div>
              <div className="p-4">
                <div className="mono-label mb-3 flex items-center gap-2 text-acid">
                  <Icon name="shield" size={12} />🛡️ المميزات المرفقة مع الخدمة
                </div>
                <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {PAY_FEATURES.map((f, i) => (
                    <li key={i} className="flex items-start gap-2 border border-line bg-abyss/60 p-3 text-xs leading-relaxed text-mute">
                      <Icon name="check" size={11} className="mt-0.5 shrink-0 text-acid" />{pick(lang, f)}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="border-t border-line p-3">
                <button onClick={() => setDetails(false)} className="btn-ghost w-full py-2 text-[10px]">
                  <Icon name="close" size={11} />✖ إغلاق
                </button>
              </div>
            </div>
          )}
        </section>

        {/* ═══ 6 — أزرار التواصل الذكية ═══ */}
        <section className="panel space-y-3 p-4 sm:p-5">
          <button onClick={() => contact(continueMessage(selected))} className="btn-primary w-full">
            <Icon name="send" size={16} />متابعة الشراء
          </button>
          <div className="border border-line bg-abyss/60 p-3 text-center">
            <p className="text-xs leading-relaxed text-mute">{pick(lang, ALT_NOTE)}</p>
            <button onClick={() => contact(MSG_ALT)} className="btn-acid mt-3 w-full py-2.5">
              <Icon name="chat" size={13} />الاستفسار عن طرق بديلة
            </button>
          </div>
          <button onClick={close} className="btn-ghost w-full py-2.5 text-[10px]">
            <Icon name="back" size={12} className="rtl:rotate-180" />🔙 الرجوع للموقع الرئيسي
          </button>
        </section>
      </main>
    </div>
  );
}
