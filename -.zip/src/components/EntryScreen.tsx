"use client";

import { useState } from "react";
import { LANGS, type Lang } from "@/lib/i18n";
import { SITE } from "@/lib/site";
import { useT, changeLang } from "@/lib/client";
import { Icon } from "./Icon";
import Decryption from "./Decryption";

/** شاشة اختيار اللغة: شعار + عنوان + 3 لغات + (+) + زر «ادخل للمنصة» */
export default function EntryScreen({ onEnter }: { onEnter: (l: Lang) => void }) {
  const t = useT();
  const [sel, setSel] = useState<Lang | null>(null);
  const [open, setOpen] = useState(false);
  const mains = LANGS.filter((l) => l.main);
  const extras = LANGS.filter((l) => !l.main);
  const selDef = LANGS.find((l) => l.code === sel);

  const enter = () => {
    if (!sel) return;
    changeLang(sel);
    onEnter(sel);
  };

  const flagBtn = (l: (typeof LANGS)[number]) => (
    <button
      key={l.code}
      onClick={() => setSel(l.code)}
      className={`panel panel-hover corners group flex flex-col items-center gap-2 px-3 py-5 transition-colors ${
        sel === l.code ? "!border-acid/70 bg-panel2" : ""
      }`}
    >
      <span className="text-3xl leading-none transition-transform group-hover:scale-110">{l.flag}</span>
      <span className="text-sm font-bold">{l.name}</span>
      <span
        className={`font-mono text-[9px] tracking-[0.25em] transition-opacity ${
          sel === l.code ? "text-acid opacity-100" : "opacity-0 group-hover:opacity-60"
        }`}
      >
        {sel === l.code ? "● SELECTED" : "[SELECT]"}
      </span>
    </button>
  );

  return (
    <div className="grid-bg relative min-h-screen overflow-hidden">
      <div className="vignette pointer-events-none absolute inset-0" />
      <div className="scanlines pointer-events-none absolute inset-0 opacity-50" />
      <div className="noise pointer-events-none absolute inset-0" />

      <div className="pointer-events-none absolute top-6 start-6 font-mono text-[10px] tracking-[0.3em] text-dim/60">
        [ SECURE-ENTRY // {SITE.version} ]
      </div>
      <div className="pointer-events-none absolute top-6 end-6 font-mono text-[10px] tracking-[0.3em] text-dim/60">
        [ GRID:48PX ]
      </div>

      <main className="relative z-10 mx-auto flex min-h-screen w-full max-w-3xl flex-col items-center justify-center px-5 py-16 text-center">
        {/* الشعار */}
        <div className="animate-fade-up mb-7">
          <svg viewBox="0 0 64 64" width="84" height="84" className="mx-auto drop-shadow-[0_0_24px_rgba(184,239,128,0.35)]">
            <rect width="64" height="64" fill="#0b100e" />
            <path d="M32 6 54 19v26L32 58 10 45V19L32 6Z" fill="none" stroke="#b8ef80" strokeWidth="2.5" />
            <path d="M24 20h11a7 7 0 0 1 0 14h-11V20Zm0 16h13a7 7 0 0 1 0 14H24V36Z" fill="#b8ef80" />
          </svg>
        </div>

        {/* العنوان */}
        <h1
          data-text="BLACK MART"
          className="glitch animate-fade-up font-mono text-5xl font-bold tracking-[0.12em] text-glow sm:text-6xl md:text-7xl"
          style={{ animationDelay: "0.1s", fontSize: "clamp(44px, 9vw, 84px)" }}
        >
          BLACK&nbsp;MART
        </h1>

        <p className="animate-fade-up mt-5 max-w-xl text-base font-medium leading-relaxed text-mute sm:text-lg" style={{ animationDelay: "0.25s" }}>
          <Decryption text={t("entry.tagline")} />
        </p>

        <div className="animate-fade-up mt-4 flex items-center gap-2 font-mono text-[10px] tracking-[0.22em] text-dim" style={{ animationDelay: "0.35s" }}>
          <Icon name="lock" size={12} />
          <span>{t("entry.status")}</span>
        </div>

        {/* اختيار اللغة */}
        <div className="animate-fade-up mt-10 w-full max-w-xl" style={{ animationDelay: "0.45s" }}>
          <div className="mono-label mb-4 flex items-center justify-center gap-2">
            <span className="inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full bg-acid" />
            {t("entry.choose")}
          </div>

          <div className="grid grid-cols-3 gap-3">{mains.map(flagBtn)}</div>

          {/* السهم → بقية اللغات */}
          <div className="mt-4 flex flex-col items-center">
            <button
              onClick={() => setOpen((v) => !v)}
              aria-label={t("entry.more")}
              className="btn-icon"
            >
              <Icon name="chevron" size={16} className={open ? "rotate-180 transition-transform" : "transition-transform"} />
            </button>
            <span className="mono-label mt-2">{t("entry.more")}</span>
            {open && (
              <div className="animate-fade-up mt-4 flex flex-wrap justify-center gap-2">
                {extras.map((l) => (
                  <button
                    key={l.code}
                    onClick={() => setSel(l.code)}
                    className={`panel panel-hover flex items-center gap-2 px-4 py-2.5 text-sm font-bold ${
                      sel === l.code ? "!border-acid/70" : ""
                    }`}
                  >
                    <span>{l.flag}</span>
                    <span>{l.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* زر الدخول للمنصة */}
        <div className="animate-fade-up mt-8 w-full max-w-xl" style={{ animationDelay: "0.55s" }}>
          {selDef && (
            <div className="mono-label mb-2 flex items-center justify-center gap-2 text-dim">
              <span>{t("entry.selected")}</span>
              <span className="text-sm">{selDef.flag}</span>
              <span className="font-bold text-fog">{selDef.name}</span>
            </div>
          )}
          <button
            onClick={enter}
            disabled={!sel}
            className="btn-primary w-full"
          >
            <Icon name="lock" size={16} />
            {t("entry.enter")}
          </button>
        </div>

        <div className="mono-label animate-fade-up mt-10 flex items-center gap-2" style={{ animationDelay: "0.65s" }}>
          <span className="inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full bg-acid" />
          {t("entry.tip")}
        </div>
      </main>
    </div>
  );
}
