"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { CARD_CATS, CARD_DIFF, BUY_MANAGER, pick, type CardCatDef } from "@/lib/site";
import { useT, useLang, api } from "@/lib/client";
import { ProductRow } from "@/lib/types";
import { Icon } from "./Icon";
import Shell from "./Shell";
import CardProductCard from "./CardProductCard";
import CardDetailsModal from "./CardDetailsModal";

type Tab = "all" | "injected" | "drained";
type Offer = "all" | "bundle" | "verified";

/**
 * قسم البطاقات المحقونة — التجربة العميقة:
 *
 * أول دخول  → أزرار الأقسام الفرعية (المحقونة) + منتجات NOVBV تلقائياً
 * تاب [الكل]      → شبكة الأقسام الثمانية (2×2 / 3×3)
 * تاب [المحقونة]  → أزرار [NOVBV] [PayPal] [American Express 10.1] + منتجات الفرع
 * تاب [المسحوبة]  → أزرار [Credit] [Debit] [Classic] [Platinum] [American Express] + منتجات الفرع
 *
 * جلب المنتجات: طلب واحد شامل → تصفية محلية فورية (سريع وموثوق)
 */
export default function MarketCardsPage() {
  const t = useT();
  const lang = useLang();
  const router = useRouter();

  /* أول دخول → تاب [الكل] مع شبكة الأقسام الثمانية */
  const [tab, setTab] = useState<Tab>("all");
  const [view, setView] = useState<"grid" | "products">("grid");
  const [activeCat, setActiveCat] = useState("b-novbv");
  const [diffOpen, setDiffOpen] = useState(false);
  const [offer, setOffer] = useState<Offer>("all");
  const [country, setCountry] = useState("all");
  const [ptype, setPtype] = useState("all");
  const [all, setAll] = useState<ProductRow[] | null>(null);
  const [failed, setFailed] = useState(false);
  const [picked, setPicked] = useState<ProductRow | null>(null);

  const cat: CardCatDef = CARD_CATS.find((c) => c.id === activeCat) ?? CARD_CATS[0];
  const kindCats = CARD_CATS.filter((c) => (tab === "all" ? true : c.kind === tab));

  /* طلب واحد شامل لكل منتجات السوق */
  const load = useCallback(() => {
    setFailed(false);
    setAll(null);
    api<ProductRow[]>("/api/products")
      .then((r) => setAll(r))
      .catch(() => {
        setAll([]);
        setFailed(true);
      });
  }, []);

  useEffect(load, [load]);

  const countFor = useCallback(
    (id: string) => (all ?? []).filter((p) => p.branchId === id).length,
    [all],
  );

  const branchProducts = useMemo(
    () => (all ?? []).filter((p) => p.branchId === activeCat),
    [all, activeCat],
  );

  const visibleProducts = branchProducts.filter((p) => {
    if (offer === "bundle" && !p.nameEn.toUpperCase().includes("BUNDLE")) return false;
    if (offer === "verified" && !p.verified) return false;
    if (country === "eu" || country === "uk") return false;
    if (ptype !== "all" && p.nameEn !== ptype) return false;
    return true;
  });

  const pickTab = (x: Tab) => {
    setTab(x);
    if (x === "all") {
      setView("grid");
    } else {
      const first = CARD_CATS.find((c) => c.kind === x);
      if (first) setActiveCat(first.id);
      setView("products");
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const openCat = (id: string) => {
    const c = CARD_CATS.find((x) => x.id === id);
    if (!c) return;
    setActiveCat(id);
    setTab(c.kind);
    setView("products");
    setOffer("all");
    setCountry("all");
    setPtype("all");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const back = () => {
    if (view === "products") {
      setView("grid");
      window.scrollTo({ top: 0 });
    } else {
      router.push("/market");
    }
  };

  const typeOptions =
    Array.from(new Set(branchProducts.map((p) => p.nameEn.split(" ").slice(0, 2).join(" "))))[0] ??
    "Visa / Mastercard";

  const selCls = "inp !py-2 !text-[11px] font-mono !w-full appearance-none";

  return (
    <Shell>
      <div className="space-y-4 pt-4">
        {/* الشريط الثابت: رجوع + الأسماء المختصرة الثمانية */}
        <div className="sticky top-[96px] z-10 -mx-3 border-b border-line bg-void/95 px-3 py-2 backdrop-blur-md sm:-mx-5 sm:px-5">
          <div className="flex items-center gap-2.5">
            <button onClick={back} className="btn-ghost shrink-0 px-3 py-1.5">
              <Icon name="back" size={13} className="rtl:rotate-180" />
              {view === "products" ? t(`cards.tab.${cat.kind}`) : t("cards.tab.all")}
            </button>
            <span className="mono-label hidden sm:block">{t("mkt.index")}</span>
          </div>
          {view === "products" && (
            <div className="no-scrollbar -mx-1 mt-2 flex gap-1.5 overflow-x-auto px-1">
              {CARD_CATS.map((c) => (
                <button
                  key={c.id}
                  onClick={() => openCat(c.id)}
                  title={pick(lang, c.name)}
                  className={`shrink-0 border px-3 py-1.5 font-mono text-[10px] font-bold tracking-wider transition-all ${
                    activeCat === c.id
                      ? "border-acid bg-acid text-void shadow-[0_0_16px_rgba(184,239,128,0.35)]"
                      : "border-line bg-abyss/60 text-mute hover:border-line2 hover:text-fog"
                  }`}
                  dir="ltr"
                >
                  {c.short}
                  {all && <span className="ms-1 opacity-60">[{countFor(c.id)}]</span>}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* شريط الفرق (يظهر في عرض الأقسام فقط) */}
        {view === "grid" && (
          <div className="panel px-4 py-3">
            <div className="flex flex-wrap items-center gap-3">
              <Icon name="warn" size={16} className="shrink-0 text-amber" />
              <span className="flex-1 text-sm font-bold">{t("cards.diff.title")}</span>
              <button onClick={() => setDiffOpen((v) => !v)} className="btn-ghost px-3 py-1.5 text-[10px]">
                <Icon name={diffOpen ? "eye" : "eyeOff"} size={12} />
                {diffOpen ? t("cards.diff.hide") : t("cards.diff.show")}
              </button>
            </div>
            {diffOpen && (
              <div className="animate-fade-up mt-3 grid gap-3 sm:grid-cols-2">
                <div className="border border-acid/30 bg-acid/5 p-3.5">
                  <div className="mono-label mb-1.5 text-acid">INJECTED</div>
                  <p className="text-xs leading-relaxed text-mute">{pick(lang, CARD_DIFF.injected)}</p>
                </div>
                <div className="border border-blood/30 bg-blood/5 p-3.5">
                  <div className="mono-label mb-1.5 text-blood">DRAINED</div>
                  <p className="text-xs leading-relaxed text-mute">{pick(lang, CARD_DIFF.drained)}</p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* التابات الثلاثة الرئيسية (دائمة الظهور) */}
        <div className="grid grid-cols-3 gap-1.5">
          {(["all", "injected", "drained"] as Tab[]).map((x) => {
            const cnt = x === "all" ? CARD_CATS.length : CARD_CATS.filter((c) => c.kind === x).length;
            return (
              <button
                key={x}
                onClick={() => pickTab(x)}
                className={`border px-2 py-2.5 font-mono text-[10px] font-bold tracking-wider transition-all sm:text-[11px] ${
                  tab === x
                    ? "border-acid bg-acid text-void shadow-[0_0_18px_rgba(184,239,128,0.3)]"
                    : "border-line bg-abyss/60 text-mute hover:border-line2 hover:text-fog"
                }`}
              >
                {t(`cards.tab.${x}`)}
                {all && <span className="ms-1 opacity-60">[{cnt}]</span>}
              </button>
            );
          })}
        </div>

        {/* أزرار الأقسام الفرعية — مع عدّاد المنتجات لكل فرع */}
        {view === "products" && (
          <div className="no-scrollbar -mx-1 flex gap-1.5 overflow-x-auto px-1">
            {kindCats.map((c) => (
              <button
                key={c.id}
                onClick={() => openCat(c.id)}
                className={`shrink-0 border px-3.5 py-2 font-mono text-[10px] font-bold tracking-wider transition-all ${
                  activeCat === c.id
                    ? c.kind === "injected"
                      ? "border-acid bg-acid text-void shadow-[0_0_18px_rgba(184,239,128,0.35)]"
                      : "border-blood bg-blood text-void shadow-[0_0_18px_rgba(232,123,125,0.35)]"
                    : "border-line bg-abyss/60 text-mute hover:border-line2 hover:text-fog"
                }`}
              >
                {pick(lang, c.chip)}
                {all && <span className="ms-1.5 opacity-60">[{countFor(c.id)}]</span>}
              </button>
            ))}
          </div>
        )}

        {/* أداة الفلترة */}
        {view === "products" && (
          <div className="panel p-3">
            <div className="grid grid-cols-2 items-end gap-2 sm:grid-cols-4">
              <div>
                <label className="mono-label mb-1 block">{t("cards.filter.country")}</label>
                <select className={selCls} value={country} onChange={(e) => setCountry(e.target.value)}>
                  <option value="all">{t("cards.filter.all")}</option>
                  <option value="us">United States</option>
                  <option value="eu">Europe</option>
                  <option value="uk">United Kingdom</option>
                </select>
              </div>
              <div>
                <label className="mono-label mb-1 block">{t("cards.filter.type")}</label>
                <select className={selCls} value={ptype} onChange={(e) => setPtype(e.target.value)}>
                  <option value="all">{t("cards.filter.all")}</option>
                  <option value={typeOptions}>{typeOptions}</option>
                </select>
              </div>
              <div>
                <label className="mono-label mb-1 block">{t("cards.filter.offers")}</label>
                <select className={selCls} value={offer} onChange={(e) => setOffer(e.target.value as Offer)}>
                  <option value="all">{t("cards.filter.all")}</option>
                  <option value="bundle">{t("cards.offer.bundle")}</option>
                  <option value="verified">{t("cards.offer.verified")}</option>
                </select>
              </div>
              <a href={`https://t.me/${BUY_MANAGER}`} target="_blank" rel="noreferrer" className="btn-acid !py-2.5 text-[10px]">
                <Icon name="chat" size={12} />
                {t("cards.contact")}
              </a>
            </div>
          </div>
        )}

        {/* المحتوى */}
        {view === "grid" ? (
          /* شبكة الأقسام: 2×2 هاتف / 3×3 كمبيوتر */
          <section>
            <div className="mono-label mb-3">// {t("mkt.branches")} · {String(kindCats.length).padStart(2, "0")}</div>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
              {kindCats.map((c) => (
                <button
                  key={c.id}
                  onClick={() => openCat(c.id)}
                  className="panel panel-hover corners group flex flex-col overflow-hidden text-start"
                >
                  <div className="relative h-24 overflow-hidden sm:h-32">
                    <img
                      src={c.img}
                      alt=""
                      loading="lazy"
                      decoding="async"
                      className="h-full w-full object-cover opacity-85 transition-transform duration-500 group-hover:scale-105"
                    />
                    <span className="absolute top-2 end-2 border border-line bg-void/85 px-1.5 py-0.5 font-mono text-[9px] text-mute" dir="ltr">
                      {c.short}
                    </span>
                    {all && (
                      <span className="absolute bottom-2 start-2 border border-acid/40 bg-void/85 px-1.5 py-0.5 font-mono text-[9px] text-acid" dir="ltr">
                        {countFor(c.id)} ITEMS
                      </span>
                    )}
                  </div>
                  <div className={`h-[3px] w-full ${c.kind === "injected" ? "bg-gradient-to-l from-acid via-acid/60 to-transparent" : "bg-gradient-to-l from-blood via-blood/60 to-transparent"}`} />
                  <div className="flex flex-1 flex-col p-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="text-[13px] font-bold leading-snug sm:text-sm">{pick(lang, c.name)}</div>
                      <span className={`shrink-0 border px-1.5 py-0.5 font-mono text-[8px] tracking-widest ${c.kind === "injected" ? "border-acid/40 text-acid" : "border-blood/40 text-blood"}`}>
                        {t(`cards.kind.${c.kind}`)}
                      </span>
                    </div>
                    <div className="btn-acid mt-3 w-full !py-2 text-[10px]">{t("c.enter")}</div>
                  </div>
                </button>
              ))}
            </div>
          </section>
        ) : (
          /* منتجات القسم الفرعي المختار فقط */
          <div key={activeCat} className="animate-fade-up space-y-4">
            <div className="panel flex items-center gap-3 p-3.5 sm:p-4">
              <div className="h-14 w-24 shrink-0 overflow-hidden border border-line">
                <img src={cat.productImg} alt="" loading="lazy" decoding="async" className="h-full w-full object-cover opacity-90" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="mono-label mb-0.5">{pick(lang, cat.sub)}</div>
                <h2 className="truncate text-base font-bold sm:text-lg">{pick(lang, cat.productTitle)}</h2>
                <p className="mt-0.5 line-clamp-1 text-xs text-mute sm:line-clamp-none">{pick(lang, cat.productDesc)}</p>
              </div>
              {all && (
                <span className="shrink-0 border border-acid/40 bg-acid/10 px-2 py-1 font-mono text-[10px] font-bold text-acid" dir="ltr">
                  {countFor(activeCat)} ITEMS
                </span>
              )}
            </div>

            {/* شبكة المنتجات: 1 هاتف / 2 تابلت / 3 كمبيوتر */}
            {failed ? (
              <div className="panel flex flex-col items-center gap-3 p-10 text-center">
                <Icon name="warn" size={28} className="text-amber" />
                <p className="font-mono text-xs text-mute">LOAD FAILED</p>
                <button onClick={load} className="btn-acid px-4 py-2 text-[10px]">
                  <Icon name="refresh" size={12} />
                  RETRY
                </button>
              </div>
            ) : all === null ? (
              <div className="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="panel h-[430px] animate-pulse-soft bg-panel2/40" />
                ))}
              </div>
            ) : visibleProducts.length === 0 ? (
              <div className="panel p-10 text-center font-mono text-xs text-mute">EMPTY FILTER</div>
            ) : (
              <div className="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3">
                {visibleProducts.map((p) => (
                  <CardProductCard key={p.id} p={p} cat={cat} onOpen={setPicked} />
                ))}
              </div>
            )}

            {/* AMEX Elite Access */}
            {activeCat === "b-amex-c" && (
              <div className="panel relative overflow-hidden p-5 text-center sm:p-7">
                <div className="grid-bg-fine pointer-events-none absolute inset-0" />
                <div className="relative">
                  <div className="mono-label mb-2 text-blood">ELITE ACCESS</div>
                  <h3 className="text-lg font-bold sm:text-xl">{t("cards.cta.title")}</h3>
                  <p className="mx-auto mt-2 max-w-xl text-xs leading-relaxed text-mute sm:text-sm">{t("cards.cta.text")}</p>
                  <div className="mx-auto mt-5 grid max-w-xl gap-3 sm:grid-cols-2">
                    <a
                      href="/market/transfer?b=t-amex"
                      className="red-frame flex items-center justify-center gap-2 border border-blood/80 bg-void/60 px-4 py-3.5 font-mono text-[11px] font-bold tracking-wider text-blood transition-transform hover:scale-[1.02]"
                    >
                      <Icon name="swap" size={14} />
                      {t("cards.cta.injected")}
                    </a>
                    <a
                      href="/market/accounts?b=a-amex"
                      className="red-frame flex items-center justify-center gap-2 border border-blood/80 bg-void/60 px-4 py-3.5 font-mono text-[11px] font-bold tracking-wider text-blood transition-transform hover:scale-[1.02]"
                    >
                      <Icon name="user" size={14} />
                      {t("cards.cta.borrowed")}
                    </a>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {picked && <CardDetailsModal p={picked} cat={cat} onClose={() => setPicked(null)} />}
    </Shell>
  );
}
