"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { LINKS, ROUTES } from "@/lib/site";
import {
  useT, useLang, useAuth, useCart, useWishlist, toggleWishlist, useShell,
  bumpCart, clearCart, toast, api, fmtMoney, clientId, openExternal,
} from "@/lib/client";
import { ProductRow, pName, pDesc, fmtDate } from "@/lib/types";
import { Icon } from "./Icon";
import Shell from "./Shell";
import { loadProducts } from "./SearchBar";

/** ═══ صفحة السلة المستقلة ═══ */
export default function CartPage() {
  const t = useT();
  const lang = useLang();
  const router = useRouter();
  const auth = useAuth();
  const shell = useShell();
  const cart = useCart();
  const wishlist = useWishlist();
  const [prods, setProds] = useState<ProductRow[]>([]);
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    loadProducts().then(setProds).catch(() => {});
  }, []);

  const items = Object.entries(cart)
    .map(([id, qty]) => ({ p: prods.find((x) => x.id === Number(id)), qty }))
    .filter((x): x is { p: ProductRow; qty: number } => !!x.p);
  const total = items.reduce((a, x) => a + x.p.priceUsd * x.qty, 0);
  const count = items.reduce((a, x) => a + x.qty, 0);

  const checkout = async () => {
    if (!auth) {
      toast(t("cart.loginFirst"), "warn");
      shell?.openLogin();
      return;
    }
    setBusy(true);
    try {
      await api("/api/orders", {
        method: "POST",
        body: JSON.stringify({
          owner: auth,
          items: items.map((x) => ({ productId: x.p.id, qty: x.qty })),
          client: clientId(),
        }),
      });
      const names = items.map((x) => `• ${x.p.nameAr} × ${x.qty} — ${x.p.priceUsd * x.qty}$`).join("\n");
      const msg = [
        "[🚨 طلب شراء جديد - BLACK MART]",
        "--------------------------------------",
        `💳 الخدمة المطلوبة: سلة (${count} عنصر)`,
        `💰 القيمة: ${total}$`,
        "--------------------------------------",
        "📝 نص الطلب:",
        names,
        "يرجى تزويدي بمحافظ الدفع المتاحة والتعليمات المطلوبة لإتمام المعاملة.",
        "--------------------------------------",
        "[SYSTEM_ID: AUTO_GENERATED]",
      ].join("\n");
      await api("/api/opinions", { method: "POST", body: JSON.stringify({ name: auth, kind: "service", text: msg }) }).catch(() => {});
      clearCart();
      setDone(true);
      toast(t("cart.done"));
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch {
      toast(t("login.err"), "warn");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Shell>
      <div className="space-y-5 pt-4">
        {/* الترويسة */}
        <header className="panel grid-bg-fine relative overflow-hidden p-5 sm:p-7">
          <div className="relative flex flex-wrap items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center border border-acid/40 bg-abyss text-acid">
              <Icon name="cart" size={24} />
            </div>
            <div className="min-w-0 flex-1">
              <div className="mono-label mb-1">// CART · {String(count).padStart(2, "0")} ITEMS</div>
              <h1 className="display-2 font-bold">{t("cart.title")}</h1>
            </div>
            <button onClick={() => router.push(ROUTES.pay)} className="btn-ghost px-3.5 py-2 text-[10px]">
              <Icon name="coin" size={13} />{t("nav.payments")}
            </button>
          </div>
        </header>

        {done ? (
          <div className="panel animate-fade-up flex flex-col items-center gap-4 p-10 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full border border-acid/50 bg-acid/10">
              <Icon name="check" size={30} className="text-acid" />
            </div>
            <h2 className="text-xl font-bold">{t("cart.done")}</h2>
            <p className="max-w-md text-sm leading-relaxed text-mute">{t("buy.note")}</p>
            <div className="grid w-full max-w-md gap-2 sm:grid-cols-2">
              <button onClick={() => openExternal(LINKS.manager)} className="btn-primary">
                <Icon name="plane" size={15} />{t("op.open")}
              </button>
              <button onClick={() => { setDone(false); router.push("/market"); }} className="btn-acid">
                <Icon name="bag" size={15} />{t("c.home")}
              </button>
            </div>
          </div>
        ) : items.length === 0 ? (
          <div className="panel flex flex-col items-center gap-4 p-10 text-center">
            <div className="flex h-16 w-16 items-center justify-center border border-line bg-abyss text-mute">
              <Icon name="cart" size={28} />
            </div>
            <p className="font-mono text-sm text-mute">{t("cart.empty")}</p>
            <button onClick={() => router.push("/market")} className="btn-acid">
              <Icon name="bag" size={14} />{t("c.home")}
            </button>
          </div>
        ) : (
          <>
            {/* عناصر السلة */}
            <div className="space-y-3">
              {items.map(({ p, qty }) => {
                const wished = wishlist.includes(p.id);
                return (
                  <div key={p.id} className="panel flex flex-wrap items-center gap-3 p-3 sm:p-4">
                    <div className="grid-bg-fine flex h-16 w-20 shrink-0 items-center justify-center border border-line">
                      {p.img ? (
                        <img src={p.img} alt="" loading="lazy" className="h-full w-full object-cover opacity-85" />
                      ) : (
                        <Icon name="box" size={24} className="text-dim" />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-bold">{pName(p, lang)}</div>
                      <p className="mt-0.5 line-clamp-1 text-xs text-mute">{pDesc(p, lang)}</p>
                      <div className="mt-1 font-mono text-[10px] text-acid">{fmtMoney(p.priceUsd)} × {qty}</div>
                    </div>
                    <div className="flex shrink-0 items-center gap-1.5">
                      <button onClick={() => bumpCart(p.id, -1)} className="flex h-8 w-8 items-center justify-center border border-line text-mute hover:text-fog" aria-label="-">
                        <Icon name="minus" size={12} />
                      </button>
                      <span className="w-7 text-center font-mono text-sm">{qty}</span>
                      <button onClick={() => bumpCart(p.id, 1)} className="flex h-8 w-8 items-center justify-center border border-line text-mute hover:text-fog" aria-label="+">
                        <Icon name="plus" size={12} />
                      </button>
                      <button
                        onClick={() => toggleWishlist(p.id)}
                        aria-label={t("search.wl")}
                        className={`flex h-8 w-8 items-center justify-center border ${wished ? "border-acid/60 text-acid" : "border-line text-mute hover:text-fog"}`}
                      >
                        <Icon name="heart" size={13} filled={wished} />
                      </button>
                      <button onClick={() => bumpCart(p.id, -qty)} aria-label={t("c.close")} className="flex h-8 w-8 items-center justify-center border border-line text-mute hover:text-blood">
                        <Icon name="close" size={12} />
                      </button>
                    </div>
                    <div className="w-full shrink-0 text-end font-mono text-lg font-bold text-acid sm:w-auto">
                      {fmtMoney(p.priceUsd * qty)}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* الإجمالي */}
            <div className="panel flex flex-wrap items-center justify-between gap-3 p-4">
              <div>
                <div className="mono-label">{t("cart.total")}</div>
                <div className="mt-1 font-mono text-3xl font-bold text-acid text-glow">{fmtMoney(total)}</div>
              </div>
              <div className="flex flex-wrap gap-2">
                <button onClick={clearCart} className="btn-ghost px-3 py-2.5 text-[10px]">
                  <Icon name="refresh" size={12} />{t("fh.draftClear")}
                </button>
                <button onClick={checkout} disabled={busy} className="btn-primary disabled:opacity-50">
                  <Icon name="check" size={16} />
                  {busy ? t("c.sending") : t("cart.checkout")}
                </button>
              </div>
            </div>
          </>
        )}
      </div>
    </Shell>
  );
}
