"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { PAGES, pick, type SectionDef, type L } from "@/lib/site";
import {
  SECURITY_GUIDELINES,
  IDEAS_GUIDE,
  adminMail,
  SUPPORT_RATINGS,
  ABOUT_DOCS,
  NEWS_INTRO,
  NEWS_ITEMS,
  AI_CHIPS,
  CHECK_TOOLS,
  REFERRAL_GOAL,
  buildKnowledgeBase,
  type KbEntry,
} from "@/lib/support";
import {
  stripExifData,
  logAttachment,
  copyText,
  dispatchToTelegram,
  trackHandle,
  timestamp,
  buildTrackWebFallback,
} from "@/lib/forumClient";
import { useT, useLang, toast, clientId, api } from "@/lib/client";
import { Icon } from "./Icon";
import Shell from "./Shell";
import { AdminFormsBlock } from "./SectionPage";
import { RatingsBlock, OpinionsBlock } from "./HomeBlocks";

/** الترتيب الرسمي للأقسام الثمانية */
const ORDER = [
  "sup-pay",
  "sup-complaints",
  "sup-faq",
  "sup-ai",
  "sup-guidelines",
  "sup-tools",
  "sup-about",
  "sup-news",
];
const SECTIONS: SectionDef[] = ORDER.map(
  (id) => PAGES.support.sections.find((s) => s.id === id)!,
).filter(Boolean);

const A = (s: string): L => ({ ar: s, en: s });

/** ═══ الدعم والإرشادات — 8 أقسام، عزل تفاعلي، SPA ═══ */
export default function SupportHub() {
  const t = useT();
  const lang = useLang();
  const router = useRouter();
  const [active, setActive] = useState<string | null>(null);

  /* رابط عميق ?s=... (من البحث الذكي / Black Mart AI) */
  useEffect(() => {
    const s = new URLSearchParams(window.location.search).get("s");
    if (s && SECTIONS.some((x) => x.id === s)) setActive(s);
  }, []);

  const open = (id: string) => {
    // 01 — رابط توجيه بحت لصفحة طرق الدفع الأصلية دون أي تعديل
    if (id === "sup-pay") {
      router.push("/pay");
      return;
    }
    setActive(id);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const back = () => {
    setActive(null);
    router.replace("/support");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const sec = active ? SECTIONS.find((s) => s.id === active) : undefined;

  return (
    <Shell>
      <div className="space-y-4 pt-4">
        {/* ═══ Header ثابت ═══ */}
        <div className="sticky top-[96px] z-20 -mx-3 border-b border-line bg-void/95 px-3 py-2 backdrop-blur-md sm:-mx-5 sm:px-5">
          <div className="flex items-center gap-2.5">
            <button onClick={back} className="btn-ghost shrink-0 px-3 py-1.5 text-[9px]">
              <Icon name="back" size={11} className="rtl:rotate-180" />
              🔙 {t("sup.back")}
            </button>
            <span className="mono-label hidden sm:block">{t("sup.isolate")} :: SUPPORT</span>
            <span className="ms-auto font-mono text-[9px] tracking-widest text-amber">
              {sec ? sec.id.toUpperCase() : `08 SECTIONS`}
            </span>
          </div>
          {active && (
            <div className="no-scrollbar -mx-1 mt-2 flex gap-1.5 overflow-x-auto px-1">
              {SECTIONS.map((s) => (
                <button
                  key={s.id}
                  onClick={() => open(s.id)}
                  className={`shrink-0 border px-3 py-1.5 font-mono text-[10px] font-bold tracking-wider transition-all ${
                    active === s.id
                      ? "border-amber bg-amber text-void shadow-[0_0_16px_rgba(232,178,112,0.3)]"
                      : "border-line bg-abyss/60 text-mute hover:text-fog"
                  }`}
                >
                  {pick(lang, s.name).length > 16
                    ? pick(lang, s.name).slice(0, 14)
                    : pick(lang, s.name)}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* ═══ شبكة الأقسام: 2×2 هاتف / 3×3 كمبيوتر ═══ */}
        {!sec && (
          <section>
            <div className="mono-label mb-3">// {t("sup.sections")} · 08</div>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
              {SECTIONS.map((s, i) => (
                <button
                  key={s.id}
                  onClick={() => open(s.id)}
                  className="panel panel-hover corners group flex flex-col overflow-hidden text-start"
                >
                  <div className="grid-bg-fine flex h-20 items-center justify-center sm:h-24">
                    <Icon name={s.icon} size={28} className="text-dim transition-colors group-hover:text-amber" />
                  </div>
                  <div className="h-[3px] w-full bg-gradient-to-l from-blood via-blood/60 to-transparent" />
                  <div className="flex flex-1 flex-col p-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="text-[13px] font-bold leading-snug sm:text-sm">{pick(lang, s.name)}</div>
                      <span className="shrink-0 font-mono text-[9px] text-mute/60">0{i + 1}</span>
                    </div>
                    <p className="mt-1 line-clamp-2 text-[10px] leading-relaxed text-mute sm:text-[11px]">
                      {s.desc ? pick(lang, s.desc) : ""}
                    </p>
                    <div className="btn-acid mt-3 w-full !py-2 text-[10px]">
                      {s.id === "sup-pay" ? t("c.open") : t("c.enter")}
                    </div>
                  </div>
                </button>
              ))}
            </div>

            {/* 📊 التقييمات + 💬 الآراء — تحت الأقسام حصراً، داخل قسم الدعم فقط */}
            <div className="mt-6 grid gap-4 lg:grid-cols-2">
              <RatingsBlock />
              <OpinionsBlock />
            </div>
          </section>
        )}

        {/* ═══ محتوى القسم (عزل كامل) ═══ */}
        {sec && (
          <div key={sec.id} className="animate-fade-up space-y-4">
            <header className="panel relative overflow-hidden p-5 sm:p-7">
              <div className="grid-bg-fine pointer-events-none absolute inset-0 opacity-60" />
              <div className="relative">
                <div className="mono-label mb-2 flex items-center gap-2 text-amber">
                  <span className="inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full bg-amber" />
                  {String(ORDER.indexOf(sec.id) + 1).padStart(2, "0")} / {sec.id.toUpperCase()}
                </div>
                <h1 className="display-2 font-bold">
                  {sec.id === "sup-guidelines" ? t("sup.security") : pick(lang, sec.name)}
                </h1>
                <p className="mt-2 max-w-2xl text-sm leading-relaxed text-mute">
                  {sec.id === "sup-guidelines"
                    ? "مجموعة الإرشادات والتوصيات الأمنية لحماية حساباتك ومعاملاتك الرقمية لضمان أعلى مستويات الأمان والسرية."
                    : sDesc(sec)}
                </p>
              </div>
            </header>

            {sec.id === "sup-complaints" && <AdminFormsBlock />}
            {sec.id === "sup-faq" && <FaqBlock />}
            {sec.id === "sup-ai" && <AiBlock />}
            {sec.id === "sup-guidelines" && <SecurityBlock />}
            {sec.id === "sup-tools" && <ToolsBlock />}
            {sec.id === "sup-about" && <AboutBlock />}
            {sec.id === "sup-news" && <NewsBlock />}
          </div>
        )}
      </div>

      {/* زر رجوع عائم */}
      {active && (
        <button
          onClick={back}
          title={t("sup.back")}
          aria-label={t("sup.back")}
          className="glass glass-hover fixed bottom-16 start-4 z-40 flex h-11 w-11 items-center justify-center border-amber/50 text-amber"
        >
          <Icon name="back" size={18} className="rtl:rotate-180" />
        </button>
      )}
    </Shell>
  );
}

const sDesc = (s: SectionDef) => (s.desc ? pick("ar", s.desc) : "");

/* ═══════════ 03 — FAQ / قاعدة المعرفة ═══════════ */
function FaqBlock() {
  const t = useT();
  const lang = useLang();
  const kb = useMemo(() => buildKnowledgeBase(), []);
  const [open, setOpen] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const list = q.trim()
    ? kb.filter((k) => `${pick(lang, k.title)} ${pick(lang, k.details)}`.toLowerCase().includes(q.toLowerCase()))
    : kb;

  return (
    <div className="space-y-3">
      <div className="panel flex flex-wrap items-center gap-2 p-3">
        <span className="mono-label">{t("sup.kb")}</span>
        <span className="border border-acid/40 bg-acid/10 px-2 py-0.5 font-mono text-[10px] text-acid">
          {kb.length} ENTRIES
        </span>
        <span className="ms-auto font-mono text-[9px] text-mute">RAG → Black Mart AI</span>
      </div>
      <input className="inp" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("search.ph")} />
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        {list.slice(0, 60).map((k) => (
          <div key={k.id} className="border border-line bg-abyss/60">
            <button onClick={() => setOpen(open === k.id ? null : k.id)} className="flex w-full items-center gap-2.5 p-3 text-start">
              <Icon name="chat" size={13} className="shrink-0 text-dim" />
              <span className="flex-1 text-xs font-bold">{pick(lang, k.title)}</span>
              <span className="mono-label shrink-0">{pick(lang, k.group).slice(0, 10)}</span>
              <Icon name="chevron" size={11} className={`text-mute transition-transform ${open === k.id ? "rotate-180" : ""}`} />
            </button>
            {open === k.id && (
              <div className="animate-fade-up whitespace-pre-line border-t border-line p-3 text-xs leading-loose text-mute">
                {pick(lang, k.details)}
                <div className="mt-3 flex justify-end">
                  <button onClick={() => (window.location.href = k.route)} className="btn-ghost px-3 py-1.5 text-[9px]">
                    <Icon name="external" size={11} />
                    {t("c.open")}
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
      {list.length === 0 && <div className="panel p-8 text-center font-mono text-xs text-mute">{t("search.empty")}</div>}
    </div>
  );
}

/* ═══════════ 04 — Black Mart AI ═══════════ */
function AiBlock() {
  const t = useT();
  const lang = useLang();
  const router = useRouter();
  const kb = useMemo(() => buildKnowledgeBase(), []);
  const [lines, setLines] = useState<{ q?: string; a: string; action?: { target: string; label: string } }[]>([
    { a: t("sup.aiWelcome") },
  ]);
  const [input, setInput] = useState("");
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    boxRef.current?.scrollTo({ top: boxRef.current.scrollHeight });
  }, [lines]);

  const ask = (chip: (typeof AI_CHIPS)[number]) =>
    setLines((l) => [
      ...l,
      { q: pick(lang, chip.label), a: pick(lang, chip.text), action: chip.action ? { target: chip.action.target, label: pick(lang, chip.action.label) } : undefined },
    ]);

  /** Strict RAG: إجابة من قاعدة المعرفة فقط، وإلا توجيه للشكاوى */
  const freeAsk = () => {
    const query = input.trim();
    if (!query) return;
    setInput("");
    const words = query.toLowerCase().split(/\s+/).filter((w) => w.length > 2);
    const hit = kb.find((k) => {
      const hay = `${pick(lang, k.title)} ${pick(lang, k.details)}`.toLowerCase();
      return words.some((w) => hay.includes(w));
    });
    if (hit) {
      setLines((l) => [
        ...l,
        { q: query, a: `${pick(lang, hit.title)}\n\n${pick(lang, hit.details)}`, action: { target: hit.route, label: `${t("sup.aiNav")}: ${pick(lang, hit.title)}` } },
      ]);
    } else {
      setLines((l) => [
        ...l,
        { q: query, a: "هذه المعلومة غير متوفرة في قاعدة معرفة المنصة حالياً. يمكنك التواصل مع الإدارة عبر قسم الشكاوى والدعم.", action: { target: "/support?s=sup-complaints", label: "فتح الشكاوى والدعم ⚖️" } },
      ]);
    }
  };

  const chipCls = "border border-line bg-abyss/60 px-3 py-1.5 font-mono text-[10px] text-mute transition-colors hover:border-acid/50 hover:text-acid";

  return (
    <div className="space-y-4">
      <div className="panel">
        <div className="flex items-center gap-1.5 border-b border-line px-4 py-2.5">
          <span className="h-2.5 w-2.5 rounded-full bg-blood/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-amber/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-acid/70" />
          <span className="mono-label ms-3">BLACK-MART-AI :: STRICT RAG</span>
        </div>
        <div ref={boxRef} className="max-h-72 space-y-3 overflow-y-auto p-4">
          {lines.map((l, i) => (
            <div key={i}>
              {l.q && <div className="mb-1 flex items-start gap-2"><span className="font-mono text-xs text-violet">◈</span><span className="text-xs font-bold">{l.q}</span></div>}
              <div className="flex items-start gap-2 ps-4">
                <span className="font-mono text-xs text-acid">▸</span>
                <p className="whitespace-pre-line text-xs leading-relaxed text-mute">{l.a}</p>
              </div>
              {l.action && (
                <button
                  onClick={() => router.push(l.action!.target)}
                  className="btn-acid ms-8 mt-2 px-3 py-1.5 text-[9px]"
                >
                  <Icon name="external" size={11} />
                  {l.action.label}
                </button>
              )}
            </div>
          ))}
        </div>
        <div className="flex gap-2 border-t border-line p-3">
          <input
            className="inp flex-1"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && freeAsk()}
            placeholder={t("search.ph")}
          />
          <button onClick={freeAsk} className="btn-acid px-4 text-[10px]">
            <Icon name="send" size={12} />
          </button>
        </div>
      </div>

      <div>
        <div className="mono-label mb-2">📑 {t("ai.chips.q")}</div>
        <div className="flex flex-wrap gap-1.5">
          {AI_CHIPS.filter((c) => c.group === "general").map((c) => (
            <button key={c.id} onClick={() => ask(c)} className={chipCls}>{pick(lang, c.label)}</button>
          ))}
        </div>
      </div>
      <div>
        <div className="mono-label mb-2">🛍️ {t("ai.chips.nav")}</div>
        <div className="flex flex-wrap gap-1.5">
          {AI_CHIPS.filter((c) => c.group === "nav").map((c) => (
            <button key={c.id} onClick={() => ask(c)} className={`${chipCls} !border-acid/40 !text-acid`}>{pick(lang, c.label)}</button>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ═══════════ 05 — الإرشادات الأمنية ═══════════ */
function SecurityBlock() {
  const t = useT();
  const lang = useLang();
  const [tab, setTab] = useState<"rules" | "ideas" | "ratings">("rules");
  const TABS = [
    { k: "rules", l: A(`📖 ${t("sup.guidelines")}`) },
    { k: "ideas", l: A(`💡 ${t("sup.ideas")}`) },
    { k: "ratings", l: A(`⭐ ${t("sup.ratings")}`) },
  ] as const;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-3">
        {TABS.map((x) => (
          <button
            key={x.k}
            onClick={() => setTab(x.k)}
            className={`border px-3 py-3 font-mono text-[10px] font-bold transition-all ${
              tab === x.k ? "border-acid bg-acid text-void shadow-[0_0_16px_rgba(184,239,128,0.3)]" : "border-line bg-abyss/60 text-mute hover:text-fog"
            }`}
          >
            {pick(lang, x.l)}
          </button>
        ))}
      </div>
      {tab === "rules" && (
        <div className="space-y-3">
          {SECURITY_GUIDELINES.map((g, i) => (
            <div key={i} className="border border-line bg-abyss/60 p-4">
              <div className="text-sm font-bold">{pick(lang, g.title)}</div>
              <p className="mt-2 whitespace-pre-line text-xs leading-loose text-mute">{pick(lang, g.body)}</p>
            </div>
          ))}
        </div>
      )}
      {tab === "ideas" && <IdeasForm />}
      {tab === "ratings" && <RatingsPanel />}
    </div>
  );
}

/* صندوق الأفكار — بريد مخفي + مسح EXIF */
function IdeasForm() {
  const t = useT();
  const [title, setTitle] = useState("");
  const [details, setDetails] = useState("");
  const [file, setFile] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const onFile = async (f: File | null) => {
    if (!f) return;
    const clean = await stripExifData(f);
    await logAttachment(clean.log);
    setFile(clean.log.safeName);
    toast(t("fh.fileOk"));
  };

  const send = async () => {
    if (!title.trim() || !details.trim()) {
      toast(t("fh.required"), "warn");
      return;
    }
    setBusy(true);
    const body = [
      `[ BLACK MART IDEA - ${timestamp()} ]`,
      `• ${title.trim()}`,
      `• ${details.trim()}`,
      ...(file ? [`• ATTACHMENT: ${file} (EXIF STRIPPED)`] : []),
      "[SYSTEM_ID: AUTO_GENERATED]",
    ].join("\n");
    await copyText(body);
    // البريد الإداري مخفي — يُبنى لحظة الضغط فقط
    window.location.href = `mailto:${adminMail()}?subject=${encodeURIComponent(`BLACK MART IDEA · ${title.trim()}`)}&body=${encodeURIComponent(body)}`;
    toast(t("sup.ideaOk"));
    setBusy(false);
  };

  return (
    <div className="space-y-3">
      <div className="panel space-y-3 p-4">
        <div>
          <label className="mono-label mb-1.5 block">{t("sup.ideaTitle")}</label>
          <input className="inp" value={title} onChange={(e) => setTitle(e.target.value)} placeholder={t("sup.ideaTitle")} />
        </div>
        <div>
          <label className="mono-label mb-1.5 block">{t("sup.ideaDetails")}</label>
          <textarea className="inp min-h-[120px] resize-y" value={details} onChange={(e) => setDetails(e.target.value)} placeholder={t("sup.ideaDetails")} />
        </div>
        <div>
          <label className="btn-ghost inline-flex cursor-pointer px-3 py-2 text-[10px]">
            <Icon name="box" size={12} />
            📁 {t("fh.file")}
            <input type="file" className="hidden" onChange={(e) => onFile(e.target.files?.[0] ?? null)} />
          </label>
          {file && <div className="mt-2 font-mono text-[9px] text-acid">✓ {file} · {t("fh.scan.ok")}</div>}
        </div>
      </div>
      <div className="border border-acid/50 bg-acid/5 p-4 shadow-[0_0_30px_rgba(184,239,128,0.12)]">
        <div className="mono-label mb-2 flex items-center gap-2 text-acid"><Icon name="book" size={13} />{t("fh.guide")}</div>
        <p className="text-xs leading-loose text-fog/90">{pick(useLang(), IDEAS_GUIDE)}</p>
      </div>
      <button onClick={send} disabled={busy} className="btn-acid w-full py-3">
        <Icon name="send" size={14} />
        📤 {t("sup.ideaSend")}
      </button>
    </div>
  );
}

/* استطلاع الآراء — 10 تقييمات + نموذج */
function RatingsPanel() {
  const t = useT();
  const lang = useLang();
  const [stars, setStars] = useState(5);
  const [service, setService] = useState("");
  const [text, setText] = useState("");
  const [thanks, setThanks] = useState(false);
  const services = SUPPORT_RATINGS.map((r) => pick(lang, r.service));

  const submit = () => {
    if (!text.trim()) {
      toast(t("fh.required"), "warn");
      return;
    }
    setThanks(true);
    setText("");
    setService("");
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        {SUPPORT_RATINGS.map((r) => (
          <div key={r.id} className="border border-line bg-abyss/60 p-3">
            <div className="flex items-center justify-between gap-2">
              <span className="font-mono text-[10px] font-bold text-violet">@{r.name}</span>
              <span className="font-mono text-[10px] text-amber" dir="ltr">{"★".repeat(r.stars)}</span>
            </div>
            <div className="mt-1.5 text-xs font-bold">{pick(lang, r.service)}</div>
            <p className="mt-1 text-xs leading-relaxed text-mute">{pick(lang, r.text)}</p>
          </div>
        ))}
      </div>

      <div className="panel space-y-3 p-4">
        <div className="mono-label">{t("sup.rateSend")}</div>
        <div className="flex gap-1.5" dir="ltr">
          {[1, 2, 3, 4, 5].map((n) => (
            <button key={n} onClick={() => setStars(n)} className="transition-transform hover:scale-125" aria-label={`${n} stars`}>
              <Icon name="star" size={24} filled={n <= stars} className={n <= stars ? "text-amber" : "text-line2"} />
            </button>
          ))}
        </div>
        <select className="inp" value={service} onChange={(e) => setService(e.target.value)}>
          <option value="">{t("sup.rateService")}</option>
          {Array.from(new Set(services)).map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <textarea className="inp min-h-[90px] resize-y" value={text} onChange={(e) => setText(e.target.value)} placeholder={t("sup.rateText")} />
        <button onClick={submit} className="btn-acid w-full py-2.5">
          <Icon name="star" size={13} />
          {t("sup.rateSend")}
        </button>
        {thanks && (
          <div className="animate-fade-up border border-acid/40 bg-acid/5 p-3 text-center text-sm font-bold text-acid">
            {t("sup.rateThanks")}
          </div>
        )}
      </div>
    </div>
  );
}

/* ═══════════ 06 — أدوات الفحص (الإحالة) ═══════════ */
function ToolsBlock() {
  const t = useT();
  const lang = useLang();
  const [selected, setSelected] = useState<string | null>(null);
  const [count, setCount] = useState(0);
  const [maintenance, setMaintenance] = useState(false);
  const owner = useMemo(() => clientId(), []);
  const refLink = typeof window !== "undefined" ? `${window.location.origin}/support?s=sup-tools&ref=${owner}` : "";

  const refresh = useCallback(() => {
    api<{ count: number }>(`/api/referrals?owner=${encodeURIComponent(owner)}`)
      .then((r) => setCount(r.count ?? 0))
      .catch(() => {});
  }, [owner]);

  useEffect(() => {
    // تسجيل زائر فريد قادم من رابط مالك آخر (Anti-Fraud عبر unique index)
    const ref = new URLSearchParams(window.location.search).get("ref");
    if (ref && ref !== owner) {
      api("/api/referrals", { method: "POST", body: JSON.stringify({ owner: ref, visitor: owner }) }).catch(() => {});
    }
    refresh();
    const iv = window.setInterval(refresh, 8000); // تحديث لحظي
    return () => window.clearInterval(iv);
  }, [owner, refresh]);

  const pct = Math.min(100, Math.round((count / REFERRAL_GOAL) * 100));

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2 md:grid-cols-3 sm:gap-3">
        {CHECK_TOOLS.map((tool) => (
          <button
            key={tool.id}
            onClick={() => { setSelected(tool.id); setMaintenance(false); }}
            className="panel panel-hover corners group flex flex-col gap-2 p-4 text-start"
          >
            <Icon name={tool.icon} size={24} className="text-dim transition-colors group-hover:text-acid" />
            <div className="text-sm font-bold">{pick(lang, tool.name)}</div>
            <p className="text-xs text-mute">{pick(lang, tool.desc)}</p>
            <div className="btn-acid mt-2 w-full !py-2 text-[10px]">{t("c.enter")}</div>
          </button>
        ))}
      </div>

      {selected && (
        <div className="panel animate-fade-up space-y-4 p-4">
          <div className="mono-label flex items-center gap-2 text-amber">
            <Icon name="lock" size={13} />
            {t("sup.locked")} :: {pick(lang, CHECK_TOOLS.find((x) => x.id === selected)!.name)}
          </div>

          {/* شريط التقدم النيون */}
          <div>
            <div className="mb-1.5 flex items-center justify-between font-mono text-[10px]">
              <span className="text-mute">{t("sup.refCount")}</span>
              <span className="text-acid" dir="ltr">{count} / {REFERRAL_GOAL}</span>
            </div>
            <div className="h-3 w-full border border-line2/60 bg-abyss p-[2px]">
              <div className="h-full bg-acid shadow-[0_0_16px_rgba(184,239,128,0.5)] transition-[width] duration-500" style={{ width: `${pct}%` }} />
            </div>
          </div>

          <p className="flex items-start gap-2 border border-amber/30 bg-amber/5 p-3 text-xs leading-relaxed text-fog">
            <Icon name="warn" size={13} className="mt-0.5 shrink-0 text-amber" />
            {t("sup.refNeed")}
          </p>

          <div className="border border-line bg-abyss/60 p-3">
            <div className="mono-label mb-1.5">{t("sup.refTitle")}</div>
            <div className="flex items-center gap-2">
              <code className="min-w-0 flex-1 truncate font-mono text-[10px] text-acid" dir="ltr">{refLink}</code>
              <button onClick={async () => { if (await copyText(refLink)) toast(t("fh.copied")); }} className="btn-ghost px-3 py-1.5 text-[9px]">
                <Icon name="link" size={11} />
                {t("sup.refCopy")}
              </button>
            </div>
          </div>

          {count >= REFERRAL_GOAL && (
            <button onClick={() => setMaintenance(true)} className="btn-acid w-full py-3">
              <Icon name="lock" size={14} />
              🔓 {t("sup.toolsIntro")}
            </button>
          )}
        </div>
      )}

      {maintenance && (
        <div className="fixed inset-0 z-[65] flex items-center justify-center p-4" role="dialog" aria-modal>
          <div className="absolute inset-0 bg-void/90 backdrop-blur-sm" onClick={() => setMaintenance(false)} />
          <div className="red-frame animate-fade-up relative w-full max-w-md border border-blood/80 bg-abyss p-6 text-center">
            <Icon name="warn" size={38} className="mx-auto text-blood" />
            <h3 className="mt-4 text-lg font-bold text-blood">⚠️ {t("sup.maintenance")}</h3>
            <p className="mt-3 text-xs leading-relaxed text-mute">
              تم فتح القفل بنجاح بعد اكتمال {REFERRAL_GOAL} زائراً فريداً. يتم تحديث خوارزميات الفحص لضمان الأمان.
            </p>
            <button onClick={() => setMaintenance(false)} className="btn-ghost mt-5 px-5 py-2 text-[10px]">
              <Icon name="close" size={12} />
              {t("c.close")}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ═══════════ 07 — النبذة ═══════════ */
function AboutBlock() {
  const lang = useLang();
  const [open, setOpen] = useState("overview");
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-3">
        {ABOUT_DOCS.map((d) => (
          <button
            key={d.id}
            onClick={() => setOpen(d.id)}
            className={`border px-3 py-3 font-mono text-[10px] font-bold transition-all ${
              open === d.id ? "border-acid bg-acid text-void" : "border-line bg-abyss/60 text-mute hover:text-fog"
            }`}
          >
            {pick(lang, d.title)}
          </button>
        ))}
      </div>
      {ABOUT_DOCS.filter((d) => d.id === open).map((d) => (
        <div key={d.id} className="animate-fade-up whitespace-pre-line border border-line bg-abyss/60 p-4 text-xs leading-loose text-mute sm:text-[13px]">
          {pick(lang, d.body)}
        </div>
      ))}
    </div>
  );
}

/* ═══════════ 08 — الأخبار والإعلانات ═══════════ */
function NewsBlock() {
  const t = useT();
  const lang = useLang();
  const [open, setOpen] = useState<string | null>(null);

  const cta = (item: (typeof NEWS_ITEMS)[number]) => {
    if (!item.cta) return null;
    if (item.cta.kind === "tg") {
      return (
        <div className="mt-4 border-t border-line pt-4">
          <button
            onClick={() => { void dispatchToTelegram(item.cta!.message ?? "", trackHandle()); toast(t("fa.copied")); }}
            className="btn-primary w-full"
          >
            <Icon name="plane" size={15} />
            {pick(lang, item.cta.label)}
          </button>
          {item.cta.handleLabel && (
            <div className="mt-2 text-center font-mono text-[10px] tracking-widest text-acid" dir="ltr">
              {item.cta.handleLabel}
            </div>
          )}
        </div>
      );
    }
    return (
      <div className="mt-4 border-t border-line pt-4">
        <button
          onClick={() => { if (item.cta?.url) window.open(item.cta.url, "_blank", "noreferrer"); }}
          className="btn-primary w-full"
        >
          <Icon name="external" size={15} />
          {pick(lang, item.cta.label)}
        </button>
      </div>
    );
  };

  return (
    <div className="space-y-3">
      <div className="border border-acid/50 bg-acid/5 p-4 shadow-[0_0_30px_rgba(184,239,128,0.12)]">
        <div className="mono-label mb-2 flex items-center gap-2 text-acid">
          <Icon name="megaphone" size={13} />
          {t("sup.newsIntro")}
        </div>
        <p className="whitespace-pre-line text-xs leading-loose text-fog/90">{pick(lang, NEWS_INTRO)}</p>
      </div>

      {NEWS_ITEMS.map((item) => (
        <div key={item.id} className="border border-line bg-abyss/60">
          <button
            onClick={() => setOpen(open === item.id ? null : item.id)}
            className="flex w-full items-center gap-3 p-4 text-start"
          >
            <span className="font-mono text-[10px] font-bold text-blood">[{item.code}]</span>
            <span className="flex-1 text-sm font-bold">{pick(lang, item.title)}</span>
            <Icon name="chevron" size={13} className={`text-mute transition-transform ${open === item.id ? "rotate-180" : ""}`} />
          </button>
          {open === item.id && (
            <div className="animate-fade-up border-t border-line p-4">
              <div className="mono-label mb-2 flex items-center gap-2">📢 {pick(lang, item.title)} · {timestamp()}</div>
              <div className="max-h-[460px] overflow-y-auto whitespace-pre-line text-xs leading-loose text-fog/90 sm:text-[13px]">
                {pick(lang, item.body)}
              </div>
              {cta(item)}
              <button onClick={() => setOpen(null)} className="btn-ghost mt-3 w-full py-2 text-[10px]">
                <Icon name="close" size={12} />
                ✖ {t("sup.newsClose")}
              </button>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
