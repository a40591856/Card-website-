"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { PAY_WALLET, BUY_MANAGER } from "@/lib/site";
import { useT, useLang, useAuth, api, toast, clientId } from "@/lib/client";
import { ProductRow, pName } from "@/lib/types";
import { Icon } from "./Icon";
import Shell from "./Shell";
import Decryption from "./Decryption";
import { WalletsBlock, ChannelsBlock, ManagersBlock } from "./SectionPage";
import { loadProducts } from "./SearchBar";

/* ── صفحة الدفع الآمنة المستقلة ──
   /pay?buy=ID  → شراء فوري: ملخص + USDT/BTC + تأكيد → @k22zzo
   /pay         → المحافظ + القنوات + المسؤولون */
function PayInner() {
  const t = useT();
  const lang = useLang();
  const router = useRouter();
  const sp = useSearchParams();
  const auth = useAuth();

  const buyId = sp.get("buy") ? Number(sp.get("buy")) : null;
  const [prod, setProd] = useState<ProductRow | null>(null);
  const [method, setMethod] = useState<"usdt" | "btc">("usdt");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (!buyId) return;
    loadProducts().then((rows) => setProd(rows.find((r) => r.id === buyId) ?? null)).catch(() => {});
  }, [buyId]);

  const wallet = PAY_WALLET[method];

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(wallet.address);
      toast(t("buy.copied"));
    } catch {
      /* noop */
    }
  };

  /* قالب رسالة الطلب الموحد إلى @k22zzo */
  const [copied, setCopied] = useState(false);
  const orderMessage = (p: ProductRow) => {
    const name = pName(p, lang);
    return [
      t("buy.msg.new"),
      "--------------------------------------",
      `💳 ${t("buy.msg.service")}: ${name}`,
      p.balanceUsd > 0 ? `💵 ${t("buy.msg.balance")}: ${p.balanceUsd}$` : null,
      `💰 ${t("buy.msg.value")}: ${p.priceUsd}$`,
      "--------------------------------------",
      `📝 ${t("buy.msg.text")}:`,
      t("buy.msg.body").replace("{name}", name),
      "--------------------------------------",
      "[SYSTEM_ID: AUTO_GENERATED]",
    ]
      .filter(Boolean)
      .join("\n");
  };

  const copyMessage = async (p: ProductRow) => {
    try {
      await navigator.clipboard.writeText(orderMessage(p));
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      /* noop */
    }
  };

  const confirm = async () => {
    if (!prod || busy) return;
    setBusy(true);
    try {
      await api("/api/orders", {
        method: "POST",
        body: JSON.stringify({ owner: auth ?? clientId(), items: [{ productId: prod.id, qty: 1 }] }),
      });
      setDone(true);
      window.scrollTo({ top: 0 });
    } catch {
      toast(t("login.err"), "warn");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Shell>
      <div className="space-y-6 pt-4">
        <button
          onClick={() => {
            if (buyId) {
              if (window.history.length > 1) router.back();
              else router.push("/market");
            } else {
              router.push("/");
            }
          }}
          className="btn-ghost px-3.5 py-2"
        >
          <Icon name="back" size={13} className="rtl:rotate-180" />
          {buyId ? t("mkt.index") : t("c.home")}
        </button>

        {buyId ? (
          done && prod ? (
            /* ── نجاح ─ */
            <div className="panel animate-fade-up space-y-4 p-6 sm:p-8">
              <div className="flex flex-col items-center gap-3 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full border border-acid/50 bg-acid/10">
                  <Icon name="check" size={30} className="text-acid" />
                </div>
                <h2 className="text-xl font-bold sm:text-2xl">{t("buy.sent")}</h2>
                <p className="max-w-md text-sm leading-relaxed text-mute">{t("buy.note")}</p>
              </div>

              {/* قالب الرسالة الموحد */}
              <div className="border border-line bg-abyss">
                <div className="mono-label border-b border-line px-4 py-2">ORDER MESSAGE :: @{BUY_MANAGER}</div>
                <pre className="overflow-x-auto whitespace-pre-wrap p-4 font-mono text-[11px] leading-6 text-fog/90" dir="rtl">
                  {orderMessage(prod)}
                </pre>
              </div>

              <div className="grid gap-2 sm:grid-cols-2">
                <button onClick={() => copyMessage(prod)} className="btn-acid !py-3">
                  <Icon name={copied ? "check" : "link"} size={14} />
                  {copied ? t("c.ok") : t("buy.msg.copy")}
                </button>
                <a href={`https://t.me/${BUY_MANAGER}`} target="_blank" rel="noreferrer" className="btn-primary">
                  <Icon name="plane" size={16} />
                  {t("buy.msg.chat")} <span dir="ltr">@{BUY_MANAGER}</span>
                </a>
              </div>
            </div>
          ) : prod ? (
            /* ── الدفع ── */
            <div className="panel animate-fade-up overflow-hidden">
              <div className="flex items-center gap-2 border-b border-line bg-panel2/40 px-4 py-3">
                <Icon name="lock" size={15} className="text-acid" />
                <span className="mono-label flex-1">{t("buy.title")}</span>
                <button
                  onClick={() => router.replace("/pay")}
                  className="btn-icon h-8 w-8"
                  aria-label={t("c.close")}
                >
                  <Icon name="close" size={14} />
                </button>
              </div>

              <div className="space-y-5 p-4 sm:p-6">
                {/* ملخص الطلب */}
                <div className="border border-line bg-abyss/60 p-4">
                  <div className="mono-label mb-2">{t("buy.summary")}</div>
                  <div className="flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <div className="truncate text-sm font-bold">{pName(prod, lang)}</div>
                      <div className="mt-1 font-mono text-[10px] text-mute" dir="ltr">
                        ×1 {prod.balanceUsd > 0 ? `· BAL $${prod.balanceUsd}` : ""}
                      </div>
                    </div>
                    <div className="flex shrink-0 items-baseline gap-2">
                      {prod.oldPriceUsd > 0 && (
                        <span className="font-mono text-xs text-blood line-through" dir="ltr">
                          ${prod.oldPriceUsd}
                        </span>
                      )}
                      <span className="font-mono text-2xl font-bold text-acid text-glow" dir="ltr">
                        ${prod.priceUsd}
                      </span>
                    </div>
                  </div>
                </div>

                {/* طريقة الدفع */}
                <div>
                  <div className="mono-label mb-2">{t("buy.method")}</div>
                  <div className="grid grid-cols-2 gap-2">
                    {(["usdt", "btc"] as const).map((m) => (
                      <button
                        key={m}
                        onClick={() => setMethod(m)}
                        className={`border px-4 py-3 text-start transition-all ${
                          method === m
                            ? "border-acid bg-acid/10 shadow-[0_0_20px_rgba(184,239,128,0.15)]"
                            : "border-line bg-abyss/50 hover:border-line2"
                        }`}
                      >
                        <div className={`flex items-center gap-2 text-sm font-bold ${method === m ? "text-acid" : ""}`}>
                          <Icon name="coin" size={14} />
                          {PAY_WALLET[m].name}
                        </div>
                        <div className="mt-1 font-mono text-[9px] tracking-widest text-mute">{PAY_WALLET[m].network}</div>
                      </button>
                    ))}
                  </div>
                  <div className="mono-label mt-4 mb-1.5">{t("buy.address")}</div>
                  <div className="flex items-center gap-2 border border-line bg-abyss p-3">
                    <code className="min-w-0 flex-1 break-all font-mono text-[11px] leading-5 text-acid" dir="ltr">
                      {wallet.address}
                    </code>
                    <button onClick={copy} className="btn-ghost shrink-0 px-3 py-1.5 text-[10px]">
                      <Icon name="link" size={12} />
                      {t("buy.copy")}
                    </button>
                  </div>
                </div>

                {/* مسؤول الطلب */}
                <div className="flex items-center gap-3 border border-amber/30 bg-amber/5 p-3.5">
                  <Icon name="headset" size={18} className="shrink-0 text-amber" />
                  <div className="min-w-0 flex-1">
                    <div className="mono-label">{t("buy.manager")}</div>
                    <div className="font-mono text-sm font-bold text-amber" dir="ltr">
                      @{BUY_MANAGER}
                    </div>
                  </div>
                  <a
                    href={`https://t.me/${BUY_MANAGER}`}
                    target="_blank"
                    rel="noreferrer"
                    className="btn-acid px-3.5 py-2 text-[10px]"
                  >
                    <Icon name="plane" size={12} />
                    {t("c.open")}
                  </a>
                </div>

                <p className="text-xs leading-relaxed text-mute">{t("buy.note")}</p>

                <button onClick={confirm} disabled={busy} className="btn-primary w-full">
                  <Icon name="check" size={16} />
                  {busy ? t("c.sending") : t("buy.confirm")}
                </button>
              </div>
            </div>
          ) : (
            <div className="panel p-10 text-center font-mono text-xs text-mute">LOADING…</div>
          )
        ) : (
          <>
            {/* الصفحة المستقلة: المحافظ + القنوات + المسؤولون */}
            <header className="panel grid-bg-fine relative overflow-hidden p-5 sm:p-8">
              <div className="mono-label mb-3 flex items-center gap-2">
                <span className="inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full bg-acid" />
                // {t("pages.pay")}
              </div>
              <h1 className="display-2 font-bold">
                <Decryption text={t("pages.pay")} />
              </h1>
              <p className="mt-3 max-w-2xl text-sm leading-relaxed text-mute">{t("pay.note")}</p>
            </header>

            <section>
              <div className="mono-label mb-3 flex items-center gap-2">
                <Icon name="wallet" size={13} className="text-acid" />
                {t("pay.wallets")}
              </div>
              <WalletsBlock />
            </section>

            <section>
              <div className="mono-label mb-3 flex items-center gap-2">
                <Icon name="megaphone" size={13} className="text-acid" />
                {t("pages.forum.short")} · {t("pages.pay.short")}
              </div>
              <ChannelsBlock />
            </section>

            <section>
              <div className="mono-label mb-3 flex items-center gap-2">
                <Icon name="headset" size={13} className="text-acid" />
                {t("replies.title")} · TG
              </div>
              <ManagersBlock />
            </section>
          </>
        )}
      </div>
    </Shell>
  );
}

function PaySkeleton() {
  return (
    <Shell>
      <div className="space-y-5 pt-4">
        <div className="panel h-40 animate-pulse-soft bg-panel2/40" />
        <div className="panel h-96 animate-pulse-soft bg-panel2/40" />
      </div>
    </Shell>
  );
}

export default function PayPage() {
  return (
    <Suspense fallback={<PaySkeleton />}>
      <PayInner />
    </Suspense>
  );
}
