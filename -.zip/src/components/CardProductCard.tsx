"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useT, useLang, addToCart, toast, fmtMoney } from "@/lib/client";
import { ProductRow, pName, pDesc } from "@/lib/types";
import { pick, type CardCatDef } from "@/lib/site";
import { Icon } from "./Icon";

/**
 * بطاقة منتج السوق — أبعاد موحدة والأزرار ثابتة أسفل البطاقة.
 * [شراء الآن] | [- 1 +] سلة | [ℹ️ التفاصيل]
 */
export default function CardProductCard({
  p,
  cat,
  onOpen,
}: {
  p: ProductRow;
  cat: CardCatDef;
  onOpen: (p: ProductRow) => void;
}) {
  const t = useT();
  const lang = useLang();
  const router = useRouter();
  const [qty, setQty] = useState(1);
  const [imgErr, setImgErr] = useState(false);

  const bar = cat.kind === "injected" ? "bg-gradient-to-l from-acid via-acid/60 to-transparent" : "bg-gradient-to-l from-blood via-blood/60 to-transparent";

  const add = () => {
    addToCart(p.id, qty);
    toast(t("p.added"));
    setQty(1);
  };

  return (
    <div className="panel panel-hover corners group flex h-[420px] flex-col overflow-hidden sm:h-[440px]">
      {/* الصورة */}
      <div className="relative h-20 shrink-0 overflow-hidden sm:h-28">
        {!imgErr ? (
          <img
            src={p.img || cat.productImg}
            alt=""
            loading="lazy"
            decoding="async"
            onError={() => setImgErr(true)}
            className="h-full w-full object-cover opacity-90 transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="grid-bg-fine flex h-full w-full items-center justify-center">
            <Icon name="card" size={36} className="text-dim" />
          </div>
        )}
        {p.verified && (
          <span className="absolute top-2 start-2 inline-flex items-center gap-1 border border-acid/50 bg-void/85 px-1.5 py-0.5 font-mono text-[9px] tracking-widest text-acid">
            <Icon name="shieldCheck" size={10} />
            {t("p.verified")}
          </span>
        )}
      </div>
      {/* الشريط النحيف: أخضر للمحقونة / أحمر للمسحوبة */}
      <div className={`h-[3px] w-full shrink-0 ${bar}`} />

      <div className="flex min-h-0 flex-1 flex-col p-2.5 sm:p-3">
        <div className="mono-label mb-1 truncate text-[8px] sm:text-[10px]">{pick(lang, cat.sub)}</div>
        <h3 className="line-clamp-2 text-[11px] font-bold leading-snug sm:text-[13px]">{pName(p, lang)}</h3>
        <p className="mt-1 line-clamp-2 text-[10px] leading-relaxed text-mute sm:line-clamp-3 sm:text-[11px]">{pDesc(p, lang)}</p>

        {p.balanceUsd > 0 && (
          <div className="mt-2 flex items-center gap-1.5 font-mono text-[10px] text-acid">
            <span className="inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full bg-acid" />
            <span dir="ltr">{t("mkt.balance")} ${p.balanceUsd.toLocaleString()}</span>
          </div>
        )}

        {/* الأزرار — ثابتة أسفل البطاقة */}
        <div className="mt-auto pt-2">
          <div className="flex items-baseline gap-2">
            {p.oldPriceUsd > 0 && (
              <span className="font-mono text-[11px] text-blood line-through" dir="ltr">
                ${p.oldPriceUsd.toLocaleString()}
              </span>
            )}
            <span className="font-mono text-base font-bold text-acid text-glow sm:text-lg" dir="ltr">
              {fmtMoney(p.priceUsd)}
            </span>
            <span className="ms-auto hidden font-mono text-[9px] text-mute sm:inline" title={t("p.views")}>
              <Icon name="eye" size={9} className="inline" /> {p.views}
            </span>
          </div>

          {/* الكمية + السلة */}
          <div className="mt-2 flex items-center gap-1.5">
            <button
              onClick={() => setQty((q) => Math.max(1, q - 1))}
              className="flex h-8 w-7 shrink-0 items-center justify-center border border-line text-mute transition-colors hover:border-line2 hover:text-fog sm:w-8"
              aria-label="-"
            >
              <Icon name="minus" size={11} />
            </button>
            <span className="w-6 shrink-0 text-center font-mono text-xs sm:text-sm" dir="ltr">{qty}</span>
            <button
              onClick={() => setQty((q) => Math.min(99, q + 1))}
              className="flex h-8 w-7 shrink-0 items-center justify-center border border-line text-mute transition-colors hover:border-line2 hover:text-fog sm:w-8"
              aria-label="+"
            >
              <Icon name="plus" size={11} />
            </button>
            <button onClick={add} className="btn-ghost h-8 flex-1 !px-1 !text-[8px] sm:!text-[9px]" title={t("nav.cart")}>
              <Icon name="cart" size={12} />
              <span className="hidden sm:inline">{t("nav.cart")}</span>
            </button>
          </div>

          {/* شراء + تفاصيل */}
          <div className="mt-1.5 flex gap-1.5">
            <button onClick={() => router.push(`/pay?buy=${p.id}`)} className="btn-acid h-8 flex-1 !px-1 !text-[9px] sm:!text-[10px]">
              {t("p.buy")}
            </button>
            <button
              onClick={() => onOpen(p)}
              className="btn-ghost h-8 w-9 shrink-0 !px-0 sm:w-11"
              title={t("c.details")}
              aria-label={t("c.details")}
            >
              <Icon name="search" size={12} />
              <span className="hidden font-mono text-[8px] sm:inline">i</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
