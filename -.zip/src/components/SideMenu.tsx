"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { SITE, type L } from "@/lib/site";
import { useT, useLang, useAuth, setAuth, shareSite, toast } from "@/lib/client";
import { loadSession, clearSession, getPoints } from "@/lib/membership";
import { Icon } from "./Icon";

/* ── عناصر القائمة المرقمة ── */
function MItem({
  num,
  icon,
  label,
  onClick,
}: {
  num: string;
  icon: string;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex w-full items-center gap-2.5 border border-line bg-abyss/50 px-3 py-2.5 text-start text-[13px] font-medium text-fog transition-colors hover:border-line2 hover:bg-panel2 hover:text-acid"
    >
      <span className="w-6 shrink-0 font-mono text-[9px] font-bold text-blood" dir="ltr">
        {num}
      </span>
      <Icon name={icon} size={15} className="shrink-0 text-dim" />
      <span className="flex-1 truncate">{label}</span>
    </button>
  );
}

function Group({ title }: { title: string }) {
  return (
    <div className="mono-label mb-2 mt-4 flex items-center gap-2 first:mt-0">
      <span className="text-dim">{title}</span>
      <span className="h-px flex-1 bg-line" />
    </div>
  );
}

/* ── الأسماء متعددة اللغات ── */
const M: Record<string, L> = {
  support: { ar: "البلاغات وحل النزاعات", en: "Disputes & Resolution", ru: "Жалобы и споры" },
  loader: { ar: "اللودر والمجتمع", en: "Loader & Community", ru: "Лодер и сообщество" },
  pay: { ar: "الدفع", en: "Payment", ru: "Оплата" },
  channels: { ar: "القنوات الرسمية", en: "Official Channels", ru: "Официальные каналы" },
  ai: { ar: "مساعد BLACK MART", en: "BLACK MART Assistant", ru: "Ассистент BLACK MART" },
  market: { ar: "السوق", en: "Market", ru: "Маркет" },
  proxy: { ar: "البروكسي والخصوصية", en: "Proxy & Privacy", ru: "Прокси и приватность" },
  work: { ar: "الأعمال والنسب", en: "Work & Percent", ru: "Работа и проценты" },
  lang: { ar: "اللغة", en: "Language", ru: "Язык" },
  share: { ar: "مشاركة", en: "Share", ru: "Поделиться" },
  update: { ar: "تحديث", en: "Refresh", ru: "Обновить" },
};

/**
 * 2 SIDEBAR — CONTROL PANEL (من الأعلى إلى الأسفل)
 * Header → User Session → SUPPORT SYSTEM → KNOWLEDGE & PAYMENTS → MARKET ACCESS → Footer
 */
export default function SideMenu({
  onClose,
  onLogin,
  onLang,
  onEntry,
}: {
  onClose: () => void;
  onLogin: () => void;
  onLang: () => void;
  onEntry: () => void;
}) {
  const t = useT();
  const lang = useLang();
  const auth = useAuth();
  const router = useRouter();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const go = (route: string) => {
    onClose();
    router.push(route);
  };

  const logout = () => {
    clearSession();
    setAuth(null);
    toast(t("menu.logout"));
    onClose();
  };
  const member = auth ? loadSession() : null;

  const pickL = (k: string) => (M[k][lang] ?? M[k].en) as string;

  return (
    <div className="fixed inset-0 z-50">
      {/* تظليل — تبقى الصفحة الرئيسية ظاهرة */}
      <div className="absolute inset-0 bg-[#000000b3] backdrop-blur-[2px]" onClick={onClose} />

      <aside className="panel animate-drawer absolute inset-y-0 start-0 flex w-[min(94vw,420px)] flex-col border-e border-line shadow-[40px_0_80px_rgba(0,0,0,0.6)]">
        {/* ══ Header: X + الشعار + CONTROL PANEL ══ */}
        <div className="relative border-b border-line px-4 py-4">
          <button onClick={onClose} className="btn-icon absolute top-3 end-3 h-8 w-8" aria-label={t("c.close")}>
            <Icon name="close" size={15} />
          </button>
          <div className="flex items-center gap-3 pe-10">
            <svg
              viewBox="0 0 64 64"
              width="42"
              height="42"
              className="shrink-0 drop-shadow-[0_0_16px_rgba(184,239,128,0.55)]"
            >
              <path d="M32 4 56 18v28L32 60 8 46V18L32 4Z" fill="none" stroke="#b8ef80" strokeWidth="4" />
              <path d="M25 20h10a7 7 0 0 1 0 14h-10V20Zm0 16h12a7 7 0 0 1 0 14H25V36Z" fill="#b8ef80" />
            </svg>
            <div className="min-w-0">
              <div className="font-mono text-sm font-bold tracking-[0.15em]">
                BLACK<span className="text-acid">MART</span>
              </div>
              <div className="mt-0.5 font-mono text-[9px] tracking-[0.35em] text-dim">CONTROL PANEL</div>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-auto px-4 py-4">
          {/* ══ قسم حساب المستخدم: صندوق التحكم بالجلسة ══ */}
          <div className="border border-line2/60 bg-abyss/70 p-3">
            <div className="mono-label mb-2 flex items-center justify-between">
              <span>{lang === "ar" ? "التحكم بالجلسة" : "SESSION CONTROL"}</span>
              <span className={auth ? "text-acid" : "text-mute"}>{auth ? "● ACTIVE" : "● OFFLINE"}</span>
            </div>
            {auth ? (
              <>
                <div className="flex items-center gap-2.5">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center border border-acid/40 bg-panel text-acid">
                    <Icon name="user" size={18} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[11px] font-bold">👤 {member?.name ?? "عضواً"}</div>
                    <div className="mt-0.5 font-mono text-[10px] tracking-wider text-acid" dir="ltr">ID {member?.id ?? auth}</div>
                    <div className="mt-0.5 font-mono text-[8px] tracking-wider text-mute">
                      ★ {getPoints(member?.id ?? auth)} PTS · VERIFIED
                    </div>
                  </div>
                  <button
                    onClick={logout}
                    title={t("menu.logout")}
                    aria-label={t("menu.logout")}
                    className="btn-icon h-8 w-8 !text-blood hover:!border-blood/50"
                  >
                    <Icon name="logout" size={14} />
                  </button>
                </div>
                <div className="mt-2.5 grid grid-cols-2 gap-1.5">
                  <button onClick={() => go("/member")} className="btn-acid !py-1.5 text-[9px]">
                    {t("menu.openPage")}
                  </button>
                  <button onClick={() => go("/member")} className="btn-ghost !py-1.5 text-[9px]">
                    <Icon name="box" size={11} />
                    {t("menu.orders")}
                  </button>
                </div>
              </>
            ) : (
              <>
                <button
                  onClick={() => {
                    onClose();
                    onLogin();
                  }}
                  className="btn-acid w-full !py-3"
                >
                  <Icon name="lock" size={14} />
                  <span className="flex flex-col items-center leading-tight">
                    <span className="text-[11px] font-bold">{t("menu.login")}</span>
                    <span className="mt-0.5 font-mono text-[8px] tracking-[0.2em] opacity-80">LOCAL ALIAS SESSION</span>
                  </span>
                </button>
                <p className="mt-2 text-center font-mono text-[8px] tracking-[0.25em] text-mute/70" dir="ltr">
                  SHA-256 :: ENCRYPTED ALIAS
                </p>
              </>
            )}
          </div>

          {/* ══ نظام الدعم ══ */}
          <Group title="SUPPORT SYSTEM" />
          <div className="space-y-1.5">
            <MItem num="01" icon="shield" label={pickL("support")} onClick={() => go("/disputes")} />
            <MItem num="02" icon="chat" label={pickL("loader")} onClick={() => go("/forum")} />
          </div>

          {/* ══ المعرفة والمدفوعات ══ */}
          <Group title="KNOWLEDGE & PAYMENTS" />
          <div className="space-y-1.5">
            <MItem num="03" icon="coin" label={pickL("pay")} onClick={() => go("/pay")} />
            <MItem num="04" icon="megaphone" label={pickL("channels")} onClick={() => go("/channels")} />
            <MItem num="AI" icon="code" label={pickL("ai")} onClick={() => go("/support?s=sup-ai")} />
          </div>

          {/* ══ الوصول للسوق ══ */}
          <Group title="MARKET ACCESS" />
          <div className="space-y-1.5">
            <MItem num="05" icon="bag" label={pickL("market")} onClick={() => go("/market")} />
            <MItem num="06" icon="shield" label={pickL("proxy")} onClick={() => go("/market/proxy")} />
            <MItem num="07" icon="star" label={pickL("work")} onClick={() => go("/support?s=sup-percent")} />
          </div>

          {/* أدوات سريعة */}
          <div className="mt-4 grid grid-cols-3 gap-1.5">
            <button onClick={() => { onClose(); onLang(); }} className="btn-ghost !px-1 !py-2 !text-[9px]">
              <Icon name="globe" size={11} />
              {pickL("lang")}
            </button>
            <button onClick={() => shareSite(t)} className="btn-ghost !px-1 !py-2 !text-[9px]">
              <Icon name="share" size={11} />
              {pickL("share")}
            </button>
            <button onClick={() => { onClose(); onEntry(); }} className="btn-ghost !px-1 !py-2 !text-[9px]">
              <Icon name="refresh" size={11} />
              {pickL("update")}
            </button>
          </div>
        </div>

        {/* ══ Footer: الحالة + تفاصيل الجلسة ══ */}
        <div className="border-t border-line px-4 py-3">
          <div className="flex items-center gap-2 font-mono text-[9px] tracking-[0.25em] text-dim">
            <span className="inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full bg-acid" />
            ONLINE
          </div>
          <div className="mt-1.5 font-mono text-[8px] tracking-[0.15em] text-mute/60" dir="ltr">
            SESSION: {auth ?? "GUEST-LOCAL"} • SYS {SITE.version} • AES-256
          </div>
        </div>
      </aside>
    </div>
  );
}
