"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { marketById, pick, type MarketBranch } from "@/lib/site";
import { useT, useLang, api } from "@/lib/client";
import { ProductRow } from "@/lib/types";
import { Icon } from "./Icon";
import Shell from "./Shell";
import Decryption from "./Decryption";
import ProductCard, { ProductModal } from "./ProductCard";

type FilterTag = "all" | "injected" | "drained";

/* ── شبكة المنتجات — 2 في الصف هاتف / 3 كمبيوتر ── */
function ProductGrid({
  branchId,
  tagFilter,
  onPick,
}: {
  branchId: string;
  tagFilter: FilterTag;
  onPick: (p: ProductRow) => void;
}) {
  const [rows, setRows] = useState<ProductRow[] | null>(null);
  useEffect(() => {
    setRows(null);
    api<ProductRow[]>(`/api/products?branch=${branchId}`).then(setRows).catch(() => setRows([]));
  }, [branchId]);

  if (rows === null)
    return (
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="panel h-64 animate-pulse-soft bg-panel2/40" />
        ))}
      </div>
    );

  const filtered = tagFilter === "all" ? rows : rows.filter((p) => p.tag === tagFilter);
  if (filtered.length === 0)
    return (
      <div className="panel p-8 text-center font-mono text-xs text-mute">
        PHASE-2 :: LOADING CONTENT
      </div>
    );

  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
      {filtered.map((p) => (
        <ProductCard key={p.id} p={p} onOpen={onPick} />
      ))}
    </div>
  );
}

/* ── بطاقة فرع ── */
function BranchCard({ b, onOpen }: { b: MarketBranch; onOpen: () => void }) {
  const t = useT();
  const lang = useLang();
  return (
    <button onClick={onOpen} className="panel panel-hover corners group flex flex-col overflow-hidden text-start">
      <div className="grid-bg-fine flex h-20 items-center justify-center sm:h-24">
        <Icon name={b.icon} size={30} className="text-dim transition-colors group-hover:text-acid" />
      </div>
      <div className="h-[3px] w-full bg-gradient-to-l from-blood via-blood/60 to-transparent" />
      <div className="flex flex-1 flex-col p-3">
        <div className="text-sm font-bold leading-snug">{pick(lang, b.name)}</div>
        <div className="btn-acid mt-3 w-full !py-2 text-[10px]">{t("c.enter")}</div>
      </div>
    </button>
  );
}

/* ── مستوى ثانٍ + ثالث ── */
function MarketSectionInner({ sectionId }: { sectionId: string }) {
  const t = useT();
  const lang = useLang();
  const router = useRouter();
  const sp = useSearchParams();
  const sec = marketById(sectionId);
  const [branch, setBranch] = useState<string | null>(null);
  const [filter, setFilter] = useState<FilterTag>("all");
  const [bDetails, setBDetails] = useState(false);
  const [picked, setPicked] = useState<ProductRow | null>(null);

  useEffect(() => {
    const b = sp.get("b");
    if (sec && b && sec.branches.some((x) => x.id === b)) setBranch(b);
    else setBranch(null);
  }, [sp, sec]);

  if (!sec)
    return (
      <Shell>
        <div className="panel p-10 text-center font-mono text-sm text-mute">404 :: SECTION NOT FOUND</div>
      </Shell>
    );

  const hasBranches = sec.branches.length > 0;
  const activeBranch = sec.branches.find((b) => b.id === branch) ?? null;

  /* الرجوع التدريجي: فرع ← قسم ← السوق */
  const back = () => {
    if (branch) {
      setBranch(null);
      window.scrollTo({ top: 0 });
      return;
    }
    router.push("/market");
  };

  const openBranch = (id: string) => {
    setBranch(id);
    setFilter("all");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <Shell>
      <div className="space-y-5 pt-4">
        {/* زر الرجوع التدريجي الثابت + فهرس الفروع */}
        <div className="sticky top-[96px] z-10 -mx-3 border-b border-line bg-void/95 px-3 py-2 backdrop-blur-md sm:-mx-5 sm:px-5">
          <div className="flex items-center gap-2.5">
            <button onClick={back} className="btn-ghost shrink-0 px-3 py-1.5">
              <Icon name="back" size={13} className="rtl:rotate-180" />
              {branch ? pick(lang, sec.name) : "Market"}
            </button>
            <span className="mono-label hidden sm:block">{t("mkt.index")}</span>
            {activeBranch && (
              <span className="truncate font-mono text-[10px] tracking-wider text-acid">
                ▸ {pick(lang, activeBranch.name)}
              </span>
            )}
          </div>
          {hasBranches && (
            <div className="no-scrollbar -mx-1 mt-2 flex gap-1.5 overflow-x-auto px-1">
              {sec.branches.map((b) => (
                <button
                  key={b.id}
                  onClick={() => (branch === b.id ? setBranch(null) : openBranch(b.id))}
                  className={`shrink-0 border px-3 py-1.5 font-mono text-[10px] tracking-wider transition-all ${
                    branch === b.id
                      ? "border-acid bg-acid font-bold text-void shadow-[0_0_16px_rgba(184,239,128,0.35)]"
                      : "border-line bg-abyss/60 text-mute hover:border-line2 hover:text-fog"
                  }`}
                >
                  {pick(lang, b.name)}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Hero — حسب العمق */}
        {!branch ? (
          <header className="panel corners relative overflow-hidden">
            <img src={sec.thumb} alt="" className="absolute inset-0 h-full w-full object-cover opacity-25" />
            <div className="absolute inset-0 bg-gradient-to-t from-void via-void/75 to-void/30" />
            <div className="relative p-5 sm:p-8">
              <div className="mono-label mb-3 flex items-center gap-2">
                <span className="inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full bg-blood" />
                // MARKET · SEC {sec.code}
              </div>
              <h1 className="display-2 font-bold">
                <Decryption text={pick(lang, sec.name)} />
              </h1>
              <p className="mt-3 max-w-2xl text-sm leading-relaxed text-mute sm:text-base">{pick(lang, sec.desc)}</p>
              <div className="mt-4 font-mono text-[10px] tracking-[0.25em] text-mute/70">
                {t("mkt.branches")} :: {String(sec.branches.length).padStart(2, "0")}
              </div>
            </div>
          </header>
        ) : (
          <header className="panel flex items-center gap-3 p-4">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center border border-line bg-abyss text-acid">
              <Icon name={activeBranch!.icon} size={20} />
            </div>
            <div className="min-w-0 flex-1">
              <div className="mono-label">{pick(lang, sec.name)} · BRANCH</div>
              <h1 className="truncate text-lg font-bold sm:text-xl">{pick(lang, activeBranch!.name)}</h1>
              <p className="mt-1 text-xs leading-relaxed text-mute">{pick(lang, activeBranch!.desc)}</p>
            </div>
          </header>
        )}

        {/* الفلترة الثلاثية — قسم البطاقات المحقونة فقط */}
        {sec.filter && (
          <div className="flex flex-wrap items-center gap-2">
            {(["all", "injected", "drained"] as FilterTag[]).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`flex items-center gap-1.5 border px-3.5 py-2 font-mono text-[10px] tracking-wider transition-all ${
                  filter === f
                    ? "border-acid bg-acid/10 font-bold text-acid shadow-[0_0_16px_rgba(184,239,128,0.2)]"
                    : "border-line bg-abyss/60 text-mute hover:border-line2 hover:text-fog"
                }`}
              >
                {t(`mkt.filter.${f}`)}
                <Icon name="chevron" size={11} />
              </button>
            ))}
          </div>
        )}

        {/* [تفاصيل الفروع] */}
        {hasBranches && !branch && (
          <div>
            <button
              onClick={() => setBDetails((v) => !v)}
              className={`btn-ghost w-full py-2.5 ${bDetails ? "!border-acid/50 !text-acid" : ""}`}
            >
              <Icon name="book" size={13} />
              {t("mkt.branchDetails")}
              <Icon name="chevron" size={12} className={bDetails ? "rotate-180 transition-transform" : "transition-transform"} />
            </button>
            {bDetails && (
              <div className="panel animate-fade-up mt-2">
                <div className="mono-label flex items-center justify-between border-b border-line px-4 py-2.5">
                  <span>◈ {t("mkt.branchDetails")}</span>
                  <button onClick={() => setBDetails(false)} className="flex items-center gap-1 text-mute hover:text-acid">
                    <Icon name="close" size={11} />
                    {t("c.close")}
                  </button>
                </div>
                <div className="divide-y divide-line">
                  {sec.branches.map((b, i) => (
                    <div key={b.id} className="flex gap-3 px-4 py-3">
                      <span className="font-mono text-[10px] font-bold text-blood">{String(i + 1).padStart(2, "0")}</span>
                      <div className="min-w-0">
                        <div className="text-sm font-bold">{pick(lang, b.name)}</div>
                        <p className="mt-1 text-xs leading-relaxed text-mute">{pick(lang, b.desc)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* المحتوى: فرع ← منتجات / بدون فرع ← بطاقات الفروع أو منتجات مباشرة */}
        {branch && activeBranch ? (
          <div key={branch} className="animate-fade-up">
            <ProductGrid branchId={branch} tagFilter={sec.filter ? filter : "all"} onPick={setPicked} />
          </div>
        ) : hasBranches ? (
          <section>
            <div className="mono-label mb-3">// {t("mkt.branches")}</div>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
              {sec.branches.map((b) => (
                <BranchCard key={b.id} b={b} onOpen={() => openBranch(b.id)} />
              ))}
            </div>
          </section>
        ) : (
          /* قسم بدون فروع (حقن الحسابات): منتجات مباشرة */
          <div key="direct" className="animate-fade-up">
            <div className="mono-label mb-3">// PRODUCTS</div>
            <ProductGrid branchId="inj-direct" tagFilter="all" onPick={setPicked} />
          </div>
        )}
      </div>

      {/* وضع التركيز */}
      {picked && <ProductModal p={picked} onClose={() => setPicked(null)} />}
    </Shell>
  );
}

/** هيكل عظمي فوري — يظهر لحظياً أثناء التحميل (بدون وميض أبيض) */
function MarketSkeleton() {
  return (
    <Shell>
      <div className="space-y-5 pt-4">
        <div className="panel h-48 animate-pulse-soft bg-panel2/40" />
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="panel h-52 animate-pulse-soft bg-panel2/40" />
          ))}
        </div>
      </div>
    </Shell>
  );
}

export default function MarketSectionPage({ sectionId }: { sectionId: string }) {
  return (
    <Suspense fallback={<MarketSkeleton />}>
      <MarketSectionInner sectionId={sectionId} />
    </Suspense>
  );
}
