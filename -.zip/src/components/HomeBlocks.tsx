"use client";

import { useEffect, useState } from "react";
import { useT, useLang, api, toast } from "@/lib/client";
import { BUY_MANAGER } from "@/lib/site";
import { copyText, dispatchToTelegram, timestamp, buildWebFallback } from "@/lib/forumClient";
import { ProductRow, RatingRow, OpinionRow, pName, fmtDate } from "@/lib/types";
import { Icon } from "./Icon";
import ProductCard from "./ProductCard";
import { loadProducts } from "./SearchBar";

/* ── ⭐ الخدمات الأكثر مبيعاً ── */
export function BestSellers({ onPick }: { onPick: (p: ProductRow) => void }) {
  const t = useT();
  const [prods, setProds] = useState<ProductRow[] | null>(null);

  useEffect(() => {
    loadProducts().then((r) => setProds([...r].sort((a, b) => b.views - a.views).slice(0, 8))).catch(() => setProds([]));
  }, []);

  return (
    <section>
      <div className="mb-4 flex items-end justify-between">
        <div>
          <div className="mono-label mb-1">// {t("home.best")}</div>
          <h2 className="text-xl font-extrabold sm:text-2xl">{t("home.best")}</h2>
        </div>
        <span className="hidden font-mono text-[10px] tracking-[0.2em] text-mute sm:block">{t("home.bestSub")}</span>
      </div>
      {prods === null ? (
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="panel h-64 animate-pulse-soft bg-panel2/40" />
          ))}
        </div>
      ) : (
        <div className="no-scrollbar -mx-1 flex snap-x gap-4 overflow-x-auto px-1 pb-2">
          {(prods.length ? prods : []).map((p) => (
            <div key={p.id} className="w-[240px] shrink-0 snap-start">
              <ProductCard p={p} onOpen={onPick} />
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

/* ── نجوم قابلة للنقر ── */
function StarInput({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  const [hover, setHover] = useState(0);
  return (
    <div className="flex gap-1.5" dir="ltr">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          onClick={() => onChange(n)}
          onMouseEnter={() => setHover(n)}
          onMouseLeave={() => setHover(0)}
          aria-label={`${n} stars`}
          className="transition-transform hover:scale-125"
        >
          <Icon name="star" size={26} filled={n <= (hover || value)} className={n <= (hover || value) ? "text-amber" : "text-line2"} />
        </button>
      ))}
    </div>
  );
}

function Stars({ n }: { n: number }) {
  return (
    <span className="flex gap-0.5" dir="ltr">
      {[1, 2, 3, 4, 5].map((i) => (
        <Icon key={i} name="star" size={12} filled={i <= n} className={i <= n ? "text-amber" : "text-line2"} />
      ))}
    </span>
  );
}

/* ── 📊 التقييمات ── */
export function RatingsBlock() {
  const t = useT();
  const lang = useLang();
  const [stars, setStars] = useState(0);
  const [name, setName] = useState("");
  const [text, setText] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const [list, setList] = useState<RatingRow[]>([]);

  useEffect(() => {
    api<RatingRow[]>("/api/ratings").then(setList).catch(() => {});
  }, []);

  const submit = async () => {
    if (!stars || busy) return;
    setBusy(true);
    const fallback = lang === "ar" ? "زائر" : lang === "ru" ? "Гость" : "Guest";
    try {
      await api("/api/ratings", {
        method: "POST",
        body: JSON.stringify({ name: name.trim() || fallback, stars, text: text.trim() }),
      });
      setMsg(t("ratings.thanks"));
      setStars(0);
      setName("");
      setText("");
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="panel flex h-full flex-col">
      <div className="flex items-center gap-2 border-b border-line px-5 py-4">
        <Icon name="star" size={16} className="text-amber" />
        <h3 className="flex-1 text-lg font-extrabold">{t("ratings.title")}</h3>
        <span className="font-mono text-[9px] tracking-[0.2em] text-mute">RATINGS_DB</span>
      </div>

      <div className="border-b border-line p-5">
        <p className="mb-3 text-xs leading-relaxed text-mute">{t("ratings.sub")}</p>
        <StarInput value={stars} onChange={setStars} />
        <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
          <input className="inp" value={name} onChange={(e) => setName(e.target.value)} placeholder={t("ratings.name.ph")} />
          <input className="inp" value={text} onChange={(e) => setText(e.target.value)} placeholder={t("ratings.text.ph")} />
        </div>
        <button onClick={submit} disabled={!stars || busy} className="btn-acid mt-3 w-full py-2.5 disabled:opacity-40">
          <Icon name="star" size={13} />
          {busy ? t("c.sending") : t("ratings.submit")}
        </button>
        {msg && (
          <div className="animate-fade-up mt-3 flex items-start gap-2 border border-acid/40 bg-acid/5 p-3 text-xs leading-relaxed text-acid">
            <Icon name="check" size={14} className="mt-0.5 shrink-0" />
            <span className="text-fog">{msg}</span>
          </div>
        )}
      </div>

      <div className="flex-1 p-5">
        {list.length === 0 ? (
          <div className="py-6 text-center font-mono text-xs text-mute">{t("ratings.empty")}</div>
        ) : (
          <div className="divide-y divide-line">
            {list.map((r) => (
              <div key={r.id} className="py-3 first:pt-0">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold">{r.name}</span>
                  <Stars n={r.stars} />
                  <span className="ms-auto font-mono text-[9px] text-mute">{fmtDate(r.createdAt, lang)}</span>
                </div>
                {r.text && <p className="mt-1.5 text-xs leading-relaxed text-mute">{r.text}</p>}
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

/* ── 💬 الآراء ── */
export function OpinionsBlock() {
  const t = useT();
  const lang = useLang();
  const [name, setName] = useState("");
  const [text, setText] = useState("");
  const [msg, setMsg] = useState("");
  const [relayMsg, setRelayMsg] = useState("");
  const [copied, setCopied] = useState(false);
  const [busy, setBusy] = useState(false);
  const [list, setList] = useState<OpinionRow[]>([]);

  useEffect(() => {
    api<OpinionRow[]>("/api/opinions", undefined).then(setList).catch(() => {});
  }, []);

  /** الرسالة المرتبة: تُنسخ للحافظة وتُوجَّه للمسؤول tg:// (اليوزر مخفي) */
  const buildOpinionMessage = (who: string, body: string) =>
    [
      `[ BLACK MART OPINION - ${timestamp(false)} ]`,
      "--------------------------------------",
      `👤 ${t("op.name")}: ${who}`,
      `💬 ${t("op.title")}: ${body}`,
      "--------------------------------------",
      "🔒 ZERO-FOOTPRINT · LOCAL DRAFT ONLY",
      "[SYSTEM_ID: AUTO_GENERATED]",
    ].join("\n");

  const submit = async () => {
    if (!text.trim() || busy) return;
    setBusy(true);
    const fallback = lang === "ar" ? "زائر" : lang === "ru" ? "Гость" : "Guest";
    const who = name.trim() || fallback;
    const body = text.trim();
    try {
      await api("/api/opinions", {
        method: "POST",
        body: JSON.stringify({ name: who, kind: "opinion", text: body }),
      });
      const relay = buildOpinionMessage(who, body);
      await copyText(relay); // نسخ احتياطي للحافظة
      void dispatchToTelegram(relay, BUY_MANAGER); // tg:// + بديل ويب — اليوزر مخفي
      setRelayMsg(relay);
      setCopied(true);
      setMsg(t("op.relayOk"));
      setName("");
      setText("");
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="panel flex h-full flex-col">
      <div className="flex items-center gap-2 border-b border-line px-5 py-4">
        <Icon name="chat" size={16} className="text-acid" />
        <h3 className="flex-1 text-lg font-extrabold">{t("op.title")}</h3>
        <span className="font-mono text-[9px] tracking-[0.2em] text-mute">TG_RELAY</span>
      </div>

      <div className="border-b border-line p-5">
        <p className="mb-3 flex items-center gap-2 text-xs leading-relaxed text-mute">
          <Icon name="plane" size={13} className="shrink-0 text-dim" />
          {t("op.sub")}
        </p>
        <div className="grid grid-cols-1 gap-2">
          <input className="inp" value={name} onChange={(e) => setName(e.target.value)} placeholder={t("ratings.name.ph")} />
          <textarea className="inp min-h-[84px] resize-y" value={text} onChange={(e) => setText(e.target.value)} placeholder={t("op.text.ph")} />
        </div>
        <button onClick={submit} disabled={!text.trim() || busy} className="btn-acid mt-3 w-full py-2.5 disabled:opacity-40">
          <Icon name="send" size={13} />
          {busy ? t("c.sending") : t("op.submit")}
        </button>
        {msg && (
          <div className="animate-fade-up mt-3 flex items-start gap-2 border border-acid/40 bg-acid/5 p-3 text-xs leading-relaxed">
            <Icon name="plane" size={14} className="mt-0.5 shrink-0 text-acid" />
            <span className="text-fog">{msg}</span>
          </div>
        )}

        {/* معاينة الرسالة المؤرخة + النسخ + التوجيه */}
        {relayMsg && (
          <div className="animate-fade-up mt-3 border border-line bg-abyss">
            <div className="mono-label flex items-center justify-between border-b border-line px-3 py-2">
              <span>{t("op.preview")}</span>
              <span className="text-acid">✓ {t("op.copied")}</span>
            </div>
            <pre className="max-h-48 overflow-auto whitespace-pre-wrap p-3 font-mono text-[10px] leading-5 text-fog/90" dir="auto">
              {relayMsg}
            </pre>
            <div className="grid grid-cols-2 gap-2 border-t border-line p-3">
              <button
                onClick={async () => { if (await copyText(relayMsg)) { setCopied(true); toast(t("op.copied")); } }}
                className="btn-ghost px-2 py-2 text-[9px]"
              >
                <Icon name={copied ? "check" : "link"} size={11} />
                {t("op.copy")}
              </button>
              <button
                onClick={() => window.open(buildWebFallback(relayMsg, BUY_MANAGER), "_blank", "noreferrer")}
                className="btn-acid px-2 py-2 text-[9px]"
              >
                <Icon name="plane" size={11} />
                {t("op.open")}
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="flex-1 p-5">
        {list.length === 0 ? (
          <div className="py-6 text-center font-mono text-xs text-mute">{t("op.empty")}</div>
        ) : (
          <div className="divide-y divide-line">
            {list.map((o) => (
              <div key={o.id} className="py-3 first:pt-0">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold">{o.name}</span>
                  <span className="ms-auto font-mono text-[9px] text-mute">{fmtDate(o.createdAt, lang)}</span>
                </div>
                <p className="mt-1.5 text-xs leading-relaxed text-mute">{o.text}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
