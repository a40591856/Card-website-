"use client";

import { useCallback, useEffect, useState } from "react";
import {
  PRIVACY_NOTE, ENCRYPT_STEPS, CERT_TITLE, NO_ACCOUNT, EMAIL_RE,
  MEMBER_KEYS, MemberAccount, MemberSession, localHash, make8, nowStamp,
  loadAccounts, saveAccount, findAccount, saveSession, setPoints, getPoints,
  captureRef, pendingRef, clearPendingRef, referralLink,
  serverRegister, serverLogin, serverRefer,
} from "@/lib/membership";
import { setAuth, toast, useT, useLang } from "@/lib/client";
import { pick } from "@/lib/site";
import { Icon } from "./Icon";

type Mode = "login" | "register" | "encrypt" | "cert";

/** ═══ نظام العضوية — Swiss-Vault Identity ═══ */
export default function MembershipModal({ onClose }: { onClose: () => void }) {
  const t = useT();
  const lang = useLang();
  const [mode, setMode] = useState<Mode>("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [confirm, setConfirm] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [step, setStep] = useState(0);
  const [newId, setNewId] = useState("");
  const [session, setSession] = useState<MemberSession | null>(null);
  const [ref, setRef] = useState("");

  useEffect(() => { captureRef(); setRef(pendingRef() || ""); }, []);

  /* شاشة التشفير السينمائية */
  useEffect(() => {
    if (mode !== "encrypt") return;
    setProgress(0);
    setStep(0);
    const total = 52; // ~2.6 ثانية (محاكاة بصرية مبهرة)
    let n = 0;
    const iv = window.setInterval(() => {
      n++;
      const pct = Math.round((n / total) * 100);
      setProgress(pct);
      setStep(Math.min(ENCRYPT_STEPS.length - 1, Math.floor((pct / 100) * ENCRYPT_STEPS.length)));
      if (n >= total) {
        window.clearInterval(iv);
        window.setTimeout(() => setMode("cert"), 420);
      }
    }, 50);
    return () => window.clearInterval(iv);
  }, [mode]);

  const finishSession = useCallback((s: MemberSession) => {
    saveSession(s);
    setAuth(s.id); // يُحدّث كل واجهة الموقع فوراً
  }, []);

  /** دخول صارم: السجل المحلي أولاً، ثم تحقق الخادم للدخول من جهاز آخر */
  const doLogin = async () => {
    if (!EMAIL_RE.test(email.trim()) || !pass) { setErr("أدخل البريد وكلمة المرور بشكل صحيح"); return; }
    setBusy(true); setErr("");
    const local = findAccount(email);
    if (local) {
      if (local.passHash !== localHash(pass)) {
        setErr("كلمة المرور غير صحيحة"); setBusy(false); return;
      }
      finishSession({
        id: local.id, name: local.name, email: local.email, refCode: local.refCode,
        avatar: local.avatar, points: getPoints(local.id),
      });
      toast("✅ تم الدخول — مرحباً بعودتك");
      onClose(); setBusy(false); return;
    }
    // جهاز آخر: تحقق من الخادم (يرفض أي بريد غير مسجل)
    const remote = await serverLogin(email.trim(), pass);
    if (!remote) {
      setErr(pick(lang, NO_ACCOUNT)); setBusy(false); return;
    }
    const acc: MemberAccount = {
      id: remote.id, name: remote.name, email: remote.email, passHash: localHash(pass),
      refCode: remote.refCode, avatar: remote.avatar ?? undefined, createdAt: nowStamp(),
    };
    saveAccount(acc);                 // استيراد للسجل المحلي
    setPoints(remote.id, remote.points);
    finishSession({
      id: remote.id, name: remote.name, email: remote.email, refCode: remote.refCode,
      avatar: acc.avatar, points: remote.points,
    });
    toast("✅ تم استعادة حسابك بكل نقاطك وطلباتك");
    onClose(); setBusy(false);
  };

  /** إنشاء حساب جديد → شاشة التشفير */
  const doRegister = async () => {
    if (!name.trim() || name.trim().length < 3) { setErr("الاسم 3 أحرف على الأقل"); return; }
    if (!EMAIL_RE.test(email.trim())) { setErr("بريد إلكتروني غير صالح"); return; }
    if (pass.length < 6) { setErr("كلمة المرور 6 أحرف على الأقل"); return; }
    if (pass !== confirm) { setErr("تأكيد كلمة المرور غير مطابق"); return; }
    if (findAccount(email)) { setErr("هذا البريد مسجل مسبقاً — سجّل الدخول"); return; }
    setBusy(true); setErr("");
    const id = make8();
    const acc: MemberAccount = {
      id, name: name.trim(), email: email.trim().toLowerCase(), passHash: localHash(pass),
      refCode: id, createdAt: nowStamp(),
    };
    saveAccount(acc);
    setPoints(id, 0);
    const s: MemberSession = {
      id, name: acc.name, email: acc.email, refCode: id, points: 0,
    };
    setSession(s); setNewId(id);
    // مزامنة الخادم (للدخول من جهاز آخر) + احتساب نقطة الإحالة
    void serverRegister({ id, name: acc.name, email: acc.email, pass });
    const r = pendingRef();
    if (r && r !== id) {
      const owner = loadAccounts().find((x) => x.refCode === r || x.id === r);
      if (owner) { const pts = getPoints(owner.id) + 1; setPoints(owner.id, pts); }
      void serverRefer(r); clearPendingRef();
    }
    setBusy(false);
    setMode("encrypt");
  };

  const enterSite = () => {
    if (session) finishSession(session);
    toast("🎉 تم إنشاء حسابك المشفر بنجاح");
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[85] flex items-center justify-center p-4" role="dialog" aria-modal>
      <div className="absolute inset-0 bg-void/90 backdrop-blur-md" onClick={mode === "encrypt" ? undefined : onClose} />
      <div className="panel animate-fade-up relative w-full max-w-md overflow-hidden">
        {/* الترويسة البنكية */}
        <div className="flex items-center gap-2.5 border-b border-line bg-gradient-to-l from-acid/10 to-transparent px-5 py-3.5">
          <div className="flex h-9 w-9 items-center justify-center border border-acid/50 bg-void text-acid">
            <Icon name="shieldCheck" size={18} />
          </div>
          <div className="min-w-0 flex-1">
            <div className="mono-label !text-acid">SWISS-VAULT IDENTITY</div>
            <div className="text-sm font-bold">BLACK MART · SECURE ACCESS</div>
          </div>
          {mode !== "encrypt" && (
            <button onClick={onClose} className="btn-icon h-8 w-8" aria-label="close"><Icon name="close" size={15} /></button>
          )}
        </div>

        {/* ═══ شاشة التشفير ═══ */}
        {mode === "encrypt" && (
          <div className="grid-bg-fine p-7 text-center">
            <div className="mx-auto mb-5 flex h-24 w-24 items-center justify-center rounded-full border-2 border-acid/25" style={{ borderTopColor: "#b8ef80", animation: "spin 1.1s linear infinite" }}>
              <Icon name="lock" size={34} className="text-acid" />
            </div>
            <div className="mono-label mb-2 text-acid">AES-256 · KEY GENERATION</div>
            <div className="font-mono text-3xl font-bold text-acid text-glow" dir="ltr">{progress}%</div>
            <div className="mt-4 h-2 w-full border border-line2/60 bg-abyss p-[2px]">
              <div className="h-full bg-acid shadow-[0_0_16px_rgba(184,239,128,0.6)] transition-[width] duration-75" style={{ width: `${progress}%` }} />
            </div>
            <div className="mt-5 space-y-2 text-start">
              {ENCRYPT_STEPS.map((s, i) => (
                <div key={i} className={`font-mono text-[11px] ${i <= step ? "text-acid" : "text-mute/35"}`}>
                  {i <= step ? "✓ " : "· "}{pick(lang, s)}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ═══ شهادة التشفير ═══ */}
        {mode === "cert" && (
          <div className="p-6 text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-acid/50 bg-acid/10">
              <Icon name="check" size={30} className="text-acid" />
            </div>
            <h3 className="mt-4 text-lg font-bold">{pick(lang, CERT_TITLE)}</h3>
            <p className="mt-2 text-xs leading-relaxed text-mute">هويتك الرقمية موثّقة ومشفّرة بالكامل على هذا الجهاز.</p>
            <div className="mt-5 border border-acid/40 bg-acid/5 p-4">
              <div className="mono-label">MEMBER ID · 8 DIGITS</div>
              <div className="mt-1 font-mono text-3xl font-bold tracking-[0.25em] text-acid text-glow" dir="ltr">{newId}</div>
              <div className="mt-2 font-mono text-[10px] text-mute">{email.trim().toLowerCase()}</div>
            </div>
            <div className="mt-3 border border-line bg-abyss/60 p-3 text-start">
              <div className="mono-label mb-1.5">رابط الإحالة الخاص بك</div>
              <div className="truncate font-mono text-[10px] text-acid" dir="ltr">{referralLink(newId)}</div>
            </div>
            <button onClick={enterSite} className="btn-primary mt-5 w-full">
              <Icon name="user" size={16} />الدخول إلى حسابي
            </button>
          </div>
        )}

        {/* ═══ تسجيل الدخول ═══ */}
        {mode === "login" && (
          <div className="p-5">
            <p className="mb-4 text-xs leading-relaxed text-mute">الدخول اختياري تماماً؛ يمكنك الشراء كزائر في أي وقت. بياناتك مشفّرة ومحفوظة على جهازك.</p>
            <label className="mono-label mb-1.5 block">البريد الإلكتروني</label>
            <input className="inp" dir="ltr" type="email" value={email} onChange={(e) => { setEmail(e.target.value); setErr(""); }} placeholder="name@mail.com" />
            <label className="mono-label mb-1.5 mt-4 block">كلمة المرور</label>
            <input className="inp" dir="ltr" type="password" value={pass} onChange={(e) => { setPass(e.target.value); setErr(""); }} onKeyDown={(e) => e.key === "Enter" && doLogin()} placeholder="••••••••" />
            {err && <div className="mt-3 flex items-center gap-2 border border-blood/40 bg-blood/10 px-3 py-2 text-xs text-blood"><Icon name="warn" size={12} />{err}</div>}
            <button onClick={doLogin} disabled={busy} className="btn-primary mt-4 w-full disabled:opacity-50">
              <Icon name="lock" size={15} />{busy ? "جارٍ التحقق…" : "تسجيل الدخول"}
            </button>
            <div className="my-4 flex items-center gap-2"><span className="h-px flex-1 bg-line" /><span className="mono-label">أو</span><span className="h-px flex-1 bg-line" /></div>
            <button onClick={() => { setMode("register"); setErr(""); }} className="w-full border border-blood/60 bg-blood/10 py-3 text-sm font-bold text-blood transition-colors hover:bg-blood/20">
              ✚ إنشاء حساب جديد
            </button>
          </div>
        )}

        {/* ═══ إنشاء حساب ═══ */}
        {mode === "register" && (
          <div className="p-5">
            {/* الشريط التعليمي المطمئن */}
            <div className="mb-4 flex items-start gap-2 border border-acid/40 bg-acid/5 p-3">
              <Icon name="shieldCheck" size={15} className="mt-0.5 shrink-0 text-acid" />
              <p className="text-xs font-bold italic leading-loose text-fog/90">{pick(lang, PRIVACY_NOTE)}</p>
            </div>
            <label className="mono-label mb-1.5 block">الاسم</label>
            <input className="inp" value={name} onChange={(e) => { setName(e.target.value); setErr(""); }} placeholder="Shadow_01" />
            <label className="mono-label mb-1.5 mt-3 block">البريد الإلكتروني</label>
            <input className="inp" dir="ltr" type="email" value={email} onChange={(e) => { setEmail(e.target.value); setErr(""); }} placeholder="name@mail.com" />
            <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div><label className="mono-label mb-1.5 block">كلمة المرور</label>
                <input className="inp" dir="ltr" type="password" value={pass} onChange={(e) => { setPass(e.target.value); setErr(""); }} placeholder="••••••••" /></div>
              <div><label className="mono-label mb-1.5 block">تأكيد كلمة المرور</label>
                <input className="inp" dir="ltr" type="password" value={confirm} onChange={(e) => { setConfirm(e.target.value); setErr(""); }} placeholder="••••••••" /></div>
            </div>
            {ref && <p className="mt-3 font-mono text-[10px] text-acid">🔗 تم رصد رابط إحالة: {ref} — ستحصل على نقطة عند التسجيل.</p>}
            {err && <div className="mt-3 flex items-center gap-2 border border-blood/40 bg-blood/10 px-3 py-2 text-xs text-blood"><Icon name="warn" size={12} />{err}</div>}
            <button onClick={doRegister} disabled={busy} className="btn-primary mt-4 w-full disabled:opacity-50">
              <Icon name="shield" size={15} />إنشاء الحساب المشفر
            </button>
            <button onClick={() => { setMode("login"); setErr(""); }} className="btn-ghost mt-2 w-full py-2 text-[10px]">
              <Icon name="back" size={11} className="rtl:rotate-180" />لدي حساب بالفعل — تسجيل الدخول
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
