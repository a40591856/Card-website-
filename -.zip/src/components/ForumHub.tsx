"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { FORUM_SECTIONS, type ForumSectionDef, type ServiceDef, type SpecialtyDef, type FieldDef } from "@/lib/forum";
import {
  saveDraft,
  loadDraft,
  clearDraft,
  stripExifData,
  logAttachment,
  affiliateHash,
  savedAffiliateHash,
  buildForumMessage,
  buildRelayLink,
  buildWebFallback,
  copyText,
  timestamp,
  type AttachmentLog,
  type DraftData,
  type StrippedFile,
} from "@/lib/forumClient";
import { useT, useLang, toast } from "@/lib/client";
import { pick, type L } from "@/lib/site";
import { Icon } from "./Icon";
import Shell from "./Shell";
import MeetingHub from "./MeetingHub";
import PercentHub from "./PercentHub";
import ForumAnnouncement from "./ForumAnnouncement";

const SESSION_SECONDS = 15 * 60; // مؤقت الجلسة التنازلي

/** المنتدى والمجتمع — SPA بلا أثر: عزل تفاعلي + تخزين محلي + توجيه مشفر */
export default function ForumHub() {
  const t = useT();
  const lang = useLang();

  const [secId, setSecId] = useState<string | null>(null);
  const [specId, setSpecId] = useState<string | null>(null);
  const [groupId, setGroupId] = useState<"inbound" | "outbound" | null>(null);
  const [boardFilter, setBoardFilter] = useState<"all" | "operator" | "receiver">("all");
  const [secDetails, setSecDetails] = useState(false);
  const [extraOpen, setExtraOpen] = useState(false);
  const [svcId, setSvcId] = useState<string | null>(null);
  const [role, setRole] = useState<"a" | "b">("a");
  const [fields, setFields] = useState<DraftData>({});
  const [attachments, setAttachments] = useState<StrippedFile[]>([]);
  const [logs, setLogs] = useState<AttachmentLog[]>([]);
  const [message, setMessage] = useState("");
  const [copied, setCopied] = useState(false);
  const [draftSaved, setDraftSaved] = useState(false);
  const [err, setErr] = useState(false);
  const [seconds, setSeconds] = useState(SESSION_SECONDS);
  const [hash, setHash] = useState("");

  /* رابط عميق ?sec=... من البحث الذكي */
  useEffect(() => {
    const s = new URLSearchParams(window.location.search).get("sec");
    if (s && FORUM_SECTIONS.some((x) => x.id === s)) setSecId(s);
  }, []);

  /* مؤقت الجلسة التنازلي */
  useEffect(() => {
    const iv = window.setInterval(() => setSeconds((s) => (s > 0 ? s - 1 : SESSION_SECONDS)), 1000);
    return () => window.clearInterval(iv);
  }, []);
  useEffect(() => {
    setHash(savedAffiliateHash());
  }, []);

  const sec: ForumSectionDef | undefined = secId ? FORUM_SECTIONS.find((s) => s.id === secId) : undefined;
  const spec: SpecialtyDef | undefined = useMemo(
    () => sec?.specialties?.find((s) => s.id === specId),
    [sec, specId],
  );
  const serviceList: ServiceDef[] = (spec?.services ?? sec?.services ?? []);
  const svc: ServiceDef | undefined = serviceList.find((s) => s.id === svcId);

  /* الخدمات الظاهرة بعد تصفية المجموعة + تيوبات لوحة الطلبات */
  const visibleList = serviceList.filter(
    (s) =>
      (!groupId || s.group === groupId) &&
      (!sec?.offerTabs ||
        boardFilter === "all" ||
        s.offer === "both" ||
        s.offer === boardFilter),
  );

  /* تحميل المسودة المحلية عند اختيار الخدمة */
  useEffect(() => {
    if (!secId || !svcId) return;
    const d = loadDraft(secId, svcId);
    setFields(d);
    setDraftSaved(Object.keys(d).length > 0);
    setAttachments([]);
    setMessage("");
    setErr(false);
    setExtraOpen(false);
  }, [secId, svcId]);

  const resetToHub = useCallback(() => {
    setSecId(null);
    setSpecId(null);
    setGroupId(null);
    setBoardFilter("all");
    setSvcId(null);
    setFields({});
    setMessage("");
    setSecDetails(false);
    window.scrollTo({ top: 0 });
  }, []);

  const openSection = (id: string) => {
    setSecId(id);
    setSpecId(null);
    setGroupId(null);
    setBoardFilter("all");
    setSvcId(null);
    setRole("a");
    setFields({});
    setMessage("");
    setSecDetails(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  /* ═══ الرجوع التدريجي: خدمة ← مجموعة/تخصص ← قسم ← كل الأقسام ═══ */
  const goBack = () => {
    if (svcId) {
      setSvcId(null);
      setMessage("");
      setErr(false);
    } else if (groupId) {
      setGroupId(null);
      setSvcId(null);
      setSecDetails(false);
    } else if (specId) {
      setSpecId(null);
      setSecDetails(false);
    } else if (secId) {
      resetToHub();
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const backLabel = svcId
    ? t("fh.backServices")
    : groupId
      ? t("fh.groups")
      : specId
        ? t("fh.backSpecs")
        : t("fh.back");

  const openGroup = (g: "inbound" | "outbound") => {
    setGroupId(g);
    setSvcId(null);
    setFields({});
    setMessage("");
    setSecDetails(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const selectService = (s: ServiceDef) => {
    setSvcId(s.id);
    setMessage("");
    setErr(false);
    if (s.id.startsWith("m-") && s.fields[0]) {
      const cityName = pick(lang, s.name).split("—").pop()?.trim() ?? "";
      setFields((f) => ({ ...f, city: cityName }));
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const changeField = (id: string, value: string) => {
    setFields((f) => {
      const next = { ...f, [id]: value };
      if (secId && svcId) {
        saveDraft(secId, svcId, next);
        setDraftSaved(true);
      }
      return next;
    });
    setMessage("");
    setErr(false);
  };

  /* رفع ملفات: stripExifData فوراً + تسجيل في IndexedDB (بدون رفع لأي خادم) */
  const onFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const clean: StrippedFile[] = [];
    for (const f of Array.from(files).slice(0, 5)) {
      const c = await stripExifData(f); // يمسح GPS / التاريخ / نوع الهاتف
      clean.push(c);
      await logAttachment(c.log);
    }
    setAttachments((prev) => [...prev, ...clean]);
    setLogs((l) => [...clean.map((c) => c.log), ...l].slice(0, 8));
    toast(t("fh.fileOk"));
  };

  const generateHash = () => {
    const h = affiliateHash(fields.subject || "CAMPAIGN");
    setHash(h);
    toast(t("fh.copied"));
  };

  /* صياغة + توجيه تلقائي مشفر */
  const submit = () => {
    if (!sec || !svc) return;
    const missing = svc.fields.some((f) => f.required && !(fields[f.id] || "").trim());
    if (missing) {
      setErr(true);
      toast(t("fh.required"), "warn");
      return;
    }
    const msg = buildForumMessage({
      section: pick(lang, sec.name),
      service: pick(lang, svc.name),
      specialty: spec ? pick(lang, spec.name) : undefined,
      role: sec.offerTabs
        ? boardFilter !== "all"
          ? t(`fh.tab.${boardFilter}`)
          : undefined
        : sec.roles
          ? pick(lang, sec.roles[role])
          : undefined,
      fields: svc.fields
        .filter((f) => f.type !== "file")
        .map((f) => ({ label: pick(lang, f.label), value: fields[f.id] || "—" })),
      hash: sec.mode === "affiliate" ? hash || savedAffiliateHash() : undefined,
      attachment: attachments.length
        ? attachments.map((a) => a.log.safeName).join(", ")
        : undefined,
    });
    setMessage(msg);
    setCopied(false);
    toast(t("fh.sent"));
    // التوجيه في الخلفية عبر Deep-Linking — لا يوزر مكشوف في الواجهة
    try {
      window.location.href = buildRelayLink(msg);
    } catch {
      /* المتصفح قد يحجب tg:// — النسخ والبديل متاحان */
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const mm = String(Math.floor(seconds / 60)).padStart(2, "0");
  const ss = String(seconds % 60).padStart(2, "0");

  const fieldLabel = (f: FieldDef) => pick(lang, f.label);
  const fieldPh = (f: FieldDef) => (f.ph ? pick(lang, f.ph) : "");

  return (
    <Shell>
      <div className="space-y-4 pt-4">
        {/* ═══ الترويسة الثابتة: حالة الأمان + مؤقت الجلسة + فاحص المرفقات ═══ */}
        <div className="sticky top-[96px] z-20 -mx-3 border border-line bg-void/95 px-3 py-2.5 backdrop-blur-md sm:-mx-5 sm:px-5">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
            <span className="flex shrink-0 items-center gap-2 font-mono text-[10px] tracking-[0.2em] text-acid">
              <span className="inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full bg-acid" />
              {t("fh.system")}
            </span>
            <span className="flex shrink-0 items-center gap-1.5 font-mono text-[10px] tracking-wider text-mute">
              <Icon name="clock" size={12} />
              {t("fh.session")}
              <b dir="ltr" className="text-fog">{mm}:{ss}</b>
            </span>
            <span className="flex shrink-0 items-center gap-1.5 border border-line bg-abyss/60 px-2 py-1 font-mono text-[9px] text-mute">
              <Icon name="shieldCheck" size={12} className={logs.length ? "text-acid" : ""} />
              {t("fh.scan")}: {logs.length ? t("fh.scan.ok") : t("fh.scan.none")}
              {logs.length > 0 && <b className="text-acid">[{logs.length}]</b>}
            </span>
            <span className="ms-auto hidden font-mono text-[9px] tracking-[0.2em] text-mute/60 md:block">
              {t("fh.zero")}
            </span>
            {secId && (
              <>
                <button onClick={goBack} className="btn-ghost shrink-0 px-3 py-1.5 text-[9px]">
                  <Icon name="back" size={11} className="rtl:rotate-180" />
                  🔙 {t("fh.backTo")} · {backLabel}
                </button>
                <button
                  onClick={resetToHub}
                  title={t("fh.hub")}
                  aria-label={t("fh.hub")}
                  className="btn-icon h-8 w-8 shrink-0"
                >
                  <Icon name="terminal" size={13} />
                </button>
              </>
            )}
          </div>

          {/* شريط تبويبات أفقي للتنقل السريع بين الأقسام (وضع العزل) */}
          {secId && (
            <div className="no-scrollbar -mx-1 mt-2 flex gap-1.5 overflow-x-auto px-1">
              {FORUM_SECTIONS.map((s) => (
                <button
                  key={s.id}
                  onClick={() => openSection(s.id)}
                  className={`shrink-0 border px-3 py-1.5 font-mono text-[10px] font-bold tracking-wider transition-all ${
                    s.id === secId
                      ? "border-violet bg-violet text-void shadow-[0_0_16px_rgba(163,139,243,0.35)]"
                      : "border-line bg-abyss/60 text-mute hover:text-fog"
                  }`}
                >
                  {pick(lang, s.short)}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* ═══ شبكة الأقسام الرئيسية (Grid Hub) — تختفي عند العزل ═══ */}
        {!sec && (
          <section>
            <div className="mono-label mb-3">// {t("fh.hub")} · {String(FORUM_SECTIONS.length).padStart(2, "0")}</div>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
              {FORUM_SECTIONS.map((s, i) => (
                <button
                  key={s.id}
                  onClick={() => openSection(s.id)}
                  className="panel panel-hover corners group flex flex-col overflow-hidden text-start"
                >
                  <div className="grid-bg-fine flex h-20 items-center justify-center sm:h-28">
                    <Icon name={s.icon} size={28} className="text-violet transition-colors group-hover:text-acid" />
                  </div>
                  <div className="h-[3px] w-full bg-gradient-to-l from-violet via-violet/60 to-transparent" />
                  <div className="flex flex-1 flex-col p-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="text-[13px] font-bold leading-snug sm:text-sm">{pick(lang, s.name)}</div>
                      <span className="shrink-0 font-mono text-[9px] text-mute/60">0{i + 1}</span>
                    </div>
                    <p className="mt-1 line-clamp-2 text-[10px] leading-relaxed text-mute sm:text-[11px]">{pick(lang, s.desc)}</p>
                    <div className="btn-acid mt-3 w-full !py-2 text-[10px]">{t("c.enter")}</div>
                  </div>
                </button>
              ))}
            </div>
            {/* 📢 إعلان المنتدى لجميع الزوار — بدل زر التفاصيل القديم */}
            <div className="mt-4">
              <ForumAnnouncement />
            </div>
            <div className="mt-4 flex items-center gap-2 border border-line bg-panel p-3 font-mono text-[9px] tracking-[0.2em] text-mute">
              <Icon name="lock" size={12} className="text-acid" />
              {t("fh.local")} · LocalStorage / IndexedDB · {timestamp()}
            </div>
          </section>
        )}

        {/* ═══ هَب تنسيق المقابلات (واجهة مخصصة) ═══ */}
        {sec && sec.mode === "meetings" && (
          <MeetingHub onSwitchSection={openSection} />
        )}

        {/* ═══ هَب العمل بالنسبة والإحالة (واجهة مخصصة) ═══ */}
        {sec && sec.mode === "affiliate" && (
          <PercentHub onSwitchSection={openSection} onBack={goBack} />
        )}

        {/* ═══ وضع العزل: القسم المختار فقط ═══ */}
        {sec && sec.mode !== "meetings" && sec.mode !== "affiliate" && (
          <div className="space-y-4">
            <header className="panel relative overflow-hidden p-5 sm:p-7">
              <div className="grid-bg-fine pointer-events-none absolute inset-0 opacity-60" />
              <div className="relative">
                <div className="mono-label mb-2 flex items-center gap-2 text-violet">
                  <span className="inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full bg-violet" />
                  {t("fh.isolate")} :: {sec.id.toUpperCase()}
                </div>
                <h1 className="display-2 font-bold">{pick(lang, sec.name)}</h1>
                <p className="mt-2 max-w-2xl text-sm leading-relaxed text-mute">{pick(lang, sec.desc)}</p>
              </div>
            </header>

            {/* اختيار التخصص الرئيسي (القسم التقني الذاتي) */}
            {sec.mode === "specialty" && !spec && (
              <div>
                <div className="mono-label mb-3">// {t("fh.selectSpec")}</div>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                  {sec.specialties?.map((sp) => (
                    <button
                      key={sp.id}
                      onClick={() => { setSpecId(sp.id); setSvcId(null); setFields({}); }}
                      className="panel panel-hover corners group flex flex-col p-4 text-start"
                    >
                      <Icon name={sp.icon} size={24} className="text-violet transition-colors group-hover:text-acid" />
                      <div className="mt-3 text-sm font-bold">{pick(lang, sp.name)}</div>
                      <p className="mt-1 text-xs text-mute">{pick(lang, sp.desc)}</p>
                      <div className="btn-acid mt-3 w-full !py-2 text-[10px]">{t("c.enter")}</div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* ═══ تيوبات لوحة الطلبات: الكل | متاح كمنفذ | متاح كمستقبل ═══ */}
            {sec.offerTabs && (
              <div className="panel p-3">
                <div className="mono-label mb-2">{t("fh.offerFilter")}</div>
                <div className="grid grid-cols-3 gap-1.5">
                  {(["all", "operator", "receiver"] as const).map((f) => (
                    <button
                      key={f}
                      onClick={() => {
                        setBoardFilter(f);
                        setSvcId(null);
                        setSecDetails(false);
                      }}
                      className={`border px-2 py-2.5 font-mono text-[10px] font-bold tracking-wider transition-all ${
                        boardFilter === f
                          ? "border-acid bg-acid text-void shadow-[0_0_16px_rgba(184,239,128,0.3)]"
                          : "border-line bg-abyss/60 text-mute hover:text-fog"
                      }`}
                    >
                      {t(`fh.tab.${f}`)}
                      <span className="ms-1 opacity-60">
                        [
                        {f === "all"
                          ? serviceList.length
                          : serviceList.filter((s) => s.offer === "both" || s.offer === f).length}
                        ]
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* طبيعة الطلب (قسم اللودر فقط) */}
            {sec.roles && !sec.offerTabs && (
              <div className="panel p-3">
                <div className="mono-label mb-2">{t("fh.role")}</div>
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {(["a", "b"] as const).map((r) => (
                    <button
                      key={r}
                      onClick={() => setRole(r)}
                      className={`border px-3 py-2.5 text-start text-xs font-bold transition-all ${
                        role === r ? "border-acid bg-acid/10 text-acid" : "border-line bg-abyss/60 text-mute hover:text-fog"
                      }`}
                    >
                      {r === "a" ? "📥" : "📤"} {pick(lang, sec.roles![r])}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* ═══ القسمان الأساسيان (لودر التفريغ والاستقبال) ═══ */}
            {sec.groupCards && !groupId && (
              <div>
                <div className="mono-label mb-3">// {t("fh.groups")} · 02</div>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {sec.groupCards.map((g, i) => (
                    <button
                      key={g.id}
                      onClick={() => openGroup(g.id)}
                      className="panel panel-hover corners group flex flex-col overflow-hidden text-start"
                    >
                      <div className="grid-bg-fine flex h-20 items-center justify-center sm:h-24">
                        <Icon name={g.icon} size={28} className="text-violet transition-colors group-hover:text-acid" />
                      </div>
                      <div className="h-[3px] w-full bg-gradient-to-l from-blood via-blood/60 to-transparent" />
                      <div className="flex flex-1 flex-col p-4">
                        <div className="flex items-start justify-between gap-2">
                          <div className="text-base font-bold">{pick(lang, g.name)}</div>
                          <span className="shrink-0 font-mono text-[9px] text-mute/60">0{i + 1}</span>
                        </div>
                        <p className="mt-1.5 text-xs leading-relaxed text-mute">{pick(lang, g.desc)}</p>
                        <div className="btn-acid mt-4 w-full !py-2 text-[10px]">{t("c.enter")}</div>
                      </div>
                    </button>
                  ))}
                </div>
                <DetailsPanel
                  title={t("fh.groupDetails")}
                  open={secDetails}
                  onToggle={() => setSecDetails((v) => !v)}
                  items={(sec.groupCards ?? []).map((g) => ({
                    name: g.name,
                    desc: sec.groupDetails?.[g.id] ?? g.desc,
                  }))}
                />
              </div>
            )}

            {/* ═══ تيوب التنقل بين القسمين (فوق الخدمات) ═══ */}
            {sec.groupCards && groupId && (
              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-1.5">
                  {sec.groupCards.map((g) => (
                    <button
                      key={g.id}
                      onClick={() => openGroup(g.id)}
                      className={`border px-3 py-2.5 font-mono text-[10px] font-bold tracking-wider transition-all ${
                        g.id === groupId
                          ? "border-acid bg-acid text-void shadow-[0_0_16px_rgba(184,239,128,0.3)]"
                          : "border-line bg-abyss/60 text-mute hover:text-fog"
                      }`}
                    >
                      {pick(lang, g.name)}
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => { setGroupId(null); setSvcId(null); setSecDetails(false); }}
                  className="btn-ghost px-3 py-1.5 text-[9px]"
                >
                  <Icon name="back" size={11} className="rtl:rotate-180" />
                  {t("fh.groups")}
                </button>
              </div>
            )}

            {/* قائمة الخدمات — للقسم المختار فقط */}
            {!svc && (sec.mode !== "specialty" || spec) && (!sec.groupCards || groupId) && (
              <div>
                <div className="mono-label mb-3">
                  // {spec ? `${pick(lang, spec.name)} · ` : ""}
                  {sec.groupCards && groupId ? `${pick(lang, sec.groupCards.find((g) => g.id === groupId)!.name)} · ` : ""}
                  {t(sec.groupCards ? "fh.groupServices" : "fh.selectService")} · {String(visibleList.length).padStart(2, "0")}
                </div>
                <div className="grid grid-cols-2 gap-2 md:grid-cols-3 sm:gap-3">
                  {visibleList.map((s) => (
                    <ServiceButton key={s.id} s={s} onClick={() => selectService(s)} />
                  ))}
                </div>
                <DetailsPanel
                  title={t("fh.serviceDetails")}
                  open={secDetails}
                  onToggle={() => setSecDetails((v) => !v)}
                  items={visibleList.map((s) => ({ name: s.name, desc: s.guide }))}
                />
              </div>
            )}

            {/* ═══ الخدمة المختارة: حقول + صندوق الشرح + الإرسال ═══ */}
            {svc && (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center gap-2">
                  <button onClick={goBack} className="btn-ghost px-3 py-2 text-[10px]">
                    <Icon name="back" size={11} className="rtl:rotate-180" />
                    🔙 {t("fh.backTo")}
                  </button>
                  <button
                    onClick={() => { setSvcId(null); setMessage(""); }}
                    className="btn-ghost px-3 py-2 text-[10px]"
                  >
                    <Icon name="refresh" size={12} />
                    🔄 {t("fh.change")}
                  </button>
                  {spec && (
                    <button onClick={() => { setSpecId(null); setSvcId(null); }} className="btn-ghost px-3 py-2 text-[10px]">
                      <Icon name="back" size={12} className="rtl:rotate-180" />
                      {t("fh.selectSpec")}
                    </button>
                  )}
                  <span className="flex-1 truncate font-mono text-[10px] tracking-wider text-violet">
                    ▸ {pick(lang, svc.name)}
                  </span>
                </div>

                {/* ═══ الدليل التشغيلي — يظهر أولاً بشكل بارز ═══ */}
                <div className="border border-acid/50 bg-acid/5 p-4 shadow-[0_0_30px_rgba(184,239,128,0.12)] sm:p-5">
                  <div className="mono-label mb-2 flex items-center gap-2 text-acid">
                    <Icon name="book" size={13} />
                    {t("fh.guide")} · {pick(lang, svc.name)}
                  </div>
                  <p className="text-xs leading-loose text-fog/90 sm:text-[13px]">{pick(lang, svc.guide)}</p>
                </div>

                {/* ═══ حقول الإدخال — تحت الدليل مباشرة ═══ */}
                <div className="panel p-4">
                  <div className="mono-label mb-3">{t("fh.form")}</div>
                  <div className="space-y-3">
                    {svc.fields.map((f) => (
                      <div key={f.id}>
                        <label className="mono-label mb-1.5 block">
                          {fieldLabel(f)}{f.required && <span className="text-blood"> *</span>}
                        </label>
                        {(f.type === "text" || f.type === "number") && (
                          <input
                            className="inp"
                            type={f.type === "number" ? "number" : "text"}
                            inputMode={f.type === "number" ? "numeric" : undefined}
                            value={fields[f.id] || ""}
                            onChange={(e) => changeField(f.id, e.target.value)}
                            placeholder={fieldPh(f)}
                          />
                        )}
                        {f.type === "textarea" && (
                          <textarea
                            className="inp min-h-[110px] resize-y"
                            value={fields[f.id] || ""}
                            onChange={(e) => changeField(f.id, e.target.value)}
                            placeholder={fieldPh(f)}
                          />
                        )}
                        {f.type === "file" && (
                          <div>
                            <label className="btn-ghost inline-flex cursor-pointer px-3.5 py-2.5 text-[10px]">
                              <Icon name="box" size={13} />
                              {t("fh.file")}
                              <input
                                type="file"
                                multiple
                                accept="image/*,.pdf,.txt,.log,.doc,.docx"
                                className="hidden"
                                onChange={(e) => onFiles(e.target.files)}
                              />
                            </label>
                            {attachments.map((a) => (
                              <div key={a.log.id} className="mt-2 flex items-center gap-2 border border-acid/30 bg-acid/5 px-3 py-2 font-mono text-[9px] text-acid">
                                <Icon name="shieldCheck" size={12} />
                                <span className="min-w-0 flex-1 truncate">{a.log.safeName}</span>
                                <span className="shrink-0">{t("fh.scan.ok")}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  {draftSaved && (
                    <div className="mt-3 flex items-center justify-between gap-2 font-mono text-[9px] text-mute">
                      <span className="flex items-center gap-1.5"><Icon name="lock" size={11} className="text-acid" />{t("fh.draft")}</span>
                      <button
                        onClick={() => { if (secId && svcId) clearDraft(secId, svcId); setFields({}); setDraftSaved(false); }}
                        className="text-mute hover:text-blood"
                      >
                        {t("fh.draftClear")}
                      </button>
                    </div>
                  )}
                </div>

                {/* ═══ الشرح الإضافي الطويل — زر منسدل تحت الحقول ═══ */}
                {svc.extra && (
                  <div>
                    <button
                      onClick={() => setExtraOpen((v) => !v)}
                      className={`btn-ghost w-full py-2.5 ${extraOpen ? "!border-acid/50 !text-acid" : ""}`}
                    >
                      <Icon name="book" size={13} />
                      {t("fh.extra")}
                      <Icon name="chevron" size={12} className={extraOpen ? "rotate-180 transition-transform" : "transition-transform"} />
                    </button>
                    {extraOpen && (
                      <div className="panel animate-fade-up mt-2">
                        <div className="mono-label flex items-center justify-between border-b border-line px-4 py-2.5">
                          <span>◈ {t("fh.extraTitle")}</span>
                          <button onClick={() => setExtraOpen(false)} className="flex items-center gap-1 text-mute transition-colors hover:text-acid">
                            <Icon name="close" size={11} />
                            {t("c.close")}
                          </button>
                        </div>
                        <p className="p-4 text-xs leading-loose text-mute">{pick(lang, svc.extra)}</p>
                      </div>
                    )}
                  </div>
                )}

                {err && (
                  <div className="flex items-center gap-2 border border-blood/40 bg-blood/10 px-3 py-2 text-xs text-blood">
                    <Icon name="warn" size={13} />
                    {t("fh.required")}
                  </div>
                )}

                <button onClick={submit} className="btn-primary w-full">
                  <Icon name="send" size={16} />
                  📤 {t("fh.send")}
                </button>

                {/* معاينة الرسالة المؤرخة + نسخ + القناة المشفرة */}
                {message && (
                  <div className="panel animate-fade-up">
                    <div className="mono-label border-b border-line px-4 py-2.5">{t("fh.preview")}</div>
                    <pre className="max-h-64 overflow-auto whitespace-pre-wrap p-4 font-mono text-[11px] leading-6 text-fog/90" dir="auto">
                      {message}
                    </pre>
                    <div className="grid gap-2 border-t border-line p-3 sm:grid-cols-2">
                      <button
                        onClick={async () => { if (await copyText(message)) { setCopied(true); toast(t("fh.copied")); } }}
                        className="btn-acid py-2.5 text-[10px]"
                      >
                        <Icon name={copied ? "check" : "link"} size={12} />
                        {copied ? t("fh.copied") : t("fh.copy")}
                      </button>
                      <button
                        onClick={() => {
                          // يُبنى الرابط لحظة الضغط فقط — لا يوزر في DOM
                          window.open(buildWebFallback(message), "_blank", "noreferrer");
                        }}
                        className="btn-primary"
                      >
                        <Icon name="plane" size={15} />
                        {t("fh.openRelay")}
                      </button>
                    </div>
                  </div>
                )}

                {/* سجل المرفقات (IndexedDB) */}
                {logs.length > 0 && (
                  <div className="border border-line bg-panel p-3">
                    <div className="mono-label mb-2">{t("fh.attachLog")}</div>
                    {logs.map((l) => (
                      <div key={l.id} className="flex items-center justify-between gap-2 border-b border-line/50 py-1.5 font-mono text-[9px] text-mute last:border-0">
                        <span className="truncate">{l.safeName}</span>
                        <span className="text-acid">EXIF STRIPPED · {l.at}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </Shell>
  );
}

/** [تفاصيل] — قائمة منسدلة مرتبة مع زر إغلاق ✕ */
function DetailsPanel({
  title,
  open,
  onToggle,
  items,
}: {
  title: string;
  open: boolean;
  onToggle: () => void;
  items: { name: L; desc: L }[];
}) {
  const t = useT();
  const lang = useLang();
  return (
    <div className="mt-4">
      <button
        onClick={onToggle}
        className={`btn-ghost w-full py-2.5 ${open ? "!border-acid/50 !text-acid" : ""}`}
      >
        <Icon name="book" size={13} />
        {title}
        <Icon name="chevron" size={12} className={open ? "rotate-180 transition-transform" : "transition-transform"} />
      </button>
      {open && (
        <div className="panel animate-fade-up mt-2">
          <div className="mono-label flex items-center justify-between border-b border-line px-4 py-2.5">
            <span>◈ {title}</span>
            <button onClick={onToggle} className="flex items-center gap-1 text-mute transition-colors hover:text-acid">
              <Icon name="close" size={11} />
              {t("c.close")}
            </button>
          </div>
          <div className="divide-y divide-line">
            {items.map((it, i) => (
              <div key={i} className="flex gap-3 px-4 py-3">
                <span className="shrink-0 font-mono text-[10px] font-bold text-blood">{String(i + 1).padStart(2, "0")}</span>
                <div className="min-w-0">
                  <div className="text-sm font-bold">{pick(lang, it.name)}</div>
                  <p className="mt-1 text-xs leading-relaxed text-mute">{pick(lang, it.desc)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/** زر خدمة أنيق + زر [📖 عرض تفاصيل الخدمة] تحته */
function ServiceButton({ s, onClick }: { s: ServiceDef; onClick: () => void }) {
  const t = useT();
  const lang = useLang();
  return (
    <button onClick={onClick} className="panel panel-hover corners group flex flex-col gap-2 p-3 text-start">
      <div className="flex items-center gap-2.5">
        <Icon name={s.icon} size={16} className="shrink-0 text-violet transition-colors group-hover:text-acid" />
        <span className="line-clamp-2 text-[11px] font-bold leading-snug sm:text-xs">{pick(lang, s.name)}</span>
      </div>
      <span className="w-full border border-line bg-abyss/60 px-2 py-1 text-center font-mono text-[9px] text-mute transition-colors group-hover:border-acid/50 group-hover:text-acid">
        {t("fh.serviceInfo")}
      </span>
    </button>
  );
}
