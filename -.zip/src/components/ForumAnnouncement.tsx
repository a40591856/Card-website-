"use client";

import { useState } from "react";
import {
  FORUM_ANNOUNCEMENT,
  FORUM_ANNOUNCE_MESSAGE,
  FORUM_ANNOUNCE_BUTTON,
  FORUM_ANNOUNCE_TITLE,
} from "@/lib/announcements";
import { dispatchToTelegram, relayHandle } from "@/lib/forumClient";
import { useT, useLang, toast } from "@/lib/client";
import { pick } from "@/lib/site";
import { Icon } from "./Icon";

/**
 * [ 📢 إعلان المنتدى لجميع الزوار ]
 * زر واحد بارز → قائمة منسدلة بالشرح الكامل + [التوجه للوسيط] + [❌ إغلاق]
 * الوسيط @Caesar12R مخفي تماماً (يُبنى الرابط لحظة الضغط فقط).
 */
export default function ForumAnnouncement() {
  const t = useT();
  const lang = useLang();
  const [open, setOpen] = useState(false);

  const toManager = () => {
    void dispatchToTelegram(FORUM_ANNOUNCE_MESSAGE, relayHandle());
    toast(t("fa.copied"));
  };

  return (
    <div>
      <button
        onClick={() => setOpen((v) => !v)}
        className={`btn-primary w-full ${open ? "!bg-acid2" : ""}`}
      >
        <Icon name="megaphone" size={17} />
        {pick(lang, FORUM_ANNOUNCE_BUTTON)}
        <Icon
          name="chevron"
          size={13}
          className={open ? "rotate-180 transition-transform" : "transition-transform"}
        />
      </button>

      {open && (
        <div className="panel animate-fade-up mt-2 border-acid/50 shadow-[0_0_30px_rgba(184,239,128,0.12)]">
          {/* ترويسة */}
          <div className="mono-label flex items-center justify-between gap-2 border-b border-line px-4 py-2.5 text-acid">
            <span className="flex items-center gap-2">
              <Icon name="megaphone" size={13} />
              ◈ {pick(lang, FORUM_ANNOUNCE_TITLE)}
            </span>
            <button
              onClick={() => setOpen(false)}
              className="flex items-center gap-1 text-mute transition-colors hover:text-acid"
            >
              <Icon name="close" size={11} />
              {t("fa.close")}
            </button>
          </div>

          {/* نص الإعلان */}
          <div className="max-h-[440px] overflow-y-auto whitespace-pre-line border-b border-line p-4 text-xs leading-loose text-fog/90 sm:text-[13px]">
            {pick(lang, FORUM_ANNOUNCEMENT)}
          </div>

          {/* أزرار التحكم */}
          <div className="grid grid-cols-2 gap-2 p-3">
            <button onClick={toManager} className="btn-acid py-3 text-[11px]">
              <Icon name="plane" size={14} />
              {t("fa.toManager")}
            </button>
            <button onClick={() => setOpen(false)} className="btn-ghost py-3 text-[11px]">
              <Icon name="close" size={14} />
              ❌ {t("fa.close")}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
