"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useT, useLang, addToCart, toast, api, fmtMoney } from "@/lib/client";
import { ProductRow, pName, pDesc } from "@/lib/types";
import { BLACKMART_TRUST, BRANDS, pick, type CardCatDef } from "@/lib/site";
import { Icon } from "./Icon";

/**
 * نافذة التفاصيل (Focus & Fullscreen) — محمية بتشويش Blur
 * + صندوق Black Mart بإطار أحمر متحرك + منع النسخ قبل الشراء
 */
export default function CardDetailsModal({
  p,
  cat,
  onClose,
}: {
  p: ProductRow;
  cat: CardCatDef;
  onClose: () => void;
}) {
  const t = useT();
  const lang = useLang();
  const router = useRouter();
  const [revealed, setRevealed] = useState(false);
  const [imgErr, setImgErr] = useState(false);

  useEffect(() => {
    try {
      const seen: number[] = JSON.parse(sessionStorage.getItem("bm_viewed") || "[]");
      if (!seen.includes(p.id)) {
        seen.push(p.id);
        sessionStorage.setItem("bm_viewed", JSON.stringify(seen));
        api("/api/products", { method: "POST", body: JSON.stringify({ view: p.id }) }).catch(() => {});
      }
    } catch {
      /* noop */
    }
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [p.id, onClose]);

  const bal = (v: string) => (v === "{BAL}" ? `${p.balanceUsd.toLocaleString()} USD` : v);

  const trust = (l: { ar: string; en?: string; ru?: string }) => pick(lang, l);

  return (
    <div className="fixed inset-0 z-[65] flex flex-col bg-void" role="dialog" aria-modal>
      <div className="grid-bg pointer-events-none absolute inset-0" />
      <div className="vignette pointer-events-none absolute inset-0" />

      {/* ترويسة */}
      <div className="relative z-10 flex items-center justify-between border-b border-line bg-void/90 px-4 py-3">
        <span className="mono-label flex items-center gap-2">
          <span className="inline-block h-1.5 w-1.5 animate-blink rounded-full bg-blood" />
          FOCUS MODE :: {p.slug.toUpperCase()}
        </span>
        <button onClick={onClose} className="btn-icon" aria-label={t("c.close")}>
          <Icon name="close" size={16} />
        </button>
      </div>

      {/* المحتوى */}
      <div className="relative z-10 flex-1 overflow-y-auto">
        <div className="mx-auto w-full max-w-2xl p-4 sm:p-6">
          {/* الصورة + الاسم */}
          <div className="relative overflow-hidden border border-line">
            {!imgErr ? (
              <img
                src={p.img || cat.productImg}
                alt=""
                onError={() => setImgErr(true)}
                className="h-44 w-full object-cover opacity-90 sm:h-60"
              />
            ) : (
              <div className="grid-bg-fine flex h-44 w-full items-center justify-center sm:h-60">
                <Icon name="card" size={70} className="text-dim" />
              </div>
            )}
            <div className={`h-[3px] w-full ${cat.kind === "injected" ? "bg-gradient-to-l from-acid via-acid/60 to-transparent" : "bg-gradient-to-l from-blood via-blood/60 to-transparent"}`} />
            {p.verified && (
              <span className="absolute top-3 start-3 inline-flex items-center gap-1.5 border border-acid/50 bg-void/85 px-2 py-1 font-mono text-[10px] tracking-widest text-acid">
                <Icon name="shieldCheck" size={12} />
                {t("p.verified")}
              </span>
            )}
          </div>

          <div className="mono-label mt-4">{pick(lang, cat.sub)}</div>
          <h2 className="mt-1 text-2xl font-bold leading-snug sm:text-3xl">{pName(p, lang)}</h2>

          <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2">
            {p.balanceUsd > 0 && (
              <span className="flex items-center gap-2 font-mono text-sm text-acid">
                <span className="inline-block h-2 w-2 animate-pulse-soft rounded-full bg-acid" />
                <span dir="ltr">{t("mkt.balance")} ${p.balanceUsd.toLocaleString()}</span>
              </span>
            )}
            <span className="flex items-baseline gap-2.5">
              {p.oldPriceUsd > 0 && (
                <span className="font-mono text-lg text-blood line-through" dir="ltr">${p.oldPriceUsd.toLocaleString()}</span>
              )}
              <span className="font-mono text-3xl font-bold text-acid text-glow" dir="ltr">{fmtMoney(p.priceUsd)}</span>
            </span>
          </div>

          <p className="mt-3 text-sm leading-loose text-mute">{pDesc(p, lang)}</p>

          {/* صندوق البيانات المحمي */}
          <div
            className="mt-5 border border-line bg-abyss"
            onCopy={(e) => {
              if (!revealed) e.preventDefault();
            }}
          >
            <div className="flex items-center justify-between gap-2 border-b border-line px-4 py-2.5">
              <span className="mono-label">{pick(lang, cat.detailTitle)}</span>
              <button
                onClick={() => setRevealed((v) => !v)}
                className={`btn-ghost px-3 py-1.5 text-[9px] ${revealed ? "!border-acid/50 !text-acid" : ""}`}
              >
                <Icon name={revealed ? "eye" : "lock"} size={11} />
                {revealed ? t("cards.hideData") : t("cards.reveal")}
              </button>
            </div>

            <p className="border-b border-line/60 p-4 text-xs leading-loose text-mute">{pick(lang, cat.intro)}</p>

            {cat.sections.map((s) => (
              <div key={s.title} className="border-b border-line/60 p-4 last:border-0">
                <div className="mono-label mb-2.5 flex items-center gap-1.5">
                  <Icon name={s.icon} size={12} className="text-dim" />
                  {s.title}
                </div>
                <div className="grid grid-cols-1 gap-x-5 sm:grid-cols-2">
                  {s.lines.map((l) => (
                    <div key={l.k} className="flex items-center justify-between gap-3 border-b border-line/40 py-1.5 last:border-0">
                      <span className="shrink-0 font-mono text-[10px] text-mute">{l.k}</span>
                      <span
                        dir="ltr"
                        className={`truncate text-end font-mono text-[10px] transition-all duration-300 ${
                          revealed ? "select-auto text-fog" : "select-none text-fog/80 blur-[3px]"
                        }`}
                      >
                        {bal(l.v)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}

            {!revealed && (
              <div className="flex items-center gap-2 border-t border-line px-4 py-2.5 font-mono text-[10px] text-amber">
                <Icon name="warn" size={12} />
                {t("cards.nocopy")}
              </div>
            )}
          </div>

          {/* ملحقات الطلب */}
          {cat.extras.length > 0 && (
            <div className="mt-4 border border-line bg-panel p-4">
              <div className="mono-label mb-2.5">ORDER ATTACHMENTS</div>
              <ul className="space-y-2">
                {cat.extras.map((x, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs leading-relaxed text-mute">
                    <Icon name="check" size={11} className="mt-0.5 shrink-0 text-acid" />
                    {pick(lang, x)}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* صندوق Black Mart — إطار أحمر متحرك */}
          <div className="red-frame mt-5 border border-blood/70 bg-abyss p-4 sm:p-5">
            <div className="flex items-center justify-center gap-2 text-center">
              <Icon name="shieldCheck" size={16} className="text-blood" />
              <h3 className="text-sm font-bold">{trust(BLACKMART_TRUST.title1)}</h3>
            </div>
            <ul className="mt-3 space-y-2">
              {BLACKMART_TRUST.why.map((x, i) => (
                <li key={i} className="flex items-start gap-2 text-xs leading-relaxed text-mute">
                  <Icon name="check" size={11} className="mt-0.5 shrink-0 text-acid" />
                  {trust(x)}
                </li>
              ))}
            </ul>
            <div className="my-4 h-px bg-line" />
            <div className="flex items-center justify-center gap-2 text-center">
              <Icon name="shield" size={14} className="text-blood" />
              <h3 className="text-sm font-bold">{trust(BLACKMART_TRUST.title2)}</h3>
            </div>
            <ul className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
              {BLACKMART_TRUST.features.map((x, i) => (
                <li key={i} className="flex items-start gap-2 text-xs leading-relaxed text-mute">
                  <Icon name="check" size={11} className="mt-0.5 shrink-0 text-acid" />
                  {trust(x)}
                </li>
              ))}
            </ul>
            <div className="my-4 h-px bg-line" />
            {/* شريط العلامات التجارية */}
            <div className="flex flex-wrap items-center justify-center gap-2">
              {BRANDS.map((b) => (
                <span key={b} className="border border-line bg-void px-3 py-1 font-mono text-[9px] tracking-widest text-mute">
                  {b}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* شريط أزرار ثابت */}
      <div className="relative z-10 border-t border-line bg-void/95 p-3 backdrop-blur-md">
        <div className="mx-auto grid max-w-2xl grid-cols-3 gap-2">
          <button onClick={() => router.push(`/pay?buy=${p.id}`)} className="btn-primary !h-11 !px-2 !text-xs sm:!h-12 sm:!text-sm">
            {t("p.continue")}
          </button>
          <button
            onClick={() => {
              addToCart(p.id);
              toast(t("p.added"));
              onClose();
            }}
            className="btn-acid !h-11 !px-2 !text-[10px] sm:!h-12 sm:!text-xs"
          >
            <Icon name="cart" size={14} />
            <span className="hidden sm:inline">{t("nav.cart")}</span>
          </button>
          <button onClick={onClose} className="btn-ghost !h-11 !px-2 !text-[10px] sm:!h-12 sm:!text-xs">
            <Icon name="close" size={14} />
            <span className="hidden sm:inline">{t("c.close")}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
