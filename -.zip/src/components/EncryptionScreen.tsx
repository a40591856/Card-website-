"use client";

import { useEffect, useRef, useState } from "react";
import { ENC_DURATION_MS } from "@/lib/site";
import { useT, useLang, tArr, hex, prefersReducedMotion } from "@/lib/client";
import { Icon } from "./Icon";

/** المرحلة 1.5 — شاشة التشفير: عبارات متحركة + شريط 0→100 خلال 5 ثوانٍ */
export default function EncryptionScreen({ onDone }: { onDone: () => void }) {
  const t = useT();
  const lang = useLang();
  const lines = tArr(lang, "enc.lines");
  const [shown, setShown] = useState<string[]>([]);
  const [progress, setProgress] = useState(0);
  const [hexLine, setHexLine] = useState(() => hex(64));
  const doneRef = useRef(false);

  useEffect(() => {
    const reduce = prefersReducedMotion();
    const dur = reduce ? 1200 : ENC_DURATION_MS;

    // كتابتها تسلسلية
    let li = 0;
    let t1: number | undefined;
    const typeLine = () => {
      if (li >= lines.length) return;
      li++;
      setShown(lines.slice(0, li));
      t1 = window.setTimeout(typeLine, reduce ? 40 : 430);
    };
    typeLine();

    // الشريط: 0 → 100
    const ticks = Math.max(2, Math.round(dur / 50));
    let c = 0;
    const iv = window.setInterval(() => {
      c++;
      setProgress(Math.min(100, Math.round((c / ticks) * 100)));
      setHexLine(hex(64));
      if (c >= ticks) {
        window.clearInterval(iv);
        if (!doneRef.current) {
          doneRef.current = true;
          window.setTimeout(onDone, reduce ? 120 : 650);
        }
      }
    }, 50);

    return () => {
      window.clearInterval(iv);
      window.clearTimeout(t1);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const full = progress >= 100;

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden grid-bg px-5">
      <div className="pointer-events-none absolute inset-0 vignette" />
      <div className="pointer-events-none absolute inset-0 scanlines opacity-60" />
      <div className="pointer-events-none absolute inset-0 noise" />
      <div className="pointer-events-none absolute inset-x-0 h-10 animate-scanbar bg-gradient-to-b from-transparent via-acid/10 to-transparent" />

      <div className="relative z-10 w-full max-w-2xl">
        {/* ترويسة */}
        <div className="mb-6 flex items-center justify-between font-mono text-[10px] tracking-[0.3em] text-dim">
          <span className="flex items-center gap-2">
            <Icon name="terminal" size={14} />
            SECURE-BOOT
          </span>
          <span className="flex items-center gap-2">
            <span className="inline-block h-1.5 w-1.5 animate-blink rounded-full bg-acid" />
            {full ? "COMPLETE" : "LINKING"}
          </span>
        </div>

        {/* نافذة طرفية: العبارات المتحركة */}
        <div className="panel">
          <div className="flex items-center gap-1.5 border-b border-line px-4 py-2.5">
            <span className="h-2.5 w-2.5 rounded-full bg-blood/70" />
            <span className="h-2.5 w-2.5 rounded-full bg-amber/70" />
            <span className="h-2.5 w-2.5 rounded-full bg-acid/70" />
            <span className="mono-label ms-3">decrypt.log</span>
          </div>
          <div className="min-h-[168px] p-4 font-mono text-[12px] leading-6 text-dim sm:text-[13px]">
            {shown.map((l, i) => (
              <div key={i} className={i === shown.length - 1 && !full ? "text-acid" : ""}>
                {l}
                {i === shown.length - 1 && !full && <span className="animate-blink">▌</span>}
              </div>
            ))}
            {full && (
              <div className="text-acid">
                {t("enc.done")}
                <span className="animate-blink">▌</span>
              </div>
            )}
          </div>
        </div>

        {/* النسبة */}
        <div className="mt-6 flex items-end justify-between">
          <div className="font-mono text-5xl font-extrabold tracking-tight text-acid text-glow sm:text-6xl">
            {progress}
            <span className="text-2xl text-dim">%</span>
          </div>
          <div className="pb-2 text-end font-mono text-[10px] leading-4 tracking-[0.2em] text-mute">
            <div>{t("enc.title")}</div>
            <div className="mt-1 opacity-70">{t("enc.sub")}</div>
          </div>
        </div>

        {/* الشريط */}
        <div className="mt-3 h-2.5 w-full border border-line2/60 bg-abyss p-[2px]">
          <div
            className="h-full bg-acid shadow-[0_0_16px_rgba(0,255,136,0.6)] transition-[width] duration-75"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* تيار سداسي */}
        <div className="mt-4 break-all font-mono text-[10px] leading-4 tracking-[0.18em] text-mute/70">
          {hexLine}
        </div>
      </div>
    </div>
  );
}
