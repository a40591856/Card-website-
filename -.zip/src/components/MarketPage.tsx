"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { MARKET_SECTIONS, MARKET_NAME, pick } from "@/lib/site";
import { useT, useLang } from "@/lib/client";
import { Icon } from "./Icon";
import Shell from "./Shell";
import Decryption from "./Decryption";

/**
 * السوق — المستوى الأول
 * 7 أقسام: [صورة مصغرة] + [اسم عريض] + [شريط أحمر نحيف] + [دخول]
 * + زر [تفاصيل الأقسام] منسدل مع ✕
 */
const MARKET_ABOUT = {
  ar: "سبعة أقسام تخصصية، كل قسم صفحة كاملة منفصلة بفهرس فروع خاص. المنتجات معروضات برصيد أخضر وسعر قديم مشطوب وسعر جديد مميز وثلاثة أزرار فورية: تفاصيل، سلة، شراء.",
  en: "Seven specialized sections, each a full separate page with its own branch index. Products show a green balance, struck old price, featured new price, and three instant buttons: Details, Cart, Buy.",
  ru: "Семь специализированных разделов, каждый — отдельная полная страница со своим индексом ветвей. Товары с зелёным балансом, старой зачёркнутой ценой и тремя кнопками: детали, корзина, купить.",
};

export default function MarketPage() {
  const t = useT();
  const lang = useLang();
  const router = useRouter();
  const [details, setDetails] = useState(false);

  return (
    <Shell>
      <div className="space-y-5 pt-4">
        <button onClick={() => router.push("/")} className="btn-ghost px-3.5 py-2">
          <Icon name="back" size={13} className="rtl:rotate-180" />
          {t("c.home")}
        </button>

        {/* Hero */}
        <header className="panel corners relative overflow-hidden">
          <img src="/images/ads/ad-1.jpg" alt="" className="absolute inset-0 h-full w-full object-cover opacity-25" />
          <div className="absolute inset-0 bg-gradient-to-t from-void via-void/75 to-void/30" />
          <div className="grid-bg-fine absolute inset-0 opacity-50" />
          <div className="relative p-5 sm:p-8">
            <div className="mono-label mb-3 flex items-center gap-2">
              <span className="inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full bg-blood" />
              // SECURE MARKET · 07 SECTIONS
            </div>
            <h1 className="display-2 font-bold">
              <Decryption text={pick(lang, MARKET_NAME)} />
            </h1>
            <p className="mt-3 max-w-2xl text-sm leading-relaxed text-mute sm:text-base">
              {pick(lang, MARKET_ABOUT)}
            </p>
          </div>
        </header>

        {/* الأقسام السبعة — 2×2 هاتف / 3×3 كمبيوتر */}
        <section>
          <div className="mono-label mb-3">// {t("mkt.branches")} · 07</div>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
            {MARKET_SECTIONS.map((s) => (
              <Link
                key={s.id}
                href={`/market/${s.id}`}
                className="panel panel-hover corners group flex flex-col overflow-hidden text-start"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={s.thumb}
                    alt=""
                    className="h-24 w-full object-cover opacity-80 transition-transform duration-500 group-hover:scale-105 sm:h-32"
                    loading="lazy"
                  />
                  <span className="absolute top-2 end-2 border border-blood/50 bg-void/85 px-1.5 py-0.5 font-mono text-[10px] font-bold text-blood">
                    {s.code}
                  </span>
                </div>
                <div className="h-[3px] w-full bg-gradient-to-l from-blood via-blood/60 to-transparent" />
                <div className="flex flex-1 flex-col p-3 sm:p-4">
                  <div className="text-sm font-bold leading-snug sm:text-base">{pick(lang, s.name)}</div>
                  <div className="mt-1.5 font-mono text-[9px] tracking-[0.2em] text-mute/70">
                    BR::{String(s.branches.length).padStart(2, "0")}
                    {s.filter ? " · FILTER×3" : ""}
                  </div>
                  <div className="btn-acid mt-3 w-full !py-2 text-[10px]">{t("c.enter")}</div>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* [تفاصيل الأقسام] */}
        <div>
          <button
            onClick={() => setDetails((v) => !v)}
            className={`btn-ghost w-full py-2.5 ${details ? "!border-acid/50 !text-acid" : ""}`}
          >
            <Icon name="book" size={13} />
            {t("mkt.detailsAll")}
            <Icon name="chevron" size={12} className={details ? "rotate-180 transition-transform" : "transition-transform"} />
          </button>
          {details && (
            <div className="panel animate-fade-up mt-2">
              <div className="mono-label flex items-center justify-between border-b border-line px-4 py-2.5">
                <span>◈ {t("mkt.detailsAll")}</span>
                <button
                  onClick={() => setDetails(false)}
                  className="flex items-center gap-1 text-mute hover:text-acid"
                >
                  <Icon name="close" size={11} />
                  {t("c.close")}
                </button>
              </div>
              <div className="divide-y divide-line">
                {MARKET_SECTIONS.map((s) => (
                  <div key={s.id} className="flex gap-3 px-4 py-3">
                    <span className="font-mono text-[10px] font-bold text-blood">{s.code}</span>
                    <div className="min-w-0">
                      <div className="text-sm font-bold">{pick(lang, s.name)}</div>
                      <p className="mt-1 text-xs leading-relaxed text-mute">{pick(lang, s.desc)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </Shell>
  );
}
