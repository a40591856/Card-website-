"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  ARSENAL_SECTIONS,
  arsenalOrderMessage,
  type ArsenalTool,
  type ArsenalSection,
} from "@/lib/arsenal";
import { BUY_MANAGER, pick } from "@/lib/site";
import { dispatchToTelegram } from "@/lib/forumClient";
import { useT, useLang, toast } from "@/lib/client";
import { Icon } from "./Icon";
import Shell from "./Shell";

type Cart = Record<string, number>;

const ALL_TOOLS: ArsenalTool[] = ARSENAL_SECTIONS.flatMap((s) => s.tools);
const toolById = (id: string) => ALL_TOOLS.find((x) => x.id === id);

/** ═══ الترسانة — SPA كامل بلا إعادة تحميل ═══ */
export default function ArsenalHub() {
  const t = useT();
  const lang = useLang();
  const router = useRouter();

  const [secId, setSecId] = useState<string | null>(null);
  const [modal, setModal] = useState<ArsenalTool | null>(null);
  const [cart, setCart] = useState<Cart>({});
  const [cartOpen, setCartOpen] = useState(false);

  /* رابط عميق ?sec=... من البحث الذكي */
  useEffect(() => {
    const s = new URLSearchParams(window.location.search).get("sec");
    if (s && ARSENAL_SECTIONS.some((x) => x.id === s)) setSecId(s);
  }, []);

  const sec: ArsenalSection | undefined = secId
    ? ARSENAL_SECTIONS.find((s) => s.id === secId)
    : undefined;

  const openSection = (id: string) => {
    setSecId(id);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const back = () => {
    if (modal) {
      setModal(null);
    } else if (secId) {
      setSecId(null);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      router.push("/");
    }
  };

  /* ═══ الشراء: نسخ + توجيه للمسؤول ═══ */
  const buy = useCallback(
    (tool: ArsenalTool, qty = 1) => {
      const msg = arsenalOrderMessage([
        {
          name: pick(lang, tool.name),
          price: tool.priceUsd,
          desc: pick(lang, tool.desc),
          qty,
        },
      ]);
      void dispatchToTelegram(msg, BUY_MANAGER);
      toast(t("ars.copied"));
    },
    [lang, t],
  );

  const addCart = (id: string, qty = 1) => {
    setCart((c) => ({ ...c, [id]: (c[id] || 0) + qty }));
    toast(t("p.added"));
  };

  const cartItems = Object.entries(cart)
    .map(([id, qty]) => ({ tool: toolById(id), qty }))
    .filter((x): x is { tool: ArsenalTool; qty: number } => !!x.tool);
  const cartCount = cartItems.reduce((a, x) => a + x.qty, 0);
  const cartTotal = cartItems.reduce((a, x) => a + x.tool.priceUsd * x.qty, 0);

  const sendCart = () => {
    if (cartItems.length === 0) return;
    const msg = arsenalOrderMessage(
      cartItems.map((x) => ({
        name: pick(lang, x.tool.name),
        price: x.tool.priceUsd,
        desc: pick(lang, x.tool.desc),
        qty: x.qty,
      })),
    );
    void dispatchToTelegram(msg, BUY_MANAGER);
    toast(t("ars.copied"));
    setCartOpen(false);
  };

  /* نافذة التفاصيل: ESC + قفل التمرير */
  useEffect(() => {
    if (!modal) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setModal(null);
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [modal]);

  return (
    <Shell>
      <div className="space-y-4 pt-4">
        {/* ═══ Header ثابت بأسماء الأقسام العشرة ═══ */}
        <div className="sticky top-[96px] z-20 -mx-3 border-b border-line bg-void/90 px-3 py-2 backdrop-blur-md sm:-mx-5 sm:px-5">
          <div className="flex items-center gap-2.5">
            <button onClick={back} className="btn-ghost shrink-0 px-3 py-1.5 text-[9px]">
              <Icon name="back" size={11} className="rtl:rotate-180" />
              🔙 {secId ? t("ars.back") : t("c.home")}
            </button>
            <span className="mono-label hidden sm:block">ARSENAL :: {String(ARSENAL_SECTIONS.length).padStart(2, "0")} SECTIONS</span>
            <span className="ms-auto font-mono text-[9px] tracking-wider text-blood">
              {sec ? `${sec.tools.length} TOOLS` : t("ars.dashboard")}
            </span>
          </div>
          <div className="no-scrollbar -mx-1 mt-2 flex gap-1.5 overflow-x-auto px-1">
            {ARSENAL_SECTIONS.map((s) => (
              <button
                key={s.id}
                onClick={() => openSection(s.id)}
                className={`shrink-0 border px-3 py-1.5 font-mono text-[10px] font-bold tracking-wider transition-all ${
                  secId === s.id
                    ? "border-blood bg-blood text-void shadow-[0_0_16px_rgba(232,123,125,0.35)]"
                    : "border-line bg-abyss/60 text-mute hover:border-line2 hover:text-fog"
                }`}
              >
                {pick(lang, s.short)}
              </button>
            ))}
          </div>
        </div>

        {/* ═══ Dashboard: شبكة الأقسام العشرة ═══ */}
        {!sec && (
          <section>
            <div className="mono-label mb-3">// {t("ars.dashboard")} · {String(ARSENAL_SECTIONS.length).padStart(2, "0")}</div>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
              {ARSENAL_SECTIONS.map((s, i) => (
                <button
                  key={s.id}
                  onClick={() => openSection(s.id)}
                  className="glass glass-hover corners group flex flex-col overflow-hidden text-start"
                >
                  <div className="relative h-20 overflow-hidden sm:h-28">
                    <img
                      src={s.img}
                      alt=""
                      loading="lazy"
                      decoding="async"
                      className="h-full w-full object-cover opacity-70 transition-transform duration-500 group-hover:scale-105"
                    />
                    <span className="absolute top-2 end-2 border border-blood/50 bg-void/85 px-1.5 py-0.5 font-mono text-[9px] font-bold text-blood">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="absolute bottom-2 start-2 border border-acid/40 bg-void/85 px-1.5 py-0.5 font-mono text-[9px] text-acid" dir="ltr">
                      {s.tools.length} TOOLS
                    </span>
                  </div>
                  <div className="h-[3px] w-full bg-gradient-to-l from-blood via-blood/60 to-transparent" />
                  <div className="flex flex-1 flex-col p-3">
                    <div className="text-[13px] font-bold leading-snug sm:text-sm">{pick(lang, s.name)}</div>
                    <p className="mt-1 line-clamp-2 text-[10px] leading-relaxed text-mute sm:text-[11px]">{pick(lang, s.desc)}</p>
                    <div className="btn-acid mt-3 w-full !py-2 text-[10px]">{t("c.enter")}</div>
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* ═══ محتوى القسم: شبكة الأدوات ═══ */}
        {sec && (
          <div key={sec.id} className="animate-fade-up space-y-4">
            <header className="glass relative overflow-hidden p-5 sm:p-7">
              <img src={sec.img} alt="" className="absolute inset-0 h-full w-full object-cover opacity-20" loading="lazy" />
              <div className="relative">
                <div className="mono-label mb-2 flex items-center gap-2 text-blood">
                  <span className="inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full bg-blood" />
                  ARSENAL :: {sec.id.toUpperCase()}
                </div>
                <h1 className="display-2 font-bold">{pick(lang, sec.name)}</h1>
                <p className="mt-2 max-w-2xl text-sm leading-relaxed text-mute">{pick(lang, sec.desc)}</p>
                <div className="mt-3 font-mono text-[10px] tracking-[0.25em] text-mute/70">
                  {t("ars.tools")} :: {String(sec.tools.length).padStart(2, "0")}
                </div>
              </div>
            </header>

            {/* Desktop 3×2 / Mobile 2×2 */}
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
              {sec.tools.map((tool) => (
                <ArsenalToolCard
                  key={tool.id}
                  tool={tool}
                  onDetails={() => setModal(tool)}
                  onBuy={(q) => buy(tool, q)}
                  onAdd={(q) => addCart(tool.id, q)}
                />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ═══ زر الرجوع العائم ═══ */}
      {secId && (
        <button
          onClick={back}
          title={t("ars.back")}
          aria-label={t("ars.back")}
          className="glass glass-hover fixed bottom-16 start-4 z-40 flex h-11 w-11 items-center justify-center border-blood/50 text-blood"
        >
          <Icon name="back" size={18} className="rtl:rotate-180" />
        </button>
      )}

      {/* ═══ زر السلة العائمة + العدّاد ═══ */}
      {cartCount > 0 && (
        <button
          onClick={() => setCartOpen((v) => !v)}
          title={t("ars.cart")}
          aria-label={t("ars.cart")}
          className="glass glass-hover fixed bottom-16 end-4 z-40 flex h-11 w-11 items-center justify-center border-acid/50 text-acid"
        >
          <Icon name="cart" size={18} />
          <span className="absolute -top-1 -end-1 flex h-4 min-w-4 items-center justify-center bg-acid px-1 font-mono text-[9px] font-bold text-void">
            {cartCount}
          </span>
        </button>
      )}

      {/* ═══ درج السلة ═══ */}
      {cartOpen && cartCount > 0 && (
        <div className="glass fixed bottom-28 end-4 z-[55] w-[min(92vw,340px)] p-3 shadow-[0_24px_60px_-20px_rgba(0,0,0,0.9)]">
          <div className="mb-2 flex items-center gap-2 border-b border-line pb-2">
            <Icon name="cart" size={14} className="text-acid" />
            <span className="mono-label flex-1">{t("ars.cart")}</span>
            <button onClick={() => setCartOpen(false)} className="text-mute hover:text-fog" aria-label={t("c.close")}>
              <Icon name="close" size={14} />
            </button>
          </div>
          <div className="max-h-56 space-y-2 overflow-auto">
            {cartItems.map(({ tool, qty }) => (
              <div key={tool.id} className="flex items-center gap-2 border border-line bg-abyss/60 p-2">
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[11px] font-bold">{pick(lang, tool.name)}</div>
                  <div className="font-mono text-[10px] text-blood">${tool.priceUsd * qty}</div>
                </div>
                <button
                  onClick={() => setCart((c) => ({ ...c, [tool.id]: Math.max(0, c[tool.id] - 1) }))}
                  className="flex h-7 w-7 items-center justify-center border border-line text-mute hover:text-fog"
                >
                  <Icon name="minus" size={10} />
                </button>
                <span className="w-5 text-center font-mono text-xs">{qty}</span>
                <button
                  onClick={() => setCart((c) => ({ ...c, [tool.id]: c[tool.id] + 1 }))}
                  className="flex h-7 w-7 items-center justify-center border border-line text-mute hover:text-fog"
                >
                  <Icon name="plus" size={10} />
                </button>
              </div>
            ))}
          </div>
          <div className="mt-3 flex items-center justify-between border-t border-line pt-2">
            <span className="mono-label">{t("ars.total")}</span>
            <span className="font-mono text-lg font-bold text-blood">${cartTotal}</span>
          </div>
          <button onClick={sendCart} className="btn-acid mt-3 w-full py-2.5 text-[10px]">
            <Icon name="send" size={12} />
            {t("ars.sendCart")}
          </button>
        </div>
      )}

      {/* ═══ نافذة التفاصيل (Modal) ═══ */}
      {modal && (
        <div className="fixed inset-0 z-[65] flex items-center justify-center p-4" role="dialog" aria-modal>
          <div className="absolute inset-0 bg-void/85 backdrop-blur-sm" onClick={() => setModal(null)} />
          <div className="glass animate-fade-up relative w-full max-w-lg">
            <div className="flex items-center justify-between border-b border-line px-4 py-3">
              <span className="mono-label">{t("ars.details")} :: DETAIL MODAL</span>
              <button onClick={() => setModal(null)} className="btn-icon h-8 w-8" aria-label={t("c.close")}>
                <Icon name="close" size={15} />
              </button>
            </div>
            <div className="grid-bg-fine flex h-40 items-center justify-center border-b border-line">
              <Icon name={modal.icon} size={64} className="text-violet drop-shadow-[0_0_18px_rgba(163,139,243,0.45)]" />
            </div>
            <div className="h-[3px] w-full bg-gradient-to-l from-blood via-blood/60 to-transparent" />
            <div className="p-5">
              {modal.highlight && (
                <span className="mb-2 inline-block border border-violet/50 bg-violet/10 px-2 py-0.5 font-mono text-[9px] tracking-widest text-violet">
                  ★ {t("ars.highlight")}
                </span>
              )}
              <h2 className="text-xl font-bold sm:text-2xl">{pick(lang, modal.name)}</h2>
              <p className="mt-2 text-sm leading-relaxed text-mute">{pick(lang, modal.desc)}</p>
              <div className="mt-3 font-mono text-2xl font-bold text-blood neon-red">${modal.priceUsd}</div>
              <div className="mt-4 max-h-44 overflow-auto border border-line bg-abyss/60 p-4">
                <div className="mono-label mb-2">{t("ars.tech")}</div>
                <p className="text-xs leading-loose text-fog/85">{pick(lang, modal.details)}</p>
              </div>
              <div className="mt-5 grid grid-cols-2 gap-2">
                <button
                  onClick={() => { buy(modal); setModal(null); }}
                  className="btn-primary"
                >
                  <Icon name="cart" size={15} />
                  {t("ars.buy")}
                </button>
                <button
                  onClick={() => { addCart(modal.id); setModal(null); }}
                  className="btn-acid"
                >
                  <Icon name="plus" size={14} />
                  {t("ars.add")}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </Shell>
  );
}

/** ═══ بطاقة المنتج الزجاجية ═══ */
function ArsenalToolCard({
  tool,
  onDetails,
  onBuy,
  onAdd,
}: {
  tool: ArsenalTool;
  onDetails: () => void;
  onBuy: (qty: number) => void;
  onAdd: (qty: number) => void;
}) {
  const t = useT();
  const lang = useLang();
  const [qty, setQty] = useState(1);

  return (
    <div className={`glass glass-hover flex flex-col overflow-hidden ${tool.highlight ? "!border-violet/60 shadow-[0_0_30px_rgba(163,139,243,0.18)]" : ""}`}>
      {/* الأعلى: أيقونة المنتج */}
      <div className="relative flex h-20 shrink-0 items-center justify-center bg-black/30 sm:h-24">
        <Icon name={tool.icon} size={34} className="text-violet drop-shadow-[0_0_14px_rgba(163,139,243,0.4)]" />
        {tool.highlight && (
          <span className="absolute top-2 start-2 border border-violet/50 bg-void/80 px-1.5 py-0.5 font-mono text-[8px] tracking-widest text-violet">
            ★ {t("ars.highlight")}
          </span>
        )}
      </div>
      <div className="h-[3px] w-full shrink-0 bg-gradient-to-l from-blood via-blood/60 to-transparent" />

      <div className="flex min-h-0 flex-1 flex-col p-2.5 sm:p-3">
        {/* الاسم → الوصف → السعر */}
        <h3 className="line-clamp-2 text-[11px] font-bold leading-snug sm:text-[13px]">{pick(lang, tool.name)}</h3>
        <p className="mt-1 line-clamp-2 text-[10px] leading-relaxed text-mute sm:text-[11px]">{pick(lang, tool.desc)}</p>
        <div className="mt-2 font-mono text-base font-bold text-blood neon-red sm:text-lg">${tool.priceUsd}</div>

        {/* شريط علوي: تفاصيل 👁 */}
        <button onClick={onDetails} className="btn-ghost mt-3 w-full !py-1.5 !text-[9px]">
          <Icon name="eye" size={11} />
          👁 {t("ars.details")}
        </button>

        {/* شريط سفلي: شراء + سلة + عدّاد */}
        <div className="mt-2 flex items-center gap-1">
          <button onClick={() => onBuy(qty)} className="btn-acid h-8 flex-1 !px-1 !text-[9px]">
            {t("ars.buy")}
          </button>
          <button
            onClick={() => { onAdd(qty); setQty(1); }}
            className="btn-ghost h-8 !px-1.5 !text-[9px]"
            title={t("ars.add")}
          >
            <Icon name="cart" size={11} />
          </button>
          <div className="flex h-8 shrink-0 items-center border border-line bg-abyss/60">
            <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="flex h-full w-6 items-center justify-center text-mute hover:text-fog" aria-label="-">
              <Icon name="minus" size={9} />
            </button>
            <span className="w-5 text-center font-mono text-[10px]" dir="ltr">{qty}</span>
            <button onClick={() => setQty((q) => Math.min(99, q + 1))} className="flex h-full w-6 items-center justify-center text-mute hover:text-fog" aria-label="+">
              <Icon name="plus" size={9} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
