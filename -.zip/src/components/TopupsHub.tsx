"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  TOPUP_SECTIONS,
  THREE_HOUR_WARNING,
  CUSTOM_REQUEST_NOTE,
  CUSTOM_REQUEST_MESSAGE,
  packageOrderMessage,
  visualToolMessage,
  visualPackageMessage,
  audioToolMessage,
  unitPrice,
  type TopupPackage,
  type TopupApp,
  type TopupSection,
} from "@/lib/topup";
import { BUY_MANAGER, pick, type L } from "@/lib/site";
import { copyText, dispatchToTelegram, buildWebFallback } from "@/lib/forumClient";
import { useT, useLang, toast } from "@/lib/client";
import { Icon } from "./Icon";
import Shell from "./Shell";
import SectionToolCTA from "./SectionToolCTA";

const A = (ar: string, en = ar): L => ({ ar, en });
type Cart = Record<string, number>;

const LB = {
  sections: A("الأقسام", "Sections"),
  home: A("🌐 العودة للرئيسية", "🌐 Back to main"),
  apps: A("التطبيقات", "Apps"),
  packages: A("الباقات", "Packages"),
  details: A("تفاصيل", "Details"),
  charge: A("🛒 اشحن الآن ⚡", "🛒 Charge now ⚡"),
  cart: A("السلة", "Cart"),
  addCart: A("إضافة للسلة", "Add to cart"),
  buy: A("شراء", "Buy"),
  total: A("الإجمالي", "Total"),
  sendCart: A("إرسال طلب السلة", "Send cart order"),
  preview: A("معاينة الرسالة", "Message preview"),
  copy: A("نسخ الرسالة", "Copy message"),
  open: A("فتح المحادثة", "Open chat"),
  close: A("إغلاق", "Close"),
  guide: A("دليل القسم", "Section guide"),
  all: A("الكل", "All"),
  visualTool: A("⚙️ أداة الشحن المرئي", "⚙️ Visual top-up tool"),
  audioTool: A("⚙️ أداة الشحن الذكي الموحدة", "⚙️ Smart custom top-up tool"),
  app: A("اختيار التطبيق", "Choose app"),
  pkg: A("اختيار الباقة", "Choose package"),
  user: A("يوزر الحساب", "Username"),
  pass: A("كلمة المرور", "Password"),
  id: A("الـ ID (رقم هوية المستخدم)", "User ID"),
  userPass: A("اليوزر / الباسورد", "Username / Password"),
  qty: A("الكمية المطلوبة", "Quantity"),
  price: A("السعر (تلقائي)", "Price (auto)"),
  complete: A("🚀 إكمال الشحن", "🚀 Complete top-up"),
  pkgNote: A("⚠️ تنبيه هام لاختيار الباقة: يرجى اختيار الباقة المطلوبة مباشرة من القائمة المنسدلة أعلاه. لا يمكن تنفيذ أي طلبات خارج الباقات المحددة. تأكد من اختيار الباقة المناسبة بدقة قبل الإكمال.", "⚠️ Pick the package directly from the list. No requests outside the listed packages."),
  qtyNote: A("⚠️ تنبيه: اختر التطبيق المطلوب، ثم أدخل كمية شحن أكبر من كمية الباقة الأساسية المعروضة للتطبيق. (سيتم احتساب السعر تلقائياً بناءً على سعر الباقة الأساسية).", "⚠️ Pick the app, then enter a quantity greater than its base package. Price is computed from the base unit price."),
  qtyErr: A("يجب أن تكون الكمية أكبر من الباقة الأساسية", "Quantity must exceed the base package"),
  required: A("أكمل جميع الحقول قبل الإرسال", "Fill all fields before sending"),
  balance: A("الرصيد", "Balance"),
  warning: A("⚠️ تنبيه أمني هام (قاعدة الـ 3 ساعات)", "⚠️ 3-hour security rule"),
};

/** ═══ APP TOP-UP VAULT — شحن التطبيقات ═══ */
export default function TopupsHub() {
  const t = useT();
  const lang = useLang();
  const router = useRouter();

  const [section, setSection] = useState<"visual" | "audio" | null>(null);
  const [visualApp, setVisualApp] = useState<string | null>(null);
  const [audioApp, setAudioApp] = useState<string>("all");
  const [modal, setModal] = useState<TopupPackage | null>(null);
  const [orderPkg, setOrderPkg] = useState<TopupPackage | null>(null);
  const [cart, setCart] = useState<Cart>({});
  const [cartOpen, setCartOpen] = useState(false);
  const [relay, setRelay] = useState("");
  const [copied, setCopied] = useState(false);
  const [guideOpen, setGuideOpen] = useState(false);

  useEffect(() => {
    const s = new URLSearchParams(window.location.search).get("b");
    if (s === "u-audio" || s === "audio") setSection("audio");
    else if (s === "u-video" || s === "visual") setSection("visual");
  }, []);

  useEffect(() => {
    if (!modal) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setModal(null);
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", onKey); document.body.style.overflow = ""; };
  }, [modal]);

  const sec = section ? TOPUP_SECTIONS.find((s) => s.id === section) : undefined;
  const app = sec && visualApp ? sec.apps.find((a) => a.id === visualApp) : undefined;

  const send = useCallback((msg: string) => {
    void copyText(msg);
    void dispatchToTelegram(msg, BUY_MANAGER);
    setRelay(msg);
    setCopied(true);
    toast(t("fa.copied"));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [t]);

  const buy = (p: TopupPackage) => {
    const isVisual = TOPUP_SECTIONS.find((s) => s.id === "visual")?.apps.some((a) => a.id === p.app);
    if (isVisual) { setOrderPkg(p); return; }   // TOOL-09: نافذة جمع البيانات
    const a = TOPUP_SECTIONS.flatMap((s) => s.apps).find((x) => x.id === p.app);
    send(packageOrderMessage(p, a?.name.ar || p.app));
  };
  const addCart = (id: string) => { setCart((c) => ({ ...c, [id]: (c[id] || 0) + 1 })); toast(t("p.added")); };

  const all = useMemo(() => TOPUP_SECTIONS.flatMap((s) => s.apps.flatMap((a) => a.packages.map((p) => ({ p, a })))), []);
  const cartItems = Object.entries(cart)
    .map(([id, qty]) => ({ ...all.find((x) => x.p.id === id), qty }))
    .filter((x): x is { p: TopupPackage; a: TopupApp; qty: number } => !!x.p);
  const cartCount = cartItems.reduce((a, x) => a + x.qty, 0);
  const cartTotal = cartItems.reduce((a, x) => a + x.p.priceUsd * x.qty, 0);

  const sendCart = () => {
    if (!cartItems.length) return;
    send([
      "⚡ طلب شحن جديد (سلة)",
      cartItems.map((x) => `• ${x.p.name.ar} × ${x.qty} — ${x.p.priceUsd * x.qty}$`).join("\n"),
      `💵 السعر: ${cartTotal}$`,
      "الرجاء تزويدي بمحفظة الدفع لإتمام العملية فوراً.",
    ].join("\n"));
    setCartOpen(false);
  };

  const open = (id: "visual" | "audio") => {
    setSection(id); setVisualApp(null); setAudioApp("all"); setGuideOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const back = () => {
    if (modal) setModal(null);
    else if (visualApp) setVisualApp(null);
    else if (section) { setSection(null); router.replace("/market/topup"); window.scrollTo({ top: 0, behavior: "smooth" }); }
    else router.push("/market");
  };

  /* التطبيقات/الباقات الظاهرة */
  const audioAppsToShow = sec?.id === "audio"
    ? (audioApp === "all" ? sec.apps : sec.apps.filter((a) => a.id === audioApp))
    : [];
  const shownPackages: { p: TopupPackage; a: TopupApp }[] = sec?.id === "audio"
    ? audioAppsToShow.flatMap((a) => a.packages.slice(0, 1).map((p) => ({ p, a })))
    : app ? app.packages.map((p) => ({ p, a: app })) : [];

  return (
    <Shell>
      <div className="space-y-5 pb-28 pt-4">
        {/* ═══ شريط علوي ثابت ═══ */}
        <div className="sticky top-[96px] z-20 -mx-3 border-b border-line bg-void/95 px-3 py-2 backdrop-blur-md sm:-mx-5 sm:px-5">
          <div className="flex flex-wrap items-center gap-2">
            <button onClick={back} className="btn-ghost shrink-0 px-3 py-1.5 text-[9px]">
              <Icon name="back" size={11} className="rtl:rotate-180" />{pick(lang, LB.home)}
            </button>
            <span className="ms-auto font-mono text-[9px] tracking-widest text-acid">
              {sec ? `${sec.apps.length} APPS` : "02 SECTIONS"}
            </span>
          </div>
          {sec && (
            <div className="no-scrollbar -mx-1 mt-2 flex gap-1.5 overflow-x-auto px-1">
              <button onClick={open.bind(null, "visual")}
                className={`shrink-0 border px-3 py-1.5 font-mono text-[10px] font-bold ${section === "visual" ? "border-acid bg-acid text-void" : "border-line bg-abyss/60 text-mute"}`}>مرئية</button>
              <button onClick={open.bind(null, "audio")}
                className={`shrink-0 border px-3 py-1.5 font-mono text-[10px] font-bold ${section === "audio" ? "border-acid bg-acid text-void" : "border-line bg-abyss/60 text-mute"}`}>صوتية</button>
              {section === "visual" && sec.apps.map((a) => (
                <button key={a.id} onClick={() => setVisualApp(a.id)}
                  className={`shrink-0 border px-3 py-1.5 font-mono text-[10px] font-bold ${visualApp === a.id ? "border-acid bg-acid/10 text-acid" : "border-line bg-abyss/60 text-mute"}`}>{pick(lang, a.short)}</button>
              ))}
              {section === "audio" && (
                <>
                  <button onClick={() => setAudioApp("all")} className={`shrink-0 border px-3 py-1.5 font-mono text-[10px] ${audioApp === "all" ? "border-acid bg-acid/10 text-acid" : "border-line bg-abyss/60 text-mute"}`}>{pick(lang, LB.all)}</button>
                  {sec.apps.map((a) => (
                    <button key={a.id} onClick={() => setAudioApp(a.id)} className={`shrink-0 border px-3 py-1.5 font-mono text-[10px] ${audioApp === a.id ? "border-acid bg-acid/10 text-acid" : "border-line bg-abyss/60 text-mute"}`}>{pick(lang, a.short)}</button>
                  ))}
                </>
              )}
            </div>
          )}
        </div>

        {/* ═══ معاينة الرسالة ═══ */}
        {relay && (
          <div className="panel animate-fade-up">
            <div className="mono-label flex items-center justify-between border-b border-line px-4 py-2.5">
              <span>📤 {pick(lang, LB.preview)}</span><span className="text-acid">✓ {t("op.copied")}</span>
            </div>
            <pre className="max-h-52 overflow-auto whitespace-pre-wrap p-4 font-mono text-[11px] leading-6 text-fog/90" dir="auto">{relay}</pre>
            <div className="grid grid-cols-3 gap-2 border-t border-line p-3">
              <button onClick={async () => { if (await copyText(relay)) toast(t("op.copied")); }} className="btn-ghost py-2 text-[9px]"><Icon name={copied ? "check" : "link"} size={11} />{pick(lang, LB.copy)}</button>
              <button onClick={() => window.open(buildWebFallback(relay, BUY_MANAGER), "_blank", "noreferrer")} className="btn-acid py-2 text-[9px]"><Icon name="plane" size={11} />{pick(lang, LB.open)}</button>
              <button onClick={() => setRelay("")} className="btn-ghost py-2 text-[9px]"><Icon name="close" size={11} />{pick(lang, LB.close)}</button>
            </div>
          </div>
        )}

        {/* ═══ شبكة الأقسام: 2×2 على الهاتف والكمبيوتر ═══ */}
        {!sec && (
          <section>
            <div className="mono-label mb-3">// APP TOP-UP VAULT · 02</div>
            <div className="grid grid-cols-2 gap-3 sm:gap-4">
              {TOPUP_SECTIONS.map((s, i) => (
                <button key={s.id} onClick={() => open(s.id)} className="panel panel-hover corners group flex flex-col overflow-hidden text-start">
                  <div className="relative h-24 overflow-hidden sm:h-40">
                    <img src={s.hero} alt="" loading="lazy" decoding="async" className="h-full w-full object-cover opacity-80 transition-transform duration-500 group-hover:scale-105" />
                    <span className="absolute top-2 end-2 border border-line bg-void/85 px-1.5 py-0.5 font-mono text-[9px] text-acid">{String(i + 1).padStart(2, "0")} · {s.apps.length}</span>
                  </div>
                  <div className="acc-strip h-[3px] w-full" />
                  <div className="flex flex-1 flex-col p-3">
                    <div className="text-[13px] font-bold leading-snug sm:text-base">{pick(lang, s.name)}</div>
                    <p className="mt-1 line-clamp-2 text-[10px] leading-relaxed text-mute sm:text-xs">{pick(lang, s.desc)}</p>
                    <div className="btn-acid mt-3 w-full !py-2 text-[10px]">{t("c.enter")}</div>
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* ═══ محتوى القسم ═══ */}
        {sec && (
          <div key={sec.id} className="animate-fade-up space-y-4">
            <header className="panel relative overflow-hidden p-5 sm:p-7">
              <img src={sec.hero} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-20" />
              <div className="relative">
                <div className="mono-label mb-2 flex items-center gap-2 text-acid"><Icon name="play" size={12} className="acc-lock" />{sec.id.toUpperCase()} :: TOP-UP VAULT</div>
                <h1 className="display-2 font-bold">{pick(lang, sec.name)}</h1>
                <p className="mt-2 max-w-3xl text-sm leading-relaxed text-mute">{pick(lang, sec.desc)}</p>
              </div>
            </header>

            {/* الأداة المخصّصة داخل القسم نفسه */}
            <SectionToolCTA
              label={sec.id === "visual" ? A("⚙️ أداة الشحن المرئي — اختيار الباقة") : A("⚙️ أداة الشحن الذكي — كمية مخصصة")}
              hint={A("الأداة موجودة هنا داخل القسم: أدخل بياناتك وسيُحتسب السعر تلقائياً ويُوجَّه الطلب للمسؤول.")}
              badge={sec.id === "visual" ? "2 APPS" : "9 APPS"}
            />

            {/* دليل القسم */}
            <div>
              <button onClick={() => setGuideOpen((v) => !v)} className={`btn-ghost w-full py-2.5 ${guideOpen ? "!border-acid/50 !text-acid" : ""}`}>
                <Icon name="book" size={13} />{pick(lang, sec.guideTitle)}
                <Icon name="chevron" size={12} className={guideOpen ? "rotate-180 transition-transform" : "transition-transform"} />
              </button>
              {guideOpen && (
                <div className="panel animate-fade-up mt-2">
                  <div className="mono-label flex items-center justify-between border-b border-line px-4 py-2.5"><span>◈ {pick(lang, LB.guide)}</span><button onClick={() => setGuideOpen(false)} className="flex items-center gap-1 text-mute hover:text-acid"><Icon name="close" size={11} />{pick(lang, LB.close)}</button></div>
                  <ul className="space-y-2 p-4">{sec.guide.map((g, i) => <li key={i} className="flex items-start gap-2 text-xs leading-relaxed text-mute"><Icon name="check" size={11} className="mt-0.5 shrink-0 text-acid" />{pick(lang, g)}</li>)}</ul>
                </div>
              )}
            </div>

            {/* المرئي: بطاقتا التطبيق قبل الاختيار */}
            {sec.id === "visual" && !visualApp && (
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                {sec.apps.map((a) => (
                  <button key={a.id} onClick={() => setVisualApp(a.id)} className="panel panel-hover corners group flex flex-col overflow-hidden text-start">
                    <div className="relative h-32 overflow-hidden sm:h-40"><img src={a.img} alt="" loading="lazy" className="h-full w-full object-cover opacity-80 transition-transform duration-500 group-hover:scale-105" /></div>
                    <div className="acc-strip h-[3px] w-full" />
                    <div className="flex flex-1 flex-col p-4">
                      <div className="text-base font-bold">{pick(lang, a.name)}</div>
                      <p className="mt-1 text-xs text-mute">{pick(lang, a.desc)}</p>
                      <div className="btn-acid mt-3 w-full !py-2 text-[10px]">{t("c.enter")}</div>
                    </div>
                  </button>
                ))}
              </div>
            )}

            {/* الباقات 2×2 / 3×3 */}
            {shownPackages.length > 0 && (
              <>
                <div className="mono-label">// {visualApp ? pick(lang, app?.name ?? LB.packages) : pick(lang, LB.packages)} · {String(shownPackages.length).padStart(2, "0")}</div>
                <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
                  {shownPackages.map(({ p, a }) => (
                    <PackageCard key={p.id} p={p} a={a} onBuy={() => buy(p)} onCart={() => addCart(p.id)} onDetails={() => setModal(p)} />
                  ))}
                </div>
              </>
            )}

            {/* أداة الشحن */}
            <div id="custom-tool" className="acc-cta-panel scroll-mt-32">
              {sec.id === "visual" && <VisualTool section={sec} onSend={send} />}
              {sec.id === "audio" && <AudioTool section={sec} onSend={send} />}
            </div>
          </div>
        )}
      </div>

      {/* ═══ الملاحظة الثابتة تحت كل الأقسام ═══ */}
      <div className="fixed inset-x-0 bottom-12 z-30 border-t border-line bg-void/95 px-3 py-2 backdrop-blur-md">
        <div className="mx-auto flex max-w-[1190px] flex-wrap items-center gap-2">
          <Icon name="warn" size={13} className="shrink-0 text-amber" />
          <p className="min-w-0 flex-1 text-[10px] leading-relaxed text-mute sm:text-[11px]">{pick(lang, CUSTOM_REQUEST_NOTE)}</p>
          <button onClick={() => send(CUSTOM_REQUEST_MESSAGE)} className="btn-acid shrink-0 !py-1.5 !text-[9px]">
            <Icon name="plane" size={11} />راسل المسؤول
          </button>
        </div>
      </div>

      {/* أزرار عائمة */}
      {section && (
        <button onClick={back} title={pick(lang, LB.home)} aria-label={pick(lang, LB.home)} className="glass glass-hover fixed bottom-24 start-4 z-40 flex h-11 w-11 items-center justify-center border-acid/50 text-acid">
          <Icon name="back" size={18} className="rtl:rotate-180" />
        </button>
      )}
      {cartCount > 0 && (
        <button onClick={() => setCartOpen((v) => !v)} className="glass glass-hover fixed bottom-24 end-4 z-40 flex h-11 w-11 items-center justify-center border-acid/50 text-acid">
          <Icon name="cart" size={18} />
          <span className="absolute -top-1 -end-1 flex h-4 min-w-4 items-center justify-center bg-acid px-1 font-mono text-[9px] font-bold text-void">{cartCount}</span>
        </button>
      )}
      {cartOpen && cartCount > 0 && (
        <div className="panel fixed bottom-36 end-4 z-[55] w-[min(92vw,340px)] p-3 shadow-[0_24px_60px_-20px_rgba(0,0,0,0.9)]">
          <div className="mb-2 flex items-center gap-2 border-b border-line pb-2"><Icon name="cart" size={14} className="text-acid" /><span className="mono-label flex-1">{pick(lang, LB.cart)}</span><button onClick={() => setCartOpen(false)} className="text-mute hover:text-fog"><Icon name="close" size={14} /></button></div>
          <div className="max-h-56 space-y-2 overflow-auto">
            {cartItems.map(({ p, qty }) => (
              <div key={p.id} className="flex items-center gap-2 border border-line bg-abyss/60 p-2">
                <div className="min-w-0 flex-1"><div className="truncate text-[11px] font-bold">{pick(lang, p.name)}</div><div className="font-mono text-[10px] text-acid">${p.priceUsd * qty}</div></div>
                <button onClick={() => setCart((c) => ({ ...c, [p.id]: Math.max(0, c[p.id] - 1) }))} className="flex h-7 w-7 items-center justify-center border border-line text-mute"><Icon name="minus" size={10} /></button>
                <span className="w-5 text-center font-mono text-xs">{qty}</span>
                <button onClick={() => setCart((c) => ({ ...c, [p.id]: c[p.id] + 1 }))} className="flex h-7 w-7 items-center justify-center border border-line text-mute"><Icon name="plus" size={10} /></button>
              </div>
            ))}
          </div>
          <div className="mt-3 flex items-center justify-between border-t border-line pt-2"><span className="mono-label">{pick(lang, LB.total)}</span><span className="font-mono text-lg font-bold text-acid">${cartTotal}</span></div>
          <button onClick={sendCart} className="btn-acid mt-3 w-full py-2.5 text-[10px]"><Icon name="send" size={12} />{pick(lang, LB.sendCart)}</button>
        </div>
      )}

      {modal && <DetailModal p={modal} onClose={() => setModal(null)} onBuy={() => { buy(modal); setModal(null); }} onCart={() => { addCart(modal.id); setModal(null); }} />}
      {orderPkg && <VisualOrderModal p={orderPkg} onClose={() => setOrderPkg(null)} onSend={(m) => { send(m); setOrderPkg(null); }} />}
    </Shell>
  );
}

/** ═══ TOOL-09: نافذة جمع بيانات شحن الباقة المرئية ═══ */
function VisualOrderModal({ p, onClose, onSend }: {
  p: TopupPackage; onClose: () => void; onSend: (m: string) => void;
}) {
  const lang = useLang();
  const visual = TOPUP_SECTIONS.find((s) => s.id === "visual")!;
  const initialApp = visual.apps.find((a) => a.id === p.app) ?? visual.apps[0];
  const [appId, setAppId] = useState(initialApp.id);
  const [pkgId, setPkgId] = useState(p.id);
  const [id, setId] = useState("");
  const [pass, setPass] = useState("");
  const [err, setErr] = useState(false);
  const app = visual.apps.find((a) => a.id === appId) ?? visual.apps[0];
  const pkg = app.packages.find((x) => x.id === pkgId) ?? app.packages[0];

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", onKey); document.body.style.overflow = ""; };
  }, [onClose]);

  const submit = () => {
    if (!id.trim() || !pass.trim()) { setErr(true); return; }
    onSend(visualPackageMessage({
      app: app.name.ar || "", pkg: pkg.name.ar || "", qty: pkg.balance.ar || "",
      price: pkg.priceUsd, id: id.trim(), pass: pass.trim(),
    }));
    setId(""); setPass(""); setErr(false);  // تصفير آلي
  };

  return (
    <div className="fixed inset-0 z-[66] flex items-center justify-center p-4" role="dialog" aria-modal>
      <div className="absolute inset-0 bg-void/85 backdrop-blur-sm" onClick={onClose} />
      <div className="panel animate-fade-up relative w-full max-w-md p-5">
        <div className="mb-3 flex items-center justify-between">
          <span className="mono-label">⚡ طلب شحن تطبيق مرئي</span>
          <button onClick={onClose} className="btn-icon h-8 w-8"><Icon name="close" size={14} /></button>
        </div>
        <div className="space-y-3">
          <div><label className="mono-label mb-1.5 block">اختيار التطبيق</label>
            <select className="inp" value={appId} onChange={(e) => { const a = visual.apps.find((x) => x.id === e.target.value)!; setAppId(e.target.value); setPkgId(a.packages[0].id); }}>
              {visual.apps.map((a) => <option key={a.id} value={a.id}>{pick(lang, a.name)}</option>)}
            </select></div>
          <div><label className="mono-label mb-1.5 block">اختيار الباقة</label>
            <select className="inp" value={pkgId} onChange={(e) => setPkgId(e.target.value)}>
              {app.packages.map((x) => <option key={x.id} value={x.id}>{pick(lang, x.name)} — {x.priceUsd}$</option>)}
            </select></div>
          <div><label className="mono-label mb-1.5 block">الـ ID (رقم هوية المستخدم)</label>
            <input className="inp" dir="ltr" value={id} onChange={(e) => { setId(e.target.value); setErr(false); }} placeholder="123456789" /></div>
          <div><label className="mono-label mb-1.5 block">الباسورد (بيانات الدخول)</label>
            <input className="inp" dir="ltr" type="password" value={pass} onChange={(e) => { setPass(e.target.value); setErr(false); }} placeholder="••••••••" /></div>
          <div className="flex items-center justify-between border border-acid/30 bg-acid/5 px-3 py-2">
            <span className="mono-label">السعر</span><span className="font-mono text-lg font-bold text-acid">{pkg.priceUsd}$</span>
          </div>
          {err && <p className="text-xs text-blood">أكمل جميع الحقول الإجبارية</p>}
          <button onClick={submit} className="btn-acid w-full py-2.5"><Icon name="send" size={13} />🚀 إكمال الشحن</button>
        </div>
      </div>
    </div>
  );
}

/* ═══════════ بطاقة الباقة ═══════════ */
function PackageCard({ p, a, onBuy, onCart, onDetails }: {
  p: TopupPackage; a: TopupApp; onBuy: () => void; onCart: () => void; onDetails: () => void;
}) {
  const lang = useLang();
  const [err, setErr] = useState(false);
  return (
    <div className="panel panel-hover corners group flex h-full flex-col overflow-hidden">
      <div className="relative h-24 overflow-hidden sm:h-28">
        {!err ? <img src={p.img} alt="" loading="lazy" onError={() => setErr(true)} className="h-full w-full object-cover opacity-85 transition-transform duration-500 group-hover:scale-105" />
          : <div className="grid-bg-fine flex h-full w-full items-center justify-center"><Icon name="play" size={34} className="text-dim" /></div>}
        <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-void/80 to-transparent" />
        {p.featured && <span className="absolute top-2 start-2 border border-acid/50 bg-void/85 px-1.5 py-0.5 font-mono text-[8px] text-acid">★ HOT</span>}
      </div>
      <div className="acc-strip h-[3px] w-full" />
      <div className="flex min-h-0 flex-1 flex-col p-2.5 sm:p-3">
        <h3 className="line-clamp-2 text-[11px] font-bold leading-snug sm:text-[13px]">{pick(lang, p.name)}</h3>
        <p className="mt-1 line-clamp-2 text-[10px] leading-relaxed text-mute sm:text-[11px]">{pick(lang, p.desc)}</p>
        <div className="mt-1.5 font-mono text-[9px] text-acid">💰 {pick(lang, LB.balance)}: {pick(lang, p.balance)}</div>
        <div className="mt-1 flex flex-wrap gap-1">{p.badges.map((b) => <span key={b} className="border border-line2/60 bg-abyss/70 px-1.5 py-0.5 font-mono text-[8px] tracking-wider text-mute">{b}</span>)}</div>
        <div className="mt-auto pt-2">
          <div className="flex items-baseline gap-2">
            <span className="font-mono text-[10px] text-mute/70 line-through" dir="ltr">${p.oldPriceUsd}</span>
            <span className="font-mono text-lg font-bold text-acid text-glow sm:text-xl" dir="ltr">${p.priceUsd}</span>
          </div>
          <div className="mt-2 grid grid-cols-2 gap-1.5">
            <button onClick={onBuy} className="btn-acid !px-1 !py-2 !text-[9px]">{pick(lang, LB.charge)}</button>
            <button onClick={onDetails} className="btn-ghost !px-1 !py-2 !text-[9px]"><Icon name="eye" size={10} />{pick(lang, LB.details)}</button>
          </div>
          <button onClick={onCart} className="btn-ghost mt-1.5 w-full !px-1 !py-1.5 !text-[9px]"><Icon name="cart" size={10} />{pick(lang, LB.addCart)}</button>
        </div>
      </div>
    </div>
  );
}

/* ═══════════ نافذة التفاصيل ═══════════ */
function DetailModal({ p, onClose, onBuy, onCart }: {
  p: TopupPackage; onClose: () => void; onBuy: () => void; onCart: () => void;
}) {
  const lang = useLang();
  const [err, setErr] = useState(false);
  return (
    <div className="fixed inset-0 z-[65] flex items-center justify-center p-4" role="dialog" aria-modal>
      <div className="absolute inset-0 bg-void/85 backdrop-blur-sm" onClick={onClose} />
      <div className="panel animate-fade-up relative flex max-h-[88vh] w-full max-w-xl flex-col">
        <div className="flex items-center justify-between border-b border-line px-4 py-3">
          <span className="mono-label">ℹ️ {pick(lang, LB.details)} :: PACKAGE</span>
          <button onClick={onClose} className="btn-icon h-8 w-8"><Icon name="close" size={15} /></button>
        </div>
        <div className="flex-1 overflow-y-auto">
          <div className="relative h-44 sm:h-56">
            {!err ? <img src={p.img} alt="" onError={() => setErr(true)} className="h-full w-full object-cover opacity-85" />
              : <div className="grid-bg-fine flex h-full w-full items-center justify-center"><Icon name="play" size={64} className="text-dim" /></div>}
          </div>
          <div className="acc-strip h-[3px] w-full" />
          <div className="p-5">
            <h2 className="text-xl font-bold sm:text-2xl">{pick(lang, p.name)}</h2>
            <p className="mt-2 text-sm leading-relaxed text-mute">{pick(lang, p.desc)}</p>
            <div className="mt-2 font-mono text-xs text-acid">💰 {pick(lang, LB.balance)}: {pick(lang, p.balance)}</div>
            <div className="mt-3 flex items-baseline gap-3">
              <span className="font-mono text-base text-mute/70 line-through" dir="ltr">${p.oldPriceUsd}</span>
              <span className="font-mono text-3xl font-bold text-acid text-glow" dir="ltr">${p.priceUsd}</span>
            </div>
            <div className="mt-4 border border-blood/50 bg-blood/10 p-4">
              <div className="mb-2 flex items-center gap-2 text-sm font-bold text-blood"><Icon name="warn" size={14} />{pick(lang, LB.warning)}</div>
              <ul className="space-y-2">
                {THREE_HOUR_WARNING.slice(1).map((w, i) => <li key={i} className="flex items-start gap-2 text-xs leading-relaxed text-fog/90"><Icon name="warn" size={10} className="mt-0.5 shrink-0 text-blood" />{pick(lang, w)}</li>)}
              </ul>
            </div>
            <div className="mt-4 border border-line bg-abyss/60 p-4">
              <div className="mono-label mb-2">📜 تفاصيل الباقة</div>
              <p className="whitespace-pre-line text-xs leading-loose text-fog/90">{pick(lang, p.details)}</p>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 border-t border-line p-3">
          <button onClick={onBuy} className="btn-primary"><Icon name="cart" size={15} />{pick(lang, LB.charge)}</button>
          <button onClick={onCart} className="btn-acid"><Icon name="plus" size={14} />{pick(lang, LB.addCart)}</button>
        </div>
      </div>
    </div>
  );
}

/* ═══════════ أداة الشحن المرئي ═══════════ */
function VisualTool({ section, onSend }: { section: TopupSection; onSend: (m: string) => void }) {
  const lang = useLang();
  const [appId, setAppId] = useState(section.apps[0].id);
  const [pkgId, setPkgId] = useState(section.apps[0].packages[0].id);
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");
  const [err, setErr] = useState(false);

  const app = section.apps.find((a) => a.id === appId) ?? section.apps[0];
  const packages = app.packages;
  const pkg = packages.find((p) => p.id === pkgId) ?? packages[0];

  const switchApp = (id: string) => {
    const a = section.apps.find((x) => x.id === id) ?? section.apps[0];
    setAppId(id);
    setPkgId(a.packages[0].id);  // فلترة الباقات تلقائياً
    setErr(false);
  };

  const submit = () => {
    if (!user.trim() || !pass.trim()) { setErr(true); return; }
    onSend(visualToolMessage({ app: app.name.ar || "", pkg: pkg.name.ar || "", price: pkg.priceUsd, user: user.trim(), pass: pass.trim() }));
    setUser(""); setPass(""); setPkgId(packages[0].id); setErr(false); // Clear()
  };

  return (
    <div className="panel p-4">
      <div className="mono-label mb-2 flex items-center gap-2 text-acid"><Icon name="tool" size={12} />{pick(lang, LB.visualTool)}</div>
      <p className="mb-3 flex items-start gap-2 border border-amber/30 bg-amber/5 p-3 text-xs leading-relaxed text-fog/90"><Icon name="warn" size={12} className="mt-0.5 shrink-0 text-amber" />{pick(lang, LB.pkgNote)}</p>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div>
          <label className="mono-label mb-1.5 block">{pick(lang, LB.app)}</label>
          <select className="inp" value={appId} onChange={(e) => switchApp(e.target.value)}>
            {section.apps.map((a) => <option key={a.id} value={a.id}>{pick(lang, a.name)}</option>)}
          </select>
        </div>
        <div>
          <label className="mono-label mb-1.5 block">{pick(lang, LB.pkg)}</label>
          <select className="inp" value={pkgId} onChange={(e) => setPkgId(e.target.value)}>
            {packages.map((p) => <option key={p.id} value={p.id}>{pick(lang, p.name)} — {p.priceUsd}$</option>)}
          </select>
        </div>
        <div>
          <label className="mono-label mb-1.5 block">{pick(lang, LB.user)}</label>
          <input className="inp" dir="ltr" value={user} onChange={(e) => { setUser(e.target.value); setErr(false); }} placeholder="@username" />
        </div>
        <div>
          <label className="mono-label mb-1.5 block">{pick(lang, LB.pass)}</label>
          <input className="inp" dir="ltr" type="password" value={pass} onChange={(e) => { setPass(e.target.value); setErr(false); }} placeholder="••••••••" />
        </div>
        <div className="sm:col-span-2">
          <label className="mono-label mb-1.5 block">{pick(lang, LB.price)}</label>
          <input className="inp font-mono !text-acid" dir="ltr" readOnly value={`${pkg.priceUsd}$`} />
        </div>
      </div>
      {err && <p className="mt-2 flex items-center gap-2 text-xs text-blood"><Icon name="warn" size={12} />{pick(lang, LB.required)}</p>}
      <button onClick={submit} className="btn-acid mt-3 w-full py-3"><Icon name="send" size={14} />{pick(lang, LB.complete)}</button>
    </div>
  );
}

/* ═══════════ أداة الشحن الذكي (الصوتي) ═══════════ */
function AudioTool({ section, onSend }: { section: TopupSection; onSend: (m: string) => void }) {
  const lang = useLang();
  const [appId, setAppId] = useState(section.apps[0].id);
  const [qty, setQty] = useState("");
  const [id, setId] = useState("");
  const [userPass, setUserPass] = useState("");
  const [err, setErr] = useState(false);
  const [qtyErr, setQtyErr] = useState(false);

  const app = section.apps.find((a) => a.id === appId) ?? section.apps[0];
  const base = app.packages[0];
  const qtyNum = Number(qty) || 0;
  const price = Math.round(qtyNum * unitPrice(base) * 100) / 100;
  const tooLow = qty.trim() !== "" && qtyNum <= base.qty;

  const submit = () => {
    if (qtyNum <= base.qty) { setQtyErr(true); return; }
    if (!id.trim() || !userPass.trim()) { setErr(true); return; }
    onSend(audioToolMessage({ app: app.name.ar || "", qty: qtyNum, price, id: id.trim(), userPass: userPass.trim() }));
    setQty(""); setId(""); setUserPass(""); setErr(false); setQtyErr(false); // Clear()
  };

  return (
    <div className="panel p-4">
      <div className="mono-label mb-2 flex items-center gap-2 text-acid"><Icon name="tool" size={12} />{pick(lang, LB.audioTool)}</div>
      <p className="mb-3 flex items-start gap-2 border border-amber/30 bg-amber/5 p-3 text-xs leading-relaxed text-fog/90"><Icon name="warn" size={12} className="mt-0.5 shrink-0 text-amber" />{pick(lang, LB.qtyNote)}</p>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div>
          <label className="mono-label mb-1.5 block">{pick(lang, LB.app)}</label>
          <select className="inp" value={appId} onChange={(e) => { setAppId(e.target.value); setQtyErr(false); }}>
            {section.apps.map((a) => <option key={a.id} value={a.id}>{pick(lang, a.name)} — أساس {a.packages[0].balance.ar}</option>)}
          </select>
        </div>
        <div>
          <label className="mono-label mb-1.5 block">{pick(lang, LB.qty)}</label>
          <input className="inp font-mono" type="number" inputMode="numeric" value={qty} onChange={(e) => { setQty(e.target.value); setQtyErr(false); }} placeholder={String(base.qty + 1)} />
        </div>
        <div>
          <label className="mono-label mb-1.5 block">{pick(lang, LB.id)}</label>
          <input className="inp" dir="ltr" value={id} onChange={(e) => { setId(e.target.value); setErr(false); }} placeholder="123456789" />
        </div>
        <div>
          <label className="mono-label mb-1.5 block">الباسورد (بيانات الدخول)</label>
          <input className="inp" dir="ltr" value={userPass} onChange={(e) => { setUserPass(e.target.value); setErr(false); }} placeholder="user / pass" />
        </div>
        <div className="sm:col-span-2">
          <label className="mono-label mb-1.5 block">{pick(lang, LB.price)}</label>
          <input className="inp font-mono !text-acid" dir="ltr" readOnly value={`${price.toFixed(2)}$`} />
        </div>
      </div>
      {(tooLow || qtyErr) && <p className="mt-2 flex items-center gap-2 text-xs text-blood"><Icon name="warn" size={12} />{pick(lang, LB.qtyErr)} — أساس {pick(lang, base.balance)}</p>}
      {err && <p className="mt-2 flex items-center gap-2 text-xs text-blood"><Icon name="warn" size={12} />{pick(lang, LB.required)}</p>}
      <button onClick={submit} disabled={tooLow} className="btn-acid mt-3 w-full py-3 disabled:opacity-40"><Icon name="send" size={14} />{pick(lang, LB.complete)}</button>
    </div>
  );
}
