"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { CHANNEL_CARDS, CHANNEL_ALERT, CHANNEL_DROPDOWNS } from "@/lib/channelsHub";
import { pick } from "@/lib/site";
import { openExternal, useT, useLang, langDef } from "@/lib/client";
import { Icon } from "./Icon";

/** ═══ القنوات الرسمية ومركز خدمة العملاء — صفحة مستقلة ═══ */
export default function ChannelsPage() {
  const t = useT();
  const lang = useLang();
  const router = useRouter();
  const [open, setOpen] = useState<string | null>(null);

  useEffect(() => {
    document.documentElement.dir = langDef(lang).dir;
    document.documentElement.lang = lang;
  }, [lang]);

  const close = () => {
    if (open) { setOpen(null); return; }
    if (window.history.length > 1) router.back();
    else router.push("/");
  };

  return (
    <div className="min-h-screen bg-void text-fog">
      <div className="grid-bg pointer-events-none fixed inset-0" />
      <div className="vignette pointer-events-none fixed inset-0" />
      <div className="scanlines pointer-events-none fixed inset-0 opacity-30" />

      {/* ═══ 1 — عناصر التحكم ═══ */}
      <div className="sticky top-0 z-30 border-b border-line bg-void/95 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-[1190px] items-center gap-2 px-3 sm:px-5">
          <button onClick={close} className="btn-ghost !py-1.5 !text-[9px]">
            <Icon name="close" size={12} />❌ إغلاق الصفحة
          </button>
          <button onClick={() => router.push("/")} className="btn-ghost !py-1.5 !text-[9px]">
            <Icon name="terminal" size={12} />🏠 الرجوع للصفحة الرئيسية
          </button>
          <span className="ms-auto hidden font-mono text-[9px] tracking-widest text-acid sm:block">OFFICIAL CHANNELS</span>
        </div>
      </div>

      <main className="relative z-10 mx-auto w-full max-w-[900px] space-y-5 px-3 pb-24 pt-8 sm:px-5">
        <header className="text-center">
          <div className="mono-label mb-2 flex items-center justify-center gap-2 text-acid">
            <span className="inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full bg-acid" />
            VERIFIED · OFFICIAL ONLY
          </div>
          <h1 className="display-1 font-mono font-bold tracking-tight">القنوات الرسمية 📢</h1>
          <p className="mt-2 text-sm text-mute">مركز خدمة العملاء وقنوات BLACK MART المعتمدة</p>
        </header>

        {/* ═══ 2 — بطاقات القنوات ═══ */}
        <section className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          {CHANNEL_CARDS.map((card) => (
            <div key={card.id} className="panel panel-hover overflow-hidden">
              {/* البنار */}
              <div className="grid-bg-fine flex h-28 items-center justify-center border-b border-line" style={{ background: `radial-gradient(ellipse at 50% 120%, ${card.color}22, transparent 70%)` }}>
                <div className="flex h-14 w-14 items-center justify-center border" style={{ borderColor: card.color, color: card.color }}>
                  <Icon name={card.icon} size={28} />
                </div>
                <span className="absolute mt-16 text-lg">{card.emoji}</span>
              </div>
              <div className="flex flex-col gap-2 p-4">
                <h3 className="text-sm font-bold leading-snug">{pick(lang, card.title)}</h3>
                <p className="line-clamp-2 text-[11px] leading-relaxed text-mute">{pick(lang, card.desc)}</p>
                <button
                  onClick={() => openExternal(card.url)}
                  className="btn-acid mt-auto w-full !py-2 !text-[10px]"
                >
                  {pick(lang, card.button)}
                </button>
              </div>
            </div>
          ))}
        </section>

        {/* ═══ 3 — التنبيه الأمني ═══ */}
        <div className="border border-blood/50 bg-blood/10 p-4">
          {CHANNEL_ALERT.map((x, i) => (
            <p key={i} className={`text-xs leading-loose ${i === 0 ? "font-bold text-blood" : "text-fog/90"}`}>
              {pick(lang, x)}
            </p>
          ))}
        </div>

        {/* ═══ 4 — القوائم المنسدلة ═══ */}
        <section>
          <div className="mono-label mb-3">// دليل الخدمات</div>
          <div className="space-y-2">
            {CHANNEL_DROPDOWNS.map((d) => {
              const isOpen = open === d.id;
              return (
                <div key={d.id} className="border border-line bg-abyss/60">
                  <button
                    onClick={() => setOpen(isOpen ? null : d.id)}
                    className={`flex w-full items-center gap-2.5 p-3.5 text-start transition-colors ${isOpen ? "text-acid" : "hover:text-fog"}`}
                  >
                    <Icon name={d.icon} size={15} className="shrink-0 text-dim" />
                    <span className="flex-1 text-sm font-bold">{pick(lang, d.label)}</span>
                    <Icon name="chevron" size={13} className={`shrink-0 text-mute transition-transform ${isOpen ? "rotate-180" : ""}`} />
                  </button>
                  {isOpen && (
                    <div className="animate-fade-up border-t border-line">
                      <div className="mono-label flex items-center justify-between border-b border-line px-4 py-2.5">
                        <span>◈ {pick(lang, d.label)}</span>
                        <button onClick={() => setOpen(null)} className="flex items-center gap-1 text-mute hover:text-acid">
                          <Icon name="close" size={11} />❌ إغلاق
                        </button>
                      </div>
                      <div className="max-h-[420px] space-y-2 overflow-y-auto p-4">
                        {d.items.map((item, i) => (
                          <p key={i} className="whitespace-pre-line border-b border-line/50 pb-2 text-xs leading-loose text-mute last:border-0">
                            {pick(lang, item)}
                          </p>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        <button onClick={() => router.push("/")} className="btn-ghost w-full py-2.5 text-[10px]">
          <Icon name="back" size={12} className="rtl:rotate-180" />🔙 الرجوع للصفحة الرئيسية
        </button>
      </main>
    </div>
  );
}
