"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { PAGES, MARKET_SECTIONS, pick, type PageId } from "@/lib/site";
import { ARSENAL_SECTIONS } from "@/lib/arsenal";
import { FORUM_SECTIONS } from "@/lib/forum";
import { useT, useLang, api, fmtMoney } from "@/lib/client";
import { ProductRow, pName } from "@/lib/types";
import { Icon } from "./Icon";

let productsCache: ProductRow[] | null = null;

export function loadProducts(): Promise<ProductRow[]> {
  if (productsCache) return Promise.resolve(productsCache);
  return api<ProductRow[]>("/api/products").then((r) => {
    productsCache = r;
    return r;
  });
}

/** 🔍 بحث ذكي — اقتراحات فورية أثناء الكتابة (منتجات + أقسام + صفحات) */
export default function SearchBar({ onPick }: { onPick: (p: ProductRow) => void }) {
  const t = useT();
  const lang = useLang();
  const router = useRouter();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [products, setProducts] = useState<ProductRow[]>([]);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadProducts().then(setProducts).catch(() => {});
  }, []);

  useEffect(() => {
    const fn = (e: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", fn);
    return () => document.removeEventListener("mousedown", fn);
  }, []);

  const ql = q.trim().toLowerCase();

  const sections = useMemo(() => {
    if (!ql) return [];
    const out: { label: string; icon: string; route: string; kind: "page" | "section" }[] = [];
    // السوق: أقسام + فروع
    for (const ms of MARKET_SECTIONS) {
      if (pick(lang, ms.name).toLowerCase().includes(ql))
        out.push({ label: pick(lang, ms.name), icon: ms.icon, route: `/market/${ms.id}`, kind: "page" });
      for (const br of ms.branches) {
        if (pick(lang, br.name).toLowerCase().includes(ql))
          out.push({ label: pick(lang, br.name), icon: br.icon, route: `/market/${ms.id}?b=${br.id}`, kind: "section" });
      }
    }
    // الترسانة: 10 أقسام + 57 أداة
    for (const as of ARSENAL_SECTIONS) {
      if (pick(lang, as.name).toLowerCase().includes(ql))
        out.push({ label: pick(lang, as.name), icon: as.icon, route: `/arsenal?sec=${as.id}`, kind: "page" });
      for (const tool of as.tools) {
        if (pick(lang, tool.name).toLowerCase().includes(ql))
          out.push({ label: pick(lang, tool.name), icon: tool.icon, route: `/arsenal?sec=${as.id}`, kind: "section" });
      }
    }
    // المنتدى: الأقسام الخمسة
    for (const fs of FORUM_SECTIONS) {
      if (pick(lang, fs.name).toLowerCase().includes(ql))
        out.push({ label: pick(lang, fs.name), icon: fs.icon, route: `/forum?sec=${fs.id}`, kind: "page" });
    }
    // الدعم
    const pg = PAGES.support;
    if (pick(lang, pg.name).toLowerCase().includes(ql))
      out.push({ label: pick(lang, pg.name), icon: pg.icon, route: pg.route, kind: "page" });
    for (const s of pg.sections) {
      if (pick(lang, s.name).toLowerCase().includes(ql))
        out.push({ label: pick(lang, s.name), icon: s.icon, route: `${pg.route}?s=${s.id}`, kind: "section" });
    }
    return out.slice(0, 6);
  }, [ql, lang]);

  const prods = useMemo(() => {
    if (!ql) return [];
    return products
      .filter((p) =>
        [p.nameAr, p.nameEn, p.nameRu].some((n) => n.toLowerCase().includes(ql)),
      )
      .slice(0, 6);
  }, [ql, products]);

  const go = (route: string) => {
    setOpen(false);
    setQ("");
    router.push(route);
  };

  return (
    <div ref={boxRef} className="relative w-full">
      <div className="flex items-center gap-2 border border-line bg-abyss/90 px-3 py-2.5 transition-colors focus-within:border-dim focus-within:shadow-[0_0_0_3px_rgba(0,255,136,0.07)]">
        <Icon name="search" size={17} className="shrink-0 text-dim" />
        <input
          value={q}
          onChange={(e) => {
            setQ(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          onKeyDown={(e) => {
            if (e.key === "Escape") setOpen(false);
            if (e.key === "Enter") {
              if (prods[0]) {
                onPick(prods[0]);
                setOpen(false);
                setQ("");
              } else if (sections[0]) go(sections[0].route);
            }
          }}
          placeholder={t("search.ph")}
          className="w-full bg-transparent text-sm text-fog outline-none placeholder:text-mute/70"
        />
        {q && (
          <button onClick={() => { setQ(""); setOpen(false); }} aria-label="clear" className="text-mute hover:text-fog">
            <Icon name="close" size={14} />
          </button>
        )}
      </div>

      {/* الاقتراحات */}
      {open && ql && (
        <div className="panel absolute inset-x-0 top-full z-50 mt-2 max-h-[min(70vh,340px)] overflow-auto shadow-[0_24px_60px_-20px_rgba(0,0,0,0.8)]">
          {sections.length > 0 && (
            <div className="p-2">
              <div className="mono-label px-2 pb-1">{t("search.sections")}</div>
              {sections.map((s, idx) => (
                <button
                  key={idx}
                  onClick={() => go(s.route)}
                  className="flex w-full items-center gap-2.5 px-2 py-2 text-start text-sm transition-colors hover:bg-panel2"
                >
                  <Icon name={s.icon} size={15} className="text-dim" />
                  <span className="flex-1 truncate">{s.label}</span>
                  <span className="font-mono text-[9px] tracking-widest text-mute">
                    {s.kind === "page" ? "PAGE" : "SEC"}
                  </span>
                </button>
              ))}
            </div>
          )}
          {prods.length > 0 && (
            <div className="border-t border-line p-2">
              <div className="mono-label px-2 pb-1">{t("search.products")}</div>
              {prods.map((p) => (
                <button
                  key={p.id}
                  onClick={() => {
                    onPick(p);
                    setOpen(false);
                    setQ("");
                  }}
                  className="flex w-full items-center gap-2.5 px-2 py-2 text-start text-sm transition-colors hover:bg-panel2"
                >
                  <Icon name="box" size={15} className="text-dim" />
                  <span className="flex-1 truncate">{pName(p, lang)}</span>
                  {p.verified && <Icon name="shieldCheck" size={13} className="text-acid" />}
                  <span className="font-mono text-[11px] text-acid">{fmtMoney(p.priceUsd)}</span>
                </button>
              ))}
            </div>
          )}
          {sections.length === 0 && prods.length === 0 && (
            <div className="p-5 text-center font-mono text-xs text-mute">{t("search.empty")}</div>
          )}
        </div>
      )}
    </div>
  );
}
