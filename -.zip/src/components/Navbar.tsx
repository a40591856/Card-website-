"use client";

import { useRouter } from "next/navigation";
import { LANGS } from "@/lib/i18n";
import { LINKS, ROUTES, SITE } from "@/lib/site";
import { useT, useLang, useCart, cartCount, useShell, openExternal } from "@/lib/client";
import { Icon } from "./Icon";

/**
 * ═══ L1 — الشريط العلوي الثابت (z-30) ═══
 * من اليمين في العربية: القائمة → اللغة → السلة → الدفع → الدعم → تليجرام → واتساب
 * لا عين · لا جرس · روابط خارجية تُبنى لحظة الضغط دون ظهورها كنصوص.
 */
export default function Navbar() {
  const t = useT();
  const lang = useLang();
  const cart = useCart();
  const router = useRouter();
  const shell = useShell();
  const flag = LANGS.find((l) => l.code === lang)?.flag ?? "";

  const ib =
    "flex h-8 w-8 shrink-0 items-center justify-center text-mute transition-colors hover:text-acid sm:h-[39px] sm:w-[39px]";

  return (
    <header className="fixed inset-x-0 top-0 z-30 bg-void/90 backdrop-blur-md">
      <div className="border-b border-line">
        <div className="mx-auto flex h-14 max-w-[1310px] items-center gap-0.5 px-2 sm:gap-1 sm:px-5">
          {/* 1 — القائمة الجانبية */}
          <button
            onClick={() => shell?.openMenu()}
            aria-label={t("nav.menu")}
            title={t("nav.menu")}
            className={ib}
          >
            <Icon name="menu" size={19} />
          </button>

          {/* الشعار */}
          <button onClick={() => router.push("/")} className="me-1 hidden items-center gap-2 sm:flex" aria-label={SITE.name}>
            <svg viewBox="0 0 64 64" width="26" height="26">
              <path d="M32 4 56 18v28L32 60 8 46V18L32 4Z" fill="none" stroke="#b8ef80" strokeWidth="4" />
              <path d="M25 20h10a7 7 0 0 1 0 14h-10V20Zm0 16h12a7 7 0 0 1 0 14H25V36Z" fill="#b8ef80" />
            </svg>
            <span className="font-mono text-sm font-bold tracking-[0.18em]">
              BLACK<span className="text-acid">MART</span>
            </span>
          </button>

          <div className="min-w-0 flex-1" />

          {/* 2 — اللغة (قائمة التغيير المباشرة) */}
          <button
            onClick={() => shell?.openLang()}
            aria-label={t("nav.lang")}
            title={t("nav.lang")}
            className="flex h-8 w-8 shrink-0 items-center justify-center text-base transition-transform hover:scale-110 sm:h-[39px] sm:w-[39px] sm:text-lg"
          >
            {flag}
          </button>

          {/* 3 — السلة → صفحة السلة مباشرة */}
          <button
            onClick={() => router.push(ROUTES.cart)}
            aria-label={t("nav.cart")}
            title={t("nav.cart")}
            className={`relative ${ib}`}
          >
            <Icon name="cart" size={17} />
            {cartCount(cart) > 0 && (
              <span className="absolute -top-0.5 -end-0.5 flex h-4 min-w-4 items-center justify-center bg-acid px-1 font-mono text-[9px] font-bold text-void">
                {cartCount(cart)}
              </span>
            )}
          </button>

          <span className="mx-0.5 hidden h-6 w-px shrink-0 bg-line sm:block" />

          {/* 4 — الدفع → صفحة طرق الدفع */}
          <button
            onClick={() => router.push(ROUTES.pay)}
            aria-label={t("nav.payments")}
            title={t("nav.payments")}
            className={ib}
          >
            <Icon name="coin" size={17} />
          </button>

          {/* 5 — الدعم الفني → مراسلة الدعم (رابط مخفي) */}
          <button
            onClick={() => openExternal(LINKS.support)}
            aria-label={t("nav.support")}
            title={t("nav.support")}
            className={ib}
          >
            <Icon name="headset" size={17} />
          </button>

          {/* 6 — تليجرام → القناة الرسمية (رابط مخفي) */}
          <button
            onClick={() => openExternal(LINKS.group)}
            aria-label={t("nav.tg")}
            title={t("nav.tg")}
            className={ib}
          >
            <Icon name="plane" size={17} />
          </button>

          {/* 7 — واتساب → القناة الرسمية (ملصق حقيقي + رابط مخفي) */}
          <button
            onClick={() => openExternal(LINKS.whatsapp)}
            aria-label={t("nav.wa")}
            title={t("nav.wa")}
            className={`${ib} hover:!text-[#25D366]`}
          >
            <Icon name="whatsapp" size={19} />
          </button>
        </div>
      </div>
      {/* شريط القياس الرقيق */}
      <div className="h-px bg-gradient-to-l from-transparent via-acid/50 to-transparent" />
    </header>
  );
}
