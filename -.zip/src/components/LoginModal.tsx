"use client";

import { useState } from "react";
import { useT, api, setAuth, toast } from "@/lib/client";
import { Icon } from "./Icon";

/** تسجيل الدخول / إنشاء عضوية — ID فريد BM-XXXXXX */
export default function LoginModal({ onClose }: { onClose: () => void }) {
  const t = useT();
  const [name, setName] = useState("");
  const [pass, setPass] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const submit = async () => {
    if (name.trim().length < 3) {
      setErr(t("login.min"));
      return;
    }
    setBusy(true);
    setErr("");
    try {
      const r = await api<{ id?: string; error?: boolean }>("/api/auth", {
        method: "POST",
        body: JSON.stringify({ name: name.trim(), pass }),
      });
      if (r.error || !r.id) {
        setErr(t("login.err"));
      } else {
        setAuth(r.id);
        toast(t("login.welcome"));
        onClose();
      }
    } catch {
      setErr(t("login.err"));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[95] flex items-center justify-center p-4" role="dialog" aria-modal>
      <div className="absolute inset-0 bg-void/85 backdrop-blur-sm" onClick={onClose} />
      <div className="panel animate-fade-up relative w-full max-w-sm">
        <div className="flex items-center gap-2 border-b border-line px-4 py-3">
          <Icon name="lock" size={16} className="text-acid" />
          <span className="mono-label">{t("login.title")}</span>
          <button onClick={onClose} aria-label={t("c.close")} className="ms-auto text-mute hover:text-fog">
            <Icon name="close" size={16} />
          </button>
        </div>
        <div className="p-5">
          <p className="text-xs leading-relaxed text-mute">{t("login.sub")}</p>
          <label className="mono-label mt-5 block">{t("login.name")}</label>
          <input
            className="inp mt-1.5 font-mono"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={t("login.name.ph")}
            autoFocus
          />
          <label className="mono-label mt-4 block">{t("login.pass")}</label>
          <input
            className="inp mt-1.5 font-mono"
            type="password"
            value={pass}
            onChange={(e) => setPass(e.target.value)}
            placeholder={t("login.pass.ph")}
            onKeyDown={(e) => e.key === "Enter" && submit()}
          />
          {err && (
            <div className="mt-3 flex items-center gap-2 border border-blood/40 bg-blood/10 px-3 py-2 text-xs text-blood">
              <Icon name="warn" size={13} />
              {err}
            </div>
          )}
          <button onClick={submit} disabled={busy} className="btn-acid mt-5 w-full py-2.5 disabled:opacity-50">
            <Icon name="lock" size={14} />
            {busy ? t("c.sending") : t("login.submit")}
          </button>
          <p className="mt-4 flex items-center justify-center gap-1.5 font-mono text-[10px] tracking-wider text-mute/70">
            <Icon name="shield" size={11} />
            {t("login.hint")}
          </p>
        </div>
      </div>
    </div>
  );
}
