"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  DISPUTE_LINKS, DISPUTE_TITLE, DISPUTE_SUBTITLE, AUTH_ALERT,
  TICKETS_KEY, makeTicketHash, ticketDate,
  WALLET_NETWORKS, validateWallet, TICKET_FORMS,
  DISPUTE_POLICY, POLICY_FOOTER, supportLink, mailtoLink, ticketSubject,
  ticketBody, SUPPORT_QUICK_MSG,
} from "@/lib/disputes";
import type { LocalTicket, TicketFormDef } from "@/lib/disputes";
import { pick } from "@/lib/site";
import { openExternal, useT, useLang, toast, useAuth, langDef } from "@/lib/client";
import { copyText, stripExifData, logAttachment } from "@/lib/forumClient";
import { Icon } from "./Icon";
import MembershipModal from "./MembershipModal";

/* ═══════════ عدّاد الجلسة المشفّر ═══════════ */
function SessionTimer() {
  const [s, setS] = useState(0);
  useEffect(() => {
    const iv = window.setInterval(() => setS((v) => v + 1), 1000);
    return () => window.clearInterval(iv);
  }, []);
  const p = (n: number) => String(n).padStart(2, "0");
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 border-t border-blood/40 bg-void/95 backdrop-blur-md">
      <div className="mx-auto flex max-w-[1190px] items-center justify-between gap-2 px-3 py-2 sm:px-5">
        <span className="mono-label flex items-center gap-2 !text-blood">
          <span className="inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full bg-blood" />
          SESSION SECURITY TIMER
        </span>
        <span className="font-mono text-sm font-bold tracking-[0.2em] text-blood neon-red" dir="ltr">
          {p(Math.floor(s / 3600))}:{p(Math.floor((s % 3600) / 60))}:{p(s % 60)}
        </span>
      </div>
    </div>
  );
}

function loadTickets(): LocalTicket[] {
  try {
    return JSON.parse(localStorage.getItem(TICKETS_KEY) || "[]");
  } catch { return []; }
}

/** ═══ الصفحة الرئيسية ═══ */
export default function ManagementAndSupportPage() {
  const t = useT();
  const lang = useLang();
  const router = useRouter();
  const auth = useAuth();
  const [hash] = useState(makeTicketHash);
  const [tickets, setTickets] = useState<LocalTicket[]>([]);
  const [stripped, setStripped] = useState<string[]>([]);
  const [authOpen, setAuthOpen] = useState(false);
  const [loginOpen, setLoginOpen] = useState(false);
  const [chat, setChat] = useState("");
  const [activeForm, setActiveForm] = useState<string | null>(null);

  useEffect(() => {
    document.documentElement.dir = langDef(lang).dir;
    document.documentElement.lang = lang;
    setTickets(loadTickets());
  }, [lang]);

  const requireAuth = useCallback(() => {
    if (auth) return true;
    setAuthOpen(true);
    return false;
  }, [auth]);

  const saveTicket = (tk: LocalTicket) => {
    const next = [tk, ...tickets].slice(0, 60);
    setTickets(next);
    try { localStorage.setItem(TICKETS_KEY, JSON.stringify(next)); } catch { /* noop */ }
  };

  const chatSend = () => {
    if (!requireAuth()) return;
    const msg = chat.trim() || SUPPORT_QUICK_MSG;
    void copyText(msg);
    openExternal(supportLink(msg));
    toast(t("op.open"));
    setChat("");
  };

  return (
    <div className="min-h-screen bg-void text-fog">
      <div className="grid-bg pointer-events-none fixed inset-0" />
      <div className="vignette pointer-events-none fixed inset-0" />
      <div className="scanlines pointer-events-none fixed inset-0 opacity-30" />

      {/* ═══ 1 — Header ═══ */}
      <div className="sticky top-0 z-30 border-b border-line bg-void/95 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-[1190px] items-center gap-2 px-3 sm:px-5">
          <button onClick={() => router.push("/")} className="btn-icon hover:!text-blood" title="إغلاق الصفحة" aria-label="إغلاق الصفحة">
            <Icon name="close" size={17} />
          </button>
          <div className="flex-1" />
          <button onClick={() => openExternal(DISPUTE_LINKS.support)} className="btn-icon" title="خدمة العملاء" aria-label="خدمة العملاء">
            <Icon name="headset" size={17} />
          </button>
          <button onClick={() => openExternal(DISPUTE_LINKS.channel)} className="btn-icon" title="القناة الرسمية" aria-label="القناة الرسمية">
            <Icon name="megaphone" size={17} />
          </button>
        </div>
      </div>

      <main className="relative z-10 mx-auto w-full max-w-[1000px] space-y-5 px-3 pb-24 pt-7 sm:px-5">
        <header className="text-center">
          <div className="mono-label mb-2 flex items-center justify-center gap-2 text-acid">
            <span className="inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full bg-acid" />
            ZERO-FOOTPRINT · LOCAL ARCHIVE · SECURE ARBITRATION
          </div>
          <h1 className="display-1 font-bold">{pick(lang, DISPUTE_TITLE)}</h1>
          <p className="mt-2 text-sm text-mute">{pick(lang, DISPUTE_SUBTITLE)}</p>
        </header>

        {/* ═══ 4 — النواة الأمنية ═══ */}
        <section className="panel p-4">
          <div className="mono-label mb-3 flex items-center gap-2 text-acid"><Icon name="shield" size={13} />SECURITY CORE</div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="border border-line bg-abyss/60 p-3">
              <div className="mono-label mb-1.5">مولّد الهاش المرجعي</div>
              <div className="font-mono text-lg font-bold text-acid">{hash}</div>
            </div>
            <div className="border border-line bg-abyss/60 p-3">
              <div className="mono-label mb-1.5">أداة تنظيف الصور (EXIF Stripper)</div>
              <div className={`flex items-center gap-2 text-xs font-bold ${stripped.length ? "text-acid" : "text-mute"}`}>
                <Icon name={stripped.length ? "shieldCheck" : "lock"} size={13} />
                {stripped.length ? `✅ تم مسح ميتاداتا ${stripped.length} ملف` : "بانتظار إرفاق صورة…"}
              </div>
              {stripped.length > 0 && <div className="mt-1 truncate font-mono text-[9px] text-mute">{stripped.join(" · ")}</div>}
            </div>
          </div>
          <WalletValidator />
          <p className="mt-3 font-mono text-[10px] leading-relaxed text-mute">
            🔐 خيار التشفير المحلي يحمي نسختك داخل المتصفح فقط، ولا يؤثر إطلاقاً على وضوح البيانات (Plain Text) الواردة للبريد الرسمي.
          </p>
        </section>

        {/* ═══ 3 — الأرشيف المحلي ═══ */}
        <LocalArchive tickets={tickets} onClear={() => { localStorage.removeItem(TICKETS_KEY); setTickets([]); }} />

        {/* ═══ 5 — خدمة العملاء ═══ */}
        <section className="panel p-4">
          <div className="mono-label mb-2 flex items-center gap-2 text-acid"><Icon name="chat" size={13} />خدمة العملاء والمراسلة المباشرة</div>
          <p className="mb-3 text-xs leading-relaxed text-mute">للاستفسارات السريعة، المساعدة في التفريغ، والتوجيه المباشر — الرسالة تُنسخ وتُجهَّز في تيليجرام لتضغط «إرسال» فقط.</p>
          <textarea className="inp min-h-[90px] resize-y" value={chat} onChange={(e) => setChat(e.target.value)} placeholder={SUPPORT_QUICK_MSG} />
          <button onClick={chatSend} className="btn-acid mt-3 w-full py-2.5">
            <Icon name="plane" size={13} />📨 إرسال إلى خدمة العملاء
          </button>
        </section>

        {/* ═══ 6 — التذاكر الرسمية ═══ */}
        <section>
          <div className="mono-label mb-3">// التذاكر الرسمية · تُوجَّه حصرياً للبريد الرسمي</div>
          <div className="space-y-2">
            {TICKET_FORMS.map((form) => (
              <TicketForm
                key={form.id}
                def={form}
                hash={hash}
                open={activeForm === form.id}
                onToggle={() => setActiveForm(activeForm === form.id ? null : form.id)}
                requireAuth={requireAuth}
                onSave={saveTicket}
                onStripped={(name) => setStripped((s) => [name, ...s].slice(0, 8))}
              />
            ))}
          </div>
        </section>

        {/* ═══ 7 — السياسة الرسمية ═══ */}
        <DisputePolicyBox />

        {/* ═══ Footer ═══ */}
        <div className="flex flex-wrap gap-2 border-t border-line pt-4">
          <button onClick={() => router.push("/")} className="btn-ghost flex-1 py-2.5 text-[10px]">
            <Icon name="back" size={12} className="rtl:rotate-180" />🔙 زر رجوع صريح
          </button>
          <button onClick={() => openExternal(DISPUTE_LINKS.support)} className="btn-acid flex-1 py-2.5 text-[10px]">
            <Icon name="headset" size={12} />🎧 خدمة عملاء تيليجرام
          </button>
        </div>
      </main>

      <SessionTimer />

      {/* ═══ 2 — حارس الدخول ═══ */}
      {authOpen && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-4" role="dialog" aria-modal>
          <div className="absolute inset-0 bg-void/85 backdrop-blur-sm" onClick={() => setAuthOpen(false)} />
          <div className="panel animate-fade-up relative w-full max-w-sm p-5">
            <div className="mb-3 flex items-center gap-2 border-b border-line pb-3">
              <Icon name="warn" size={17} className="text-blood" />
              <span className="mono-label flex-1">AUTH GUARD</span>
              <button onClick={() => setAuthOpen(false)} className="btn-icon h-8 w-8"><Icon name="close" size={14} /></button>
            </div>
            <p className="text-sm font-bold leading-loose text-fog">{pick(lang, AUTH_ALERT)}</p>
            <p className="mt-2 text-xs leading-relaxed text-mute">الشروحات والأرشيف متاحة للجميع دون قيود؛ رفع التذاكر فقط يتطلب جلسة موثّقة.</p>
            <button onClick={() => { setAuthOpen(false); setLoginOpen(true); }} className="btn-acid mt-4 w-full py-2.5">
              <Icon name="lock" size={13} />تسجيل الدخول / إنشاء حساب
            </button>
          </div>
        </div>
      )}
      {loginOpen && <MembershipModal onClose={() => setLoginOpen(false)} />}
    </div>
  );
}

/* ═══════════ محلل المحافظ الذكي ═══════════ */
function WalletValidator() {
  const lang = useLang();
  const [net, setNet] = useState("trc20");
  const [addr, setAddr] = useState("");
  const result = addr ? validateWallet(net, addr) : null;
  return (
    <div className="mt-3 border border-line bg-abyss/60 p-3">
      <div className="mono-label mb-2 flex items-center gap-2 text-acid"><Icon name="search" size={12} />محلل المحافظ الذكي (Wallet Validator)</div>
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        <select className="inp" value={net} onChange={(e) => setNet(e.target.value)}>
          {WALLET_NETWORKS.map((n) => <option key={n.id} value={n.id}>{pick(lang, n.name)}</option>)}
        </select>
        <input className="inp font-mono" dir="ltr" value={addr} onChange={(e) => setAddr(e.target.value)} placeholder="عنوان المحفظة…" />
      </div>
      {result && <p className={`mt-2 text-xs font-bold ${result.ok ? "text-acid" : "text-blood"}`}>{result.msg}</p>}
    </div>
  );
}

/* ═══════════ الأرشيف المحلي ═══════════ */
function LocalArchive({ tickets, onClear }: { tickets: LocalTicket[]; onClear: () => void }) {
  const lang = useLang();
  const [open, setOpen] = useState(false);
  const summary = (tk: LocalTicket) => {
    try { return tk.encrypted ? decodeURIComponent(tk.summary) : tk.summary; } catch { return tk.summary; }
  };
  return (
    <section className="panel overflow-hidden">
      <button onClick={() => setOpen((v) => !v)} className={`flex w-full items-center gap-2.5 p-4 text-start ${open ? "text-acid" : "hover:text-fog"}`}>
        <Icon name="box" size={15} className="text-dim" />
        <span className="flex-1 text-sm font-bold">📂 سجل بلاغاتي وتذاكري السابقة ({tickets.length})</span>
        <Icon name="chevron" size={13} className={`text-mute transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div className="animate-fade-up border-t border-line p-4">
          {tickets.length === 0 ? (
            <p className="py-4 text-center font-mono text-xs text-mute">لا توجد تذاكر محفوظة على هذا الجهاز بعد.</p>
          ) : (
            <>
              {/* جدول على الكمبيوتر */}
              <table className="hidden w-full text-sm md:table">
                <thead><tr className="border-b border-line text-start">
                  <th className="mono-label px-2 py-2 text-start font-normal">الهاش</th>
                  <th className="mono-label px-2 py-2 text-start font-normal">النوع</th>
                  <th className="mono-label px-2 py-2 text-start font-normal">التاريخ</th>
                  <th className="mono-label px-2 py-2 text-start font-normal">الملخص</th>
                </tr></thead>
                <tbody>
                  {tickets.map((tk, i) => (
                    <tr key={i} className="border-b border-line/60 last:border-0">
                      <td className="px-2 py-2.5 font-mono text-[11px] text-acid">{tk.hash}</td>
                      <td className="px-2 py-2.5 text-xs">{tk.kind}</td>
                      <td className="px-2 py-2.5 font-mono text-[10px] text-mute">{tk.at}</td>
                      <td className="max-w-[280px] truncate px-2 py-2.5 text-xs text-mute">{summary(tk)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {/* بطاقات على الجوال */}
              <div className="space-y-2 md:hidden">
                {tickets.map((tk, i) => (
                  <div key={i} className="border border-line bg-abyss/60 p-3">
                    <div className="font-mono text-[11px] font-bold text-acid">{tk.hash}</div>
                    <div className="mt-1 text-xs">{tk.kind} · <span className="font-mono text-[10px] text-mute">{tk.at}</span></div>
                    <p className="mt-1 line-clamp-2 text-xs text-mute">{summary(tk)}</p>
                  </div>
                ))}
              </div>
              <button onClick={onClear} className="btn-ghost mt-3 w-full py-2 text-[9px]">
                <Icon name="refresh" size={11} />مسح السجل المحلي
              </button>
            </>
          )}
        </div>
      )}
    </section>
  );
}

/* ═══════════ نموذج التذكرة ═══════════ */
function TicketForm({ def, hash, open, onToggle, requireAuth, onSave, onStripped }: {
  def: TicketFormDef;
  hash: string;
  open: boolean;
  onToggle: () => void;
  requireAuth: () => boolean;
  onSave: (tk: LocalTicket) => void;
  onStripped: (name: string) => void;
}) {
  const lang = useLang();
  const [vals, setVals] = useState<Record<string, string>>({});
  const [imgs, setImgs] = useState<string[]>([]);
  const [video, setVideo] = useState("");
  const [encrypted, setEncrypted] = useState(false);
  const [err, setErr] = useState("");

  const set = (id: string, v: string) => { setVals((x) => ({ ...x, [id]: v })); setErr(""); };

  const onFiles = async (files: FileList | null) => {
    if (!files) return;
    const names: string[] = [];
    for (const f of Array.from(files).slice(0, 5)) {
      const clean = await stripExifData(f);
      await logAttachment(clean.log);
      names.push(clean.log.safeName);
      onStripped(clean.log.safeName);
    }
    setImgs((s) => [...s, ...names]);
  };

  const submit = () => {
    if (!requireAuth()) return;
    const missing = def.fields.some((f) => f.required && !(vals[f.id] || "").trim());
    if (missing) { setErr("أكمل جميع الحقول الإجبارية"); return; }
    if (def.id === "refund") {
      const r = validateWallet(vals.network || "", vals.wallet || "");
      if (!r.ok) { setErr(r.msg); return; }
    }
    const newHash = makeTicketHash();
    const body = ticketBody({
      hash: newHash, kind: def.kind.ar || def.id,
      fields: def.fields.map((f) => ({ label: f.label.ar || f.id, value: vals[f.id] || "" })),
      attachments: imgs, videoLink: video, encrypted,
    });
    const subject = ticketSubject(def.subject, newHash);
    const raw = def.fields.map((f) => `${f.label.ar}: ${vals[f.id] || ""}`).join(" · ");
    onSave({
      hash: newHash, kind: def.kind.ar || def.id, subject,
      summary: encrypted ? encodeURIComponent(raw) : raw,
      at: ticketDate(), encrypted, attachments: imgs,
    });
    setVals({}); setImgs([]); setVideo(""); setErr("");
    window.location.href = mailtoLink(subject, body);
    toast("📨 تم تجهيز التذكرة في تطبيق البريد");
  };

  const walletCheck = def.id === "refund" ? validateWallet(vals.network || "", vals.wallet || "") : null;

  return (
    <div className="border border-line bg-abyss/60">
      <button onClick={onToggle} className={`flex w-full items-center gap-2.5 p-3.5 text-start ${open ? "text-acid" : "hover:text-fog"}`}>
        <Icon name={def.icon} size={16} className="shrink-0 text-dim" />
        <span className="flex-1 text-sm font-bold">{pick(lang, def.kind)}</span>
        <Icon name="chevron" size={13} className={`text-mute transition-transform ${open ? "rotate-180" : ""}`} />
      </button>

      {open && (
        <div className="animate-fade-up space-y-3 border-t border-line p-4">
          <p className="text-xs leading-relaxed text-mute">{pick(lang, def.desc)}</p>
          {def.fields.map((f) => (
            <div key={f.id}>
              <label className="mono-label mb-1.5 block">{pick(lang, f.label)}{f.required && <span className="text-blood"> *</span>}</label>
              {f.type === "textarea" ? (
                <textarea className="inp min-h-[95px] resize-y" value={vals[f.id] || ""} onChange={(e) => set(f.id, e.target.value)} placeholder={pick(lang, f.ph)} />
              ) : f.type === "select" ? (
                <select className="inp" value={vals[f.id] || ""} onChange={(e) => set(f.id, e.target.value)}>
                  <option value="">—</option>
                  {(f.options ?? []).map((o) => <option key={o.value} value={o.value}>{pick(lang, o.label)}</option>)}
                </select>
              ) : (
                <input className="inp" value={vals[f.id] || ""} onChange={(e) => set(f.id, e.target.value)} placeholder={pick(lang, f.ph)} />
              )}
            </div>
          ))}

          {walletCheck && vals.wallet && (
            <p className={`text-xs font-bold ${walletCheck.ok ? "text-acid" : "text-blood"}`}>{walletCheck.msg}</p>
          )}

          {/* المرفقات */}
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            <label className="btn-ghost cursor-pointer justify-center py-2.5 text-[10px]">
              <Icon name="box" size={12} />📷 إرفاق صور (EXIF يُمسح تلقائياً)
              <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => onFiles(e.target.files)} />
            </label>
            <label className="btn-ghost cursor-pointer justify-center py-2.5 text-[10px]">
              <Icon name="play" size={12} />🎞️ إرفاق فيديو قصير
              <input type="file" accept="video/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) setVideo(f.name); }} />
            </label>
          </div>
          <input className="inp" value={video} onChange={(e) => setVideo(e.target.value)} placeholder="أو رابط فيديو الإثبات…" />
          {imgs.length > 0 && (
            <div className="flex items-center gap-2 border border-acid/30 bg-acid/5 px-3 py-2 font-mono text-[10px] text-acid">
              <Icon name="shieldCheck" size={12} />🔒 تم مسح بيانات {imgs.length} صورة · {imgs.join(" | ")}
            </div>
          )}
          <label className="flex cursor-pointer items-start gap-2 border border-line bg-panel p-3 text-xs leading-relaxed text-mute">
            <input type="checkbox" checked={encrypted} onChange={(e) => setEncrypted(e.target.checked)} className="mt-0.5 accent-[#b8ef80]" />
            🔐 تشفير النسخة المحلية على جهازي (اختياري — لا يؤثر على وضوح البريد الرسمي)
          </label>
          {err && <p className="flex items-center gap-2 text-xs text-blood"><Icon name="warn" size={12} />{err}</p>}
          <button onClick={submit} className="btn-acid w-full py-2.5">
            <Icon name="send" size={13} />✉️ تجهيز التذكرة وإرسالها للبريد الرسمي
          </button>
          <p className="text-center font-mono text-[9px] text-mute">المرجع الحالي: {hash} · يُولَّد هاش جديد لكل تذكرة</p>
        </div>
      )}
    </div>
  );
}

/* ═══════════ صندوق السياسة ═══════════ */
function DisputePolicyBox() {
  const lang = useLang();
  const [open, setOpen] = useState(true);
  return (
    <section className="panel border-acid/30 overflow-hidden">
      <button onClick={() => setOpen((v) => !v)} className="flex w-full items-center gap-2.5 border-b border-line bg-acid/5 p-4 text-start">
        <Icon name="shield" size={16} className="text-acid" />
        <span className="flex-1 text-sm font-bold text-acid">⚖️ سياسة الدعم وتنسيق النزاعات الرسمية</span>
        <Icon name="chevron" size={13} className={`text-mute transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div className="animate-fade-up max-h-[520px] space-y-4 overflow-y-auto p-5">
          <p className="text-sm font-bold italic leading-loose text-fog">
            أخي العضو/المتعامل: تم بناء هذا المركز ليكون الضامن الأول لحقوقك الماليّة والتشغيلية داخل المنصة. يرجى الاطلاع على آلية عمل التذاكر والتحكيم الرسمية:
          </p>
          {DISPUTE_POLICY.map((g, i) => (
            <div key={i}>
              <h4 className="text-sm font-bold text-acid">{pick(lang, g.title)}</h4>
              <ul className="mt-2 space-y-2">
                {g.items.map((x, j) => (
                  <li key={j} className="text-xs italic leading-loose text-mute">{pick(lang, x)}</li>
                ))}
              </ul>
            </div>
          ))}
          <div className="border-t border-line pt-4">
            {POLICY_FOOTER.map((x, i) => <p key={i} className="mt-2 text-xs font-bold italic leading-loose text-fog/90">{pick(lang, x)}</p>)}
          </div>
          <button onClick={() => openExternal(DISPUTE_LINKS.support)} className="btn-acid w-full py-2.5">
            <Icon name="headset" size={13} />🎧 خدمة عملاء تيليجرام
          </button>
        </div>
      )}
    </section>
  );
}
