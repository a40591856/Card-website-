"use client";

import { useEffect, useState } from "react";
import { prefersReducedMotion } from "@/lib/client";

const CHARS = "!<>-_\\/[]{}=+*^?#0123456789ABCDEF";

/** تأثير فك التشفير: نص مشوّش يتفكك حرفاً حرفاً إلى نصه الحقيقي */
export default function Decryption({
  text,
  className,
  delay = 0,
}: {
  text: string;
  className?: string;
  delay?: number;
}) {
  const [out, setOut] = useState(text);

  useEffect(() => {
    // التأثير يعمل مرة واحدة فقط في الجلسة — بعدها يظهر النص فوراً
    let skip = prefersReducedMotion();
    if (!skip) {
      try {
        if (sessionStorage.getItem("bm_decrypted") === "1") skip = true;
        else sessionStorage.setItem("bm_decrypted", "1");
      } catch {
        /* noop */
      }
    }
    if (skip) {
      setOut(text);
      return;
    }
    let frame = 0;
    let iv: number | undefined;
    let to: number | undefined;
    const total = Math.max(16, Math.round(text.length * 1.5));

    const run = () => {
      iv = window.setInterval(() => {
        frame++;
        if (frame >= total) {
          setOut(text);
          window.clearInterval(iv);
          return;
        }
        const resolved = Math.floor((frame / total) * text.length);
        setOut(
          text
            .split("")
            .map((c, i) =>
              i < resolved ? c : c === " " ? " " : CHARS[Math.floor(Math.random() * CHARS.length)],
            )
            .join(""),
        );
      }, 28);
    };

    if (delay > 0) to = window.setTimeout(run, delay);
    else run();

    return () => {
      window.clearInterval(iv);
      window.clearTimeout(to);
    };
  }, [text, delay]);

  return <span className={className}>{out}</span>;
}
