"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  PROXY_SECTIONS, PROXY_EDUCATION, PROXY_DURATIONS, PROXY_TYPES,
  D2_QTY_OPTIONS, ELITE_COUNTRIES, ELITE_DESC, ELITE_ACCOUNT_PRICE,
  ELITE_EXTRAS, ELITE_NOTE, CHECK_NOTE,
  proxyRequestMessage, proxyCustomMessage, aiMessage, courseMessage,
  architectMessage, d2Message, eliteAccountMessage, checksMessage,
  type VProduct, type VSection,
} from "@/lib/proxy";
import { BUY_MANAGER, pick, type L } from "@/lib/site";
import { copyText, dispatchToTelegram, buildWebFallback } from "@/lib/forumClient";
import { useT, useLang, toast } from "@/lib/client";
import { Icon } from "./Icon";
import Shell from "./Shell";
import SectionToolCTA from "./SectionToolCTA";

const A = (ar: string, en = ar): L => ({ ar, en });
type Cart = Record<string, number>;

const LB = {
  home: A("🌐 العودة للأقسام", "🌐 Back to sections"),
  back: A("🔙 عودة للأقسام", "🔙 Back"),
  arsenal: A("🚀 الانتقال لـ أدوات التفريغ", "🚀 Go to Arsenal"),
  arsenalShort: A("🛠️ الانتقال لأدوات التفريغ", "🛠️ Arsenal tools"),
  details: A("عرض التفاصيل", "Details"),
  buy: A("شراء", "Buy"),
  cart: A("السلة", "Cart"),
  addCart: A("إضافة للسلة", "Add to cart"),
  total: A("الإجمالي", "Total"),
  sendCart: A("إرسال طلب السلة", "Send cart order"),
  preview: A("معاينة الرسالة", "Message preview"),
  copy: A("نسخ الرسالة", "Copy message"),
  open: A("فتح المحادثة", "Open chat"),
  close: A("إغلاق", "Close"),
  guide: A("دليل القسم", "Section guide"),
  whatProxy: A("ℹ️ ما هو البروكسي؟", "ℹ️ What is a proxy?"),
  orderProxy: A("🛒 اطلب البروكسي", "🛒 Order proxy"),
  customizer: A("⚙️ أداة تخصيص الاشتراك", "⚙️ Subscription customizer"),
  ip: A("إدخال عنوان الـ IP", "Enter IP address"),
  ipNote: A("يرجى تحديد الـ IP المراد برمجة الموقع عليه، والوجهة المراد استخدام البروكسي فيها لتشفير الاتصال بشكل صحيح.", "Specify the IP to bind and the destination to encrypt the connection properly."),
  sendReq: A("⚡ إرسال الطلب للمسؤول", "⚡ Send request"),
  type: A("نوع البروكسي", "Proxy type"),
  duration: A("المدة", "Duration"),
  confirmSub: A("🛒 تأكيد طلب الاشتراك المخصص", "🛒 Confirm custom subscription"),
  activate: A("⚡ تفعيل BlackGPT-Core", "⚡ Activate BlackGPT-Core"),
  subscribe: A("🛒 اشتراك فوري", "🛒 Subscribe now"),
  architectBuy: A("🛒 اشتراك فوري في الكورس الشامل ⚡", "🛒 Get the full package ⚡"),
  qty: A("اختيار الكمية", "Choose quantity"),
  confirmBuy: A("💸 تأكيد الشراء", "💸 Confirm purchase"),
  readyAccounts: A("🔗 حسابات مستعارة جاهزة", "🔗 Ready borrowed accounts"),
  eliteTool1: A("🏦 فتح حساب بنكي مستعار باسمك (موثق)", "🏦 Open verified borrowed bank account"),
  eliteTool2: A("🧾 خدمة بيع شيكات", "🧾 Bank checks service"),
  country: A("اختيار الدولة", "Choose country"),
  bank: A("اختيار البنك", "Choose bank"),
  fullName: A("الاسم الرباعي", "Full name"),
  dob: A("تاريخ الميلاد", "Date of birth"),
  email: A("البريد الإلكتروني", "Email"),
  checkValue: A("قيمة الشيك المطلوبة", "Check amount"),
  goManager: A("توجه للمسؤول", "Contact manager"),
  required: A("أكمل جميع الحقول الإلزامية", "Fill all required fields"),
  loading: A("جارٍ التوجيه…", "Routing…"),
};

/** ═══ PROXY & ENCRYPTION VAULT ═══ */
export default function ProxyHub() {
  const t = useT();
  const lang = useLang();
  const router = useRouter();

  const [active, setActive] = useState<string | null>(null);
  const [modal, setModal] = useState<VProduct | null>(null);
  const [eduOpen, setEduOpen] = useState(false);
  const [cart, setCart] = useState<Cart>({});
  const [cartOpen, setCartOpen] = useState(false);
  const [relay, setRelay] = useState("");
  const [copied, setCopied] = useState(false);
  const [guideOpen, setGuideOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const s = new URLSearchParams(window.location.search).get("s");
    if (s && PROXY_SECTIONS.some((x) => x.id === s)) setActive(s);
  }, []);

  useEffect(() => {
    if (!modal && !eduOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && (setModal(null), setEduOpen(false));
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", onKey); document.body.style.overflow = ""; };
  }, [modal, eduOpen]);

  const sec = active ? PROXY_SECTIONS.find((s) => s.id === active) : undefined;

  const send = useCallback((msg: string) => {
    void copyText(msg);
    void dispatchToTelegram(msg, BUY_MANAGER);
    setRelay(msg);
    setCopied(true);
    toast(t("fa.copied"));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [t]);

  /** تأثير Loading Spinner قبل التوجه لتليجرام */
  const sendWithSpinner = useCallback((msg: string) => {
    if (busy) return;
    setBusy(true);
    window.setTimeout(() => { send(msg); setBusy(false); }, 550);
  }, [busy, send]);

  const buy = (p: VProduct) => {
    if (p.kind === "ai") return sendWithSpinner(aiMessage());
    if (p.id === "ac1") return sendWithSpinner(architectMessage());
    if (p.kind === "course") return sendWithSpinner(courseMessage(p.name.ar || ""));
    sendWithSpinner([
      "[🚨 طلب شراء جديد - BLACK MART]",
      `💳 الخدمة المطلوبة: ${p.name.ar || ""}`,
      `💰 القيمة: ${p.priceUsd}$`,
      "📝 نص الطلب: أريد شراء هذه الخدمة. يرجى تزويدي بمحافظ الدفع المتاحة والتعليمات المطلوبة لإتمام المعاملة.",
      "[SYSTEM_ID: AUTO_GENERATED]",
    ].join("\n"));
  };
  const addCart = (id: string) => { setCart((c) => ({ ...c, [id]: (c[id] || 0) + 1 })); toast(t("p.added")); };

  const all = useMemo(() => PROXY_SECTIONS.flatMap((s) => s.products.map((p) => ({ p, s }))), []);
  const cartItems = Object.entries(cart)
    .map(([id, qty]) => ({ ...all.find((x) => x.p.id === id), qty }))
    .filter((x): x is { p: VProduct; s: VSection; qty: number } => !!x.p);
  const cartCount = cartItems.reduce((a, x) => a + x.qty, 0);
  const cartTotal = cartItems.reduce((a, x) => a + x.p.priceUsd * x.qty, 0);
  const sendCart = () => {
    if (!cartItems.length) return;
    send([
      "[🚨 طلب شراء جديد - BLACK MART]",
      `💳 الخدمة المطلوبة: سلة (${cartCount} عنصر)`,
      `💰 القيمة: ${cartTotal}$`,
      cartItems.map((x) => `• ${x.p.name.ar} × ${x.qty} — ${x.p.priceUsd * x.qty}$`).join("\n"),
      "[SYSTEM_ID: AUTO_GENERATED]",
    ].join("\n"));
    setCartOpen(false);
  };

  const open = (id: string) => { setActive(id); setGuideOpen(false); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const back = () => {
    if (modal) setModal(null);
    else if (eduOpen) setEduOpen(false);
    else if (active) { setActive(null); router.replace("/market/proxy"); window.scrollTo({ top: 0, behavior: "smooth" }); }
    else router.push("/market");
  };

  return (
    <Shell>
      <div className="space-y-5 pb-28 pt-4">
        {/* ═══ شريط علوي ثابت ═══ */}
        <div className="sticky top-[96px] z-20 -mx-3 border-b border-line bg-void/95 px-3 py-2 backdrop-blur-md sm:-mx-5 sm:px-5">
          <div className="flex flex-wrap items-center gap-2">
            <button onClick={back} className="btn-ghost shrink-0 px-3 py-1.5 text-[9px]">
              <Icon name="back" size={11} className="rtl:rotate-180" />{pick(lang, LB.home)}
            </button>
            <a href="/arsenal" className="btn-acid shrink-0 !border-violet/50 !bg-violet/10 !px-3 !py-1.5 !text-[9px] !text-violet">
              <Icon name="tool" size={11} />{pick(lang, LB.arsenal)}
            </a>
            <span className="ms-auto font-mono text-[9px] tracking-widest text-acid">{sec ? sec.id.toUpperCase() : "05 SECTIONS"}</span>
          </div>
          {active && (
            <div className="no-scrollbar -mx-1 mt-2 flex gap-1.5 overflow-x-auto px-1">
              {PROXY_SECTIONS.map((s) => (
                <button key={s.id} onClick={() => open(s.id)}
                  className={`shrink-0 border px-3 py-1.5 font-mono text-[10px] font-bold tracking-wider transition-all ${
                    active === s.id ? "border-acid bg-acid text-void shadow-[0_0_16px_rgba(184,239,128,0.3)]" : "border-line bg-abyss/60 text-mute hover:text-fog"
                  }`}>{pick(lang, s.short)}</button>
              ))}
            </div>
          )}
        </div>

        {/* ═══ معاينة الرسالة ═══ */}
        {relay && (
          <div className="panel animate-fade-up">
            <div className="mono-label flex items-center justify-between border-b border-line px-4 py-2.5"><span>📤 {pick(lang, LB.preview)}</span><span className="text-acid">✓ {t("op.copied")}</span></div>
            <pre className="max-h-52 overflow-auto whitespace-pre-wrap p-4 font-mono text-[11px] leading-6 text-fog/90" dir="auto">{relay}</pre>
            <div className="grid grid-cols-3 gap-2 border-t border-line p-3">
              <button onClick={async () => { if (await copyText(relay)) toast(t("op.copied")); }} className="btn-ghost py-2 text-[9px]"><Icon name={copied ? "check" : "link"} size={11} />{pick(lang, LB.copy)}</button>
              <button onClick={() => window.open(buildWebFallback(relay, BUY_MANAGER), "_blank", "noreferrer")} className="btn-acid py-2 text-[9px]"><Icon name="plane" size={11} />{pick(lang, LB.open)}</button>
              <button onClick={() => setRelay("")} className="btn-ghost py-2 text-[9px]"><Icon name="close" size={11} />{pick(lang, LB.close)}</button>
            </div>
          </div>
        )}

        {/* ═══ شبكة الأقسام ═══ */}
        {!sec && (
          <section>
            <div className="mono-label mb-3">// PROXY & ENCRYPTION VAULT · 05</div>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
              {PROXY_SECTIONS.map((s, i) => (
                <button key={s.id} onClick={() => open(s.id)} className="panel panel-hover corners group flex flex-col overflow-hidden text-start">
                  <div className="relative h-24 overflow-hidden sm:h-32">
                    <img src={s.hero} alt="" loading="lazy" decoding="async" className="h-full w-full object-cover opacity-80 transition-transform duration-500 group-hover:scale-105" />
                    <span className="absolute top-2 end-2 border border-line bg-void/85 px-1.5 py-0.5 font-mono text-[9px] text-acid">{String(i + 1).padStart(2, "0")} · {s.products.length || "2"}</span>
                  </div>
                  <div className="acc-strip h-[3px] w-full" />
                  <div className="flex flex-1 flex-col p-3">
                    <div className="text-[13px] font-bold leading-snug sm:text-sm">{pick(lang, s.name)}</div>
                    <p className="mt-1 line-clamp-2 text-[10px] leading-relaxed text-mute sm:text-[11px]">{pick(lang, s.desc)}</p>
                    <div className="btn-acid mt-3 w-full !py-2 text-[10px]">{t("c.enter")}</div>
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* ═══ محتوى القسم ═══ */}
        {sec && (
          <div key={sec.id} className={`animate-fade-up space-y-4 ${sec.id === "ai" ? "ai-shell" : ""}`}>
            <header className="panel relative overflow-hidden p-5 sm:p-7">
              <img src={sec.hero} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-20" />
              <div className="relative">
                <div className="mono-label mb-2 flex items-center gap-2 text-acid"><Icon name="lock" size={12} className="acc-lock" />{sec.id.toUpperCase()} :: ✅ VERIFIED</div>
                <h1 className={`display-2 font-bold ${sec.id === "ai" ? "glitch" : ""}`} data-text={pick(lang, sec.name)}>{pick(lang, sec.name)}</h1>
                <p className="mt-2 max-w-3xl text-sm leading-relaxed text-mute">{pick(lang, sec.desc)}</p>
              </div>
            </header>

            {/* الأداة المخصّصة داخل القسم نفسه */}
            {(sec.id === "proxy" || sec.id === "d2" || sec.id === "elite") && (
              <SectionToolCTA
                label={sec.id === "proxy" ? A("⚙️ أداة تخصيص اشتراك البروكسي") : sec.id === "d2" ? A("⚙️ أداة اختيار كمية حزمة D2") : A("⚙️ أدوات خدمات النخبة التقنية")}
                hint={A("الأداة موجودة هنا داخل القسم: اختر، عبّئ البيانات، وسيُوجَّه الطلب للمسؤول مباشرة.")}
                badge={sec.id === "proxy" ? "7 DURATIONS" : sec.id === "d2" ? "4 OPTIONS" : "2 TOOLS"}
              />
            )}

            {/* دليل القسم + روابط سريعة */}
            <div>
              <button onClick={() => setGuideOpen((v) => !v)} className={`btn-ghost w-full py-2.5 ${guideOpen ? "!border-acid/50 !text-acid" : ""}`}>
                <Icon name="book" size={13} />{pick(lang, sec.guideTitle)}
                <Icon name="chevron" size={12} className={guideOpen ? "rotate-180 transition-transform" : "transition-transform"} />
              </button>
              {guideOpen && (
                <div className="panel animate-fade-up mt-2">
                  <div className="mono-label flex items-center justify-between border-b border-line px-4 py-2.5"><span>◈ {pick(lang, LB.guide)}</span><button onClick={() => setGuideOpen(false)} className="flex items-center gap-1 text-mute hover:text-acid"><Icon name="close" size={11} />{pick(lang, LB.close)}</button></div>
                  <ul className="space-y-2 p-4">{sec.guide.map((g, i) => <li key={i} className="flex items-start gap-2 text-xs leading-relaxed text-mute"><Icon name="check" size={11} className="mt-0.5 shrink-0 text-acid" />{pick(lang, g)}</li>)}</ul>
                </div>
              )}
            </div>

            {sec.id === "proxy" && (
              <button onClick={() => setEduOpen(true)} className="btn-ghost w-full py-2.5"><Icon name="book" size={13} />{pick(lang, LB.whatProxy)}</button>
            )}
            {sec.id === "academy" && <div className="mono-label">// 17 كورساً · اضغط «تفاصيل» لاستعراض المنهج</div>}
            {sec.id === "elite" && (
              <a href="/market/accounts" className="btn-acid flex w-full py-2.5"><Icon name="user" size={13} />{pick(lang, LB.readyAccounts)}</a>
            )}

            {/* المنتجات */}
            {sec.products.length > 0 && (
              <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
                {sec.products.map((p) => (
                  <ProductCard key={p.id} p={p} sec={sec} busy={busy}
                    onBuy={() => buy(p)} onCart={() => addCart(p.id)} onDetails={() => setModal(p)}
                    onEdu={() => setEduOpen(true)} />
                ))}
              </div>
            )}

            {/* أدوات الأقسام */}
            <div id="custom-tool" className="acc-cta-panel scroll-mt-32">
              {sec.id === "proxy" && <ProxyTools busy={busy} onSend={sendWithSpinner} />}
              {sec.id === "d2" && <div className="panel p-3 text-center text-xs text-mute">// افتح «تفاصيل» أي حزمة لاختيار الكمية (رابط واحد / 10 / 25 / الحزمة الكاملة)</div>}
              {sec.id === "elite" && <EliteTools busy={busy} onSend={sendWithSpinner} />}
            </div>
          </div>
        )}
      </div>

      {/* ═══ شريط سفلي ثابت ═══ */}
      <div className="fixed inset-x-0 bottom-12 z-30 border-t border-line bg-void/95 px-3 py-2 backdrop-blur-md">
        <div className="mx-auto flex max-w-[1190px] flex-wrap items-center gap-2">
          <button onClick={back} className="btn-ghost shrink-0 !py-1.5 !text-[9px]"><Icon name="back" size={11} className="rtl:rotate-180" />{pick(lang, LB.back)}</button>
          <a href="/arsenal" className="btn-acid shrink-0 !py-1.5 !text-[9px]"><Icon name="tool" size={11} />{pick(lang, LB.arsenalShort)}</a>
          {/* TOOL-13 */}
          <p className="order-last w-full text-[10px] leading-relaxed text-mute sm:order-none sm:w-auto sm:min-w-0 sm:flex-1">
            📌 طلب مخصص: إذا لم تجد التطبيق المطلوب في القائمة، راسل المسؤول فوراً لتحديد التكلفة وتوفير الخدمة. وسيتم شحن التطبيق المطلوب.
          </p>
          <button onClick={() => sendWithSpinner("مرحباً، أرغب بطلب مخصص غير مدرج في القائمة. يرجى تحديد التكلفة وتوفير الخدمة.")} className="btn-ghost shrink-0 !py-1.5 !text-[9px]"><Icon name="plane" size={11} />✈️ راسل المسؤول</button>
        </div>
      </div>

      {/* أزرار عائمة */}
      {active && (
        <button onClick={back} title={pick(lang, LB.home)} aria-label={pick(lang, LB.home)} className="glass glass-hover fixed bottom-24 start-4 z-40 flex h-11 w-11 items-center justify-center border-acid/50 text-acid"><Icon name="back" size={18} className="rtl:rotate-180" /></button>
      )}
      {cartCount > 0 && (
        <button onClick={() => setCartOpen((v) => !v)} className="glass glass-hover fixed bottom-24 end-4 z-40 flex h-11 w-11 items-center justify-center border-acid/50 text-acid">
          <Icon name="cart" size={18} /><span className="absolute -top-1 -end-1 flex h-4 min-w-4 items-center justify-center bg-acid px-1 font-mono text-[9px] font-bold text-void">{cartCount}</span>
        </button>
      )}
      {cartOpen && cartCount > 0 && (
        <div className="panel fixed bottom-36 end-4 z-[55] w-[min(92vw,340px)] p-3 shadow-[0_24px_60px_-20px_rgba(0,0,0,0.9)]">
          <div className="mb-2 flex items-center gap-2 border-b border-line pb-2"><Icon name="cart" size={14} className="text-acid" /><span className="mono-label flex-1">{pick(lang, LB.cart)}</span><button onClick={() => setCartOpen(false)} className="text-mute hover:text-fog"><Icon name="close" size={14} /></button></div>
          <div className="max-h-56 space-y-2 overflow-auto">{cartItems.map(({ p, qty }) => (
            <div key={p.id} className="flex items-center gap-2 border border-line bg-abyss/60 p-2">
              <div className="min-w-0 flex-1"><div className="truncate text-[11px] font-bold">{pick(lang, p.name)}</div><div className="font-mono text-[10px] text-acid">${p.priceUsd * qty}</div></div>
              <button onClick={() => setCart((c) => ({ ...c, [p.id]: Math.max(0, c[p.id] - 1) }))} className="flex h-7 w-7 items-center justify-center border border-line text-mute"><Icon name="minus" size={10} /></button>
              <span className="w-5 text-center font-mono text-xs">{qty}</span>
              <button onClick={() => setCart((c) => ({ ...c, [p.id]: c[p.id] + 1 }))} className="flex h-7 w-7 items-center justify-center border border-line text-mute"><Icon name="plus" size={10} /></button>
            </div>))}</div>
          <div className="mt-3 flex items-center justify-between border-t border-line pt-2"><span className="mono-label">{pick(lang, LB.total)}</span><span className="font-mono text-lg font-bold text-acid">${cartTotal}</span></div>
          <button onClick={sendCart} className="btn-acid mt-3 w-full py-2.5 text-[10px]"><Icon name="send" size={12} />{pick(lang, LB.sendCart)}</button>
        </div>
      )}

      {/* نافذة «ما هو البروكسي؟» */}
      {eduOpen && (
        <div className="fixed inset-0 z-[65] flex items-center justify-center p-4" role="dialog" aria-modal>
          <div className="absolute inset-0 bg-void/85 backdrop-blur-sm" onClick={() => setEduOpen(false)} />
          <div className="panel animate-fade-up relative flex max-h-[85vh] w-full max-w-xl flex-col">
            <div className="flex items-center justify-between border-b border-line px-4 py-3"><span className="mono-label">ℹ️ {pick(lang, LB.whatProxy)}</span><button onClick={() => setEduOpen(false)} className="btn-icon h-8 w-8"><Icon name="close" size={15} /></button></div>
            <div className="flex-1 overflow-y-auto p-5">
              {PROXY_EDUCATION.map((e, i) => (
                <div key={i} className="mb-4 border-b border-line/60 pb-4 last:border-0">
                  <div className={`text-sm font-bold ${i === 4 ? "text-blood" : "text-acid"}`}>{pick(lang, e.title)}</div>
                  <p className="mt-1.5 text-xs leading-loose text-mute">{pick(lang, e.body)}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* نافذة تفاصيل المنتج (+ أداة كمية D2) */}
      {modal && sec && (
        <DetailModal p={modal} busy={busy} onClose={() => setModal(null)}
          onBuy={() => { buy(modal); setModal(null); }}
          onCart={() => { addCart(modal.id); setModal(null); }}
          onSend={sendWithSpinner} />
      )}
    </Shell>
  );
}

/* ═══════════ بطاقة المنتج ═══════════ */
function ProductCard({ p, sec, busy, onBuy, onCart, onDetails, onEdu }: {
  p: VProduct; sec: VSection; busy: boolean;
  onBuy: () => void; onCart: () => void; onDetails: () => void; onEdu: () => void;
}) {
  const lang = useLang();
  const [err, setErr] = useState(false);
  const old = p.oldPriceUsd ?? Math.round(p.priceUsd * 1.3);
  const specialAi = p.kind === "ai";
  const golden = !!p.featured && p.kind === "course";
  return (
    <div className={`panel panel-hover corners group flex h-full flex-col overflow-hidden ${golden ? "!border-amber/60 shadow-[0_0_26px_rgba(255,215,0,0.16)]" : ""} ${specialAi ? "ai-glitch" : ""}`}>
      <div className="relative h-24 overflow-hidden sm:h-28">
        {!err ? <img src={p.img} alt="" loading="lazy" onError={() => setErr(true)} className="h-full w-full object-cover opacity-80 transition-transform duration-500 group-hover:scale-105 group-hover:brightness-90" />
          : <div className="grid-bg-fine flex h-full w-full items-center justify-center"><Icon name={sec.icon} size={34} className="text-dim" /></div>}
        <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-void/80 to-transparent" />
        {golden && <span className="absolute top-2 start-2 border border-amber/60 bg-void/85 px-1.5 py-0.5 font-mono text-[8px] text-amber">★ FEATURED</span>}
        {specialAi && <span className="absolute top-2 start-2 border border-violet/60 bg-void/85 px-1.5 py-0.5 font-mono text-[8px] text-violet">NO_ETHICS_LIMITS</span>}
        <span className="absolute bottom-2 end-2 border border-line bg-void/85 px-1.5 py-0.5 font-mono text-[10px] font-bold text-amber">${p.priceUsd}</span>
      </div>
      <div className="acc-strip h-[3px] w-full" />
      <div className="flex min-h-0 flex-1 flex-col p-2.5 sm:p-3">
        <h3 className="line-clamp-2 text-[11px] font-bold leading-snug sm:text-[13px]">{pick(lang, p.name)}</h3>
        <p className="mt-1 line-clamp-2 text-[10px] leading-relaxed text-mute sm:text-[11px]">{pick(lang, p.desc)}</p>
        {p.balance && <div className="mt-1.5 font-mono text-[9px] text-acid">⏱ {pick(lang, p.balance)}</div>}
        <div className="mt-1 flex flex-wrap gap-1">{p.badges.map((b) => <span key={b} className="border border-line2/60 bg-abyss/70 px-1.5 py-0.5 font-mono text-[8px] tracking-wider text-mute">{b}</span>)}</div>
        <div className="mt-auto pt-2">
          <div className="flex items-baseline gap-2">
            <span className="font-mono text-[10px] text-mute/70 line-through" dir="ltr">${old}</span>
            <span className="font-mono text-lg font-bold text-acid text-glow sm:text-xl" dir="ltr">${p.priceUsd}</span>
          </div>
          {sec.id === "proxy" && (
            <div className="mt-1.5 grid grid-cols-2 gap-1.5">
              <button onClick={onEdu} className="btn-ghost !px-1 !py-1.5 !text-[8px]">{pick(lang, LB.whatProxy)}</button>
              <button onClick={onDetails} className="btn-ghost !px-1 !py-1.5 !text-[8px]">{pick(lang, LB.orderProxy)}</button>
            </div>
          )}
          <div className="mt-2 grid grid-cols-2 gap-1.5">
            <button onClick={onBuy} disabled={busy} className="btn-acid !px-1 !py-2 !text-[9px] disabled:opacity-50">
              {busy ? pick(lang, LB.loading) : specialAi ? pick(lang, LB.activate) : p.kind === "course" ? pick(lang, LB.subscribe) : p.kind === "d2" ? pick(lang, LB.buy) : pick(lang, LB.orderProxy)}
            </button>
            <button onClick={onDetails} className="btn-ghost !px-1 !py-2 !text-[9px]"><Icon name="eye" size={10} />{p.kind === "course" ? "ℹ️ تفاصيل" : pick(lang, LB.details)}</button>
          </div>
          <button onClick={onCart} className="btn-ghost mt-1.5 w-full !px-1 !py-1.5 !text-[9px]"><Icon name="cart" size={10} />{pick(lang, LB.addCart)}</button>
        </div>
      </div>
    </div>
  );
}

/* ═══════════ نافذة التفاصيل ═══════════ */
function DetailModal({ p, busy, onClose, onBuy, onCart, onSend }: {
  p: VProduct; busy: boolean; onClose: () => void; onBuy: () => void; onCart: () => void; onSend: (m: string) => void;
}) {
  const lang = useLang();
  const [err, setErr] = useState(false);
  const [qtyOpt, setQtyOpt] = useState(D2_QTY_OPTIONS[3].id);
  const opt = D2_QTY_OPTIONS.find((o) => o.id === qtyOpt) ?? D2_QTY_OPTIONS[3];
  const optPrice = opt.price === "base" ? p.priceUsd : opt.price;
  return (
    <div className="fixed inset-0 z-[65] flex items-center justify-center p-4" role="dialog" aria-modal>
      <div className="absolute inset-0 bg-void/85 backdrop-blur-sm" onClick={onClose} />
      <div className="glass animate-fade-up relative flex max-h-[88vh] w-full max-w-xl flex-col">
        <div className="flex items-center justify-between border-b border-line px-4 py-3"><span className="mono-label">ℹ️ {pick(lang, LB.details)} :: {p.kind.toUpperCase()}</span><button onClick={onClose} className="btn-icon h-8 w-8"><Icon name="close" size={15} /></button></div>
        <div className="flex-1 overflow-y-auto">
          <div className="relative h-40 sm:h-48">
            {!err ? <img src={p.img} alt="" onError={() => setErr(true)} className="h-full w-full object-cover opacity-80" /> : <div className="grid-bg-fine flex h-full w-full items-center justify-center"><Icon name="shield" size={60} className="text-dim" /></div>}
          </div>
          <div className="acc-strip h-[3px] w-full" />
          <div className="p-5">
            <h2 className="text-xl font-bold sm:text-2xl">{pick(lang, p.name)}</h2>
            <p className="mt-2 text-sm leading-relaxed text-mute">{pick(lang, p.desc)}</p>
            {p.balance && <div className="mt-2 font-mono text-xs text-acid">⏱ {pick(lang, p.balance)}</div>}
            <div className="mt-3 flex items-baseline gap-3">
              <span className="font-mono text-base text-mute/70 line-through" dir="ltr">${p.oldPriceUsd ?? Math.round(p.priceUsd * 1.3)}</span>
              <span className="font-mono text-3xl font-bold text-acid text-glow" dir="ltr">${p.priceUsd}</span>
            </div>
            <div className="mt-4 border border-line bg-abyss/60 p-4">
              <div className="mono-label mb-2">📜 التفاصيل الكاملة</div>
              <p className="whitespace-pre-line text-xs leading-loose text-fog/90">{pick(lang, p.details)}</p>
            </div>
            {/* أداة اختيار الكمية D2 */}
            {p.kind === "d2" && (
              <div className="mt-4 border border-acid/40 bg-acid/5 p-4">
                <div className="mono-label mb-2">{pick(lang, LB.qty)}</div>
                <select className="inp" value={qtyOpt} onChange={(e) => setQtyOpt(e.target.value)}>
                  {D2_QTY_OPTIONS.map((o) => <option key={o.id} value={o.id}>{pick(lang, o.label)} — {o.price === "base" ? p.priceUsd : o.price}$</option>)}
                </select>
                <div className="mt-3 flex items-center justify-between"><span className="mono-label">السعر المختار</span><span className="font-mono text-xl font-bold text-acid">${optPrice}</span></div>
                <button onClick={() => { onSend(d2Message(p.name.ar || "", pick(lang, opt.label), optPrice)); onClose(); }} disabled={busy} className="btn-acid mt-3 w-full py-2.5 disabled:opacity-50">
                  <Icon name="cart" size={13} />{busy ? pick(lang, LB.loading) : pick(lang, LB.confirmBuy)}
                </button>
              </div>
            )}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 border-t border-line p-3">
          <button onClick={onBuy} disabled={busy} className="btn-primary">{busy ? pick(lang, LB.loading) : p.id === "ac1" ? pick(lang, LB.architectBuy) : pick(lang, LB.subscribe)}</button>
          <button onClick={onCart} className="btn-acid"><Icon name="plus" size={14} />{pick(lang, LB.addCart)}</button>
        </div>
      </div>
    </div>
  );
}

/* ═══════════ أدوات البروكسي ═══════════ */
function ProxyTools({ busy, onSend }: { busy: boolean; onSend: (m: string) => void }) {
  const lang = useLang();
  const [ip, setIp] = useState("");
  const [err, setErr] = useState(false);
  const [type, setType] = useState(PROXY_TYPES[0].ar || "Residential");
  const [dur, setDur] = useState(PROXY_DURATIONS[0].id);
  const [cIp, setCIp] = useState("");
  const [cErr, setCErr] = useState(false);
  const d = PROXY_DURATIONS.find((x) => x.id === dur) ?? PROXY_DURATIONS[0];

  const submit = () => {
    if (!ip.trim()) { setErr(true); return; }
    onSend(proxyRequestMessage("PROXY_ENCRYPTION_VAULT", ip.trim()));
    setIp(""); setErr(false);
  };
  const submitCustom = () => {
    if (!cIp.trim()) { setCErr(true); return; }
    onSend(proxyCustomMessage(type, pick(lang, d.label), cIp.trim(), d.price));
    setCIp(""); setCErr(false);
  };

  return (
    <>
      <div className="panel p-4">
        <div className="mono-label mb-2 flex items-center gap-2 text-acid"><Icon name="send" size={12} />{pick(lang, LB.orderProxy)}</div>
        <p className="mb-3 text-xs leading-relaxed text-mute">{pick(lang, LB.ipNote)}</p>
        <label className="mono-label mb-1.5 block">{pick(lang, LB.ip)}</label>
        <input className="inp font-mono" dir="ltr" value={ip} onChange={(e) => { setIp(e.target.value); setErr(false); }} placeholder="192.168.1.1" />
        {err && <p className="mt-2 text-xs text-blood">{pick(lang, LB.required)}</p>}
        <button onClick={submit} disabled={busy} className="btn-acid mt-3 w-full py-2.5 disabled:opacity-50">
          {busy ? <><span className="spin" />{pick(lang, LB.loading)}</> : <><Icon name="send" size={13} />{pick(lang, LB.sendReq)}</>}
        </button>
      </div>

      <div className="panel p-4">
        <div className="mono-label mb-3 flex items-center gap-2 text-acid"><Icon name="tool" size={12} />{pick(lang, LB.customizer)}</div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div>
            <label className="mono-label mb-1.5 block">{pick(lang, LB.type)}</label>
            <select className="inp" value={type} onChange={(e) => setType(e.target.value)}>{PROXY_TYPES.map((x) => <option key={x.ar} value={x.ar}>{pick(lang, x)}</option>)}</select>
          </div>
          <div>
            <label className="mono-label mb-1.5 block">{pick(lang, LB.duration)}</label>
            <select className="inp" value={dur} onChange={(e) => setDur(e.target.value)}>{PROXY_DURATIONS.map((x) => <option key={x.id} value={x.id}>{pick(lang, x.label)} — {x.price}$</option>)}</select>
          </div>
          <div className="sm:col-span-2">
            <label className="mono-label mb-1.5 block">{pick(lang, LB.ip)}</label>
            <input className="inp font-mono" dir="ltr" value={cIp} onChange={(e) => { setCIp(e.target.value); setCErr(false); }} placeholder="192.168.1.1" />
          </div>
          <div className="sm:col-span-2">
            <label className="mono-label mb-1.5 block">السعر (تلقائي)</label>
            <div className="flex h-[42px] items-center border border-acid/40 bg-acid/5 px-3 font-mono text-lg font-bold text-acid">${d.price}</div>
          </div>
        </div>
        {cErr && <p className="mt-2 text-xs text-blood">{pick(lang, LB.required)}</p>}
        <button onClick={submitCustom} disabled={busy} className="btn-acid mt-3 w-full py-2.5 disabled:opacity-50">
          {busy ? pick(lang, LB.loading) : <><Icon name="cart" size={13} />{pick(lang, LB.confirmSub)}</>}
        </button>
      </div>
    </>
  );
}

/* ═══════════ أدوات خدمات النخبة ═══════════ */
function EliteTools({ busy, onSend }: { busy: boolean; onSend: (m: string) => void }) {
  const lang = useLang();
  const [country, setCountry] = useState(ELITE_COUNTRIES[0].id);
  const [bank, setBank] = useState(ELITE_COUNTRIES[0].banks[0].id);
  const [name, setName] = useState("");
  const [dob, setDob] = useState("");
  const [email, setEmail] = useState("");
  const [extras, setExtras] = useState<string[]>([]);
  const [err, setErr] = useState(false);
  const [cBank, setCBank] = useState(ELITE_COUNTRIES[0].banks[0].name.ar || "");
  const [amount, setAmount] = useState("");
  const [cName, setCName] = useState("");
  const [cErr, setCErr] = useState(false);

  const c = ELITE_COUNTRIES.find((x) => x.id === country) ?? ELITE_COUNTRIES[0];
  const banks = c.banks;
  const b = banks.find((x) => x.id === bank) ?? banks[0];
  const total = ELITE_ACCOUNT_PRICE + extras.reduce((a, id) => a + (ELITE_EXTRAS.find((x) => x.id === id)?.price ?? 0), 0);

  const switchCountry = (id: string) => {
    const cc = ELITE_COUNTRIES.find((x) => x.id === id) ?? ELITE_COUNTRIES[0];
    setCountry(id); setBank(cc.banks[0].id); setCBank(cc.banks[0].name.ar || "");
  };
  const submitAccount = () => {
    if (!name.trim() || !dob.trim() || !email.trim()) { setErr(true); return; }
    onSend(eliteAccountMessage({
      country: pick(lang, c.name), bank: pick(lang, b.name), name: name.trim(), dob: dob.trim(), email: email.trim(),
      extras: extras.map((id) => pick(lang, ELITE_EXTRAS.find((x) => x.id === id)!.label)), total,
    }));
    setName(""); setDob(""); setEmail(""); setExtras([]); setErr(false);
  };
  const submitCheck = () => {
    if (!amount.trim() || !cName.trim()) { setCErr(true); return; }
    onSend(checksMessage({ bank: cBank, amount: amount.trim(), name: cName.trim() }));
    setAmount(""); setCName(""); setCErr(false);
  };

  return (
    <>
      <div className="border border-line bg-abyss/60 p-4 text-xs leading-loose text-mute">{pick(lang, ELITE_DESC)}</div>

      {/* الأداة 1 */}
      <div className="panel p-4">
        <div className="mono-label mb-3 flex items-center gap-2 text-acid"><Icon name="shield" size={12} />{pick(lang, LB.eliteTool1)} · ${ELITE_ACCOUNT_PRICE}</div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div><label className="mono-label mb-1.5 block">{pick(lang, LB.country)}</label>
            <select className="inp" value={country} onChange={(e) => switchCountry(e.target.value)}>{ELITE_COUNTRIES.map((x) => <option key={x.id} value={x.id}>{pick(lang, x.name)}</option>)}</select></div>
          <div><label className="mono-label mb-1.5 block">{pick(lang, LB.bank)}</label>
            <select className="inp" value={bank} onChange={(e) => setBank(e.target.value)}>{banks.map((x) => <option key={x.id} value={x.id}>{pick(lang, x.name)}</option>)}</select></div>
          <div><label className="mono-label mb-1.5 block">{pick(lang, LB.fullName)}</label><input className="inp" value={name} onChange={(e) => { setName(e.target.value); setErr(false); }} placeholder="الاسم الرباعي" /></div>
          <div><label className="mono-label mb-1.5 block">{pick(lang, LB.dob)}</label><input className="inp" dir="ltr" value={dob} onChange={(e) => { setDob(e.target.value); setErr(false); }} placeholder="YYYY-MM-DD" /></div>
          <div className="sm:col-span-2"><label className="mono-label mb-1.5 block">{pick(lang, LB.email)}</label><input className="inp" dir="ltr" value={email} onChange={(e) => { setEmail(e.target.value); setErr(false); }} placeholder="name@mail.com" /></div>
        </div>
        <p className="mt-3 text-[11px] leading-relaxed text-amber">{pick(lang, ELITE_NOTE)}</p>
        <div className="mt-3 space-y-2">
          {ELITE_EXTRAS.map((x) => (
            <label key={x.id} className="flex cursor-pointer items-start gap-2 border border-line bg-abyss/60 p-3 text-xs leading-relaxed text-mute">
              <input type="checkbox" checked={extras.includes(x.id)} onChange={(e) => setExtras((v) => e.target.checked ? [...v, x.id] : v.filter((i) => i !== x.id))} className="mt-0.5 accent-[#b8ef80]" />
              {pick(lang, x.label)}
            </label>
          ))}
        </div>
        <div className="mt-3 flex items-center justify-between border border-acid/40 bg-acid/5 px-3 py-2"><span className="mono-label">السعر الإجمالي</span><span className="font-mono text-xl font-bold text-acid">${total}</span></div>
        {err && <p className="mt-2 text-xs text-blood">{pick(lang, LB.required)}</p>}
        <button onClick={submitAccount} disabled={busy} className="btn-acid mt-3 w-full py-2.5 disabled:opacity-50"><Icon name="plane" size={13} />{busy ? pick(lang, LB.loading) : pick(lang, LB.goManager)}</button>
      </div>

      {/* الأداة 2 */}
      <div className="panel p-4">
        <div className="mono-label mb-2 flex items-center gap-2 text-acid"><Icon name="card" size={12} />{pick(lang, LB.eliteTool2)}</div>
        <p className="mb-3 text-xs leading-relaxed text-mute">توفير واختبار الشيكات البنكية المضمونة مع كامل تفاصيل التسليم.</p>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div className="sm:col-span-2"><label className="mono-label mb-1.5 block">قائمة منسدلة لاختيار البنك / الدولة المصدرة للشيك</label>
            <select className="inp" value={cBank} onChange={(e) => setCBank(e.target.value)}>
              {ELITE_COUNTRIES.flatMap((x) => x.banks.map((bb) => <option key={`${x.id}-${bb.id}`} value={`${bb.name.ar} — ${x.name.ar}`}>{bb.name.ar} — {x.name.ar}</option>))}
            </select></div>
          <div><label className="mono-label mb-1.5 block">{pick(lang, LB.checkValue)}</label><input className="inp font-mono" dir="ltr" value={amount} onChange={(e) => { setAmount(e.target.value); setCErr(false); }} placeholder="10,000$" /></div>
          <div><label className="mono-label mb-1.5 block">{pick(lang, LB.fullName)}</label><input className="inp" value={cName} onChange={(e) => { setCName(e.target.value); setCErr(false); }} placeholder="الاسم الرباعي" /></div>
        </div>
        <p className="mt-3 text-[11px] leading-relaxed text-amber">{pick(lang, CHECK_NOTE)}</p>
        {cErr && <p className="mt-2 text-xs text-blood">{pick(lang, LB.required)}</p>}
        <button onClick={submitCheck} disabled={busy} className="btn-acid mt-3 w-full py-2.5 disabled:opacity-50"><Icon name="plane" size={13} />{busy ? pick(lang, LB.loading) : pick(lang, LB.goManager)}</button>
      </div>
    </>
  );
}
