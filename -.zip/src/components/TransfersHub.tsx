"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  TRANSFER_SECTIONS,
  EXPLORE_ITEMS,
  OTHER_SERVICES,
  orderMessage,
  customOrderMessage,
  type TProduct,
  type TSection,
  type CustomCfg,
  type TField,
} from "@/lib/transfers";
import { BUY_MANAGER, pick, type L } from "@/lib/site";
import { copyText, dispatchToTelegram, buildWebFallback } from "@/lib/forumClient";
import { useT, useLang, toast } from "@/lib/client";
import { Icon } from "./Icon";
import Shell from "./Shell";
import SectionToolCTA from "./SectionToolCTA";

const A = (ar: string, en = ar): L => ({ ar, en });
type Cart = Record<string, number>;

const LB = {
  sections: A("الأقسام", "Sections"),
  products: A("العروض الثابتة", "Fixed offers"),
  details: A("عرض التفاصيل", "Details"),
  buy: A("شراء", "Buy"),
  cart: A("السلة", "Cart"),
  addCart: A("إضافة للسلة", "Add to cart"),
  total: A("الإجمالي", "Total"),
  sendCart: A("إرسال طلب السلة", "Send cart order"),
  preview: A("معاينة الرسالة", "Message preview"),
  copy: A("نسخ الرسالة", "Copy message"),
  open: A("فتح المحادثة", "Open chat"),
  explore: A("🌐 استكشف باقي الخدمات", "🌐 Explore services"),
  otherSvc: A("➕ حقن خدمات أخرى", "➕ Inject other services"),
  custom: A("طلب مخصص", "Custom order"),
  qty: A("الكمية المطلوبة", "Quantity"),
  price: A("السعر الإجمالي", "Total price"),
  next: A("التالي", "Next"),
  prev: A("السابق", "Previous"),
  close: A("إغلاق", "Close"),
  minErr: A("عذراً، الحد الأدنى للطلب لم يتحقق — لا يمكن المتابعة.", "Minimum quantity not met."),
  required: A("أكمل جميع الحقول الإلزامية.", "Fill all required fields."),
  tech: A("الشرح التقني الكامل", "Full technical guide"),
};

/** ═══ MONEY_FLOW_SYSTEM — التحويلات والتبييض ═══ */
export default function TransfersHub() {
  const t = useT();
  const lang = useLang();
  const router = useRouter();

  const [active, setActive] = useState<string | null>(null);
  const [explore, setExplore] = useState(false);
  const [other, setOther] = useState(false);
  const [modal, setModal] = useState<TProduct | null>(null);
  const [customOpen, setCustomOpen] = useState(false);
  const [cart, setCart] = useState<Cart>({});
  const [cartOpen, setCartOpen] = useState(false);
  const [relay, setRelay] = useState("");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!modal && !customOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && (setModal(null), setCustomOpen(false));
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", onKey); document.body.style.overflow = ""; };
  }, [modal, customOpen]);

  const sec = active ? TRANSFER_SECTIONS.find((s) => s.id === active) : undefined;

  const send = useCallback((msg: string) => {
    void copyText(msg);
    void dispatchToTelegram(msg, BUY_MANAGER);
    setRelay(msg);
    setCopied(true);
    toast(t("fa.copied"));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [t]);

  /** العروض الثابتة → تحويل مباشر برسالة الشراء الموحدة */
  const buy = (p: TProduct, s?: TSection) =>
    send(orderMessage(p.name.ar || "", p.priceUsd, s?.buyNote.ar ? [`📌 ${s.buyNote.ar}`] : undefined));

  const addCart = (id: string) => {
    setCart((c) => ({ ...c, [id]: (c[id] || 0) + 1 }));
    toast(t("p.added"));
  };

  const allProducts = useMemo(
    () => TRANSFER_SECTIONS.flatMap((s) => s.products.map((p) => ({ p, s }))),
    [],
  );
  const cartItems = Object.entries(cart)
    .map(([id, qty]) => ({ ...allProducts.find((x) => x.p.id === id), qty }))
    .filter((x): x is { p: TProduct; s: TSection; qty: number } => !!x.p);
  const cartCount = cartItems.reduce((a, x) => a + x.qty, 0);
  const cartTotal = cartItems.reduce((a, x) => a + x.p.priceUsd * x.qty, 0);

  const sendCart = () => {
    if (!cartItems.length) return;
    send(orderMessage(
      `سلة تحويلات (${cartCount} عنصر)`, cartTotal,
      cartItems.map((x) => `• ${x.p.name.ar} × ${x.qty} — ${x.p.priceUsd * x.qty}$`),
    ));
    setCartOpen(false);
  };

  const open = (id: string) => { setActive(id); setExplore(false); setOther(false); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const back = () => {
    if (modal) setModal(null);
    else if (customOpen) setCustomOpen(false);
    else if (explore) setExplore(false);
    else if (active) { setActive(null); router.replace("/market/transfer"); window.scrollTo({ top: 0, behavior: "smooth" }); }
    else router.push("/market");
  };

  return (
    <Shell>
      <div className="space-y-5 pb-28 pt-4">
        {/* ═══ شريط علوي ثابت ═══ */}
        <div className="sticky top-[96px] z-20 -mx-3 border-b border-line bg-void/95 px-3 py-2 backdrop-blur-md sm:-mx-5 sm:px-5">
          <div className="flex flex-wrap items-center gap-2">
            <button onClick={back} className="btn-ghost shrink-0 px-3 py-1.5 text-[9px]">
              <Icon name="back" size={11} className="rtl:rotate-180" />
              🔙 {active ? pick(lang, LB.sections) : t("c.back")}
            </button>
            <button onClick={() => setExplore((v) => !v)} className="btn-ghost shrink-0 !border-violet/50 !px-3 !py-1.5 !text-[9px] !text-violet">
              {pick(lang, LB.explore)}
            </button>
            <span className="ms-auto font-mono text-[9px] tracking-widest text-acid">
              {sec ? `${sec.products.length} OFFERS` : "05 SECTIONS"}
            </span>
          </div>
          {active && (
            <div className="no-scrollbar -mx-1 mt-2 flex gap-1.5 overflow-x-auto px-1">
              {TRANSFER_SECTIONS.map((s) => (
                <button key={s.id} onClick={() => open(s.id)}
                  className={`shrink-0 border px-3 py-1.5 font-mono text-[10px] font-bold tracking-wider transition-all ${
                    active === s.id ? "border-acid bg-acid text-void shadow-[0_0_16px_rgba(184,239,128,0.3)]" : "border-line bg-abyss/60 text-mute hover:text-fog"
                  }`}>{pick(lang, s.short)}</button>
              ))}
            </div>
          )}
        </div>

        {/* ═══ قائمة «استكشف باقي الخدمات» المنزلقة ═══ */}
        {explore && (
          <>
            <div className="fixed inset-0 z-[75] bg-void/60" onClick={() => setExplore(false)} />
            <aside className="panel animate-drawer fixed inset-y-0 start-0 z-[76] w-[min(88vw,320px)] overflow-auto border-e border-line p-4">
              <div className="mb-4 flex items-center justify-between">
                <span className="mono-label">{pick(lang, LB.explore)}</span>
                <button onClick={() => setExplore(false)} className="btn-icon h-8 w-8"><Icon name="close" size={14} /></button>
              </div>
              <div className="space-y-2">
                {EXPLORE_ITEMS.map((x) => (
                  <button key={x.id} onClick={() => router.push(x.route)} className="flex w-full items-center gap-3 border border-line bg-abyss/60 px-3 py-3 text-start text-sm hover:border-acid/50 hover:text-acid">
                    <Icon name={x.icon} size={15} className="text-dim" />
                    <span className="flex-1">{pick(lang, x.label)}</span>
                    <Icon name="back" size={12} className="rotate-180 text-mute rtl:rotate-0" />
                  </button>
                ))}
              </div>
            </aside>
          </>
        )}

        {/* ═══ معاينة الرسالة ═══ */}
        {relay && (
          <div className="panel animate-fade-up">
            <div className="mono-label flex items-center justify-between border-b border-line px-4 py-2.5">
              <span>📤 {pick(lang, LB.preview)}</span><span className="text-acid">✓ {t("op.copied")}</span>
            </div>
            <pre className="max-h-52 overflow-auto whitespace-pre-wrap p-4 font-mono text-[11px] leading-6 text-fog/90" dir="auto">{relay}</pre>
            <div className="grid grid-cols-3 gap-2 border-t border-line p-3">
              <button onClick={async () => { if (await copyText(relay)) toast(t("op.copied")); }} className="btn-ghost py-2 text-[9px]"><Icon name={copied ? "check" : "link"} size={11} />{pick(lang, LB.copy)}</button>
              <button onClick={() => window.open(buildWebFallback(relay, BUY_MANAGER), "_blank", "noreferrer")} className="btn-acid py-2 text-[9px]"><Icon name="plane" size={11} />{pick(lang, LB.open)}</button>
              <button onClick={() => setRelay("")} className="btn-ghost py-2 text-[9px]"><Icon name="close" size={11} />{pick(lang, LB.close)}</button>
            </div>
          </div>
        )}

        {/* ═══ شبكة الأقسام 2×2 / 3×3 ═══ */}
        {!sec && (
          <section>
            <div className="mono-label mb-3">// MONEY_FLOW_SYSTEM · 05</div>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
              {TRANSFER_SECTIONS.map((s, i) => (
                <button key={s.id} onClick={() => open(s.id)} className="panel panel-hover corners group flex flex-col overflow-hidden text-start">
                  <div className="relative h-24 overflow-hidden sm:h-32">
                    <img src={s.hero} alt="" loading="lazy" decoding="async" className="h-full w-full object-cover opacity-80 transition-transform duration-500 group-hover:scale-105" />
                    <span className="absolute top-2 end-2 border border-line bg-void/85 px-1.5 py-0.5 font-mono text-[9px] text-acid">{String(i + 1).padStart(2, "0")} · {s.products.length}</span>
                  </div>
                  <div className="acc-strip h-[3px] w-full" />
                  <div className="flex flex-1 flex-col p-3">
                    <div className="text-[13px] font-bold leading-snug sm:text-sm">{pick(lang, s.name)}</div>
                    <p className="mt-1 line-clamp-2 text-[10px] leading-relaxed text-mute sm:text-[11px]">{pick(lang, s.desc)}</p>
                    <div className="btn-acid mt-3 w-full !py-2 text-[10px]">{t("c.enter")}</div>
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* ═══ محتوى القسم ═══ */}
        {sec && (
          <div key={sec.id} className="animate-fade-up space-y-4">
            <header className="panel relative overflow-hidden p-5 sm:p-7">
              <img src={sec.hero} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-20" />
              <div className="relative">
                <div className="mono-label mb-2 flex items-center gap-2 text-acid">
                  {sec.id === "bank" ? <Icon name="swap" size={12} className="acc-lock" /> : <Icon name="lock" size={12} className="acc-lock" />}
                  {sec.id.toUpperCase()} :: ✅ VERIFIED
                </div>
                <h1 className="display-2 font-bold">{pick(lang, sec.name)}</h1>
                <p className="mt-2 max-w-3xl text-sm leading-relaxed text-mute">{pick(lang, sec.desc)}</p>
              </div>
            </header>

            {/* العروض الثابتة */}
            <div className="mono-label">// {pick(lang, LB.products)} · {String(sec.products.length).padStart(2, "0")}</div>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
              {sec.products.map((p) => (
                <ProductCard key={p.id} p={p} sec={sec} onBuy={() => buy(p, sec)} onCart={() => addCart(p.id)} onDetails={() => setModal(p)} />
              ))}
            </div>

            {/* الشرح التقني الكامل */}
            <TechBox section={sec} />

            {/* أداة الطلب المخصص — داخل القسم نفسه */}
            {sec.custom && (
              <>
                <SectionToolCTA
                  label={sec.custom.title}
                  hint={A("⚙️ اطلب كمية مخصصة وأدخل بياناتك من هنا — الأداة موجودة داخل هذا القسم، لا حاجة للذهاب لأي صفحة أخرى.")}
                  badge={`${sec.custom.min.toLocaleString()} MIN`}
                />
                <CustomTool cfg={sec.custom} section={sec} onSend={send} />
              </>
            )}

            {/* زر حقن خدمات أخرى — صفحة AMEX */}
            {sec.id === "amex" && (
              <div className="panel p-3">
                <button onClick={() => setOther((v) => !v)} className={`btn-ghost w-full py-2.5 ${other ? "!border-acid/50 !text-acid" : ""}`}>
                  <Icon name="plus" size={13} />{pick(lang, LB.otherSvc)}
                  <Icon name="chevron" size={12} className={other ? "rotate-180 transition-transform" : "transition-transform"} />
                </button>
                {other && (
                  <div className="animate-fade-up mt-2 grid grid-cols-1 gap-2 sm:grid-cols-3">
                    {OTHER_SERVICES.map((o) => (
                      <button key={o.id}
                        onClick={() => send(orderMessage(pick(lang, o.label), 0, [`📌 مرحباً، أريد طلب خدمة ${pick(lang, o.label)}، يرجى تزويدي بمحفظة الدفع.`]))}
                        className="btn-acid px-2 py-2.5 text-[10px]">{pick(lang, o.label)}</button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* TOOL-13: الملاحظة الثابتة تحت كل الأقسام */}
      <div className="fixed inset-x-0 bottom-12 z-30 border-t border-line bg-void/95 px-3 py-2 backdrop-blur-md">
        <div className="mx-auto flex max-w-[1190px] flex-wrap items-center gap-2">
          <Icon name="warn" size={13} className="shrink-0 text-amber" />
          <p className="min-w-0 flex-1 text-[10px] leading-relaxed text-mute sm:text-[11px]">
            📌 طلب مخصص: إذا لم تجد التطبيق المطلوب في القائمة، راسل المسؤول فوراً لتحديد التكلفة وتوفير الخدمة. وسيتم شحن التطبيق المطلوب.
          </p>
          <button onClick={() => send("مرحباً، أرغب بطلب مخصص غير مدرج في القائمة. يرجى تحديد التكلفة وتوفير الخدمة.")} className="btn-acid shrink-0 !py-1.5 !text-[9px]">
            <Icon name="plane" size={11} />✈️ راسل المسؤول
          </button>
        </div>
      </div>

      {/* رجوع عائم */}
      {active && (
        <button onClick={back} title={pick(lang, LB.sections)} aria-label={pick(lang, LB.sections)} className="glass glass-hover fixed bottom-16 start-4 z-40 flex h-11 w-11 items-center justify-center border-acid/50 text-acid">
          <Icon name="back" size={18} className="rtl:rotate-180" />
        </button>
      )}

      {/* السلة */}
      {cartCount > 0 && (
        <button onClick={() => setCartOpen((v) => !v)} className="glass glass-hover fixed bottom-16 end-4 z-40 flex h-11 w-11 items-center justify-center border-acid/50 text-acid">
          <Icon name="cart" size={18} />
          <span className="absolute -top-1 -end-1 flex h-4 min-w-4 items-center justify-center bg-acid px-1 font-mono text-[9px] font-bold text-void">{cartCount}</span>
        </button>
      )}
      {cartOpen && cartCount > 0 && (
        <div className="panel fixed bottom-28 end-4 z-[55] w-[min(92vw,340px)] p-3 shadow-[0_24px_60px_-20px_rgba(0,0,0,0.9)]">
          <div className="mb-2 flex items-center gap-2 border-b border-line pb-2">
            <Icon name="cart" size={14} className="text-acid" /><span className="mono-label flex-1">{pick(lang, LB.cart)}</span>
            <button onClick={() => setCartOpen(false)} className="text-mute hover:text-fog"><Icon name="close" size={14} /></button>
          </div>
          <div className="max-h-56 space-y-2 overflow-auto">
            {cartItems.map(({ p, qty }) => (
              <div key={p.id} className="flex items-center gap-2 border border-line bg-abyss/60 p-2">
                <div className="min-w-0 flex-1"><div className="truncate text-[11px] font-bold">{pick(lang, p.name)}</div><div className="font-mono text-[10px] text-acid">${p.priceUsd * qty}</div></div>
                <button onClick={() => setCart((c) => ({ ...c, [p.id]: Math.max(0, c[p.id] - 1) }))} className="flex h-7 w-7 items-center justify-center border border-line text-mute"><Icon name="minus" size={10} /></button>
                <span className="w-5 text-center font-mono text-xs">{qty}</span>
                <button onClick={() => setCart((c) => ({ ...c, [p.id]: c[p.id] + 1 }))} className="flex h-7 w-7 items-center justify-center border border-line text-mute"><Icon name="plus" size={10} /></button>
              </div>
            ))}
          </div>
          <div className="mt-3 flex items-center justify-between border-t border-line pt-2"><span className="mono-label">{pick(lang, LB.total)}</span><span className="font-mono text-lg font-bold text-acid">${cartTotal}</span></div>
          <button onClick={sendCart} className="btn-acid mt-3 w-full py-2.5 text-[10px]"><Icon name="send" size={12} />{pick(lang, LB.sendCart)}</button>
        </div>
      )}

      {/* نافذة التفاصيل */}
      {modal && sec && (
        <DetailModal p={modal} sec={sec} onClose={() => setModal(null)} onBuy={() => { buy(modal, sec); setModal(null); }} onCart={() => { addCart(modal.id); setModal(null); }} />
      )}
      {/* نافذة جمع بيانات الطلب المخصص */}
      {customOpen && sec?.custom && (
        <CustomModal cfg={sec.custom} section={sec} onClose={() => setCustomOpen(false)} onSend={(msg) => { send(msg); setCustomOpen(false); }} />
      )}
    </Shell>
  );
}

/* ═══════════ بطاقة المنتج ═══════════ */
function ProductCard({ p, sec, onBuy, onCart, onDetails }: {
  p: TProduct; sec: TSection; onBuy: () => void; onCart: () => void; onDetails: () => void;
}) {
  const lang = useLang();
  const [err, setErr] = useState(false);
  return (
    <div className="panel panel-hover corners group flex h-full flex-col overflow-hidden">
      <div className={`relative h-24 overflow-hidden sm:h-28 ${sec.id === "amex" ? "acc-shiny" : ""} ${sec.id === "ewallet" ? "tr-blue" : ""}`}>
        {!err ? (
          <img src={p.img} alt="" loading="lazy" decoding="async" onError={() => setErr(true)} className="h-full w-full object-cover opacity-80 transition-transform duration-500 group-hover:scale-105" />
        ) : (
          <div className="grid-bg-fine flex h-full w-full items-center justify-center"><Icon name={sec.icon} size={34} className="text-dim" /></div>
        )}
        <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-void/80 via-transparent to-transparent" />
        {p.featured && <span className="absolute top-2 start-2 border border-acid/50 bg-void/85 px-1.5 py-0.5 font-mono text-[8px] text-acid">★ Verified</span>}
      </div>
      <div className="acc-strip h-[3px] w-full" />
      <div className="flex min-h-0 flex-1 flex-col p-2.5 sm:p-3">
        <h3 className="line-clamp-2 text-[11px] font-bold leading-snug sm:text-[13px]">{pick(lang, p.name)}</h3>
        <p className="mt-1 line-clamp-2 text-[10px] leading-relaxed text-mute sm:text-[11px]">{pick(lang, p.desc)}</p>
        {p.balance && <div className="mt-1.5 font-mono text-[9px] text-acid">💰 {pick(lang, p.balance)}</div>}
        <div className="mt-1 flex flex-wrap gap-1">
          {p.badges.map((b) => <span key={b} className="border border-line2/60 bg-abyss/70 px-1.5 py-0.5 font-mono text-[8px] tracking-wider text-mute">{b}</span>)}
        </div>
        <div className="mt-auto pt-2">
          <div className="flex items-baseline gap-2">
            {p.oldPriceUsd && <span className="font-mono text-[10px] text-mute/70 line-through" dir="ltr">${p.oldPriceUsd}</span>}
            <span className="font-mono text-lg font-bold text-acid text-glow sm:text-xl" dir="ltr">${p.priceUsd}</span>
          </div>
          <div className="mt-2 grid grid-cols-2 gap-1.5">
            <button onClick={onBuy} className="btn-acid !px-1 !py-2 !text-[9px]">{pick(lang, LB.buy)}</button>
            <button onClick={onDetails} className="btn-ghost !px-1 !py-2 !text-[9px]"><Icon name="eye" size={10} />{pick(lang, LB.details)}</button>
          </div>
          <button onClick={onCart} className="btn-ghost mt-1.5 w-full !px-1 !py-1.5 !text-[9px]"><Icon name="cart" size={10} />{pick(lang, LB.addCart)}</button>
        </div>
      </div>
    </div>
  );
}

/* ═══════════ صندوق الشرح التقني ═══════════ */
function TechBox({ section }: { section: TSection }) {
  const lang = useLang();
  const [open, setOpen] = useState(false);
  return (
    <div>
      <button onClick={() => setOpen((v) => !v)} className={`btn-ghost w-full py-2.5 ${open ? "!border-acid/50 !text-acid" : ""}`}>
        <Icon name="book" size={13} />{pick(lang, section.techTitle)}
        <Icon name="chevron" size={12} className={open ? "rotate-180 transition-transform" : "transition-transform"} />
      </button>
      {open && (
        <div className="panel animate-fade-up mt-2 border-acid/40">
          <div className="mono-label flex items-center justify-between border-b border-line px-4 py-2.5">
            <span>◈ {pick(lang, LB.tech)}</span>
            <button onClick={() => setOpen(false)} className="flex items-center gap-1 text-mute hover:text-acid"><Icon name="close" size={11} />{pick(lang, LB.close)}</button>
          </div>
          <div className="divide-y divide-line">
            {section.tech.map((x, i) => (
              <div key={i} className="flex gap-3 px-4 py-3">
                <span className="shrink-0 font-mono text-[10px] text-acid">{String(i + 1).padStart(2, "0")}</span>
                <p className="text-xs leading-loose text-mute">{pick(lang, x)}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ═══════════ أداة الطلب المخصص ═══════════ */
function CustomTool({ cfg, section, onSend }: { cfg: CustomCfg; section: TSection; onSend: (m: string) => void }) {
  const lang = useLang();
  const TOOL_ID = "custom-tool";
  const [qty, setQty] = useState(String(cfg.min));
  const [wallet, setWallet] = useState(cfg.wallets?.[0]?.id ?? "");
  const [openForm, setOpenForm] = useState(false);
  const qtyNum = Number(qty) || 0;
  const price = Math.round((qtyNum / 1000) * cfg.pricePer1000 * 100) / 100;
  const below = qtyNum < cfg.min || qtyNum < 100;

  return (
    <div id="custom-tool" className="panel acc-cta-panel scroll-mt-32 p-4">
      <div className="mono-label mb-2 flex items-center gap-2 text-acid"><Icon name="tool" size={12} />{pick(lang, cfg.title)}</div>
      <p className="mb-3 text-xs leading-relaxed text-mute">{pick(lang, cfg.note)}</p>

      {cfg.wallets && (
        <div className="mb-3">
          <label className="mono-label mb-1.5 block">اختر المحفظة</label>
          <select className="inp" value={wallet} onChange={(e) => setWallet(e.target.value)}>
            {cfg.wallets.map((w) => <option key={w.id} value={w.id}>{pick(lang, w.name)}</option>)}
          </select>
        </div>
      )}

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div>
          <label className="mono-label mb-1.5 block">{pick(lang, LB.qty)} — أدخل الكمية المطلوبة (الحد الأدنى {(cfg.labelMin ?? cfg.min).toLocaleString()} وحدة)</label>
          <input className="inp font-mono" type="number" inputMode="numeric" min={cfg.min} value={qty} onChange={(e) => setQty(e.target.value)} />
        </div>
        <div>
          <label className="mono-label mb-1.5 block">{pick(lang, LB.price)} (USD)</label>
          <div className="flex h-[42px] items-center border border-acid/40 bg-acid/5 px-3 font-mono text-lg font-bold text-acid">${price.toLocaleString()}</div>
        </div>
      </div>

      {below && <p className="mt-2 flex items-center gap-2 border border-blood/40 bg-blood/10 px-3 py-2 text-xs text-blood"><Icon name="warn" size={12} />
        {cfg.kind === "amex" ? `عذراً، الحد الأدنى للحقن هو ${cfg.min.toLocaleString()}$` : `عذراً، الحد الأدنى للطلب هو ${cfg.min.toLocaleString()} وحدة`}
      </p>}

      <button
        onClick={() => setOpenForm(true)}
        disabled={below}
        className="btn-acid mt-3 w-full py-2.5 disabled:opacity-40"
      >
        <Icon name="send" size={13} />{pick(lang, cfg.continueLabel)}
      </button>

      {openForm && (
        <CustomModalInline cfg={cfg} section={section} qty={qtyNum} price={price} walletId={wallet} onClose={() => setOpenForm(false)} onSend={onSend} />
      )}
    </div>
  );
}

/** نافذة جمع البيانات (Inline منسدلة) */
function CustomModalInline({ cfg, section, qty, price, walletId, onClose, onSend }: {
  cfg: CustomCfg; section: TSection; qty: number; price: number; walletId: string;
  onClose: () => void; onSend: (m: string) => void;
}) {
  const lang = useLang();
  const [values, setValues] = useState<Record<string, string>>({});
  const [step, setStep] = useState(0);
  const [err, setErr] = useState(false);

  const walletDef = cfg.wallets?.find((w) => w.id === walletId);
  const walletName = walletDef ? pick(lang, walletDef.name) : undefined;
  const fields: TField[] = cfg.kind === "ewallet" ? (walletDef?.fields ?? cfg.fields) : cfg.fields;
  const steps = cfg.steps ?? [];
  const isStepped = cfg.kind === "flash" && steps.length > 0;
  const current = isStepped ? steps[step] : undefined;

  const missing = isStepped
    ? !(values[current?.field.id ?? ""] || "").trim()
    : fields.some((f) => !f.optional && !(values[f.id] || "").trim());

  const finish = () => {
    if (missing) { setErr(true); return; }
    onSend(customOrderMessage({ cfg, section, qty, price, walletName, values }));
    onClose();
  };

  const renderField = (f: TField) => (
    <div key={f.id}>
      <label className="mono-label mb-1.5 block">{pick(lang, f.label)}{!f.optional && <span className="text-blood"> *</span>}</label>
      {f.options ? (
        <select className="inp" value={values[f.id] || ""} onChange={(e) => { setValues((v) => ({ ...v, [f.id]: e.target.value })); setErr(false); }}>
          <option value="">—</option>
          {f.options.map((o, i) => <option key={i} value={pick(lang, o)}>{pick(lang, o)}</option>)}
        </select>
      ) : (
        <input className="inp" dir="ltr" value={values[f.id] || ""} onChange={(e) => { setValues((v) => ({ ...v, [f.id]: e.target.value })); setErr(false); }} placeholder={pick(lang, f.ph)} />
      )}
      <p className="mt-1 text-[10px] text-mute/70">{pick(lang, f.label)}</p>
    </div>
  );

  return (
    <div className="animate-fade-up mt-3 border border-line bg-abyss/70 p-4">
      <div className="mono-label mb-3 flex items-center justify-between">
        <span>📝 {isStepped ? pick(lang, current?.title ?? LB.custom) : `بيانات ${walletName ?? pick(lang, cfg.title)}`}</span>
        <button onClick={onClose} className="flex items-center gap-1 text-mute hover:text-acid"><Icon name="close" size={11} />{pick(lang, LB.close)}</button>
      </div>

      <div className="mb-3 flex items-center justify-between border border-acid/30 bg-acid/5 px-3 py-2 font-mono text-[11px]">
        <span className="text-mute">{qty.toLocaleString()} {pick(lang, cfg.unitLabel)}</span>
        <span className="text-acid">${price.toLocaleString()}</span>
      </div>

      {isStepped ? (
        <div className="space-y-3">
          <div className="mono-label">{pick(lang, current?.title ?? LB.custom)} · {step + 1}/{steps.length}</div>
          {current && renderField(current.field)}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">{fields.map(renderField)}</div>
      )}

      {err && <p className="mt-2 flex items-center gap-2 text-xs text-blood"><Icon name="warn" size={12} />{pick(lang, LB.required)}</p>}

      <div className="mt-4 flex gap-2">
        {isStepped && step > 0 && (
          <button onClick={() => { setStep((s) => s - 1); setErr(false); }} className="btn-ghost px-4 py-2.5 text-[10px]"><Icon name="back" size={12} className="rtl:rotate-180" />{pick(lang, LB.prev)}</button>
        )}
        {isStepped && step < steps.length - 1 ? (
          <button onClick={() => { if (missing) { setErr(true); return; } setStep((s) => s + 1); setErr(false); }} className="btn-acid flex-1 py-2.5 text-[10px]">{pick(lang, LB.next)}</button>
        ) : (
          <button onClick={finish} className="btn-acid flex-1 py-2.5 text-[10px]"><Icon name="send" size={12} />{pick(lang, cfg.submitLabel)}</button>
        )}
      </div>
    </div>
  );
}

/** نافذة مستقلة (للتوافق مع زر ESC) */
function CustomModal({ cfg, section, onClose, onSend }: {
  cfg: CustomCfg; section: TSection; onClose: () => void; onSend: (m: string) => void;
}) {
  return (
    <div className="fixed inset-0 z-[65] flex items-center justify-center p-4" role="dialog" aria-modal>
      <div className="absolute inset-0 bg-void/85 backdrop-blur-sm" onClick={onClose} />
      <div className="panel animate-fade-up relative w-full max-w-lg p-4">
        <CustomModalInline cfg={cfg} section={section} qty={cfg.min} price={cfg.pricePer1000} walletId={cfg.wallets?.[0]?.id ?? ""} onClose={onClose} onSend={onSend} />
      </div>
    </div>
  );
}

/* ═══════════ نافذة التفاصيل ═══════════ */
function DetailModal({ p, sec, onClose, onBuy, onCart }: {
  p: TProduct; sec: TSection; onClose: () => void; onBuy: () => void; onCart: () => void;
}) {
  const lang = useLang();
  const [err, setErr] = useState(false);
  return (
    <div className="fixed inset-0 z-[65] flex items-center justify-center p-4" role="dialog" aria-modal>
      <div className="absolute inset-0 bg-void/85 backdrop-blur-sm" onClick={onClose} />
      <div className="panel animate-fade-up relative flex max-h-[88vh] w-full max-w-xl flex-col">
        <div className="flex items-center justify-between border-b border-line px-4 py-3">
          <span className="mono-label">ℹ️ {pick(lang, LB.details)} :: DETAILS</span>
          <button onClick={onClose} className="btn-icon h-8 w-8"><Icon name="close" size={15} /></button>
        </div>
        <div className="flex-1 overflow-y-auto">
          <div className="relative h-44 sm:h-56">
            {!err ? <img src={p.img} alt="" onError={() => setErr(true)} className="h-full w-full object-cover opacity-85" /> :
              <div className="grid-bg-fine flex h-full w-full items-center justify-center"><Icon name={sec.icon} size={64} className="text-dim" /></div>}
            <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-void/80 to-transparent" />
          </div>
          <div className="acc-strip h-[3px] w-full" />
          <div className="p-5">
            <h2 className="text-xl font-bold sm:text-2xl">{pick(lang, p.name)}</h2>
            <p className="mt-2 text-sm leading-relaxed text-mute">{pick(lang, p.desc)}</p>
            {p.balance && <div className="mt-2 font-mono text-xs text-acid">💰 {pick(lang, p.balance)}</div>}
            <div className="mt-2 flex flex-wrap gap-1.5">
              {p.badges.map((b) => <span key={b} className="border border-acid/40 bg-acid/10 px-2 py-0.5 font-mono text-[9px] tracking-widest text-acid">{b}</span>)}
            </div>
            <div className="mt-3 flex items-baseline gap-3">
              {p.oldPriceUsd && <span className="font-mono text-base text-mute/70 line-through" dir="ltr">${p.oldPriceUsd}</span>}
              <span className="font-mono text-3xl font-bold text-acid text-glow" dir="ltr">${p.priceUsd}</span>
            </div>
            <div className="mt-4 border border-line bg-abyss/60 p-4">
              <div className="mono-label mb-2">📜 تفاصيل العرض</div>
              <p className="whitespace-pre-line text-xs leading-loose text-fog/90">{pick(lang, p.details)}</p>
            </div>
            <div className="mt-4 border border-acid/40 bg-acid/5 p-4">
              <div className="mono-label mb-2 flex items-center gap-2 text-acid"><Icon name="book" size={12} />{pick(lang, sec.techTitle)}</div>
              <ul className="space-y-1.5">
                {sec.tech.map((x, i) => <li key={i} className="flex items-start gap-2 text-xs leading-relaxed text-mute"><Icon name="check" size={10} className="mt-0.5 shrink-0 text-acid" />{pick(lang, x)}</li>)}
              </ul>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 border-t border-line p-3">
          <button onClick={onBuy} className="btn-primary"><Icon name="cart" size={15} />{pick(lang, LB.buy)}</button>
          <button onClick={onCart} className="btn-acid"><Icon name="plus" size={14} />{pick(lang, LB.addCart)}</button>
        </div>
      </div>
    </div>
  );
}
