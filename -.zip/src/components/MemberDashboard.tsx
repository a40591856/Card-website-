"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  loadSession, saveSession, clearSession, MemberSession, MemberAccount,
  loadAccounts, saveAccount, localHash, getPoints, setPoints,
  getOrders, MemberOrder, referralLink, serverSync,
} from "@/lib/membership";
import { setAuth, toast, useT, useLang, useShell, shareSite } from "@/lib/client";
import { copyText } from "@/lib/forumClient";
import { Icon } from "./Icon";
import Shell from "./Shell";

/** ═══ لوحة تحكم العضو ═══ */
export default function MemberDashboard() {
  const t = useT();
  const lang = useLang();
  const router = useRouter();
  const shell = useShell();
  const [session, setSession] = useState<MemberSession | null>(null);
  const [points, setPointsState] = useState(0);
  const [orders, setOrders] = useState<MemberOrder[]>([]);
  const [name, setName] = useState("");
  const [pass, setPass] = useState("");
  const [newPass, setNewPass] = useState("");
  const [editing, setEditing] = useState(false);
  const [err, setErr] = useState("");

  const refresh = useCallback(() => {
    const s = loadSession();
    setSession(s);
    if (!s) return;
    setName(s.name);
    setPointsState(getPoints(s.id));
    setOrders(getOrders(s.id));
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  useEffect(() => {
    if (!session) return;
    // دمج طلبات قاعدة البيانات مع الصندوق المحلي
    fetch(`/api/account?owner=${encodeURIComponent(session.id)}`)
      .then((r) => r.json())
      .then((d) => {
        const remote: MemberOrder[] = (d.orders ?? []).map((o: { id: number; productId: number; qty: number; totalUsd: number; createdAt: string }) => ({
          id: `DB-${o.id}`, owner: session.id, name: `#${o.productId}`,
          priceUsd: o.totalUsd, qty: o.qty,
          at: String(o.createdAt).slice(0, 19).replace("T", " "),
        }));
        setOrders([...getOrders(session.id), ...remote]);
      })
      .catch(() => {});
  }, [session?.id]);

  const saveProfile = () => {
    if (!session) return;
    if (name.trim().length < 3) { setErr("الاسم 3 أحرف على الأقل"); return; }
    if (newPass && (newPass.length < 6 || !pass)) { setErr("كلمة المرور الجديدة 6 أحرف على الأقل مع الحالية"); return; }
    const acc = loadAccounts().find((a) => a.id === session.id);
    if (newPass && acc && acc.passHash !== localHash(pass)) { setErr("كلمة المرور الحالية غير صحيحة"); return; }
    const next: MemberSession = { ...session, name: name.trim() };
    const updated: MemberAccount | null = acc ? { ...acc, name: name.trim(), passHash: newPass ? localHash(newPass) : acc.passHash } : null;
    if (updated) saveAccount(updated);
    saveSession(next);
    setSession(next);
    void serverSync({ id: session.id, name: name.trim(), pass: pass || undefined, newPass: newPass || undefined, points: getPoints(session.id) });
    setPass(""); setNewPass(""); setErr(""); setEditing(false);
    toast("✅ تم تحديث بيانات الحساب");
  };

  const onAvatar = (file: File | null) => {
    if (!file || !session) return;
    const reader = new FileReader();
    reader.onload = () => {
      const avatar = String(reader.result);
      const next = { ...session, avatar };
      saveSession(next); setSession(next);
      const acc = loadAccounts().find((a) => a.id === session.id);
      if (acc) saveAccount({ ...acc, avatar });
      void serverSync({ id: session.id, avatar });
      toast("✅ تم تحديث الصورة الرمزية");
    };
    reader.readAsDataURL(file);
  };

  const logout = () => {
    clearSession();
    setAuth(null);
    toast("تم تسجيل الخروج — عدت كزائر");
    router.push("/");
  };

  if (!session) return (
    <Shell>
      <div className="panel flex flex-col items-center gap-4 p-10 text-center">
        <Icon name="lock" size={40} className="text-mute" />
        <h1 className="text-xl font-bold">جلسة غير موثّقة</h1>
        <p className="text-sm text-mute">سجّل الدخول أو أنشئ حساباً مشفراً للوصول إلى لوحة العضو.</p>
        <button onClick={() => shell?.openLogin()} className="btn-primary"><Icon name="user" size={15} />تسجيل الدخول</button>
      </div>
    </Shell>
  );

  return (
    <Shell>
      <div className="space-y-5 pt-4">
        {/* الترويسة الفخمة */}
        <header className="panel grid-bg-fine relative overflow-hidden p-5 sm:p-7">
          <div className="relative flex flex-wrap items-center gap-4">
            <label className="group relative cursor-pointer">
              {session.avatar ? (
                <img src={session.avatar} alt="avatar" className="h-20 w-20 rounded-full border border-acid/50 object-cover" />
              ) : (
                <div className="flex h-20 w-20 items-center justify-center rounded-full border border-acid/50 bg-panel text-acid">
                  <Icon name="user" size={36} />
                </div>
              )}
              <span className="absolute bottom-0 end-0 flex h-7 w-7 items-center justify-center rounded-full border border-acid/50 bg-void text-acid">
                <Icon name="plus" size={13} />
              </span>
              <input type="file" accept="image/*" className="hidden" onChange={(e) => onAvatar(e.target.files?.[0] ?? null)} />
            </label>
            <div className="min-w-0 flex-1">
              <div className="mono-label mb-1 !text-acid">SWISS-VAULT MEMBER · ACTIVE</div>
              <h1 className="display-2 font-bold">{session.name}</h1>
              <div className="mt-1 font-mono text-xs text-mute" dir="ltr">{session.email}</div>
              <div className="mt-2 inline-block border border-acid/40 bg-acid/10 px-2.5 py-1 font-mono text-[11px] font-bold tracking-[0.2em] text-acid" dir="ltr">
                ID: {session.id}
              </div>
            </div>
            <button onClick={logout} className="btn-ghost !border-blood/50 !text-blood"><Icon name="logout" size={14} />تسجيل الخروج</button>
          </div>
        </header>

        {/* محفظة النقاط والإحالة */}
        <section className="panel p-4 sm:p-5">
          <div className="mono-label mb-3 flex items-center gap-2 text-acid"><Icon name="star" size={13} />محفظة النقاط ونظام الإحالة</div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div className="border border-line bg-abyss/60 p-4 text-center">
              <div className="mono-label">رصيد النقاط</div>
              <div className="mt-1 font-mono text-3xl font-bold text-acid text-glow">{points}</div>
              <div className="mt-1 text-[10px] text-mute">+1 عن كل عضو يسجّل عبر رابطك</div>
            </div>
            <div className="border border-line bg-abyss/60 p-4 sm:col-span-2">
              <div className="mono-label mb-1.5">رابط الإحالة الخاص بك</div>
              <code className="block truncate border border-line bg-void px-3 py-2 font-mono text-[11px] text-acid" dir="ltr">{referralLink(session.refCode)}</code>
              <div className="mt-2 grid grid-cols-2 gap-2">
                <button onClick={async () => { if (await copyText(referralLink(session.refCode))) toast("✅ تم نسخ الرابط"); }} className="btn-acid py-2 text-[10px]">
                  <Icon name="link" size={11} />📋 نسخ الرابط
                </button>
                <button onClick={() => shareSite(t)} className="btn-ghost py-2 text-[10px]">
                  <Icon name="share" size={11} />مشاركة
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* إعدادات الحساب */}
        <section className="panel p-4 sm:p-5">
          <div className="mb-3 flex items-center justify-between gap-2">
            <div className="mono-label flex items-center gap-2 text-acid"><Icon name="gear" size={13} />إعدادات الحساب</div>
            <button onClick={() => setEditing((v) => !v)} className="btn-ghost px-3 py-1.5 text-[9px]">
              <Icon name="tool" size={11} />{editing ? "إلغاء" : "تعديل"}
            </button>
          </div>
          {editing ? (
            <div className="space-y-3">
              <div><label className="mono-label mb-1.5 block">الاسم</label>
                <input className="inp" value={name} onChange={(e) => { setName(e.target.value); setErr(""); }} /></div>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div><label className="mono-label mb-1.5 block">كلمة المرور الحالية</label>
                  <input className="inp" dir="ltr" type="password" value={pass} onChange={(e) => { setPass(e.target.value); setErr(""); }} placeholder="••••••••" /></div>
                <div><label className="mono-label mb-1.5 block">كلمة المرور الجديدة (اختياري)</label>
                  <input className="inp" dir="ltr" type="password" value={newPass} onChange={(e) => { setNewPass(e.target.value); setErr(""); }} placeholder="••••••••" /></div>
              </div>
              {err && <p className="text-xs text-blood">{err}</p>}
              <button onClick={saveProfile} className="btn-acid w-full py-2.5"><Icon name="check" size={13} />حفظ التعديلات</button>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-2 text-sm sm:grid-cols-3">
              <div className="border border-line bg-abyss/60 p-3"><span className="mono-label block">الاسم</span>{session.name}</div>
              <div className="border border-line bg-abyss/60 p-3"><span className="mono-label block">البريد</span><span dir="ltr">{session.email}</span></div>
              <div className="border border-line bg-abyss/60 p-3"><span className="mono-label block">الحالة</span><span className="text-acid">● مشفّر وموثّق</span></div>
            </div>
          )}
        </section>

        {/* صندوق الطلبات */}
        <section className="panel p-4 sm:p-5">
          <div className="mono-label mb-3 flex items-center gap-2 text-acid"><Icon name="box" size={13} />صندوق الطلبات الشخصي ({orders.length})</div>
          {orders.length === 0 ? (
            <div className="py-8 text-center font-mono text-xs text-mute">لا توجد طلبات بعد — مشترياتك ستظهر هنا تلقائياً.</div>
          ) : (
            <div className="space-y-2">
              {orders.map((o) => (
                <div key={o.id} className="flex flex-wrap items-center gap-3 border border-line bg-abyss/60 p-3">
                  <Icon name="box" size={16} className="text-dim" />
                  <div className="min-w-0 flex-1"><div className="truncate text-sm font-bold">{o.name}</div>
                    <div className="font-mono text-[10px] text-mute" dir="ltr">{o.at} · ×{o.qty}</div></div>
                  <span className="font-mono text-sm font-bold text-acid">${o.priceUsd}</span>
                  <span className="border border-amber/40 bg-amber/10 px-2 py-0.5 font-mono text-[9px] text-amber">PENDING</span>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </Shell>
  );
}
