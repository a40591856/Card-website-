"use client";

import { useLang } from "@/lib/client";
import { pick, type L } from "@/lib/site";
import { Icon } from "./Icon";

/**
 * بطاقة «الأداة المخصّصة» البارزة — تُوضع داخل كل قسم يملك أداة.
 * تمرير سلس للأداة في نفس الصفحة (بدون لوحة تحكم منفصلة).
 */
export default function SectionToolCTA({
  label,
  hint,
  targetId = "custom-tool",
  badge,
}: {
  label: L;
  hint?: L;
  targetId?: string;
  badge?: string;
}) {
  const lang = useLang();
  const jump = () =>
    document.getElementById(targetId)?.scrollIntoView({ behavior: "smooth", block: "start" });

  return (
    <div className="panel acc-cta-panel overflow-hidden p-0">
      <div className="acc-cta-head flex items-center justify-between gap-2 px-4 py-2.5">
        <span className="mono-label !text-acid">◈ CUSTOM TOOL · أداة مخصّصة</span>
        {badge && (
          <span className="shrink-0 border border-acid/50 bg-void/70 px-2 py-0.5 font-mono text-[10px] font-bold text-acid">
            {badge}
          </span>
        )}
      </div>
      <button onClick={jump} className="acc-cta flex w-full items-center gap-3 px-4 py-5 text-start sm:px-5">
        <span className="acc-cta-icon"><Icon name="tool" size={27} /></span>
        <span className="min-w-0 flex-1">
          <span className="block text-base font-extrabold leading-snug sm:text-lg">{pick(lang, label)}</span>
          {hint && (
            <span className="mt-1 block text-[11px] font-medium leading-relaxed opacity-80 sm:text-xs">
              {pick(lang, hint)}
            </span>
          )}
        </span>
        <span className="acc-cta-dot hidden sm:block" />
        <Icon name="chevron" size={20} className="shrink-0" />
      </button>
    </div>
  );
}
