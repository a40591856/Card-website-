"use client";

import { Suspense } from "react";
import { useSearchParams } from "next/navigation";
import PayPage from "./PayPage";
import PaymentMethodsPage from "./PaymentMethodsPage";

/**
 * بوّابة /pay:
 *  ?buy=ID → صفحة إتمام الشراء الفوري (كما كانت، دون أي تغيير)
 *  بدون معامل → صفحة طرق الدفع الرسمية المستقلة الجديدة
 */
function Inner() {
  const sp = useSearchParams();
  return sp.get("buy") ? <PayPage /> : <PaymentMethodsPage />;
}

export default function PaymentGate() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-void" />}>
      <Inner />
    </Suspense>
  );
}
