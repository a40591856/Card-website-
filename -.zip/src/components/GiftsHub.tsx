"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  GIFT_SECTIONS,
  TRAP_WARNING,
  giftOrderMessage,
  type GiftProduct,
  type GiftSection,
} from "@/lib/gifts";
import { BUY_MANAGER, pick, type L } from "@/lib/site";
import { copyText, dispatchToTelegram, buildWebFallback } from "@/lib/forumClient";
import { useT, useLang, toast } from "@/lib/client";
import { Icon } from "./Icon";
import Shell from "./Shell";
import SectionToolCTA from "./SectionToolCTA";

const A = (ar: string, en = ar): L => ({ ar, en });
type Cart = Record<string, number>;

const LB = {
  sections: A("الأقسام", "Sections"),
  home: A("🌐 العودة للرئيسية", "🌐 Back to main"),
  products: A("العروض", "Offers"),
  details: A("عرض التفاصيل", "Details"),
  buy: A("شراء", "Buy"),
  cart: A("السلة", "Cart"),
  addCart: A("إضافة للسلة", "Add to cart"),
  total: A("الإجمالي", "Total"),
  sendCart: A("إرسال طلب السلة", "Send cart order"),
  preview: A("معاينة الرسالة", "Message preview"),
  copy: A("نسخ الرسالة", "Copy message"),
  open: A("فتح المحادثة", "Open chat"),
  close: A("إغلاق", "Close"),
  guide: A("دليل القسم", "Section guide"),
  checker: A("🧪 فاحص صيغة الكود (محلي)", "🧪 Code format checker (local)"),
  checkerNote: A("أداة فحص محلية للتحقق من صيغة الكود قبل التسليم — لا تُرسل أي بيانات للخادم.", "Local format check before delivery — no data leaves your device."),
  check: A("فحص الكود", "Check code"),
  codeOk: A("✅ الصيغة سليمة — الكود جاهز للمراجعة قبل التسليم.", "✅ Format valid — ready for pre-delivery review."),
  codeErr: A("⚠️ الصيغة غير مطابقة — الكود يجب أن يكون 12–32 حرفاً/رقماً دون فراغات.", "⚠️ Invalid format — 12–32 alphanumeric characters, no spaces."),
};

/** ═══ GIFT CARDS VAULT — بطاقات الهدايا ═══ */
export default function GiftsHub() {
  const t = useT();
  const lang = useLang();
  const router = useRouter();

  const [active, setActive] = useState<string | null>(null);
  const [modal, setModal] = useState<GiftProduct | null>(null);
  const [cart, setCart] = useState<Cart>({});
  const [cartOpen, setCartOpen] = useState(false);
  const [relay, setRelay] = useState("");
  const [copied, setCopied] = useState(false);
  const [guideOpen, setGuideOpen] = useState(false);
  const [checkerOpen, setCheckerOpen] = useState(false);
  const [code, setCode] = useState("");
  const [codeRes, setCodeRes] = useState<"ok" | "err" | null>(null);

  useEffect(() => {
    const b = new URLSearchParams(window.location.search).get("b");
    if (b && GIFT_SECTIONS.some((s) => s.id === b)) setActive(b);
  }, []);

  useEffect(() => {
    if (!modal) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setModal(null);
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", onKey); document.body.style.overflow = ""; };
  }, [modal]);

  const sec = active ? GIFT_SECTIONS.find((s) => s.id === active) : undefined;

  const send = useCallback((msg: string) => {
    void copyText(msg);
    void dispatchToTelegram(msg, BUY_MANAGER);
    setRelay(msg);
    setCopied(true);
    toast(t("fa.copied"));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [t]);

  const buy = (p: GiftProduct) => send(giftOrderMessage(p));
  const addCart = (id: string) => { setCart((c) => ({ ...c, [id]: (c[id] || 0) + 1 })); toast(t("p.added")); };

  const all = useMemo(() => GIFT_SECTIONS.flatMap((s) => s.products.map((p) => ({ p, s }))), []);
  const cartItems = Object.entries(cart)
    .map(([id, qty]) => ({ ...all.find((x) => x.p.id === id), qty }))
    .filter((x): x is { p: GiftProduct; s: GiftSection; qty: number } => !!x.p);
  const cartCount = cartItems.reduce((a, x) => a + x.qty, 0);
  const cartTotal = cartItems.reduce((a, x) => a + x.p.priceUsd * x.qty, 0);

  const sendCart = () => {
    if (!cartItems.length) return;
    send([
      "طلب شراء جديد:",
      `🔹 اسم المنتج: سلة بطاقات (${cartCount} عنصر)`,
      `🔹 الرصيد: متعدد`,
      `🔹 السعر: ${cartTotal}$`,
      cartItems.map((x) => `• ${x.p.name.ar} × ${x.qty} — ${x.p.priceUsd * x.qty}$`).join("\n"),
      "الرجاء تزويدي بمحفظة الدفع لإتمام العملية فوراً.",
    ].join("\n"));
    setCartOpen(false);
  };

  const open = (id: string) => { setActive(id); setGuideOpen(false); setCheckerOpen(false); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const back = () => {
    if (modal) setModal(null);
    else if (active) { setActive(null); router.replace("/market/gifts"); window.scrollTo({ top: 0, behavior: "smooth" }); }
    else router.push("/market");
  };

  return (
    <Shell>
      <div className="space-y-5 pt-4">
        {/* ═══ شريط علوي ثابت ═══ */}
        <div className="sticky top-[96px] z-20 -mx-3 border-b border-line bg-void/95 px-3 py-2 backdrop-blur-md sm:-mx-5 sm:px-5">
          <div className="flex flex-wrap items-center gap-2">
            <button onClick={back} className="btn-ghost shrink-0 px-3 py-1.5 text-[9px]">
              <Icon name="back" size={11} className="rtl:rotate-180" />{pick(lang, LB.home)}
            </button>
            <button onClick={() => router.push("/market")} className="btn-ghost shrink-0 px-3 py-1.5 text-[9px]">🏠 السوق</button>
            <span className="ms-auto font-mono text-[9px] tracking-widest text-acid">
              {sec ? `${sec.products.length} ITEMS` : "06 SECTIONS"}
            </span>
          </div>
          {active && (
            <div className="no-scrollbar -mx-1 mt-2 flex gap-1.5 overflow-x-auto px-1">
              {GIFT_SECTIONS.map((s) => (
                <button key={s.id} onClick={() => open(s.id)}
                  className={`shrink-0 border px-3 py-1.5 font-mono text-[10px] font-bold tracking-wider transition-all ${
                    active === s.id ? "border-acid bg-acid text-void shadow-[0_0_16px_rgba(184,239,128,0.3)]" : "border-line bg-abyss/60 text-mute hover:text-fog"
                  }`}>{pick(lang, s.short)}</button>
              ))}
            </div>
          )}
        </div>

        {/* ═══ معاينة الرسالة ═══ */}
        {relay && (
          <div className="panel animate-fade-up">
            <div className="mono-label flex items-center justify-between border-b border-line px-4 py-2.5">
              <span>📤 {pick(lang, LB.preview)}</span><span className="text-acid">✓ {t("op.copied")}</span>
            </div>
            <pre className="max-h-52 overflow-auto whitespace-pre-wrap p-4 font-mono text-[11px] leading-6 text-fog/90" dir="auto">{relay}</pre>
            <div className="grid grid-cols-3 gap-2 border-t border-line p-3">
              <button onClick={async () => { if (await copyText(relay)) toast(t("op.copied")); }} className="btn-ghost py-2 text-[9px]"><Icon name={copied ? "check" : "link"} size={11} />{pick(lang, LB.copy)}</button>
              <button onClick={() => window.open(buildWebFallback(relay, BUY_MANAGER), "_blank", "noreferrer")} className="btn-acid py-2 text-[9px]"><Icon name="plane" size={11} />{pick(lang, LB.open)}</button>
              <button onClick={() => setRelay("")} className="btn-ghost py-2 text-[9px]"><Icon name="close" size={11} />{pick(lang, LB.close)}</button>
            </div>
          </div>
        )}

        {/* ═══ شبكة الأقسام ═══ */}
        {!sec && (
          <section>
            <div className="mono-label mb-3">// GIFT CARDS VAULT · 06</div>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
              {GIFT_SECTIONS.map((s, i) => (
                <button key={s.id} onClick={() => open(s.id)} className="panel panel-hover corners group flex flex-col overflow-hidden text-start">
                  <div className="relative h-24 overflow-hidden sm:h-32">
                    <img src={s.hero} alt="" loading="lazy" decoding="async" className="h-full w-full object-cover opacity-80 transition-transform duration-500 group-hover:scale-105" />
                    <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-void/70 to-transparent" />
                    <span className="absolute top-2 end-2 border border-line bg-void/85 px-1.5 py-0.5 font-mono text-[9px] text-acid">{String(i + 1).padStart(2, "0")} · {s.products.length}</span>
                  </div>
                  <div className="acc-strip h-[3px] w-full" />
                  <div className="flex flex-1 flex-col p-3">
                    <div className="text-[13px] font-bold leading-snug sm:text-sm">{pick(lang, s.name)}</div>
                    <p className="mt-1 line-clamp-2 text-[10px] leading-relaxed text-mute sm:text-[11px]">{pick(lang, s.desc)}</p>
                    <div className="btn-acid mt-3 w-full !py-2 text-[10px]">{t("c.enter")}</div>
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* ═══ محتوى القسم ═══ */}
        {sec && (
          <div key={sec.id} className="animate-fade-up space-y-4">
            <header className="panel relative overflow-hidden p-5 sm:p-7">
              <img src={sec.hero} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-20" />
              <div className="relative">
                <div className="mono-label mb-2 flex items-center gap-2 text-acid"><Icon name="gift" size={12} className="acc-lock" />{sec.id.toUpperCase()} :: GIFT VAULT</div>
                <h1 className="display-2 font-bold">{pick(lang, sec.name)}</h1>
                <p className="mt-2 max-w-3xl text-sm leading-relaxed text-mute">{pick(lang, sec.desc)}</p>
              </div>
            </header>

            <SectionToolCTA
              label={A("🧪 أداة فحص صيغة الكود المحلية")}
              hint={A("افحص صيغة الكود قبل التسليم دون إرسال أي بيانات للخادم.")}
              badge="LOCAL"
            />

            {/* دليل القسم */}
            <div>
              <button onClick={() => setGuideOpen((v) => !v)} className={`btn-ghost w-full py-2.5 ${guideOpen ? "!border-acid/50 !text-acid" : ""}`}>
                <Icon name="book" size={13} />{pick(lang, sec.guideTitle)}
                <Icon name="chevron" size={12} className={guideOpen ? "rotate-180 transition-transform" : "transition-transform"} />
              </button>
              {guideOpen && (
                <div className="panel animate-fade-up mt-2">
                  <div className="mono-label flex items-center justify-between border-b border-line px-4 py-2.5">
                    <span>◈ {pick(lang, LB.guide)}</span>
                    <button onClick={() => setGuideOpen(false)} className="flex items-center gap-1 text-mute hover:text-acid"><Icon name="close" size={11} />{pick(lang, LB.close)}</button>
                  </div>
                  <ul className="space-y-2 p-4">
                    {sec.guide.map((g, i) => (
                      <li key={i} className="flex items-start gap-2 text-xs leading-relaxed text-mute"><Icon name="check" size={11} className="mt-0.5 shrink-0 text-acid" />{pick(lang, g)}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* المنتجات 2×2 / 3×3 */}
            <div className="mono-label">// {pick(lang, LB.products)} · {String(sec.products.length).padStart(2, "0")}</div>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 sm:gap-4">
              {sec.products.map((p) => (
                <ProductCard key={p.id} p={p} sec={sec} onBuy={() => buy(p)} onCart={() => addCart(p.id)} onDetails={() => setModal(p)} />
              ))}
            </div>

            {/* التحذير الأحمر الثابت */}
            <div className="flex items-center gap-2 border border-blood/50 bg-blood/10 p-3.5 text-xs font-bold text-blood">
              <Icon name="warn" size={15} className="shrink-0" />{pick(lang, TRAP_WARNING)}
            </div>

            {/* فاحص صيغة الكود (محلي) */}
            <div id="custom-tool" className="panel acc-cta-panel scroll-mt-32 p-3">
              <button onClick={() => setCheckerOpen((v) => !v)} className={`btn-ghost w-full py-2.5 ${checkerOpen ? "!border-acid/50 !text-acid" : ""}`}>
                <Icon name="code" size={13} />{pick(lang, LB.checker)}
                <Icon name="chevron" size={12} className={checkerOpen ? "rotate-180 transition-transform" : "transition-transform"} />
              </button>
              {checkerOpen && (
                <div className="animate-fade-up mt-3 space-y-2">
                  <p className="text-xs leading-relaxed text-mute">{pick(lang, LB.checkerNote)}</p>
                  <div className="flex gap-2">
                    <input className="inp font-mono" dir="ltr" value={code} onChange={(e) => { setCode(e.target.value); setCodeRes(null); }} placeholder="XXXX-XXXX-XXXX-XXXX" />
                    <button onClick={() => setCodeRes(/^[A-Za-z0-9-]{12,32}$/.test(code.trim()) ? "ok" : "err")} className="btn-acid shrink-0 px-4 text-[10px]">{pick(lang, LB.check)}</button>
                  </div>
                  {codeRes && <p className={`text-xs ${codeRes === "ok" ? "text-acid" : "text-blood"}`}>{pick(lang, codeRes === "ok" ? LB.codeOk : LB.codeErr)}</p>}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* أزرار عائمة */}
      {active && (
        <button onClick={back} title={pick(lang, LB.home)} aria-label={pick(lang, LB.home)} className="glass glass-hover fixed bottom-16 start-4 z-40 flex h-11 w-11 items-center justify-center border-acid/50 text-acid">
          <Icon name="back" size={18} className="rtl:rotate-180" />
        </button>
      )}
      {cartCount > 0 && (
        <button onClick={() => setCartOpen((v) => !v)} className="glass glass-hover fixed bottom-16 end-4 z-40 flex h-11 w-11 items-center justify-center border-acid/50 text-acid">
          <Icon name="cart" size={18} />
          <span className="absolute -top-1 -end-1 flex h-4 min-w-4 items-center justify-center bg-acid px-1 font-mono text-[9px] font-bold text-void">{cartCount}</span>
        </button>
      )}
      {cartOpen && cartCount > 0 && (
        <div className="panel fixed bottom-28 end-4 z-[55] w-[min(92vw,340px)] p-3 shadow-[0_24px_60px_-20px_rgba(0,0,0,0.9)]">
          <div className="mb-2 flex items-center gap-2 border-b border-line pb-2">
            <Icon name="cart" size={14} className="text-acid" /><span className="mono-label flex-1">{pick(lang, LB.cart)}</span>
            <button onClick={() => setCartOpen(false)} className="text-mute hover:text-fog"><Icon name="close" size={14} /></button>
          </div>
          <div className="max-h-56 space-y-2 overflow-auto">
            {cartItems.map(({ p, qty }) => (
              <div key={p.id} className="flex items-center gap-2 border border-line bg-abyss/60 p-2">
                <div className="min-w-0 flex-1"><div className="truncate text-[11px] font-bold">{pick(lang, p.name)}</div><div className="font-mono text-[10px] text-acid">${p.priceUsd * qty}</div></div>
                <button onClick={() => setCart((c) => ({ ...c, [p.id]: Math.max(0, c[p.id] - 1) }))} className="flex h-7 w-7 items-center justify-center border border-line text-mute"><Icon name="minus" size={10} /></button>
                <span className="w-5 text-center font-mono text-xs">{qty}</span>
                <button onClick={() => setCart((c) => ({ ...c, [p.id]: c[p.id] + 1 }))} className="flex h-7 w-7 items-center justify-center border border-line text-mute"><Icon name="plus" size={10} /></button>
              </div>
            ))}
          </div>
          <div className="mt-3 flex items-center justify-between border-t border-line pt-2"><span className="mono-label">{pick(lang, LB.total)}</span><span className="font-mono text-lg font-bold text-acid">${cartTotal}</span></div>
          <button onClick={sendCart} className="btn-acid mt-3 w-full py-2.5 text-[10px]"><Icon name="send" size={12} />{pick(lang, LB.sendCart)}</button>
        </div>
      )}

      {modal && sec && (
        <DetailModal p={modal} sec={sec} onClose={() => setModal(null)} onBuy={() => { buy(modal); setModal(null); }} onCart={() => { addCart(modal.id); setModal(null); }} />
      )}
    </Shell>
  );
}

/* ═══════════ بطاقة المنتج ═══════════ */
function ProductCard({ p, sec, onBuy, onCart, onDetails }: {
  p: GiftProduct; sec: GiftSection; onBuy: () => void; onCart: () => void; onDetails: () => void;
}) {
  const lang = useLang();
  const [err, setErr] = useState(false);
  return (
    <div className="panel panel-hover corners group flex h-full flex-col overflow-hidden">
      <div className="relative h-24 overflow-hidden sm:h-28">
        {!err ? (
          <img src={p.img} alt="" loading="lazy" decoding="async" onError={() => setErr(true)} className="h-full w-full object-cover opacity-85 transition-transform duration-500 group-hover:scale-105" />
        ) : (
          <div className="grid-bg-fine flex h-full w-full items-center justify-center"><Icon name={sec.icon} size={34} className="text-dim" /></div>
        )}
        <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-void/80 via-transparent to-transparent" />
        {p.featured && <span className="absolute top-2 start-2 border border-acid/50 bg-void/85 px-1.5 py-0.5 font-mono text-[8px] text-acid">★ HOT</span>}
      </div>
      <div className="acc-strip h-[3px] w-full" />
      <div className="flex min-h-0 flex-1 flex-col p-2.5 sm:p-3">
        <h3 className="line-clamp-2 text-[11px] font-bold leading-snug sm:text-[13px]">{pick(lang, p.name)}</h3>
        <p className="mt-1 line-clamp-2 text-[10px] leading-relaxed text-mute sm:text-[11px]">{pick(lang, p.desc)}</p>
        <div className="mt-1.5 font-mono text-[9px] text-acid">💰 {pick(lang, LB_TOTAL_BALANCE)} {pick(lang, p.balance)}</div>
        <div className="mt-1 flex flex-wrap gap-1">
          {p.badges.map((b) => <span key={b} className="border border-line2/60 bg-abyss/70 px-1.5 py-0.5 font-mono text-[8px] tracking-wider text-mute">{b}</span>)}
        </div>
        <div className="mt-auto pt-2">
          <div className="flex items-baseline gap-2">
            {p.oldPriceUsd && <span className="font-mono text-[10px] text-mute/70 line-through" dir="ltr">${p.oldPriceUsd}</span>}
            <span className="font-mono text-lg font-bold text-acid text-glow sm:text-xl" dir="ltr">${p.priceUsd}</span>
          </div>
          <div className="mt-2 grid grid-cols-2 gap-1.5">
            <button onClick={onBuy} className="btn-acid !px-1 !py-2 !text-[9px]">{pick(lang, LB.buy)}</button>
            <button onClick={onDetails} className="btn-ghost !px-1 !py-2 !text-[9px]"><Icon name="eye" size={10} />{pick(lang, LB.details)}</button>
          </div>
          <button onClick={onCart} className="btn-ghost mt-1.5 w-full !px-1 !py-1.5 !text-[9px]"><Icon name="cart" size={10} />{pick(lang, LB.addCart)}</button>
        </div>
      </div>
    </div>
  );
}
const LB_TOTAL_BALANCE = A("الرصيد:");

/* ═══════════ نافذة التفاصيل ═══════════ */
function DetailModal({ p, sec, onClose, onBuy, onCart }: {
  p: GiftProduct; sec: GiftSection; onClose: () => void; onBuy: () => void; onCart: () => void;
}) {
  const lang = useLang();
  const [err, setErr] = useState(false);
  return (
    <div className="fixed inset-0 z-[65] flex items-center justify-center p-4" role="dialog" aria-modal>
      <div className="absolute inset-0 bg-void/85 backdrop-blur-sm" onClick={onClose} />
      <div className="panel animate-fade-up relative flex max-h-[88vh] w-full max-w-xl flex-col">
        <div className="flex items-center justify-between border-b border-line px-4 py-3">
          <span className="mono-label">ℹ️ {pick(lang, LB.details)} :: GIFT CARD</span>
          <button onClick={onClose} className="btn-icon h-8 w-8"><Icon name="close" size={15} /></button>
        </div>
        <div className="flex-1 overflow-y-auto">
          <div className="relative h-44 sm:h-56">
            {!err ? <img src={p.img} alt="" onError={() => setErr(true)} className="h-full w-full object-cover opacity-85" /> :
              <div className="grid-bg-fine flex h-full w-full items-center justify-center"><Icon name={sec.icon} size={64} className="text-dim" /></div>}
            <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-void/80 to-transparent" />
          </div>
          <div className="acc-strip h-[3px] w-full" />
          <div className="p-5">
            <h2 className="text-xl font-bold sm:text-2xl">{pick(lang, p.name)}</h2>
            <p className="mt-2 text-sm leading-relaxed text-mute">{pick(lang, p.desc)}</p>
            <div className="mt-2 font-mono text-xs text-acid">💰 الرصيد: {pick(lang, p.balance)}</div>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {p.badges.map((b) => <span key={b} className="border border-acid/40 bg-acid/10 px-2 py-0.5 font-mono text-[9px] tracking-widest text-acid">{b}</span>)}
            </div>
            <div className="mt-3 flex items-baseline gap-3">
              {p.oldPriceUsd && <span className="font-mono text-base text-mute/70 line-through" dir="ltr">${p.oldPriceUsd}</span>}
              <span className="font-mono text-3xl font-bold text-acid text-glow" dir="ltr">${p.priceUsd}</span>
            </div>

            {/* التحذير الأحمر الإلزامي */}
            <div className="mt-4 flex items-start gap-2 border border-blood/50 bg-blood/10 p-3 text-xs font-bold leading-relaxed text-blood">
              <Icon name="warn" size={14} className="mt-0.5 shrink-0" />{pick(lang, TRAP_WARNING)}
            </div>

            <div className="mt-4 border border-line bg-abyss/60 p-4">
              <div className="mono-label mb-2">📜 تفاصيل البطاقة</div>
              <p className="whitespace-pre-line text-xs leading-loose text-fog/90">{pick(lang, p.details)}</p>
            </div>

            <div className="mt-4 border border-acid/40 bg-acid/5 p-4">
              <div className="mono-label mb-2.5 flex items-center gap-2 text-acid"><Icon name="book" size={12} />{pick(lang, sec.guideTitle)}</div>
              <ul className="space-y-1.5">
                {sec.guide.map((g, i) => <li key={i} className="flex items-start gap-2 text-xs leading-relaxed text-mute"><Icon name="check" size={10} className="mt-0.5 shrink-0 text-acid" />{pick(lang, g)}</li>)}
              </ul>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 border-t border-line p-3">
          <button onClick={onBuy} className="btn-primary"><Icon name="cart" size={15} />{pick(lang, LB.buy)}</button>
          <button onClick={onCart} className="btn-acid"><Icon name="plus" size={14} />{pick(lang, LB.addCart)}</button>
        </div>
      </div>
    </div>
  );
}
