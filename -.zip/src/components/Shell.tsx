"use client";

import { useCallback, useEffect, useState, type CSSProperties, type ReactNode } from "react";
import Link from "next/link";
import { useRouter, usePathname } from "next/navigation";
import { LANGS } from "@/lib/i18n";
import { HOME_SECTIONS, pick, LINKS, SITE } from "@/lib/site";
import {
  ShellCtx,
  useT,
  useLang,
  useAuth,
  setAuth,
  useCart,
  useToasts,
  useStealth,
  setStealth,
  changeLang,
  saveLast,
  bumpCart,
  clearCart,
  toast,
  api,
  fmtMoney,
  langDef,
  clientId,
} from "@/lib/client";
import { ProductRow } from "@/lib/types";
import { Icon } from "./Icon";
import Navbar from "./Navbar";
import SideMenu from "./SideMenu";
import LoginModal from "./LoginModal";
import MembershipModal from "./MembershipModal";
import { loadSession, captureRef } from "@/lib/membership";
import { loadProducts } from "./SearchBar";

/* ── العدّاد: مدة الزيارة ── */
function Timer() {
  const [s, setS] = useState(0);
  useEffect(() => {
    const iv = window.setInterval(() => setS((v) => v + 1), 1000);
    return () => window.clearInterval(iv);
  }, []);
  const hh = String(Math.floor(s / 3600)).padStart(2, "0");
  const mm = String(Math.floor((s % 3600) / 60)).padStart(2, "0");
  const ss = String(s % 60).padStart(2, "0");
  return (
    <span className="font-mono text-xs tracking-[0.15em] text-acid" dir="ltr">
      {hh}:{mm}:{ss}
    </span>
  );
}

/* ── L3: تبويبات لاصقة (وصلات سريعة) — z-20 ── */
function Chips() {
  const t = useT();
  const lang = useLang();
  const router = useRouter();
  const pathname = usePathname();
  return (
    <div className="fixed inset-x-0 top-14 z-20 border-b border-line bg-void/80 backdrop-blur-md">
      <div className="no-scrollbar mx-auto flex h-10 max-w-[1190px] items-stretch gap-1 overflow-x-auto px-3 sm:px-5">
        <Link
          href="/"
          className={`flex shrink-0 items-center gap-1.5 border-b-2 px-3 font-mono text-[11px] tracking-wider transition-colors ${
            pathname === "/" ? "border-acid text-acid" : "border-transparent text-mute hover:text-fog"
          }`}
        >
          <Icon name="terminal" size={13} />
          HOME
        </Link>
        {HOME_SECTIONS.map((hs) => {
          const active = pathname === hs.route || (hs.id === "market" && pathname.startsWith("/market"));
          return (
            <Link
              key={hs.id}
              href={hs.route}
              className={`flex shrink-0 items-center gap-1.5 border-b-2 px-3 font-mono text-[11px] tracking-wider transition-colors ${
                active ? "border-acid text-acid" : "border-transparent text-mute hover:text-fog"
              }`}
            >
              <Icon name={hs.icon} size={13} />
              {pick(lang, hs.short)}
            </Link>
          );
        })}
        <Link
          href="/pay"
          className={`flex shrink-0 items-center gap-1.5 border-b-2 px-3 font-mono text-[11px] tracking-wider transition-colors ${
            pathname === "/pay" ? "border-acid text-acid" : "border-transparent text-mute hover:text-fog"
          }`}
        >
          <Icon name="wallet" size={13} />
          {t("pages.pay.short")}
        </Link>
        <span className="ms-auto hidden shrink-0 items-center gap-1.5 font-mono text-[9px] tracking-[0.25em] text-dim md:flex">
          <span className="inline-block h-1 w-1 animate-pulse-soft rounded-full bg-acid" />
          {t("secureLine")}
        </span>
      </div>
    </div>
  );
}

/* ── L4: الشريط السفلي — رجوع · دفع · إغلاق · عدّاد — z-40 ── */
function BottomBar() {
  const t = useT();
  const router = useRouter();
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 h-12 border-t border-line bg-void/90 backdrop-blur-md">
      <div className="mx-auto flex h-full max-w-[1190px] items-center justify-between px-3 sm:px-5">
        {/* العدّاد */}
        <div className="flex items-center gap-2" title={t("visit")}>
          <Icon name="clock" size={14} className="text-dim" />
          <Timer />
        </div>
        <div className="hidden items-center gap-2 font-mono text-[9px] tracking-[0.3em] text-mute/70 md:flex">
          <span className="inline-block h-1 w-1 animate-pulse-soft rounded-full bg-acid" />
          BLACKMART.ZONE · TLS1.3
        </div>
        {/* رجوع · دفع · إغلاق */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => {
              if (window.history.length > 1) router.back();
              else router.push("/");
            }}
            className="btn-icon"
            title={t("backBtn")}
            aria-label={t("backBtn")}
          >
            <Icon name="back" size={16} className="rtl:rotate-180" />
          </button>
          <button onClick={() => router.push("/pay")} className="btn-icon" title={t("nav.payments")} aria-label={t("nav.payments")}>
            <Icon name="coin" size={16} />
          </button>
          <button
            onClick={() => {
              setStealth(true);
              toast(t("stealth.on"), "warn");
            }}
            className="btn-icon hover:!text-amber"
            title={`${t("nav.exit")} · ESC`}
            aria-label={t("nav.exit")}
          >
            <Icon name="lock" size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ── 5 FOOTER — 4 أعمدة ── */
function Footer() {
  const t = useT();
  const lang = useLang();
  const router = useRouter();
  return (
    <footer className="relative z-10 mt-16 border-t border-line bg-abyss/70">
      <div className="mx-auto grid max-w-[1190px] grid-cols-2 gap-8 p-6 md:grid-cols-4 sm:p-8">
        <div>
          <div className="flex items-center gap-2.5">
            <svg viewBox="0 0 64 64" width="26" height="26">
              <path d="M32 4 56 18v28L32 60 8 46V18L32 4Z" fill="none" stroke="#b8ef80" strokeWidth="4" />
              <path d="M25 20h10a7 7 0 0 1 0 14h-10V20Zm0 16h12a7 7 0 0 1 0 14H25V36Z" fill="#b8ef80" />
            </svg>
            <span className="font-mono text-sm font-bold tracking-[0.15em]">
              BLACK<span className="text-acid">MART</span>
            </span>
          </div>
          <p className="mt-3 text-xs leading-relaxed text-mute">{t("footer.about")}</p>
          <div className="mt-3 flex items-center gap-2 font-mono text-[9px] tracking-[0.2em] text-dim">
            <span className="inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full bg-acid" />
            {t("footer.status")}
          </div>
        </div>
        <div>
          <div className="mono-label mb-3">{t("footer.quick")}</div>
          <ul className="space-y-2 text-sm">
            <li><button onClick={() => router.push("/")} className="text-mute transition-colors hover:text-acid">{t("c.home")}</button></li>
            <li><button onClick={() => router.push("/pay")} className="text-mute transition-colors hover:text-acid">{t("pages.pay")}</button></li>
            <li><a href={LINKS.group} target="_blank" rel="noreferrer" className="text-mute transition-colors hover:text-acid">{t("nav.tg")}</a></li>
            <li><a href={LINKS.whatsapp} target="_blank" rel="noreferrer" className="text-mute transition-colors hover:text-acid">{t("nav.wa")}</a></li>
          </ul>
        </div>
        <div>
          <div className="mono-label mb-3">{t("footer.sections")}</div>
          <ul className="space-y-2 text-sm">
            {HOME_SECTIONS.map((hs) => (
              <li key={hs.id}>
                <button onClick={() => router.push(hs.route)} className="text-mute transition-colors hover:text-acid">
                  {pick(lang, hs.short)}
                </button>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <div className="mono-label mb-3">{t("footer.contact")}</div>
          <ul className="space-y-2 text-sm">
            <li><a href={LINKS.support} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-mute transition-colors hover:text-acid"><Icon name="headset" size={13} />{t("nav.support")}</a></li>
            <li><a href={LINKS.manager} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-mute transition-colors hover:text-acid"><Icon name="user" size={13} />{t("menu.manager")}</a></li>
            <li><a href={LINKS.channel} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-mute transition-colors hover:text-acid"><Icon name="megaphone" size={13} />{t("menu.channel")}</a></li>
            <li>
              <button onClick={() => router.push("/account")} className="flex items-center gap-2 text-mute transition-colors hover:text-acid">
                <Icon name="box" size={13} />{t("menu.orders")}
              </button>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-line/60">
        <div className="mx-auto flex max-w-[1190px] flex-wrap items-center justify-between gap-2 px-5 py-3 font-mono text-[9px] tracking-[0.2em] text-mute/60">
          <span>© 2026 {SITE.name} — {t("footer.rights")}</span>
          <span dir="ltr">{SITE.version} · AES-256</span>
        </div>
      </div>
    </footer>
  );
}

/* ── درج السلة — z-55 · 440px ── */
function CartDrawer({ onClose, onCheckout }: { onClose: () => void; onCheckout: () => void }) {
  const t = useT();
  const lang = useLang();
  const cart = useCart();
  const [prods, setProds] = useState<ProductRow[]>([]);
  useEffect(() => {
    loadProducts().then(setProds).catch(() => {});
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const dir = langDef(lang).dir;
  const items = Object.entries(cart).map(([id, qty]) => ({
    p: prods.find((x) => x.id === Number(id)),
    qty,
  }));
  const total = items.reduce((a, it) => a + (it.p ? it.p.priceUsd * it.qty : 0), 0);

  return (
    <div className="fixed inset-0 z-[55]">
      <div className="absolute inset-0 bg-[#000000b3]" onClick={onClose} />
      <aside
        className="panel animate-drawer absolute inset-y-0 end-0 flex w-[min(94vw,440px)] flex-col border-s border-line shadow-[-40px_0_80px_rgba(0,0,0,0.6)]"
        style={{ "--drawer-from": dir === "rtl" ? "-100%" : "100%" } as CSSProperties}
      >
        <div className="flex items-center gap-2 border-b border-line px-4 py-3.5">
          <Icon name="cart" size={16} className="text-acid" />
          <span className="mono-label flex-1">{t("cart.title")}</span>
          <button onClick={onClose} className="btn-icon h-8 w-8" aria-label={t("c.close")}>
            <Icon name="close" size={16} />
          </button>
        </div>

        <div className="flex-1 overflow-auto p-4">
          {items.length === 0 && (
            <div className="mt-10 text-center font-mono text-xs text-mute">{t("cart.empty")}</div>
          )}
          <div className="space-y-3">
            {items.map(({ p, qty }) =>
              p ? (
                <div key={p.id} className="flex items-center gap-3 border border-line bg-abyss/60 p-3">
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-bold">{p.nameAr}</div>
                    <div className="font-mono text-[11px] text-acid">{fmtMoney(p.priceUsd)}</div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button onClick={() => bumpCart(p.id, -1)} className="flex h-8 w-8 items-center justify-center border border-line text-mute hover:text-fog">
                      <Icon name="minus" size={12} />
                    </button>
                    <span className="w-6 text-center font-mono text-sm">{qty}</span>
                    <button onClick={() => bumpCart(p.id, 1)} className="flex h-8 w-8 items-center justify-center border border-line text-mute hover:text-fog">
                      <Icon name="plus" size={12} />
                    </button>
                  </div>
                </div>
              ) : null,
            )}
          </div>
        </div>

        {items.length > 0 && (
          <div className="border-t border-line p-4">
            <div className="mb-3 flex items-center justify-between">
              <span className="mono-label">{t("cart.total")}</span>
              <span className="font-mono text-xl font-bold text-acid text-glow">{fmtMoney(total)}</span>
            </div>
            <button onClick={onCheckout} className="btn-primary w-full">
              <Icon name="check" size={16} />
              {t("cart.checkout")}
            </button>
          </div>
        )}
      </aside>
    </div>
  );
}

/* ── نافذة اختيار اللغة — z-60 ── */
function LangModal({ onClose }: { onClose: () => void }) {
  const t = useT();
  const lang = useLang();
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4" role="dialog" aria-modal>
      <div className="absolute inset-0 bg-[#000000b3]" onClick={onClose} />
      <div className="panel animate-fade-up relative w-full max-w-md">
        <div className="flex items-center gap-2 border-b border-line px-4 py-3">
          <Icon name="globe" size={15} className="text-acid" />
          <span className="mono-label flex-1">{t("lang.modal.title")}</span>
          <button onClick={onClose} className="btn-icon h-8 w-8" aria-label={t("c.close")}>
            <Icon name="close" size={16} />
          </button>
        </div>
        <div className="grid grid-cols-2 gap-2 p-4 sm:grid-cols-3">
          {LANGS.map((l) => (
            <button
              key={l.code}
              onClick={() => {
                changeLang(l.code);
                onClose();
              }}
              className={`panel panel-hover flex flex-col items-center gap-1.5 px-3 py-4 ${
                l.code === lang ? "!border-acid/60" : ""
              }`}
            >
              <span className="text-2xl">{l.flag}</span>
              <span className="text-xs font-bold">{l.name}</span>
              {l.code === lang && (
                <span className="font-mono text-[8px] tracking-[0.2em] text-acid">CURRENT</span>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ── شاشة التخفّي — z-99 ── */
function StealthScreen() {
  const t = useT();
  return (
    <div className="fixed inset-0 z-[99] flex flex-col items-center justify-center bg-[#eef0f2] text-slate-700">
      <div className="font-mono text-6xl font-bold text-slate-300" dir="ltr">
        404
      </div>
      <div className="mt-4 text-lg font-semibold">{t("stealth.f404")}</div>
      <div className="mt-2 max-w-md px-6 text-center text-sm text-slate-400">{t("stealth.f404s")}</div>
      <div className="mt-8 font-mono text-[10px] text-slate-300" dir="ltr">
        REF: 0x7F3A-2291-C0DE · EDGE: 42
      </div>
      <div className="absolute inset-x-0 bottom-10 px-6 text-center text-[10px] text-slate-400">
        {t("stealth.exit")}
      </div>
      <button
        onClick={() => setStealth(false)}
        aria-label="exit stealth"
        className="absolute bottom-4 end-4 h-3 w-3 rounded-full bg-slate-300 transition-colors hover:bg-slate-500"
      />
    </div>
  );
}

/* ── التنبيهات المنبثقة — z-97 ── */
function Toaster() {
  const toasts = useToasts();
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-16 z-[97] flex flex-col items-center gap-2 px-4">
      {toasts.map((m) => (
        <div
          key={m.id}
          className={`panel animate-fade-up flex items-center gap-2.5 px-4 py-2.5 text-sm shadow-[0_16px_40px_-12px_rgba(0,0,0,0.8)] ${
            m.kind === "warn" ? "border-amber/50" : "border-acid/50"
          }`}
        >
          <Icon name={m.kind === "warn" ? "warn" : "check"} size={14} className={m.kind === "warn" ? "text-amber" : "text-acid"} />
          <span>{m.msg}</span>
        </div>
      ))}
    </div>
  );
}

/* ── FAB: العودة للأعلى — z-40 ── */
function Fab() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const f = () => setShow(window.scrollY > 420);
    window.addEventListener("scroll", f, { passive: true });
    return () => window.removeEventListener("scroll", f);
  }, []);
  if (!show) return null;
  return (
    <button
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      aria-label="top"
      className="btn-icon animate-fade-up fixed bottom-16 end-4 z-40 border-acid/40 text-acid"
    >
      <Icon name="chevron" size={16} className="rotate-180" />
    </button>
  );
}

/**
 * الهيكل الصلب (Global Chrome):
 * 30 NAVBAR · 20 CHIPS · 10 CONTENT · FOOTER · 40 BOTTOMBAR/FAB
 * 50 SIDEBAR · 55 CART · 60 MODALS · 65 PRODUCT · 90 SCANLINES
 */
export default function Shell({ children }: { children: ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const t = useT();
  const auth = useAuth();
  const cart = useCart();
  const stealth = useStealth();
  const [menu, setMenu] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [langOpen, setLangOpen] = useState(false);
  const [loginOpen, setLoginOpen] = useState(false);
  const anyModal = menu || cartOpen || langOpen || loginOpen;

  /* استعادة الجلسة تلقائياً عند العودة للموقع + التقاط رابط الإحالة */
  useEffect(() => {
    captureRef();
    const s = loadSession();
    if (s && s.id) setAuth(s.id);
  }, []);

  useEffect(() => {
    saveLast(pathname);
  }, [pathname]);

  useEffect(() => {
    const f = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !anyModal) setStealth(!stealth);
    };
    window.addEventListener("keydown", f);
    return () => window.removeEventListener("keydown", f);
  }, [anyModal, stealth]);

  const gotoEntry = useCallback(() => {
    sessionStorage.setItem("bm_entry", "1");
    router.push("/");
  }, [router]);

  const checkout = async () => {
    if (!auth) {
      toast(t("cart.loginFirst"), "warn");
      setCartOpen(false);
      setLoginOpen(true);
      return;
    }
    const items = Object.entries(cart).map(([id, qty]) => ({ productId: Number(id), qty }));
    if (items.length === 0) return;
    try {
      await api("/api/orders", { method: "POST", body: JSON.stringify({ owner: auth, items, client: clientId() }) });
      toast(t("cart.done"));
      clearCart();
      setCartOpen(false);
    } catch {
      toast(t("login.err"), "warn");
    }
  };

  return (
    <ShellCtx.Provider
      value={{
        openMenu: () => setMenu(true),
        openCart: () => setCartOpen(true),
        openLang: () => setLangOpen(true),
        openLogin: () => setLoginOpen(true),
        gotoEntry,
      }}
    >
      <div className="relative flex min-h-screen flex-col">
        {/* الخلفية — z-0 */}
        <div className="grid-bg pointer-events-none fixed inset-0" />
        <div className="vignette pointer-events-none fixed inset-0" />

        {/* 30 — NAVBAR */}
        <Navbar />
        {/* 20 — CHIPS */}
        <Chips />

        <main className="relative z-10 mx-auto w-full max-w-[1190px] flex-1 px-3 pb-16 pt-[96px] sm:px-5">
          {children}
        </main>

        <Footer />

        {/* 40 — BOTTOMBAR + FAB */}
        <BottomBar />
        <Fab />

        {/* 90 — خطوط المسح CRT */}
        <div className="scanlines pointer-events-none fixed inset-0 z-[90] opacity-30" />
        <div className="noise pointer-events-none fixed inset-0 z-[90]" />

        {/* 50 — SIDEBAR */}
        {menu && (
          <SideMenu
            onClose={() => setMenu(false)}
            onLogin={() => setLoginOpen(true)}
            onLang={() => setLangOpen(true)}
            onEntry={gotoEntry}
          />
        )}
        {/* 55 — CART */}
        {cartOpen && <CartDrawer onClose={() => setCartOpen(false)} onCheckout={checkout} />}
        {/* 60 — MODALS */}
        {langOpen && <LangModal onClose={() => setLangOpen(false)} />}
        {loginOpen && <MembershipModal onClose={() => setLoginOpen(false)} />}
        <Toaster />
        {stealth && <StealthScreen />}
      </div>
    </ShellCtx.Provider>
  );
}
