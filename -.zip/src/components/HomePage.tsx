"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { TICKER_KEYS, ACCENT, HOME_SECTIONS, pick, type L } from "@/lib/site";

/* فهرس الفلترة الداخلية الدقيقة — تحت شاشة البث مباشرة */
const QUICK_INDEX: { l: L; route: string }[] = [
  { l: { ar: "بطاقات", en: "Cards", ru: "Карты" }, route: "/market/cards" },
  { l: { ar: "حقن", en: "Injection", ru: "Инжекция" }, route: "/market/injection" },
  { l: { ar: "تحويل", en: "Transfer", ru: "Перевод" }, route: "/market/transfer" },
  { l: { ar: "أكواد", en: "Codes", ru: "Коды" }, route: "/market/gifts" },
  { l: { ar: "شحن", en: "Top-up", ru: "Топ-ап" }, route: "/market/topup" },
  { l: { ar: "بروكسي", en: "Proxy", ru: "Прокси" }, route: "/market/proxy" },
];
import { useT, useLang, hex, prefersReducedMotion, useWishlist, toggleWishlist, api, fmtMoney } from "@/lib/client";
import { ProductRow, pName } from "@/lib/types";
import { Icon } from "./Icon";
import Shell from "./Shell";
import SearchBar from "./SearchBar";
import AdCarousel from "./AdCarousel";
import Decryption from "./Decryption";
import { ProductModal } from "./ProductCard";
import dynamic from "next/dynamic";

/* يُحمَّل بعد أول ظهور — يسرّع الفتح التفاعلي */
const HomeLowerBlocks = dynamic(() => import("./HomeLowerBlocks"), {
  ssr: false,
  loading: () => (
    <div className="space-y-4">
      <div className="panel h-56 animate-pulse-soft bg-panel2/40" />
    </div>
  ),
});

/* ── لوحة بيانات الطرفية ── */
function TerminalPanel() {
  const t = useT();
  const lang = useLang();
  const [hexLine, setHexLine] = useState(() => hex(40));
  const [now, setNow] = useState("");

  useEffect(() => {
    const tick = () => setNow(new Date().toLocaleTimeString(lang === "ru" ? "ru" : "en", { hour12: false }));
    tick();
    const iv = window.setInterval(tick, 1000);
    return () => window.clearInterval(iv);
  }, [lang]);

  useEffect(() => {
    if (prefersReducedMotion()) return;
    const iv = window.setInterval(() => setHexLine(hex(40)), 900);
    return () => window.clearInterval(iv);
  }, []);

  const Row = ({ k, v, accent = false }: { k: string; v: string; accent?: boolean }) => (
    <div className="flex items-center justify-between border-b border-line/60 py-2 font-mono text-[10px] last:border-0">
      <span className="tracking-[0.2em] text-mute">{k}</span>
      <span className={accent ? "text-acid" : "text-fog"} dir="ltr">{v}</span>
    </div>
  );

  return (
    <aside className="panel hidden self-start p-4 lg:block">
      <div className="mono-label mb-2 flex items-center gap-2">
        <span className="inline-block h-1.5 w-1.5 animate-blink rounded-full bg-acid" />
        LIVE :: NODE-DATA
      </div>
      <Row k="CHANNEL" v="OPEN" accent />
      <Row k="CIPHER" v="AES-256-GCM" accent />
      <Row k="IP" v="203.0.113.7 [MASKED]" />
      <Row k="NODE" v="0x2F-44C1-BM" />
      <Row k={t("home.time")} v={now || "--:--:--"} />
      <div className="mt-2 break-all border-t border-line pt-2 font-mono text-[9px] leading-4 tracking-[0.15em] text-mute/60" dir="ltr">
        {hexLine}
      </div>
    </aside>
  );
}

/* ── نافذة المفضلة — z-60 ── */
function WishlistModal({ onClose, onPick }: { onClose: () => void; onPick: (p: ProductRow) => void }) {
  const t = useT();
  const lang = useLang();
  const wl = useWishlist();
  const [prods, setProds] = useState<ProductRow[] | null>(null);
  useEffect(() => {
    api<ProductRow[]>("/api/products").then(setProds).catch(() => setProds([]));
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const items = (prods ?? []).filter((p) => wl.includes(p.id));

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4" role="dialog" aria-modal>
      <div className="absolute inset-0 bg-[#000000b3]" onClick={onClose} />
      <div className="panel animate-fade-up relative flex max-h-[80vh] w-full max-w-md flex-col">
        <div className="flex items-center gap-2 border-b border-line px-4 py-3">
          <Icon name="heart" size={15} className="text-acid" />
          <span className="mono-label flex-1">{t("wl.title")}</span>
          <button onClick={onClose} className="btn-icon h-8 w-8" aria-label={t("c.close")}>
            <Icon name="close" size={16} />
          </button>
        </div>
        <div className="overflow-auto p-4">
          {items.length === 0 ? (
            <div className="py-8 text-center font-mono text-xs text-mute">{t("wl.empty")}</div>
          ) : (
            <div className="space-y-2">
              {items.map((p) => (
                <div key={p.id} className="flex items-center gap-3 border border-line bg-abyss/60 p-3">
                  <button onClick={() => onPick(p)} className="min-w-0 flex-1 text-start">
                    <div className="truncate text-sm font-bold hover:text-acid">{pName(p, lang)}</div>
                    <div className="font-mono text-[10px] text-mute">
                      <Icon name="eye" size={10} className="inline" /> {p.views.toLocaleString()}
                    </div>
                  </button>
                  <span className="font-mono text-sm font-bold text-acid">{fmtMoney(p.priceUsd)}</span>
                  <button
                    onClick={() => toggleWishlist(p.id)}
                    aria-label="remove"
                    className="btn-icon h-8 w-8 hover:!border-blood/50 hover:!text-blood"
                  >
                    <Icon name="close" size={13} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ── الصفحة الرئيسية ── */
export default function HomePage() {
  const t = useT();
  const lang = useLang();
  const wl = useWishlist();
  const [picked, setPicked] = useState<ProductRow | null>(null);
  const [wlOpen, setWlOpen] = useState(false);

  const tickerItems = TICKER_KEYS.map((k) => t(k));

  return (
    <Shell>
      <div className="space-y-8">
        {/* Hero — الشاشة الرئيسية الكبيرة */}
        <section className="grid gap-5 pt-4 lg:grid-cols-[1fr_300px]">
          <div>
            <div className="mono-label flex items-center gap-2">
              {t("home.terminal")}
              <span className="inline-block h-3 w-1.5 animate-blink bg-acid" />
            </div>
            <h1
              data-text="BLACK MART"
              className="glitch display-1 mt-4 font-mono tracking-[0.08em] text-glow"
            >
              BLACK&nbsp;MART
            </h1>
            <p className="mt-4 max-w-xl text-base font-medium leading-relaxed text-mute sm:text-lg">
              <Decryption text={t("home.line1")} delay={300} />
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              <span className="flex items-center gap-2 border border-acid/40 bg-acid/5 px-3 py-1.5 font-mono text-[10px] tracking-[0.25em] text-acid">
                <span className="inline-block h-1.5 w-1.5 animate-pulse-soft rounded-full bg-acid" />
                {t("home.online")}
              </span>
              <span className="flex items-center gap-2 border border-line px-3 py-1.5 font-mono text-[10px] tracking-[0.25em] text-fog">
                <Icon name="lock" size={11} className="text-dim" />
                {t("home.secured")}
              </span>
              <span className="flex items-center gap-2 border border-line px-3 py-1.5 font-mono text-[10px] tracking-[0.25em] text-fog">
                <Icon name="code" size={11} className="text-dim" />
                {t("home.encrypted")}
              </span>
            </div>
          </div>
          <TerminalPanel />
        </section>

        {/* شريط البث المتحرك */}
        <div className="overflow-hidden border-y border-line bg-abyss/70 py-2.5">
          <div className="ticker-track">
            {[...tickerItems, ...tickerItems].map((s, i) => (
              <span key={i} className="mx-5 inline-flex items-center gap-5">
                <span className="font-mono text-[10px] tracking-[0.3em] text-mute">{s}</span>
                <span className="text-[9px] text-acid">◆</span>
              </span>
            ))}
          </div>
        </div>

        {/* Search + Quick Links */}
        <section className="flex gap-2">
          <div className="flex-1">
            <SearchBar onPick={setPicked} />
          </div>
          <button
            onClick={() => setWlOpen(true)}
            className="btn-icon relative shrink-0"
            title={t("search.wl")}
            aria-label={t("search.wl")}
          >
            <Icon name="heart" size={16} className={wl.length ? "text-acid" : ""} filled={wl.length > 0} />
            {wl.length > 0 && (
              <span className="absolute -top-1.5 -end-1.5 flex h-4 min-w-4 items-center justify-center bg-acid px-1 font-mono text-[9px] font-bold text-void">
                {wl.length}
              </span>
            )}
          </button>
        </section>

        {/* Broadcast — شاشة البث */}
        <AdCarousel />

        {/* فهرس الأقسام الداخلية — تنقل سريع تحت البث مباشرة */}
        <section className="panel px-3 py-2.5">
          <div className="no-scrollbar flex items-center gap-2 overflow-x-auto">
            <span className="mono-label flex shrink-0 items-center gap-1.5">
              <Icon name="terminal" size={11} />
              <span className="hidden sm:inline">{lang === "ar" ? "الفهرس" : "INDEX"}</span>
            </span>
            <span className="h-4 w-px shrink-0 bg-line" />
            {QUICK_INDEX.map((q) => (
              <Link
                key={q.route}
                href={q.route}
                className="shrink-0 border border-line bg-abyss/60 px-3.5 py-1.5 font-mono text-[10px] tracking-wider text-mute transition-colors hover:border-acid/50 hover:text-acid"
              >
                {pick(lang, q.l)}
              </Link>
            ))}
          </div>
        </section>

        {/* Sections — 4 أقسام رئيسية (2×2) */}
        <section>
          <div className="mb-1 flex items-end justify-between">
            <div className="mono-label">// {t("home.pages")}</div>
            <span className="font-mono text-[9px] tracking-[0.2em] text-mute/60">{t("home.pagesSub")}</span>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3 sm:gap-4">
            {HOME_SECTIONS.map((hs, i) => {
              const accent = ACCENT[hs.accent];
              return (
                <Link
                  key={hs.id}
                  href={hs.route}
                  className={`panel panel-hover corners group flex flex-col overflow-hidden text-start ${accent.glow}`}
                >
                  {hs.thumb && (
                    <img src={hs.thumb} alt="" className="h-24 w-full object-cover opacity-75 sm:h-32" loading="lazy" />
                  )}
                  <div className="h-[3px] w-full bg-gradient-to-l from-blood via-blood/60 to-transparent" />
                  <div className="flex flex-1 flex-col p-3 sm:p-4">
                    <div className="flex items-start justify-between gap-2">
                      <div className="text-sm font-bold leading-snug sm:text-base">{pick(lang, hs.name)}</div>
                      <span className="font-mono text-[10px] text-mute/60">0{i + 1}</span>
                    </div>
                    <div className="mt-1.5 font-mono text-[9px] tracking-[0.2em] text-mute/70">
                      SEC::{String(hs.count).padStart(2, "0")}
                    </div>
                    <div className="btn-acid mt-3 w-full !py-2 text-[10px]">
                      {t("c.enter")}
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </section>

        {/* ⭐ الأكثر مبيعاً + 📊 التقييمات + 💬 الآراء (تحميل ديناميكي) */}
        <HomeLowerBlocks onPick={setPicked} />
      </div>

      {picked && <ProductModal p={picked} onClose={() => setPicked(null)} />}
      {wlOpen && <WishlistModal onClose={() => setWlOpen(false)} onPick={(p) => { setWlOpen(false); setPicked(p); }} />}
    </Shell>
  );
}
