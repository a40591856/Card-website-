"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  PERCENT_POLICY,
  PERCENT_TOP_TABS,
  AFFILIATE_FIELDS,
  OTHER_WORK_FIELDS,
  CUSTOM_WORK_FIELDS,
  PERCENT_TIPS,
  PERCENT_MOTIVATION,
  PERCENT_HOWTO,
  PERCENT_MSG_TITLES,
} from "@/lib/percent";
import { FORUM_SECTIONS, type FieldDef } from "@/lib/forum";
import {
  saveDraft,
  loadDraft,
  clearDraft,
  buildForumMessage,
  buildTrackWebFallback,
  dispatchToTelegram,
  trackHandle,
  copyText,
  timestamp,
  type DraftData,
} from "@/lib/forumClient";
import { useT, useLang, toast, shareSite } from "@/lib/client";
import { pick, type L } from "@/lib/site";
import { Icon } from "./Icon";

/* نموذج بمسودة محلية مستقلة */
function useDraftForm(key: string) {
  const [data, setData] = useState<DraftData>({});
  useEffect(() => {
    setData(loadDraft("percent", key));
  }, [key]);
  const set = (id: string, v: string) =>
    setData((prev) => {
      const next = { ...prev, [id]: v };
      saveDraft("percent", key, next);
      return next;
    });
  const clear = () => {
    clearDraft("percent", key);
    setData({});
  };
  return { data, set, clear };
}

/** حقول ديناميكية قابلة لإعادة الاستخدام */
function FieldList({
  fields,
  data,
  onChange,
}: {
  fields: FieldDef[];
  data: DraftData;
  onChange: (id: string, v: string) => void;
}) {
  const lang = useLang();
  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
      {fields.map((f) => (
        <div key={f.id} className={f.type === "textarea" ? "sm:col-span-2" : ""}>
          <label className="mono-label mb-1.5 block">
            {pick(lang, f.label)}{f.required && <span className="text-blood"> *</span>}
          </label>
          {f.type === "textarea" ? (
            <textarea
              className="inp min-h-[100px] resize-y"
              value={data[f.id] || ""}
              onChange={(e) => onChange(f.id, e.target.value)}
              placeholder={f.ph ? pick(lang, f.ph) : ""}
            />
          ) : (
            <input
              className="inp"
              type={f.type === "number" ? "number" : "text"}
              inputMode={f.type === "number" ? "numeric" : undefined}
              value={data[f.id] || ""}
              onChange={(e) => onChange(f.id, e.target.value)}
              placeholder={f.ph ? pick(lang, f.ph) : ""}
            />
          )}
        </div>
      ))}
    </div>
  );
}

/** قائمة منسدلة مرتبة مع زر إغلاق */
function Dropdown({
  title,
  open,
  onToggle,
  children,
}: {
  title: string;
  open: boolean;
  onToggle: () => void;
  children: ReactNode;
}) {
  const t = useT();
  return (
    <div>
      <button
        onClick={onToggle}
        className={`btn-ghost w-full py-2.5 ${open ? "!border-acid/50 !text-acid" : ""}`}
      >
        <Icon name="book" size={13} />
        {title}
        <Icon name="chevron" size={12} className={open ? "rotate-180 transition-transform" : "transition-transform"} />
      </button>
      {open && (
        <div className="panel animate-fade-up mt-2">
          <div className="mono-label flex items-center justify-between border-b border-line px-4 py-2.5">
            <span>◈ {title}</span>
            <button onClick={onToggle} className="flex items-center gap-1 text-mute transition-colors hover:text-acid">
              <Icon name="close" size={11} />
              {t("c.close")}
            </button>
          </div>
          <div className="p-4">{children}</div>
        </div>
      )}
    </div>
  );
}

/** ═══ قسم العمل بالنسبة والإحالة ═══ */
export default function PercentHub({
  onSwitchSection,
  onBack,
}: {
  onSwitchSection: (id: string) => void;
  onBack: () => void;
}) {
  const t = useT();
  const lang = useLang();

  const reg = useDraftForm("register");
  const other = useDraftForm("otherWork");
  const custom = useDraftForm("customWork");
  const formRef = useRef<HTMLDivElement>(null);

  const [tipsOpen, setTipsOpen] = useState(false);
  const [howOpen, setHowOpen] = useState(false);
  const [otherOpen, setOtherOpen] = useState(false);
  const [customOpen, setCustomOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [copied, setCopied] = useState(false);
  const [err, setErr] = useState(false);

  const sectionName = pick(lang, PERCENT_TOP_TABS.find((x) => x.id === "percent")!.label);

  /* ═══ إرسال موحّد: عنوان ديناميكي + نسخ + tg:// إلى Track2_1 ═══ */
  const send = (title: L, fields: FieldDef[], data: DraftData) => {
    const missing = fields.some((f) => f.required && !(data[f.id] || "").trim());
    if (missing) {
      setErr(true);
      toast(t("fh.required"), "warn");
      return;
    }
    setErr(false);
    const msg = buildForumMessage({
      section: sectionName,
      service: pick(lang, title), // ← العنوان المتحول [ ارغب في الترويج ] / [ يطلب عمل ] …
      fields: fields.map((f) => ({ label: pick(lang, f.label), value: data[f.id] || "—" })),
    });
    setMessage(msg);
    setCopied(true);
    void dispatchToTelegram(msg, trackHandle());
    toast(t("pct.sent"));
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="space-y-4">
      {/* 1 — تيوب التنقل العلوي + زر رجوع */}
      <div className="panel p-2.5">
        <div className="mb-2 flex items-center justify-between gap-2 px-1">
          <span className="mono-label">{t("meet.tabs")}</span>
          <button onClick={onBack} className="btn-ghost px-3 py-1.5 text-[9px]">
            <Icon name="back" size={11} className="rtl:rotate-180" />
            🔙 {t("fh.backTo")} · {t("fh.back")}
          </button>
        </div>
        <div className="no-scrollbar flex gap-1.5 overflow-x-auto">
          {PERCENT_TOP_TABS.map((tab) => {
            const target = FORUM_SECTIONS.find((s) => s.id === tab.id);
            return (
              <button
                key={tab.id}
                onClick={() => onSwitchSection(tab.id)}
                className={`shrink-0 border px-3 py-2 font-mono text-[10px] font-bold tracking-wider transition-all ${
                  tab.id === "percent"
                    ? "border-acid bg-acid text-void shadow-[0_0_16px_rgba(184,239,128,0.3)]"
                    : "border-line bg-abyss/60 text-mute hover:text-fog"
                }`}
              >
                {pick(lang, tab.label)}
                {target && (
                  <span className="ms-1 opacity-60">[{target.services?.length ?? target.specialties?.length ?? 0}]</span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* 2 — بطاقة الشرح الرئيسية */}
      <div className="border border-acid/50 bg-acid/5 p-4 shadow-[0_0_30px_rgba(184,239,128,0.12)] sm:p-5">
        <div className="mono-label mb-3 flex items-center gap-2 text-acid">
          <Icon name="star" size={13} />
          PERCENT & AFFILIATE HUB
        </div>
        <div className="max-h-[460px] overflow-y-auto whitespace-pre-line text-xs leading-loose text-fog/90 sm:text-[13px]">
          {pick(lang, PERCENT_POLICY)}
        </div>
      </div>

      {/* 3 — زر التسجيل السريع (تمرير تلقائي للأداة) */}
      <button
        onClick={() => formRef.current?.scrollIntoView({ behavior: "smooth", block: "start" })}
        className="btn-primary w-full"
      >
        <Icon name="user" size={16} />
        🔥 {t("pct.register")}
      </button>

      {/* 4 — أداة التوجه للمسؤول لاستخراج الرابط */}
      <div ref={formRef} className="panel scroll-mt-32 p-4">
        <div className="mono-label mb-3 flex items-center gap-2">
          <Icon name="link" size={13} className="text-acid" />
          {t("pct.registerTool")}
        </div>
        {/* الدليل التشغيلي — أولاً بشكل بارز */}
        <div className="mb-4 border border-acid/40 bg-acid/5 p-3">
          <div className="mono-label mb-1.5 flex items-center gap-2 text-acid">
            <Icon name="book" size={12} />
            {t("fh.guide")}
          </div>
          <p className="text-xs leading-loose text-fog/90">{pick(lang, PERCENT_HOWTO[0].text)}</p>
        </div>
        <FieldList fields={AFFILIATE_FIELDS} data={reg.data} onChange={reg.set} />
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <button
            onClick={() => send(PERCENT_MSG_TITLES.register, AFFILIATE_FIELDS, reg.data)}
            className="btn-acid flex-1 py-3"
          >
            <Icon name="plane" size={14} />
            {t("pct.toManager")}
          </button>
          <button onClick={reg.clear} className="btn-ghost px-3 py-2.5 text-[9px]">
            <Icon name="refresh" size={11} />
            {t("fh.draftClear")}
          </button>
        </div>
        <p className="mt-2 flex items-center gap-1.5 font-mono text-[9px] text-mute">
          <Icon name="lock" size={11} className="text-acid" />
          {t("fh.draft")} · {t("fh.local")}
        </p>
      </div>

      {/* 5 — نصائح للترويج */}
      <Dropdown title={`💡 ${t("pct.tips")}`} open={tipsOpen} onToggle={() => setTipsOpen((v) => !v)}>
        <div className="space-y-3">
          {PERCENT_TIPS.map((tip, i) => (
            <div key={i} className="flex gap-3 border-b border-line/60 pb-3 last:border-0 last:pb-0">
              <span className="shrink-0 font-mono text-[10px] font-bold text-blood">{String(i + 1).padStart(2, "0")}</span>
              <div>
                <div className="text-sm font-bold">{pick(lang, tip.platform)}</div>
                <p className="mt-1 text-xs leading-relaxed text-mute">{pick(lang, tip.text)}</p>
              </div>
            </div>
          ))}
          <div className="border border-violet/40 bg-violet/5 p-3">
            <div className="mono-label mb-1.5 text-violet">MOTIVATION</div>
            <p className="text-xs leading-loose text-fog/85">{pick(lang, PERCENT_MOTIVATION)}</p>
          </div>
        </div>
      </Dropdown>

      {/* 6 — طلب عمل آخر */}
      <button
        onClick={() => setOtherOpen((v) => !v)}
        className={`btn-ghost w-full py-2.5 ${otherOpen ? "!border-acid/50 !text-acid" : ""}`}
      >
        <Icon name="gear" size={13} />
        {t("pct.other")}
        <Icon name="chevron" size={12} className={otherOpen ? "rotate-180 transition-transform" : "transition-transform"} />
      </button>
      {otherOpen && (
        <div className="panel animate-fade-up p-4">
          <div className="mono-label mb-3 flex items-center justify-between">
            <span>◈ {t("pct.other")}</span>
            <button onClick={() => setOtherOpen(false)} className="flex items-center gap-1 text-mute hover:text-acid">
              <Icon name="close" size={11} />
              {t("c.close")}
            </button>
          </div>
          <FieldList fields={OTHER_WORK_FIELDS} data={other.data} onChange={other.set} />
          <button
            onClick={() => send(PERCENT_MSG_TITLES.otherWork, OTHER_WORK_FIELDS, other.data)}
            className="btn-acid mt-4 w-full py-3"
          >
            <Icon name="send" size={14} />
            📤 {t("pct.otherSend")}
          </button>
        </div>
      )}

      {/* 7 — الأزرار الإضافية */}
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
        <button onClick={() => shareSite(t)} className="btn-ghost py-3 text-[10px]">
          <Icon name="share" size={13} />
          {t("pct.share")}
        </button>
        <button
          onClick={() => setCustomOpen((v) => !v)}
          className={`btn-ghost py-3 text-[10px] ${customOpen ? "!border-acid/50 !text-acid" : ""}`}
        >
          <Icon name="tool" size={13} />
          {t("pct.custom")}
        </button>
        <Dropdown title={t("pct.how")} open={howOpen} onToggle={() => setHowOpen((v) => !v)}>
          <div className="space-y-3">
            {PERCENT_HOWTO.map((h, i) => (
              <div key={i} className="flex gap-3 border-b border-line/60 pb-3 last:border-0 last:pb-0">
                <span className="shrink-0 font-mono text-[10px] font-bold text-acid">{String(i + 1).padStart(2, "0")}</span>
                <div>
                  <div className="text-sm font-bold">{pick(lang, h.title)}</div>
                  <p className="mt-1 text-xs leading-relaxed text-mute">{pick(lang, h.text)}</p>
                </div>
              </div>
            ))}
          </div>
        </Dropdown>
      </div>

      {customOpen && (
        <div className="panel animate-fade-up p-4">
          <div className="mono-label mb-3 flex items-center justify-between">
            <span>◈ {t("pct.custom")}</span>
            <button onClick={() => setCustomOpen(false)} className="flex items-center gap-1 text-mute hover:text-acid">
              <Icon name="close" size={11} />
              {t("c.close")}
            </button>
          </div>
          <FieldList fields={CUSTOM_WORK_FIELDS} data={custom.data} onChange={custom.set} />
          <button
            onClick={() => send(PERCENT_MSG_TITLES.customWork, CUSTOM_WORK_FIELDS, custom.data)}
            className="btn-acid mt-4 w-full py-3"
          >
            <Icon name="send" size={14} />
            📤 {t("pct.otherSend")}
          </button>
        </div>
      )}

      {err && (
        <div className="flex items-center gap-2 border border-blood/40 bg-blood/10 px-3 py-2 text-xs text-blood">
          <Icon name="warn" size={13} />
          {t("fh.required")}
        </div>
      )}

      {/* معاينة الرسالة — جاهزة ومنسوخة */}
      {message && (
        <div className="panel animate-fade-up">
          <div className="mono-label flex items-center justify-between border-b border-line px-4 py-2.5">
            <span>{t("fh.preview")}</span>
            <span className="text-acid">✓ {t("fh.copied")} · {timestamp()}</span>
          </div>
          <pre className="max-h-64 overflow-auto whitespace-pre-wrap p-4 font-mono text-[11px] leading-6 text-fog/90" dir="auto">
            {message}
          </pre>
          <div className="grid gap-2 border-t border-line p-3 sm:grid-cols-2">
            <button
              onClick={async () => { if (await copyText(message)) toast(t("fh.copied")); }}
              className="btn-acid py-2.5 text-[10px]"
            >
              <Icon name={copied ? "check" : "link"} size={12} />
              {copied ? t("fh.copied") : t("fh.copy")}
            </button>
            <button
              onClick={() => window.open(buildTrackWebFallback(message), "_blank", "noreferrer")}
              className="btn-primary"
            >
              <Icon name="plane" size={15} />
              {t("fh.openRelay")}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
