import { db } from "./index";
import { products, notifications, ratings, opinions } from "./schema";
import { SEED_PRODUCTS, SEED_NOTIFICATIONS } from "@/lib/site";

/* تهيئة تلقائية عند أول استعلام — تُملأ البيانات التجريبية مرة واحدة */
let seeded = false;
let inFlight: Promise<void> | null = null;

export function ensureSeeded(): Promise<void> {
  if (seeded) return Promise.resolve();
  if (inFlight) return inFlight;
  inFlight = (async () => {
    try {
      const r = await db.select({ id: products.id }).from(products).limit(1);
      if (r.length > 0) {
        seeded = true;
        return;
      }
      await db.insert(products).values(SEED_PRODUCTS.map((p) => ({ ...p })));
      await db.insert(notifications).values(SEED_NOTIFICATIONS.map((n) => ({ ...n })));
      await db.insert(ratings).values([
        { name: "Shadow_77", stars: 5, text: "سرعة تنفيذ مذهلة والتوثيق واضح. المنطقة أمانة.", status: "approved" },
        { name: "Ghost", stars: 5, text: "Support is instant and the payment flow is clean.", status: "approved" },
        { name: "Ночь", stars: 4, text: "Всё чётко по срокам — ждём вторую фазу каталога.", status: "approved" },
      ]);
      await db.insert(opinions).values([
        { name: "Zero", kind: "opinion", text: "أتمنى إضافة شروحات فيديو داخل كل قسم.", status: "approved" },
        { name: "Cipher", kind: "opinion", text: "The stealth mode is a lifesaver. Keep it up.", status: "approved" },
      ]);
      seeded = true;
    } catch {
      /* التهيئة اختيارية — لا تُسقط الواجهة */
    }
  })();
  return inFlight;
}
