import {
  pgTable,
  text,
  integer,
  boolean,
  timestamp,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

/* ─────────────────────────────────────────────────────────────
   BLACK MART · قاعدة البيانات
   كل الجداول قابلة للتوسعة — أضف أعمدة جديدة دون كسر النظام.
   ───────────────────────────────────────────────────────────── */

export const products = pgTable("products", {
  id: integer().primaryKey().generatedAlwaysAsIdentity(),
  slug: text().notNull().unique(),
  nameAr: text().notNull(),
  nameEn: text().notNull(),
  nameRu: text().notNull(),
  descAr: text().default(""),
  descEn: text().default(""),
  descRu: text().default(""),
  catId: text().notNull().default("cards"),
  branchId: text().notNull().default(""),
  tag: text().notNull().default(""),
  img: text(),
  priceUsd: integer().notNull().default(0),
  oldPriceUsd: integer().notNull().default(0),
  balanceUsd: integer().notNull().default(0),
  verified: boolean().notNull().default(false),
  featured: boolean().notNull().default(false),
  views: integer().notNull().default(0),
  orders: integer().notNull().default(0),
  active: boolean().notNull().default(true),
  createdAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
});

export const ratings = pgTable(
  "ratings",
  {
    id: integer().primaryKey().generatedAlwaysAsIdentity(),
    name: text().notNull().default("زائر"),
    stars: integer().notNull().default(5),
    text: text().notNull().default(""),
    status: text().notNull().default("pending"), // pending | approved
    createdAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("ratings_status_idx").on(t.status)],
);

export const opinions = pgTable(
  "opinions",
  {
    id: integer().primaryKey().generatedAlwaysAsIdentity(),
    name: text().notNull().default("زائر"),
    kind: text().notNull().default("opinion"), // opinion | complaint | exchange | return
    text: text().notNull().default(""),
    status: text().notNull().default("pending"),
    createdAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("opinions_kind_idx").on(t.kind)],
);

export const notifications = pgTable("notifications", {
  id: integer().primaryKey().generatedAlwaysAsIdentity(),
  kind: text().notNull().default("update"), // offer | update | alert
  titleAr: text().notNull(),
  titleEn: text().notNull(),
  titleRu: text().notNull(),
  bodyAr: text().notNull().default(""),
  bodyEn: text().notNull().default(""),
  bodyRu: text().notNull().default(""),
  active: boolean().notNull().default(true),
  createdAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
});

export const members = pgTable("members", {
  id: text().primaryKey(), // معرّف عضوي مكوّن من 8 أرقام (أو BM-XXXXXX للقديم)
  name: text().notNull(),
  email: text(),
  passHash: text().notNull(),
  points: integer().notNull().default(0),
  refCode: text(),
  avatar: text(),
  createdAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
  lastSeen: timestamp({ withTimezone: true }).notNull().defaultNow(),
});

export const wishlist = pgTable(
  "wishlist",
  {
    id: integer().primaryKey().generatedAlwaysAsIdentity(),
    owner: text().notNull(), // معرف العضو أو معرف الزائر المحلي
    productId: integer().notNull(),
    createdAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("wishlist_owner_product_uq").on(t.owner, t.productId)],
);

/* نظام الإحالات — زائر فريد واحد لكل مالك (Anti-Fraud) */
export const referrals = pgTable(
  "referrals",
  {
    id: integer().primaryKey().generatedAlwaysAsIdentity(),
    owner: text().notNull(),
    visitor: text().notNull(),
    createdAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("referrals_owner_visitor_uq").on(t.owner, t.visitor), index("referrals_owner_idx").on(t.owner)],
);

export const orders = pgTable(
  "orders",
  {
    id: integer().primaryKey().generatedAlwaysAsIdentity(),
    owner: text().notNull(),
    productId: integer().notNull(),
    qty: integer().notNull().default(1),
    totalUsd: integer().notNull().default(0),
    status: text().notNull().default("pending"),
    createdAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("orders_owner_idx").on(t.owner)],
);
