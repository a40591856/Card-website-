import type { Metadata } from "next";
import CartPage from "@/components/CartPage";

export const metadata: Metadata = { title: "السلة — BLACK MART" };

export default function Page() {
  return <CartPage />;
}
