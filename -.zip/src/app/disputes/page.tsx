import type { Metadata } from "next";
import ManagementAndSupportPage from "@/components/ManagementAndSupportPage";

export const metadata: Metadata = { title: "البلاغات وحل النزاعات — BLACK MART" };

export default function Page() {
  return <ManagementAndSupportPage />;
}
