import type { Metadata } from "next";
import PaymentGate from "@/components/PaymentGate";

export const metadata: Metadata = { title: "صفحة طرق الدفع الرسمية — BLACK MART" };

export default function Page() {
  return <PaymentGate />;
}
