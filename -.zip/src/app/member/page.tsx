import type { Metadata } from "next";
import MemberDashboard from "@/components/MemberDashboard";

export const metadata: Metadata = { title: "ملف العضو — BLACK MART" };

export default function Page() {
  return <MemberDashboard />;
}
