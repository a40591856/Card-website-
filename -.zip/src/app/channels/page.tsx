import type { Metadata } from "next";
import ChannelsPage from "@/components/ChannelsPage";

export const metadata: Metadata = { title: "القنوات الرسمية — BLACK MART" };

export default function Page() {
  return <ChannelsPage />;
}
