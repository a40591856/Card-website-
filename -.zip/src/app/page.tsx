"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { getLast } from "@/lib/client";
import type { Lang } from "@/lib/i18n";
import EntryScreen from "@/components/EntryScreen";
import EncryptionScreen from "@/components/EncryptionScreen";
import HomePage from "@/components/HomePage";

/**
 * تدفق الدخول:
 * - أول دخول (بدون لغة): شاشة اللغة → شاشة التشفير → الرئيسية
 * - شاشة التشفير: تظهر مرة واحدة فقط في الجلسة، ثم كل التنقل مباشر
 */
export default function Flow() {
  const router = useRouter();
  const [stage, setStage] = useState<"boot" | "entry" | "enc" | "app">("boot");

  useEffect(() => {
    const forcedEntry = sessionStorage.getItem("bm_entry");
    if (forcedEntry) {
      sessionStorage.removeItem("bm_entry");
      setStage("entry");
      return;
    }
    const hasLang = localStorage.getItem("bm_lang");
    if (!hasLang) {
      setStage("entry");
      return;
    }
    // شاشة التشفير مرة واحدة فقط لكل جلسة دخول
    if (sessionStorage.getItem("bm_booted")) setStage("app");
    else setStage("enc");
  }, []);

  const onEnter = (_l: Lang) => setStage("enc");

  const onDone = () => {
    try {
      sessionStorage.setItem("bm_booted", "1");
    } catch {
      /* noop */
    }
    setStage("app");
    const last = getLast();
    if (last && last !== window.location.pathname && last.startsWith("/")) {
      router.replace(last);
    }
  };

  if (stage === "boot") return <div className="grid-bg min-h-screen bg-void" />;
  if (stage === "entry") return <EntryScreen onEnter={onEnter} />;
  if (stage === "enc") return <EncryptionScreen onDone={onDone} />;
  return <HomePage />;
}
