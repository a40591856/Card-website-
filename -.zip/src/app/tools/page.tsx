import { redirect } from "next/navigation";

/** الأدوات المخصّصة تعيش داخل أقسامها — لا لوحة تحكم منفصلة */
export default function Page() {
  redirect("/market/transfer");
}
