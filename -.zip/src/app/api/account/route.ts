import { db } from "@/db";
import { members, orders, products } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

/** GET /api/account?owner=BM-XXXX — ملف العضو + طلباته + أسماء المنتجات */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const owner = url.searchParams.get("owner") || "";
  if (!owner) return Response.json({ member: null, orders: [], productNames: {} });

  const [memberRows, orderRows, prodRows] = await Promise.all([
    db.select().from(members).where(eq(members.id, owner)).limit(1),
    db.select().from(orders).where(eq(orders.owner, owner)).orderBy(desc(orders.createdAt)).limit(30),
    db.select().from(products),
  ]);

  const productNames: Record<number, { ar: string; en: string; ru: string }> = {};
  for (const p of prodRows) {
    productNames[p.id] = { ar: p.nameAr, en: p.nameEn, ru: p.nameRu };
  }

  const m = memberRows[0];
  return Response.json({
    member: m
      ? { id: m.id, name: m.name, createdAt: m.createdAt, lastSeen: m.lastSeen }
      : null,
    orders: orderRows,
    productNames,
  });
}
