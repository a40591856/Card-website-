import { db } from "@/db";
import { members } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { createHash } from "node:crypto";

export const dynamic = "force-dynamic";

const hash = (email: string, pass: string) =>
  createHash("sha256").update(`bmv2::${email.toLowerCase()}::${pass}`).digest("hex");

const profile = (m: typeof members.$inferSelect) => ({
  id: m.id,
  name: m.name,
  email: m.email ?? "",
  points: m.points,
  refCode: m.refCode ?? m.id,
  avatar: m.avatar,
  createdAt: m.createdAt,
});

/** POST /api/member — { action, ... } */
export async function POST(req: Request) {
  try {
    const b = (await req.json()) as Record<string, string | number | undefined>;
    const action = String(b.action || "");
    const email = String(b.email || "").trim().toLowerCase();

    if (action === "register") {
      if (!email || !b.name || !b.pass || !b.id) return Response.json({ ok: false });
      const exists = await db.select({ id: members.id }).from(members).where(eq(members.email, email)).limit(1);
      if (exists.length) return Response.json({ ok: false, reason: "exists" });
      const refCode = String(b.refCode || b.id);
      await db.insert(members).values({
        id: String(b.id), name: String(b.name), email,
        passHash: hash(email, String(b.pass)), points: 0, refCode,
      });
      const row = await db.select().from(members).where(eq(members.id, String(b.id))).limit(1);
      return Response.json({ ok: true, profile: profile(row[0]) });
    }

    if (action === "login") {
      if (!email || !b.pass) return Response.json({ ok: false });
      const row = await db.select().from(members).where(eq(members.email, email)).limit(1);
      if (!row.length || row[0].passHash !== hash(email, String(b.pass)))
        return Response.json({ ok: false, reason: "invalid" });
      await db.update(members).set({ lastSeen: new Date() }).where(eq(members.id, row[0].id));
      return Response.json({ ok: true, profile: profile(row[0]) });
    }

    if (action === "sync") {
      const id = String(b.id || "");
      if (!id) return Response.json({ ok: false });
      const patch: Record<string, unknown> = { lastSeen: new Date() };
      if (b.name) patch.name = String(b.name);
      if (b.avatar !== undefined) patch.avatar = String(b.avatar);
      if (typeof b.points === "number") patch.points = b.points;
      if (b.pass && b.newPass) patch.passHash = hash(String(b.pass), String(b.newPass));
      await db.update(members).set(patch).where(eq(members.id, id));
      return Response.json({ ok: true });
    }

    if (action === "refer") {
      const ref = String(b.refCode || "");
      if (!ref) return Response.json({ ok: false });
      await db.update(members).set({ points: sql`${members.points} + 1` }).where(eq(members.refCode, ref));
      return Response.json({ ok: true });
    }

    return Response.json({ ok: false });
  } catch {
    return Response.json({ ok: false, error: true }, { status: 400 });
  }
}
