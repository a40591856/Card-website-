import { db } from "@/db";
import { notifications } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { ensureSeeded } from "@/db/seed";

export const dynamic = "force-dynamic";

/** GET /api/notifications — النشطة فقط، الأحدث أولاً */
export async function GET() {
  await ensureSeeded();
  const rows = await db
    .select()
    .from(notifications)
    .where(eq(notifications.active, true))
    .orderBy(desc(notifications.createdAt))
    .limit(12);
  return Response.json(rows);
}
