import { db } from "@/db";
import { ratings } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

/** GET /api/ratings — التقييمات المعتمدة فقط */
export async function GET() {
  const rows = await db
    .select()
    .from(ratings)
    .where(eq(ratings.status, "approved"))
    .orderBy(desc(ratings.createdAt))
    .limit(20);
  return Response.json(rows);
}

/** POST /api/ratings — تقييم جديد (يُحفظ بانتظار مراجعة الإدارة) */
export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { name?: string; stars?: number; text?: string };
    const stars = Math.min(5, Math.max(1, Number(body.stars) || 5));
    await db.insert(ratings).values({
      name: (body.name || "زائر").slice(0, 40),
      stars,
      text: (body.text || "").slice(0, 500),
      status: "pending",
    });
    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false }, { status: 400 });
  }
}
