import { db } from "@/db";
import { referrals } from "@/db/schema";
import { eq, count } from "drizzle-orm";

export const dynamic = "force-dynamic";

/** GET /api/referrals?owner=... → عدد الزوار الفريدين */
export async function GET(req: Request) {
  const owner = new URL(req.url).searchParams.get("owner") || "";
  if (!owner) return Response.json({ count: 0 });
  const rows = await db
    .select({ n: count() })
    .from(referrals)
    .where(eq(referrals.owner, owner));
  return Response.json({ count: rows[0]?.n ?? 0 });
}

/** POST /api/referrals — تسجيل زائر فريد (لا يتكرر) */
export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { owner?: string; visitor?: string };
    const owner = (body.owner || "").slice(0, 40);
    const visitor = (body.visitor || "").slice(0, 40);
    if (!owner || !visitor || owner === visitor) return Response.json({ ok: true, duplicate: true });
    await db
      .insert(referrals)
      .values({ owner, visitor })
      .onConflictDoNothing();
    const rows = await db.select({ n: count() }).from(referrals).where(eq(referrals.owner, owner));
    return Response.json({ ok: true, count: rows[0]?.n ?? 0 });
  } catch {
    return Response.json({ ok: false }, { status: 400 });
  }
}
