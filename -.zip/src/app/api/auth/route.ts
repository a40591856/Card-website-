import { db } from "@/db";
import { members } from "@/db/schema";
import { eq } from "drizzle-orm";
import { createHash, randomInt } from "node:crypto";

export const dynamic = "force-dynamic";

const hash = (s: string) => createHash("sha256").update(`bm::${s}`).digest("hex");

/**
 * POST /api/auth — { name, pass }
 * العضوية غير موجودة → إنشاء فوري (ID فريد BM-XXXXXX)
 * موجودة → تحقق من كلمة المرور (مُجمّعة SHA-256)
 */
export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { name?: string; pass?: string };
    const name = (body.name || "").trim();
    const pass = body.pass || "";
    if (name.length < 3) return Response.json({ error: true });
    if (pass.length < 4) return Response.json({ error: true });

    const found = await db.select().from(members).where(eq(members.name, name)).limit(1);

    if (found.length === 0) {
      let id = "";
      for (let i = 0; i < 12; i++) {
        id = `BM-${randomInt(100000, 999999)}`;
        const clash = await db.select({ id: members.id }).from(members).where(eq(members.id, id)).limit(1);
        if (clash.length === 0) break;
      }
      await db.insert(members).values({ id, name, passHash: hash(`${name}::${pass}`) });
      return Response.json({ id, name, created: true });
    }

    if (found[0].passHash !== hash(`${name}::${pass}`)) {
      return Response.json({ error: true });
    }
    await db.update(members).set({ lastSeen: new Date() }).where(eq(members.id, found[0].id));
    return Response.json({ id: found[0].id, name: found[0].name });
  } catch {
    return Response.json({ error: true }, { status: 400 });
  }
}
