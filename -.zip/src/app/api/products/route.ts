import { db } from "@/db";
import { products } from "@/db/schema";
import { and, desc, eq, sql } from "drizzle-orm";
import { ensureSeeded } from "@/db/seed";

export const dynamic = "force-dynamic";

/** GET /api/products?cat=...&branch=... — قائمة المنتجات النشطة */
export async function GET(req: Request) {
  await ensureSeeded();
  const url = new URL(req.url);
  const cat = url.searchParams.get("cat");
  const branch = url.searchParams.get("branch");
  const conds = [eq(products.active, true)];
  if (cat) conds.push(eq(products.catId, cat));
  if (branch) conds.push(eq(products.branchId, branch));
  const rows = await db.select().from(products).where(and(...conds)).orderBy(desc(products.views));
  return Response.json(rows);
}

/** POST /api/products — { view?: id, order?: id } تحديث العدّادات */
export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { view?: number; order?: number };
    if (body.view) {
      await db
        .update(products)
        .set({ views: sql`${products.views} + 1` })
        .where(eq(products.id, body.view));
    }
    if (body.order) {
      await db
        .update(products)
        .set({ orders: sql`${products.orders} + 1` })
        .where(eq(products.id, body.order));
    }
    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false }, { status: 400 });
  }
}
