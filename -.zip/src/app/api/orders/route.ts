import { db } from "@/db";
import { orders, products } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

/** POST /api/orders — { owner, items: [{productId, qty}] } تأكيد الطلب */
export async function POST(req: Request) {
  try {
    const body = (await req.json()) as {
      owner?: string;
      items?: { productId: number; qty: number }[];
    };
    if (!body.owner || !Array.isArray(body.items) || body.items.length === 0) {
      return Response.json({ ok: false }, { status: 400 });
    }

    const all = await db.select().from(products);
    const map = new Map(all.map((p) => [p.id, p]));
    const toInsert = [];
    for (const it of body.items.slice(0, 20)) {
      const p = map.get(it.productId);
      if (!p) continue;
      const qty = Math.min(99, Math.max(1, Number(it.qty) || 1));
      toInsert.push({
        owner: body.owner.slice(0, 20),
        productId: p.id,
        qty,
        totalUsd: p.priceUsd * qty,
        status: "pending",
      });
      await db.update(products).set({ orders: sql`${products.orders} + ${qty}` }).where(eq(products.id, p.id));
    }
    if (toInsert.length > 0) await db.insert(orders).values(toInsert);
    return Response.json({ ok: true, count: toInsert.length });
  } catch {
    return Response.json({ ok: false }, { status: 400 });
  }
}
