import { db } from "@/db";
import { opinions } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

/** GET /api/opinions?kind=... — الآراء/الشكاوى المعتمدة */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const kind = url.searchParams.get("kind");
  const rows = kind
    ? await db
        .select()
        .from(opinions)
        .where(and(eq(opinions.status, "approved"), eq(opinions.kind, kind)))
        .orderBy(desc(opinions.createdAt))
        .limit(30)
    : await db
        .select()
        .from(opinions)
        .where(eq(opinions.status, "approved"))
        .orderBy(desc(opinions.createdAt))
        .limit(30);
  return Response.json(rows);
}

/** POST /api/opinions — إرسال (آراء / شكوى / استبدال / استرجاع) */
export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { name?: string; kind?: string; text?: string };
    const kind = ["opinion", "complaint", "exchange", "return", "service", "idea"].includes(body.kind || "")
      ? (body.kind as string)
      : "opinion";
    await db.insert(opinions).values({
      name: (body.name || "زائر").slice(0, 40),
      kind,
      text: (body.text || "").slice(0, 900),
      status: "pending",
    });
    return Response.json({ ok: true, kind });
  } catch {
    return Response.json({ ok: false }, { status: 400 });
  }
}
