import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { MARKET_SECTIONS } from "@/lib/site";
import MarketSectionPage from "@/components/MarketSectionPage";
import MarketCardsPage from "@/components/MarketCardsPage";
import InjectionHub from "@/components/InjectionHub";
import AccountsHub from "@/components/AccountsHub";
import TransfersHub from "@/components/TransfersHub";
import GiftsHub from "@/components/GiftsHub";
import TopupsHub from "@/components/TopupsHub";
import ProxyHub from "@/components/ProxyHub";

export const metadata: Metadata = { title: "سوق الكاردنق — BLACK MART" };

/** Next.js 16: params يُمرَّر كـ Promise — لا بد من await */
export async function generateStaticParams() {
  return MARKET_SECTIONS.map((s) => ({ section: s.id }));
}

export default async function Page({
  params,
}: {
  params: Promise<{ section: string }>;
}) {
  const { section } = await params;
  if (!MARKET_SECTIONS.some((s) => s.id === section)) notFound();

  // قسم البطاقات له تجربة عميقة خاصة (8 فروع + 54 منتجاً)
  if (section === "cards") return <MarketCardsPage />;
  // قسم حقن الحسابات — Injection Hub المستقل
  if (section === "injection") return <InjectionHub />;
  // الحسابات المستعارة — DIGITAL_BANK_VAULT (7 أقسام)
  if (section === "accounts") return <AccountsHub />;
  // التحويلات والتبييض — MONEY_FLOW_SYSTEM (5 أقسام)
  if (section === "transfer") return <TransfersHub />;
  // بطاقات الهدايا والاشتراكات — GIFT CARDS VAULT (6 أقسام)
  if (section === "gifts") return <GiftsHub />;
  // شحن التطبيقات الصوتية والمرئية — APP TOP-UP VAULT
  if (section === "topup") return <TopupsHub />;
  // بروكسيات التشفير والكورسات — PROXY & ENCRYPTION VAULT (5 تبويبات)
  if (section === "proxy") return <ProxyHub />;
  return <MarketSectionPage sectionId={section} />;
}
