import type { Metadata } from "next";
import MarketPage from "@/components/MarketPage";

export const metadata: Metadata = { title: "سوق الكاردنق — BLACK MART" };

export default function Page() {
  return <MarketPage />;
}
