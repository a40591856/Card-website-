import type { Metadata } from "next";
import ArsenalHub from "@/components/ArsenalHub";

export const metadata: Metadata = { title: "أدوات التفريغ — BLACK MART" };

export default function Page() {
  return <ArsenalHub />;
}
