import type { Metadata } from "next";
import ForumHub from "@/components/ForumHub";

export const metadata: Metadata = { title: "المنتدى والمجتمع — BLACK MART" };

export default function Page() {
  return <ForumHub />;
}
