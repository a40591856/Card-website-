import type { Metadata } from "next";
import SupportHub from "@/components/SupportHub";

export const metadata: Metadata = { title: "الدعم والإرشادات — BLACK MART" };

export default function Page() {
  return <SupportHub />;
}
