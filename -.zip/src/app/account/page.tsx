"use client";

import { useEffect, useState } from "react";
import { useT, useLang, useAuth, useShell, useWishlist, api, fmtMoney } from "@/lib/client";
import { fmtDate as fmtDateStr } from "@/lib/types";
import { Icon } from "@/components/Icon";
import Shell from "@/components/Shell";
import Decryption from "@/components/Decryption";

export default function AccountPage() {
  const t = useT();
  const lang = useLang();
  const auth = useAuth();
  const shell = useShell();
  const wl = useWishlist();

  const [member, setMember] = useState<{ id: string; name: string; createdAt: string; lastSeen: string } | null>(null);
  const [orders, setOrders] = useState<{ id: number; productId: number; qty: number; totalUsd: number; status: string; createdAt: string }[]>([]);
  const [names, setNames] = useState<Record<number, { ar: string; en: string; ru: string }>>({});

  useEffect(() => {
    if (!auth) return;
    api<{
      member: typeof member | null;
      orders: typeof orders;
      productNames: Record<number, { ar: string; en: string; ru: string }>;
    }>(`/api/account?owner=${auth}`)
      .then((r) => {
        setMember(r.member);
        setOrders(r.orders ?? []);
        if (r.productNames) setNames(r.productNames);
      })
      .catch(() => {});
  }, [auth]);

  const nameOf = (id: number) => {
    const n = names[id];
    if (!n) return `#${id}`;
    return lang === "ar" ? n.ar : lang === "ru" ? n.ru : n.en;
  };

  return (
    <Shell>
      <div className="space-y-6 pt-4">
        <header className="panel grid-bg-fine relative overflow-hidden p-5 sm:p-7">
          <div className="mono-label mb-4">// {t("acct.title")}</div>
          {!auth || !member ? (
            <div className="flex flex-col items-center gap-4 py-10 text-center">
              <div className="flex h-16 w-16 items-center justify-center border border-line bg-abyss text-mute">
                <Icon name="user" size={28} />
              </div>
              <p className="font-mono text-sm text-mute">{t("acct.notAuth")}</p>
              <button onClick={() => shell?.openLogin()} className="btn-acid">
                <Icon name="lock" size={14} />
                {t("menu.login")}
              </button>
            </div>
          ) : (
            <div className="flex flex-wrap items-center gap-5">
              <div className="flex h-20 w-20 items-center justify-center border border-acid/50 bg-panel text-acid">
                <Icon name="user" size={36} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="mono-label">{t("acct.id")}</div>
                <div className="mt-1 font-mono text-2xl font-extrabold tracking-wider text-acid text-glow" dir="ltr">
                  <Decryption text={member.id} />
                </div>
                <div className="mt-2 max-w-xs truncate text-sm font-bold text-fog">{member.name}</div>
              </div>
              <div className="grid grid-cols-2 gap-x-6 gap-y-1 font-mono text-[10px] text-mute">
                <span>{t("acct.joined")}</span>
                <span dir="ltr" className="text-fog">{fmtDateStr(member.createdAt, lang)}</span>
                <span>{t("acct.last")}</span>
                <span dir="ltr" className="text-fog">{fmtDateStr(member.lastSeen, lang)}</span>
              </div>
            </div>
          )}
        </header>

        {/* 📦 صندوق الطلبات */}
        <section className="panel">
          <div className="flex items-center gap-2 border-b border-line px-5 py-4">
            <Icon name="box" size={16} className="text-acid" />
            <h3 className="flex-1 text-lg font-extrabold">{t("acct.orders")}</h3>
            <span className="font-mono text-[9px] tracking-[0.2em] text-mute">BOX :: {orders.length}</span>
          </div>
          <div className="p-5">
            {orders.length === 0 ? (
              <div className="py-8 text-center font-mono text-xs text-mute">{t("acct.ordersEmpty")}</div>
            ) : (
              <div className="divide-y divide-line">
                {orders.map((o) => (
                  <div key={o.id} className="flex items-center gap-3 py-3 first:pt-0">
                    <Icon name="box" size={16} className="text-dim" />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-bold">{nameOf(o.productId)}</div>
                      <div className="font-mono text-[9px] text-mute" dir="ltr">
                        {fmtDateStr(o.createdAt, lang)} · ×{o.qty}
                      </div>
                    </div>
                    <span className="border border-amber/40 bg-amber/10 px-2 py-0.5 font-mono text-[9px] tracking-widest text-amber">
                      {o.status.toUpperCase()}
                    </span>
                    <span className="font-mono text-sm font-bold text-acid">{fmtMoney(o.totalUsd)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>
      </div>
    </Shell>
  );
}
