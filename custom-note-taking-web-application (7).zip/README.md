# موقع الملاحظات — دفتر عملك الخاص

موقع ملاحظات عربي (RTL) بتصميم أخضر: أقسام ← ملفات ← ملاحظات، مع بحث، نسخ،
مشاركة (تلقرام/واتساب)، نسخ احتياطي واستعادة، سلة مهملات، خزنة ومدير كلمات مرور،
مدير مواقع، وأوضاع قفل (رقم/نمط/كلمة سر/بصمة) وتمويه.

## رفع الموقع على Netlify (رابط دائم)

### 1) قاعدة بيانات مجانية (Neon)
- سجّل في https://neon.tech وأنشئ Project.
- انسخ رابط الاتصال (Connection String)، مثال:
  `postgresql://user:pass@host/dbname?sslmode=require`

### 2) ارفع الكود على GitHub
- أنشئ مستودعاً جديداً وارفع كل ملفات المشروع (ملف `netlify.toml` مضمّن).

### 3) اربط Netlify
- في https://netlify.com اضغط **Add new site → Import an existing project**.
- اختر مستودع GitHub. Netlify سيكتشف Next.js تلقائياً.

### 4) أضف متغيّر البيئة
- Site settings → Environment variables → أضف:
  - المفتاح: `DATABASE_URL`
  - القيمة: رابط Neon من الخطوة 1

### 5) أنشئ الجداول
بعد أول نشر، شغّل من جهازك (مع نفس `DATABASE_URL` في `.env`):
```
npx drizzle-kit push
```

### 6) رابطك الدائم
Netlify يعطيك رابطاً مثل `https://your-notes.netlify.app` — أرسله لأي هاتف
وستجد كل ملاحظاتك. يمكنك تغيير الاسم من إعدادات Netlify.

## التشغيل محلياً
```
npm install
# ضع DATABASE_URL في ملف .env
npx drizzle-kit push
npm run dev
```

> تنبيه أمني: من يملك رابط الموقع يفتحه. فعّل قفل التطبيق من الإعدادات،
> ولا تشارك الرابط مع أحد.
