import { db } from "@/db";
import { sections, files, notes } from "@/db/schema";
import { eq, inArray, sql } from "drizzle-orm";
import { jsonError } from "@/lib/server";
import { maybeSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

function attachment(payload: unknown, filename: string) {
  return Response.json(payload, {
    headers: {
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Cache-Control": "no-store",
    },
  });
}

export async function GET(req: Request) {
  const sp = new URL(req.url).searchParams;
  const kind = sp.get("kind") || "all";
  const id = sp.get("id") || "";

  await maybeSeed();

  if (kind === "all") {
    const [s, f, n] = await Promise.all([
      db.select().from(sections),
      db.select().from(files),
      db.select().from(notes),
    ]);
    return attachment(
      { app: "mialahadzat", version: 1, exportedAt: new Date().toISOString(), sections: s, files: f, notes: n },
      `mialahadzat-backup-${new Date().toISOString().slice(0, 10)}.json`,
    );
  }

  if (kind === "section" && id) {
    const s = await db.select().from(sections).where(eq(sections.id, id));
    if (!s.length) return jsonError("القسم غير موجود", 404);
    const f = await db.select().from(files).where(eq(files.sectionId, id));
    const fids = f.map((x) => x.id);
    const n = fids.length
      ? await db.select().from(notes).where(inArray(notes.fileId, fids))
      : [];
    return attachment(
      { app: "mialahadzat", version: 1, exportedAt: new Date().toISOString(), section: s[0], files: f, notes: n },
      `mialahadzat-section-${id.slice(0, 8)}.json`,
    );
  }

  if (kind === "file" && id) {
    const f = await db.select().from(files).where(eq(files.id, id));
    if (!f.length) return jsonError("الملف غير موجود", 404);
    const s = f[0].sectionId
      ? await db.select().from(sections).where(eq(sections.id, f[0].sectionId))
      : [];
    const n = await db.select().from(notes).where(eq(notes.fileId, id));
    return attachment(
      { app: "mialahadzat", version: 1, exportedAt: new Date().toISOString(), section: s[0] || null, file: f[0], notes: n },
      `mialahadzat-file-${id.slice(0, 8)}.json`,
    );
  }

  if (kind === "note" && id) {
    const n = await db.select().from(notes).where(eq(notes.id, id));
    if (!n.length) return jsonError("الملاحظة غير موجودة", 404);
    const f = n[0].fileId
      ? await db.select().from(files).where(eq(files.id, n[0].fileId))
      : [];
    const s = f.length && f[0].sectionId
      ? await db.select().from(sections).where(eq(sections.id, f[0].sectionId))
      : [];
    return attachment(
      {
        app: "mialahadzat",
        version: 1,
        exportedAt: new Date().toISOString(),
        section: s[0] || null,
        file: f[0] || null,
        note: n[0],
      },
      `mialahadzat-note-${id.slice(0, 8)}.json`,
    );
  }

  return jsonError("نوع تصدير غير معروف");
}
