import { db } from "@/db";
import { passwords } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const b = await req.json().catch(() => ({}));
  const [row] = await db
    .insert(passwords)
    .values({
      groupName: String(b.groupName || "").slice(0, 200),
      siteName: String(b.siteName || "").slice(0, 300),
      url: String(b.url || "").slice(0, 1000),
      username: String(b.username || "").slice(0, 300),
      password: String(b.password || "").slice(0, 500),
      note: String(b.note || "").slice(0, 5000),
    })
    .returning();
  return Response.json(row);
}
