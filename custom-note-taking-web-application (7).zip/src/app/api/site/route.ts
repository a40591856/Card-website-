import { db } from "@/db";
import { sites } from "@/db/schema";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(sites).where(sql`${sites.deletedAt} is null`);
  return Response.json({ sites: rows });
}

export async function POST(req: Request) {
  const b = await req.json().catch(() => ({}));
  const [row] = await db
    .insert(sites)
    .values({
      groupName: String(b.groupName || "").slice(0, 200),
      name: String(b.name || "").slice(0, 300),
      url: String(b.url || "").slice(0, 1000),
      note: String(b.note || "").slice(0, 5000),
    })
    .returning();
  return Response.json(row);
}
