import { db } from "@/db";
import { sections, files, notes } from "@/db/schema";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  if (String(body.action || "") !== "empty") return Response.json({ ok: false }, { status: 400 });

  await db.delete(notes).where(sql`${notes.deletedAt} is not null`);
  await db.delete(files).where(sql`${files.deletedAt} is not null`);
  await db.delete(sections).where(sql`${sections.deletedAt} is not null`);

  return Response.json({ ok: true });
}
