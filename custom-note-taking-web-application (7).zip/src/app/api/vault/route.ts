import { db } from "@/db";
import { appConfig, passwords } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { jsonError } from "@/lib/server";

export const dynamic = "force-dynamic";

async function getConfig() {
  const rows = await db.select().from(appConfig).where(eq(appConfig.id, "main"));
  if (rows.length) return rows[0];
  const [row] = await db.insert(appConfig).values({ id: "main" }).onConflictDoNothing().returning();
  return row ?? { id: "main", vaultPassword: "1234" };
}

// Verify the vault password (used to unlock the vault).
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const action = String(body.action || "");
  const cfg = await getConfig();

  if (action === "verify") {
    const ok = String(body.password || "") === cfg.vaultPassword;
    return Response.json({ ok });
  }

  if (action === "change") {
    if (String(body.current || "") !== cfg.vaultPassword) return jsonError("كلمة المرور الحالية غير صحيحة");
    const next = String(body.next || "");
    if (next.length < 1) return jsonError("كلمة المرور الجديدة مطلوبة");
    await db
      .insert(appConfig)
      .values({ id: "main", vaultPassword: next })
      .onConflictDoUpdate({ target: appConfig.id, set: { vaultPassword: next } });
    return Response.json({ ok: true });
  }

  return jsonError("إجراء غير معروف");
}

// List all password entries (only fetched after unlocking client-side).
export async function GET() {
  await getConfig();
  const rows = await db
    .select()
    .from(passwords)
    .where(sql`${passwords.deletedAt} is null`);
  return Response.json({ passwords: rows });
}
