import { db } from "@/db";
import { sections, files, notes } from "@/db/schema";
import { upsertRows, jsonError } from "@/lib/server";

export const dynamic = "force-dynamic";

type Raw = Record<string, unknown>;

const asArr = (x: unknown): Raw[] => (Array.isArray(x) ? (x as Raw[]) : []);
const str = (x: unknown, max = 2000) => (typeof x === "string" ? x.slice(0, max) : "");
const toDate = (x: unknown) => (x ? new Date(String(x)) : new Date());
const toDateOrNull = (x: unknown) => (x ? new Date(String(x)) : null);
const validId = (x: unknown) => typeof x === "string" && x.length === 36;

export async function POST(req: Request) {
  let payload: unknown;
  try {
    payload = await req.json();
  } catch {
    return jsonError("الملف ليس بصيغة JSON صحيحة");
  }

  const secRaw: Raw[] = [];
  const fileRaw: Raw[] = [];
  const noteRaw: Raw[] = [];

  // Absorb one export object (full backup, or single section/file/note export).
  const absorb = (p: Raw) => {
    secRaw.push(...asArr(p.sections));
    fileRaw.push(...asArr(p.files));
    noteRaw.push(...asArr(p.notes));
    if (p.section && typeof p.section === "object") secRaw.push(p.section as Raw);
    if (p.file && typeof p.file === "object") fileRaw.push(p.file as Raw);
    if (p.note && typeof p.note === "object") noteRaw.push(p.note as Raw);
  };

  if (payload && typeof payload === "object") {
    const p = payload as Raw;
    // A "bundle" is an array of export objects (multi-select backup).
    if (Array.isArray(p.bundle)) {
      for (const item of p.bundle) if (item && typeof item === "object") absorb(item as Raw);
    }
    absorb(p);
  }

  const secRows = secRaw
    .filter((r) => validId(r?.id) && str(r?.name).trim())
    .map((r) => ({
      id: String(r.id),
      name: str(r.name, 200).trim(),
      createdAt: toDate(r.createdAt),
      deletedAt: toDateOrNull(r.deletedAt),
    }));

  const fileRows = fileRaw
    .filter((r) => validId(r?.id) && str(r?.name).trim())
    .map((r) => ({
      id: String(r.id),
      sectionId: validId(r?.sectionId) ? String(r.sectionId) : null,
      name: str(r.name, 200).trim(),
      createdAt: toDate(r.createdAt),
      deletedAt: toDateOrNull(r.deletedAt),
    }));

  const noteRows = noteRaw
    .filter((r) => validId(r?.id))
    .map((r) => ({
      id: String(r.id),
      fileId: validId(r?.fileId) ? String(r.fileId) : null,
      title: str(r.title, 500),
      content: str(r.content, 2_000_000),
      type: ["note", "checklist", "drawing", "voice"].includes(String(r.type))
        ? String(r.type)
        : "note",
      tag: ["", "important", "urgent", "done", "idea"].includes(String(r.tag)) ? String(r.tag) : "",
      pinned: r.pinned === true,
      archived: r.archived === true,
      createdAt: toDate(r.createdAt),
      updatedAt: toDate(r.updatedAt),
      deletedAt: toDateOrNull(r.deletedAt),
    }));

  // Upsert sections first, then check which parents exist for files/notes.
  await upsertRows(sections, secRows, {
    name: sections.name,
    createdAt: sections.createdAt,
    deletedAt: sections.deletedAt,
  });
  const existingSecs = new Set(
    (await db.select({ id: sections.id }).from(sections)).map((r) => r.id),
  );
  const okFiles = fileRows.filter((f) => f.sectionId === null || existingSecs.has(f.sectionId));
  const skippedFiles = fileRows.length - okFiles.length;

  await upsertRows(files, okFiles, {
    name: files.name,
    sectionId: files.sectionId,
    createdAt: files.createdAt,
    deletedAt: files.deletedAt,
  });
  const existingFiles = new Set((await db.select({ id: files.id }).from(files)).map((r) => r.id));
  const okNotes = noteRows.filter((n) => n.fileId === null || existingFiles.has(n.fileId));
  const skippedNotes = noteRows.length - okNotes.length;

  await upsertRows(notes, okNotes, {
    title: notes.title,
    content: notes.content,
    type: notes.type,
    tag: notes.tag,
    pinned: notes.pinned,
    archived: notes.archived,
    fileId: notes.fileId,
    createdAt: notes.createdAt,
    updatedAt: notes.updatedAt,
    deletedAt: notes.deletedAt,
  });

  return Response.json({
    ok: true,
    sections: secRows.length,
    files: okFiles.length,
    notes: okNotes.length,
    skipped: skippedFiles + skippedNotes,
  });
}


