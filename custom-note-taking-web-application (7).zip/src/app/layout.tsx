import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "الملاحظات — دفتر عملك",
  description: "أقسام، ملفات وملاحظات خاصة بعملك: بحث سريع، نسخ، مشاركة، طباعة PDF ونسخ احتياطي.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#43a047",
};

const favicon =
  "data:image/svg+xml," +
  encodeURIComponent(
    `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect width='100' height='100' rx='22' fill='#43a047'/><path d='M24 36h16l7 9h29v27H24z' fill='#fff'/><path d='M32 55h34M32 63h24' stroke='#43a047' stroke-width='5' stroke-linecap='round'/></svg>`,
  );

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&display=swap"
          rel="stylesheet"
        />
        <link rel="icon" href={favicon} />
      </head>
      <body>{children}</body>
    </html>
  );
}
