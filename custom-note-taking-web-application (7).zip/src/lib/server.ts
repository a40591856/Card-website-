import { db } from "@/db";

export function jsonError(message: string, status = 400) {
  return Response.json({ error: message }, { status });
}

export async function upsertRows(table: any, rows: any[], set: Record<string, any>) {
  if (!rows.length) return;
  await db.insert(table).values(rows).onConflictDoUpdate({ target: table.id, set });
}
