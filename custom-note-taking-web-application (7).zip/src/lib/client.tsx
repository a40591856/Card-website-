import type { ReactNode } from "react";

export async function api<T = any>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...init,
  });
  if (!res.ok) {
    let msg = "حدث خطأ غير متوقع";
    try {
      const j = await res.json();
      if (j && j.error) msg = j.error;
    } catch {
      /* ignore */
    }
    throw new Error(msg);
  }
  return res.json();
}

export function fmtDate(iso: string): string {
  try {
    return new Intl.DateTimeFormat("ar", {
      day: "numeric",
      month: "long",
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    }).format(new Date(iso));
  } catch {
    return iso;
  }
}

export async function copyText(t: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(t);
    return true;
  } catch {
    /* fall through */
  }
  try {
    const ta = document.createElement("textarea");
    ta.value = t;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    ta.remove();
    return ok;
  } catch {
    return false;
  }
}

export async function shareText(text: string): Promise<"shared" | "copied" | "cancelled"> {
  if (typeof navigator !== "undefined" && navigator.share) {
    try {
      await navigator.share({ text });
      return "shared";
    } catch (e: any) {
      if (e && e.name === "AbortError") return "cancelled";
      return (await copyText(text)) ? "copied" : "cancelled";
    }
  }
  return (await copyText(text)) ? "copied" : "cancelled";
}

export function shareToTelegram(text: string, url?: string) {
  const u = url ? url : "";
  const link = `https://t.me/share/url?url=${encodeURIComponent(u)}&text=${encodeURIComponent(text)}`;
  window.open(link, "_blank", "noopener,noreferrer");
}

/** Clean a telegram username: strips @, t.me/, spaces. */
export function normalizeTelegramUser(raw: string): string {
  let u = raw.trim();
  u = u.replace(/^https?:\/\/(t\.me|telegram\.me)\//i, "");
  u = u.replace(/^@/, "");
  u = u.replace(/\s+/g, "");
  return u;
}

/**
 * Open a direct chat with a specific telegram user, with the text prefilled in
 * the message box (t.me/<user>?text=...). Telegram only prefills text for bots
 * reliably, but for normal users it still opens their chat; we also copy the
 * text to clipboard as a fallback so the user can paste + send.
 */
export async function sendToTelegramUser(user: string, text: string): Promise<boolean> {
  const u = normalizeTelegramUser(user);
  if (!u) return false;
  // Copy first so the user can paste even if prefill is ignored by Telegram.
  await copyText(text);
  const link = `https://t.me/${encodeURIComponent(u)}?text=${encodeURIComponent(text)}`;
  window.open(link, "_blank", "noopener,noreferrer");
  return true;
}

/** Open a direct WhatsApp chat with a specific phone number, text prefilled. */
export function sendToWhatsAppNumber(phone: string, text: string) {
  const num = phone.replace(/[^\d]/g, "");
  const link = num
    ? `https://wa.me/${num}?text=${encodeURIComponent(text)}`
    : `https://wa.me/?text=${encodeURIComponent(text)}`;
  window.open(link, "_blank", "noopener,noreferrer");
}

export function shareToWhatsApp(text: string) {
  const link = `https://wa.me/?text=${encodeURIComponent(text)}`;
  window.open(link, "_blank", "noopener,noreferrer");
}

export type SaveResult = "saved" | "shared" | "downloaded" | "cancelled";

/** Force a classic download to the phone's Downloads folder (appears in Files as a document). */
export function downloadFileDirect(obj: unknown, filename: string) {
  const blob = new Blob([JSON.stringify(obj, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

/** Save to a location the user picks (native save dialog / share-to-Files). */
export async function saveToFiles(obj: unknown, filename: string): Promise<SaveResult> {
  const text = JSON.stringify(obj, null, 2);
  const blob = new Blob([text], { type: "application/json" });

  const anyWin = window as unknown as {
    showSaveFilePicker?: (opts: unknown) => Promise<{
      createWritable: () => Promise<{ write: (d: Blob) => Promise<void>; close: () => Promise<void> }>;
    }>;
  };
  if (typeof anyWin.showSaveFilePicker === "function") {
    try {
      const handle = await anyWin.showSaveFilePicker({
        suggestedName: filename,
        types: [{ description: "نسخة احتياطية (JSON)", accept: { "application/json": [".json"] } }],
      });
      const writable = await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      return "saved";
    } catch (e: unknown) {
      if (e && (e as { name?: string }).name === "AbortError") return "cancelled";
    }
  }

  try {
    const nav = navigator as Navigator & {
      canShare?: (data: { files: File[] }) => boolean;
      share?: (data: { files: File[]; title?: string }) => Promise<void>;
    };
    const file = new File([blob], filename, { type: "application/json" });
    if (nav.share && nav.canShare && nav.canShare({ files: [file] })) {
      await nav.share({ files: [file], title: filename });
      return "shared";
    }
  } catch (e: unknown) {
    if (e && (e as { name?: string }).name === "AbortError") return "cancelled";
  }

  // No native option → fall back to a normal download.
  downloadFileDirect(obj, filename);
  return "downloaded";
}

/**
 * Save a JSON backup. Tries, in order:
 * 1) Native "Save file" picker (desktop Chrome/Edge) — lets you name & choose a folder.
 * 2) Native file Share sheet (Android/iOS) — opens "Save to Files / Send to..." chooser.
 * 3) Classic download to the Downloads folder.
 */
export async function downloadJson(obj: unknown, filename: string): Promise<SaveResult> {
  const text = JSON.stringify(obj, null, 2);
  const blob = new Blob([text], { type: "application/json" });

  // 1) Desktop save-file picker (not available inside iframes / mobile browsers)
  const anyWin = window as unknown as {
    showSaveFilePicker?: (opts: unknown) => Promise<{
      createWritable: () => Promise<{ write: (d: Blob) => Promise<void>; close: () => Promise<void> }>;
    }>;
  };
  if (typeof anyWin.showSaveFilePicker === "function") {
    try {
      const handle = await anyWin.showSaveFilePicker({
        suggestedName: filename,
        types: [{ description: "نسخة احتياطية (JSON)", accept: { "application/json": [".json"] } }],
      });
      const writable = await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      return "saved";
    } catch (e: unknown) {
      if (e && (e as { name?: string }).name === "AbortError") return "cancelled";
      // fall through
    }
  }

  // 2) Mobile: share the actual file so the user can pick "Save to Files" / send it.
  try {
    const nav = navigator as Navigator & {
      canShare?: (data: { files: File[] }) => boolean;
      share?: (data: { files: File[]; title?: string; text?: string }) => Promise<void>;
    };
    const file = new File([blob], filename, { type: "application/json" });
    if (nav.share && nav.canShare && nav.canShare({ files: [file] })) {
      await nav.share({ files: [file], title: filename, text: "نسخة احتياطية من موقع الملاحظات" });
      return "shared";
    }
  } catch (e: unknown) {
    if (e && (e as { name?: string }).name === "AbortError") return "cancelled";
    // fall through
  }

  // 3) Classic download to the Downloads folder.
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
  return "downloaded";
}

export function todayStamp() {
  return new Date().toISOString().slice(0, 10);
}

/** Is a device biometric (fingerprint / face) authenticator available? */
export async function biometricAvailable(): Promise<boolean> {
  try {
    const anyWin = window as unknown as { PublicKeyCredential?: { isUserVerifyingPlatformAuthenticatorAvailable?: () => Promise<boolean> } };
    const pkc = anyWin.PublicKeyCredential;
    if (!pkc || !pkc.isUserVerifyingPlatformAuthenticatorAvailable) return false;
    return await pkc.isUserVerifyingPlatformAuthenticatorAvailable();
  } catch {
    return false;
  }
}

/**
 * Prompt for device biometrics. Uses a throwaway WebAuthn credential request
 * that forces user verification (fingerprint/face) without needing a server.
 * Returns true if the user verified successfully.
 */
export async function biometricVerify(): Promise<boolean> {
  try {
    if (!("credentials" in navigator)) return false;
    const challenge = crypto.getRandomValues(new Uint8Array(32));
    // Try a create() with platform authenticator + user verification required.
    const cred = await navigator.credentials.create({
      publicKey: {
        challenge,
        rp: { name: "الملاحظات" },
        user: {
          id: crypto.getRandomValues(new Uint8Array(16)),
          name: "note-user",
          displayName: "مستخدم الملاحظات",
        },
        pubKeyCredParams: [
          { type: "public-key", alg: -7 },
          { type: "public-key", alg: -257 },
        ],
        authenticatorSelection: {
          authenticatorAttachment: "platform",
          userVerification: "required",
        },
        timeout: 60000,
        attestation: "none",
      },
    });
    return !!cred;
  } catch {
    return false;
  }
}

/** Split note content into blocks separated by blank lines. */
export function blocksOf(content: string): string[] {
  return (content || "")
    .split(/\n\s*\n/)
    .map((b) => b.replace(/\s+$/, ""))
    .filter((b) => b.trim().length > 0);
}

const URL_SPLIT = /(https?:\/\/[^\s"'<>()\[\]{}،؛!?]+)[.,،؛!?]*\b/g;

/** Render plain text with clickable links (opens in a new tab). */
export function Linkify({ text }: { text: string }): ReactNode {
  const parts = text.split(URL_SPLIT);
  return (
    <>
      {parts.map((p, i) =>
        /^https?:\/\//.test(p) ? (
          <a
            key={i}
            href={p}
            target="_blank"
            rel="noopener noreferrer"
            dir="ltr"
            className="inline-block break-all text-right font-bold text-grass-700 underline underline-offset-2"
          >
            {p}
          </a>
        ) : (
          <span key={i}>{p}</span>
        ),
      )}
    </>
  );
}
