"use client";

import { useCallback, useEffect, useState } from "react";

export type Accent = "green" | "blue" | "purple" | "orange" | "red" | "teal";

export type Prefs = {
  dark: boolean;
  accent: Accent;
  fontSize: number; // 14 - 26
  titleOnly: boolean; // show only note title in cards
  listMode: boolean; // list vs grid
  // Lock: kind of secret + the stored secret value
  lockKind: "none" | "pin" | "pattern" | "password";
  lockSecret: string | null; // pin digits / pattern dot-sequence / password text
  biometricLock: boolean; // require device biometrics (fingerprint/face) on open
  // Disguise: how the installed app looks on the home screen
  disguise: DisguiseKey;
  syncEmail: string; // optional email used to label backups for the user
  lastTelegramUser: string; // remembered @username for direct send
  lastWhatsAppNumber: string; // remembered number for direct send
};

export type DisguiseKey = "notes" | "calculator" | "weather" | "clock" | "files";

export const DEFAULT_PREFS: Prefs = {
  dark: false,
  accent: "green",
  fontSize: 15,
  titleOnly: false,
  listMode: false,
  lockKind: "none",
  lockSecret: null,
  biometricLock: false,
  disguise: "notes",
  syncEmail: "",
  lastTelegramUser: "",
  lastWhatsAppNumber: "",
};

// Disguise identities used when the site is added to the home screen.
export const DISGUISES: {
  key: DisguiseKey;
  label: string;
  appName: string;
  theme: string;
  icon: string; // emoji used to draw the icon svg
  bg: string; // icon background
}[] = [
  { key: "notes", label: "الملاحظات (بدون تمويه)", appName: "الملاحظات", theme: "#43a047", icon: "📝", bg: "#43a047" },
  { key: "calculator", label: "آلة حاسبة", appName: "الآلة الحاسبة", theme: "#374151", icon: "🧮", bg: "#1f2937" },
  { key: "weather", label: "الطقس", appName: "الطقس", theme: "#0284c7", icon: "⛅", bg: "#0ea5e9" },
  { key: "clock", label: "الساعة", appName: "الساعة", theme: "#111827", icon: "⏰", bg: "#111827" },
  { key: "files", label: "الملفات", appName: "الملفات", theme: "#f59e0b", icon: "📁", bg: "#f59e0b" },
];

export const ACCENTS: { key: Accent; label: string; color: string; dark: string }[] = [
  { key: "green", label: "أخضر", color: "#43a047", dark: "#2e7d32" },
  { key: "teal", label: "أزرق مخضر", color: "#0d9488", dark: "#0f766e" },
  { key: "blue", label: "أزرق", color: "#2563eb", dark: "#1d4ed8" },
  { key: "purple", label: "بنفسجي", color: "#7c3aed", dark: "#6d28d9" },
  { key: "orange", label: "برتقالي", color: "#ea580c", dark: "#c2410c" },
  { key: "red", label: "أحمر", color: "#dc2626", dark: "#b91c1c" },
];

const KEY = "mialahadzat_prefs_v1";

function load(): Prefs {
  if (typeof window === "undefined") return DEFAULT_PREFS;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return DEFAULT_PREFS;
    return { ...DEFAULT_PREFS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_PREFS;
  }
}

/** Apply accent + dark to CSS variables + font size. */
export function applyPrefs(p: Prefs) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  const a = ACCENTS.find((x) => x.key === p.accent) ?? ACCENTS[0];
  root.style.setProperty("--accent", a.color);
  root.style.setProperty("--accent-strong", a.dark);
  root.style.setProperty("--note-font", `${p.fontSize}px`);
  root.classList.toggle("dark", p.dark);
  root.setAttribute("data-accent", p.accent);
}

export function usePrefs() {
  const [prefs, setPrefs] = useState<Prefs>(DEFAULT_PREFS);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const p = load();
    setPrefs(p);
    applyPrefs(p);
    setReady(true);
  }, []);

  const update = useCallback((patch: Partial<Prefs>) => {
    setPrefs((prev) => {
      const next = { ...prev, ...patch };
      try {
        window.localStorage.setItem(KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      applyPrefs(next);
      return next;
    });
  }, []);

  return { prefs, update, ready };
}
