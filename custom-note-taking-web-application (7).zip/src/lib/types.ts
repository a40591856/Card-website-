export type SectionRow = {
  id: string;
  name: string;
  createdAt: string;
  deletedAt: string | null;
};

export type FileRow = {
  id: string;
  sectionId: string | null;
  name: string;
  createdAt: string;
  deletedAt: string | null;
};

export type NoteType = "note" | "checklist" | "drawing" | "voice";
export type NoteTag = "" | "important" | "urgent" | "done" | "idea";

export type NoteRow = {
  id: string;
  fileId: string | null;
  title: string;
  content: string;
  type: NoteType;
  tag: NoteTag;
  pinned: boolean;
  archived: boolean;
  createdAt: string;
  updatedAt: string;
  deletedAt: string | null;
};

export type PasswordRow = {
  id: string;
  groupName: string;
  siteName: string;
  url: string;
  username: string;
  password: string;
  note: string;
  createdAt: string;
  updatedAt: string;
  deletedAt: string | null;
};

export type SiteRow = {
  id: string;
  groupName: string;
  name: string;
  url: string;
  note: string;
  createdAt: string;
  updatedAt: string;
  deletedAt: string | null;
};

export type Data = {
  sections: SectionRow[];
  files: FileRow[];
  notes: NoteRow[];
};

export type SearchResult = {
  sections: SectionRow[];
  files: FileRow[];
  notes: NoteRow[];
};
