import { db } from "@/db";
import { sections, files, notes } from "@/db/schema";

/**
 * Seed the exact sections from the user's notes app the first time the app is
 * opened. Files/notes inside each section will be filled in by the user later.
 * A few home-root notes from the screenshot are added as placeholders.
 */
export async function maybeSeed() {
  const existing = await db.select({ id: sections.id }).from(sections).limit(1);
  const anyNote = await db.select({ id: notes.id }).from(notes).limit(1);
  if (existing.length > 0 || anyNote.length > 0) return;

  // Sections exactly as in the user's app (order = as shown)
  const sectionNames = [
    "اعمالي",
    "افكار المنتجات الرقميه واخطط الصور",
    "خطط المتجر الجديد الشامل",
    "ردود الاستقبال والمحافظ",
  ];
  for (const name of sectionNames) {
    await db.insert(sections).values({ name });
  }

  // Home-root notes seen on the main screen (outside any section) — placeholders.
  const rootNotes = [
    { title: "الخطط", content: "" },
    { title: "خطط موقع الادوات الاضافية", content: "" },
    { title: "الخطط", content: "" },
    { title: "خطه برمجه موقع الادوات", content: "" },
  ];
  for (const n of rootNotes) {
    await db.insert(notes).values({ fileId: null, title: n.title, content: n.content, type: "note" });
  }
}
