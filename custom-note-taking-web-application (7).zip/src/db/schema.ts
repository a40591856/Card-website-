import { pgTable, uuid, text, timestamp, boolean } from "drizzle-orm/pg-core";

export const sections = pgTable("sections", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  deletedAt: timestamp("deleted_at"),
});

export const files = pgTable("files", {
  id: uuid("id").primaryKey().defaultRandom(),
  // null = a file that lives on the home root (not inside a section yet)
  sectionId: uuid("section_id").references(() => sections.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  deletedAt: timestamp("deleted_at"),
});

export const notes = pgTable("notes", {
  id: uuid("id").primaryKey().defaultRandom(),
  // null = a note that lives on the home root (not inside a file yet)
  fileId: uuid("file_id").references(() => files.id, { onDelete: "cascade" }),
  title: text("title").notNull().default(""),
  content: text("content").notNull().default(""),
  // "note" | "checklist" | "drawing" | "voice"
  type: text("type").notNull().default("note"),
  // "" | "important" | "urgent" | "done" | "idea"
  tag: text("tag").notNull().default(""),
  pinned: boolean("pinned").notNull().default(false),
  archived: boolean("archived").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  deletedAt: timestamp("deleted_at"),
});

// Password manager entries (kept inside the protected vault section conceptually)
export const passwords = pgTable("passwords", {
  id: uuid("id").primaryKey().defaultRandom(),
  // Optional folder/group name to organize entries ("" = ungrouped)
  groupName: text("group_name").notNull().default(""),
  siteName: text("site_name").notNull().default(""),
  url: text("url").notNull().default(""),
  username: text("username").notNull().default(""),
  password: text("password").notNull().default(""),
  note: text("note").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  deletedAt: timestamp("deleted_at"),
});

// Saved websites/bookmarks (name + url + note), links open directly
export const sites = pgTable("sites", {
  id: uuid("id").primaryKey().defaultRandom(),
  groupName: text("group_name").notNull().default(""),
  name: text("name").notNull().default(""),
  url: text("url").notNull().default(""),
  note: text("note").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  deletedAt: timestamp("deleted_at"),
});

// Single-row app config (vault password lives here, server-side)
export const appConfig = pgTable("app_config", {
  id: text("id").primaryKey().default("main"),
  vaultPassword: text("vault_password").notNull().default("1234"),
});
