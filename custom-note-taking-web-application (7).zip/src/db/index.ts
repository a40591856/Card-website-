import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  throw new Error("DATABASE_URL is required");
}

const globalForDb = globalThis as typeof globalThis & {
  __arenaNextJsPostgresqlPool?: Pool;
};

// Cloud Postgres providers (Neon, Supabase, etc.) require SSL. Enable it
// automatically for remote hosts, but keep it off for the local sandbox DB.
const isLocal = /localhost|127\.0\.0\.1/.test(databaseUrl);
const wantsSsl = /sslmode=require/.test(databaseUrl) || (!isLocal && process.env.NODE_ENV === "production");

export const pool =
  globalForDb.__arenaNextJsPostgresqlPool ??
  new Pool({
    connectionString: databaseUrl,
    ...(wantsSsl ? { ssl: { rejectUnauthorized: false } } : {}),
  });

if (process.env.NODE_ENV !== "production") {
  globalForDb.__arenaNextJsPostgresqlPool = pool;
}

export const db = drizzle(pool);
