"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { ReactNode } from "react";
import type { Data, FileRow, NoteRow, NoteType, SectionRow, SearchResult } from "@/lib/types";
import {
  api,
  copyText,
  downloadJson,
  fmtDate,
  shareText,
  shareToTelegram,
  shareToWhatsApp,
  sendToTelegramUser,
  sendToWhatsAppNumber,
  todayStamp,
} from "@/lib/client";
import { usePrefs, ACCENTS, DEFAULT_PREFS, DISGUISES, type Accent } from "@/lib/prefs";
import { biometricAvailable, biometricVerify, saveToFiles, downloadFileDirect } from "@/lib/client";
import LockScreen, { PatternSetup } from "./Lock";
import Vault from "./Vault";
import Sites from "./Sites";
import NoteView from "./NoteView";
import { Overlay, ModalRow, Toast, Btn, PageShell } from "./Modal";
import {
  IPlus,
  ISearch,
  IMenu,
  IList,
  IGrid,
  IFolder,
  INote,
  ITrash,
  IGear,
  IShare,
  ICopy,
  IDownload,
  IUpload,
  IX,
  IRestore,
  IKebab,
  IChevronL,
  IPencil,
  IChecklist,
  IPen,
  IMic,
  ISection,
  IMoon,
  IPalette,
  IFontSize,
  ILock,
  ISync,
  IMove,
  ITelegram,
  IWhatsApp,
  ICheckbox,
  ICheckboxOn,
  ISelect,
  IFinger,
  IInfo,
  IBack,
  IMask,
  IPin,
  IPinned,
  ITag,
  IArchive,
  ILink,
  ISoon,
  IPrint,
} from "./Icons";

/* ---------------------------------- types ---------------------------------- */

type View = { t: "home" } | { t: "section"; id: string } | { t: "file"; id: string };

type ActionItem = { label: string; icon?: ReactNode; danger?: boolean; onClick: () => void };

type ModalState =
  | { kind: "prompt"; title: string; placeholder?: string; submitLabel?: string; onSubmit: (v: string) => void }
  | { kind: "confirm"; title: string; message: string; confirmLabel?: string; danger?: boolean; onConfirm: () => void }
  | { kind: "actions"; title: string; items: ActionItem[] }
  | { kind: "move"; title: string; kindItem: "note" | "file"; currentParentId: string | null; onPick: (parentId: string | null) => void };

type TrashItem = { type: "section" | "file" | "note"; id: string; name: string; sub: string; deletedAt: string };

/* --------------------------------- helpers --------------------------------- */

function Empty({
  icon,
  title,
  desc,
  action,
  onAction,
}: {
  icon: ReactNode;
  title: string;
  desc: string;
  action?: string;
  onAction?: () => void;
}) {
  return (
    <div className="flex flex-col items-center gap-2 py-16 text-center">
      <span className="text-grass-300">{icon}</span>
      <p className="text-base font-extrabold text-ink-900">{title}</p>
      <p className="max-w-xs text-sm font-bold leading-6 text-ink-400">{desc}</p>
      {action && onAction && (
        <button
          onClick={onAction}
          className="mt-3 flex items-center gap-2 rounded-xl bg-grass-600 px-5 py-2.5 text-sm font-extrabold text-white transition hover:bg-grass-700"
        >
          <IPlus className="h-4 w-4" />
          {action}
        </button>
      )}
    </div>
  );
}

function FolderCard({
  name,
  sub,
  date,
  big = false,
  onOpen,
  onMenu,
  selecting = false,
  selected = false,
  onToggle,
  onLongPress,
}: {
  name: string;
  sub?: string;
  date?: string;
  big?: boolean;
  onOpen: () => void;
  onMenu: () => void;
  selecting?: boolean;
  selected?: boolean;
  onToggle?: () => void;
  onLongPress?: () => void;
}) {
  const lp = useLongPress(onLongPress);
  return (
    <div
      onClick={selecting ? onToggle : onOpen}
      {...(selecting ? {} : lp)}
      className={`relative flex min-h-[150px] cursor-pointer flex-col items-center justify-center gap-1 rounded-xl border p-3 text-center shadow-[0_1px_2px_rgba(20,40,20,0.04)] transition hover:-translate-y-0.5 hover:shadow-md active:translate-y-0 ${
        selected ? "border-grass-500 bg-grass-50 ring-2 ring-grass-500/40" : "border-line bg-white"
      }`}
    >
      {selecting ? (
        <span className="absolute top-1.5 left-1.5 text-grass-600">
          {selected ? <ICheckboxOn className="h-6 w-6" /> : <ICheckbox className="h-6 w-6 text-ink-400" />}
        </span>
      ) : (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onMenu();
          }}
          title="خيارات"
          className="absolute top-1.5 left-1.5 rounded-full p-1.5 text-ink-400 opacity-70 transition hover:bg-black/5 hover:opacity-100"
        >
          <IKebab className="h-4 w-4" />
        </button>
      )}
      <IFolder strokeWidth={1.6} className={big ? "h-12 w-12 text-grass-500" : "h-10 w-10 text-grass-500"} />
      <p className="w-full truncate text-[15px] font-extrabold text-ink-900">{name}</p>
      {sub && <p className="text-[11px] font-bold text-ink-400">{sub}</p>}
      {date && <p className="text-[10px] font-bold text-ink-400/70">{date}</p>}
    </div>
  );
}

/** Long-press hook to enter selection mode (mobile-friendly). */
function useLongPress(cb?: () => void, ms = 500) {
  const timer = useRef<number | null>(null);
  const fired = useRef(false);
  if (!cb) return {};
  const start = () => {
    fired.current = false;
    timer.current = window.setTimeout(() => {
      fired.current = true;
      cb();
    }, ms);
  };
  const clear = () => {
    if (timer.current) window.clearTimeout(timer.current);
  };
  return {
    onTouchStart: start,
    onTouchEnd: clear,
    onTouchMove: clear,
    onMouseDown: start,
    onMouseUp: clear,
    onMouseLeave: clear,
    onContextMenu: (e: React.MouseEvent) => {
      e.preventDefault();
      clear();
      cb();
    },
  };
}

const noteTypeIcon: Record<NoteType, ReactNode> = {
  note: <INote className="h-4 w-4" />,
  checklist: <IChecklist className="h-4 w-4" />,
  drawing: <IPen className="h-4 w-4" />,
  voice: <IMic className="h-4 w-4" />,
};
const noteTypeLabel: Record<NoteType, string> = {
  note: "ملاحظة",
  checklist: "قائمة مرجعية",
  drawing: "كتابة يدوية",
  voice: "تسجيل صوتي",
};

const TAG_COLORS: Record<string, string> = {
  important: "#f59e0b",
  urgent: "#dc2626",
  done: "#16a34a",
  idea: "#2563eb",
};

function NoteCard({
  note,
  onOpen,
  onMenu,
  onCopy,
  titleOnly = false,
  selecting = false,
  selected = false,
  onToggle,
  onLongPress,
}: {
  note: NoteRow;
  onOpen: () => void;
  onMenu: () => void;
  onCopy: () => void;
  titleOnly?: boolean;
  selecting?: boolean;
  selected?: boolean;
  onToggle?: () => void;
  onLongPress?: () => void;
}) {
  const snippet = note.content.replace(/\s+/g, " ").trim();
  const t = (note.type ?? "note") as NoteType;
  const lp = useLongPress(onLongPress);
  return (
    <div
      onClick={selecting ? onToggle : onOpen}
      {...(selecting ? {} : lp)}
      className={`relative flex cursor-pointer flex-col rounded-xl border p-3 shadow-[0_1px_2px_rgba(20,40,20,0.04)] transition hover:-translate-y-0.5 hover:shadow-md active:translate-y-0 ${
        titleOnly ? "min-h-0" : "min-h-[150px]"
      } ${selected ? "border-grass-500 bg-grass-50 ring-2 ring-grass-500/40" : "border-line bg-white"}`}
    >
      <div className="flex items-start gap-0.5">
        {selecting ? (
          <span className="mt-0.5 shrink-0 text-grass-600">
            {selected ? <ICheckboxOn className="h-5 w-5" /> : <ICheckbox className="h-5 w-5 text-ink-400" />}
          </span>
        ) : (
          <span className="mt-0.5 shrink-0 text-grass-500">{noteTypeIcon[t]}</span>
        )}
        {note.tag && <span className="mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: TAG_COLORS[note.tag] }} />}
        {note.pinned && <IPinned className="mt-0.5 h-4 w-4 shrink-0 text-grass-500" />}
        <p className="min-w-0 flex-1 truncate text-[15px] font-extrabold text-ink-900">
          {note.title || "بدون عنوان"}
        </p>
        {!selecting && (
          <>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onCopy();
              }}
              title="نسخ كل ما بداخلها"
              className="-mt-0.5 rounded-full p-1 text-ink-400 transition hover:bg-grass-50 hover:text-grass-700"
            >
              <ICopy className="h-4 w-4" />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onMenu();
              }}
              title="خيارات"
              className="-mt-0.5 rounded-full p-1 text-ink-400 opacity-70 transition hover:bg-black/5 hover:opacity-100"
            >
              <IKebab className="h-4 w-4" />
            </button>
          </>
        )}
      </div>
      {!titleOnly && (
        <p className="mt-1 line-clamp-4 whitespace-pre-wrap text-[13px] leading-6 text-ink-600">
          {snippet ? (
            t === "checklist" ? (
              note.content
                .split("\n")
                .filter((l) => l.trim())
                .slice(0, 4)
                .map((l) => l.replace(/^\[x\]/i, "✅").replace(/^\[ ?\]/i, "⬜"))
                .join("\n")
            ) : (
              snippet
            )
          ) : (
            <span className="font-bold text-ink-400">
              {t === "voice" ? "اضغط لإضافة رابط أو نص التسجيل" : t === "drawing" ? "اضغط للكتابة" : "ملاحظة فارغة"}
            </span>
          )}
        </p>
      )}
      <p className="mt-auto pt-2 text-left text-[11px] font-bold text-ink-400">
        <span className="text-grass-500">{noteTypeLabel[t]}</span> • {fmtDate(note.updatedAt)}
      </p>
    </div>
  );
}

function ResultRow({
  icon,
  name,
  sub,
  onClick,
}: {
  icon: ReactNode;
  name: string;
  sub?: ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex w-full items-center gap-3 rounded-xl border border-line bg-white p-3 text-right transition hover:border-grass-300 hover:bg-grass-50"
    >
      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-grass-50 text-grass-700">
        {icon}
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate text-sm font-extrabold text-ink-900">{name}</span>
        {sub && <span className="mt-0.5 block truncate text-[11px] font-bold text-ink-400">{sub}</span>}
      </span>
      <IChevronL className="h-4 w-4 shrink-0 text-ink-400" />
    </button>
  );
}

function PrintArea({ note, file, section }: { note: NoteRow; file: FileRow | null; section: SectionRow | null }) {
  return (
    <div id="print-area">
      <h1 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>{note.title || "ملاحظة"}</h1>
      <p style={{ fontSize: 12, color: "#555", marginBottom: 14 }}>
        {fmtDate(note.updatedAt)}
        {file ? ` — ${section?.name ?? ""} / ${file.name}` : ""}
      </p>
      <div style={{ whiteSpace: "pre-wrap", lineHeight: 1.9, fontSize: 14 }}>{note.content}</div>
    </div>
  );
}

function SheetItem({ icon, label, onClick }: { icon: ReactNode; label: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="flex flex-col items-center gap-1.5">
      <span className="text-grass-800">{icon}</span>
      <span className="text-[12px] font-extrabold text-ink-900">{label}</span>
    </button>
  );
}

/** A settings list row like the reference app: icon on the right, label + optional subtitle, tappable. */
function SettingRow({
  icon,
  label,
  value,
  right,
  onClick,
}: {
  icon: ReactNode;
  label: string;
  value?: string;
  right?: ReactNode;
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      disabled={!onClick}
      className="flex w-full items-center gap-4 border-b border-line bg-white px-4 py-4 text-right transition enabled:hover:bg-grass-50 disabled:cursor-default"
    >
      <span className="flex w-8 shrink-0 justify-center text-grass-600">{icon}</span>
      <span className="min-w-0 flex-1">
        <span className="block text-[15px] font-bold text-ink-900">{label}</span>
        {value && <span className="mt-0.5 block text-[12px] font-bold text-ink-400">{value}</span>}
      </span>
      {right && <span className="shrink-0">{right}</span>}
    </button>
  );
}

/** Toggle switch styled for the settings list rows. */
function RowSwitch({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={(e) => {
        e.stopPropagation();
        onChange(!value);
      }}
      role="switch"
      aria-checked={value}
      className={`relative h-6 w-11 rounded-full transition ${value ? "bg-grass-500" : "bg-ink-400/30"}`}
    >
      <span
        className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${
          value ? "right-0.5" : "right-[22px]"
        }`}
      />
    </button>
  );
}

/* ----------------------------------- App ----------------------------------- */

export default function App() {
  const [data, setData] = useState<Data | null>(null);
  const [loadErr, setLoadErr] = useState(false);
  const [view, setView] = useState<View>({ t: "home" });
  const [openNoteId, setOpenNoteId] = useState<string | null>(null);
  const [justCreated, setJustCreated] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [q, setQ] = useState("");
  const [results, setResults] = useState<SearchResult | null>(null);
  const [sheet, setSheet] = useState(false);
  const [sheetAll, setSheetAll] = useState(false);
  const [page, setPage] = useState<"settings" | "trash" | "vault" | "pwmgr" | "sites" | "archived" | null>(null);
  const [modal, setModal] = useState<ModalState | null>(null);
  const [promptValue, setPromptValue] = useState("");
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [locked, setLocked] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [siteUrl, setSiteUrl] = useState("");
  const [patternSetup, setPatternSetup] = useState(false);
  // Multi-select: { type, ids } — active only when set
  const [selection, setSelection] = useState<{ type: "section" | "file" | "note"; ids: Set<string> } | null>(null);

  const { prefs, update: updatePref, ready: prefsReady } = usePrefs();
  const listMode = prefs.listMode;
  const setListMode = (v: boolean | ((m: boolean) => boolean)) =>
    updatePref({ listMode: typeof v === "function" ? v(prefs.listMode) : v });

  const toastTimer = useRef<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const loadedOnce = useRef(false);

  const toastFn = useCallback((m: string) => {
    if (!m) return;
    setToast(m);
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 2200);
  }, []);

  const refresh = useCallback(async () => {
    try {
      const d = await api<Data>("/api/data");
      setData(d);
      setLoadErr(false);
      return d;
    } catch {
      setLoadErr(true);
      return null;
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  useEffect(() => {
    setSiteUrl(window.location.origin + window.location.pathname);
  }, []);

  // Apply disguise: dynamic manifest + document title + theme color + favicon.
  useEffect(() => {
    if (!prefsReady) return;
    const d = DISGUISES.find((x) => x.key === prefs.disguise) ?? DISGUISES[0];

    document.title = d.appName;

    const setLink = (rel: string, href: string, extra?: Record<string, string>) => {
      let el = document.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
      if (!el) {
        el = document.createElement("link");
        el.rel = rel;
        document.head.appendChild(el);
      }
      el.href = href;
      if (extra) for (const [k, v] of Object.entries(extra)) el.setAttribute(k, v);
    };

    setLink("manifest", `/api/manifest?d=${prefs.disguise}`);

    const iconHref =
      "data:image/svg+xml," +
      encodeURIComponent(
        `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><rect width='512' height='512' rx='96' fill='${d.bg}'/><text x='50%' y='50%' font-size='300' text-anchor='middle' dominant-baseline='central'>${d.icon}</text></svg>`,
      );
    setLink("icon", iconHref);
    setLink("apple-touch-icon", iconHref);

    let meta = document.querySelector<HTMLMetaElement>('meta[name="apple-mobile-web-app-title"]');
    if (!meta) {
      meta = document.createElement("meta");
      meta.name = "apple-mobile-web-app-title";
      document.head.appendChild(meta);
    }
    meta.content = d.appName;

    let tc = document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');
    if (!tc) {
      tc = document.createElement("meta");
      tc.name = "theme-color";
      document.head.appendChild(tc);
    }
    tc.content = d.theme;
  }, [prefsReady, prefs.disguise]);

  // Lock the app on load if any lock is set
  useEffect(() => {
    if (prefsReady && (prefs.lockKind !== "none" || prefs.biometricLock)) setLocked(true);
  }, [prefsReady, prefs.lockKind, prefs.biometricLock]);

  // Deep links: ?n= / ?f= / ?s=
  useEffect(() => {
    if (!data || loadedOnce.current) return;
    loadedOnce.current = true;
    const p = new URLSearchParams(window.location.search);
    const n = p.get("n");
    const f = p.get("f");
    const s = p.get("s");
    if (n) {
      const note = data.notes.find((x) => x.id === n);
      if (note) {
        if (note.fileId) setView({ t: "file", id: note.fileId });
        else setView({ t: "home" });
        setOpenNoteId(n);
      }
    } else if (f && data.files.some((x) => x.id === f)) {
      setView({ t: "file", id: f });
    } else if (s && data.sections.some((x) => x.id === s)) {
      setView({ t: "section", id: s });
    }
  }, [data]);

  // Search
  useEffect(() => {
    if (!searchOpen) {
      setResults(null);
      return;
    }
    if (q.trim().length < 1) {
      setResults({ sections: [], files: [], notes: [] });
      return;
    }
    const t = window.setTimeout(async () => {
      try {
        setResults(await api<SearchResult>(`/api/search?q=${encodeURIComponent(q.trim())}`));
      } catch {
        /* ignore */
      }
    }, 180);
    return () => window.clearTimeout(t);
  }, [q, searchOpen]);

  /* ------------------------------- derived ------------------------------- */

  const sectionsLive = useMemo(
    () => (data ? data.sections.filter((s) => !s.deletedAt).sort((a, b) => a.createdAt.localeCompare(b.createdAt)) : []),
    [data],
  );

  // Files and notes that live on the home root (no parent)
  const rootFiles = useMemo(
    () => (data ? data.files.filter((f) => !f.deletedAt && !f.sectionId).sort((a, b) => a.createdAt.localeCompare(b.createdAt)) : []),
    [data],
  );
  const rootNotes = useMemo(
    () =>
      data
        ? data.notes
            .filter((n) => !n.deletedAt && !n.fileId && !n.archived)
            .sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt.localeCompare(a.updatedAt))
        : [],
    [data],
  );

  const fileCount = useCallback(
    (secId: string) => (data ? data.files.filter((f) => f.sectionId === secId && !f.deletedAt).length : 0),
    [data],
  );
  const noteCountInFile = useCallback(
    (fid: string) => (data ? data.notes.filter((n) => n.fileId === fid && !n.deletedAt).length : 0),
    [data],
  );
  const noteCountInSection = useCallback(
    (secId: string) =>
      data
        ? data.files
            .filter((f) => f.sectionId === secId && !f.deletedAt)
            .reduce((a, f) => a + noteCountInFile(f.id), 0)
        : 0,
    [data, noteCountInFile],
  );

  const fileRow = view.t === "file" ? data?.files.find((f) => f.id === view.id) ?? null : null;
  const sectionId =
    view.t === "section" ? view.id : view.t === "file" ? (fileRow?.sectionId ?? null) : null;
  const sectionRow = sectionId ? data?.sections.find((s) => s.id === sectionId) ?? null : null;

  const openNote = openNoteId && data ? data.notes.find((n) => n.id === openNoteId) ?? null : null;
  const openNoteFile = openNote ? data?.files.find((f) => f.id === openNote.fileId) ?? null : null;
  const openNoteSection = openNoteFile ? data?.sections.find((s) => s.id === openNoteFile.sectionId) ?? null : null;

  const trashItems: TrashItem[] = useMemo(() => {
    if (!data) return [];
    const out: TrashItem[] = [];
    for (const s of data.sections)
      if (s.deletedAt) out.push({ type: "section", id: s.id, name: s.name, sub: "قسم", deletedAt: s.deletedAt });
    for (const f of data.files)
      if (f.deletedAt) {
        const sec = data.sections.find((x) => x.id === f.sectionId);
        out.push({ type: "file", id: f.id, name: f.name, sub: sec ? `قسم: ${sec.name}` : "ملف", deletedAt: f.deletedAt });
      }
    for (const n of data.notes)
      if (n.deletedAt) {
        const f = data.files.find((x) => x.id === n.fileId);
        out.push({
          type: "note",
          id: n.id,
          name: n.title || "بدون عنوان",
          sub: f ? `ملف: ${f.name}` : "ملاحظة",
          deletedAt: n.deletedAt,
        });
      }
    return out.sort((a, b) => b.deletedAt.localeCompare(a.deletedAt));
  }, [data]);

  /* -------------------------------- actions -------------------------------- */

  const run = async (fn: () => Promise<void>) => {
    setBusy(true);
    try {
      await fn();
    } catch (e: any) {
      toastFn(e?.message || "حدث خطأ");
    } finally {
      setBusy(false);
    }
  };

  const showPrompt = (
    title: string,
    placeholder: string,
    onSubmit: (v: string) => void,
    submitLabel?: string,
    defaultValue = "",
  ) => {
    setPromptValue(defaultValue);
    setModal({ kind: "prompt", title, placeholder, onSubmit, submitLabel });
  };

  const confirmAction = (
    title: string,
    message: string,
    onConfirm: () => void,
    danger = true,
    confirmLabel = "تأكيد",
  ) => setModal({ kind: "confirm", title, message, danger, confirmLabel, onConfirm });

  async function submitPrompt() {
    const m = modal;
    if (m?.kind !== "prompt" || busy) return;
    const v = promptValue.trim();
    if (!v) {
      toastFn("أدخل اسماً أولاً");
      return;
    }
    setModal(null);
    await m.onSubmit(v);
  }

  async function createSection(name: string) {
    await run(async () => {
      const row = await api<SectionRow>("/api/section", { method: "POST", body: JSON.stringify({ name }) });
      await refresh();
      setView({ t: "section", id: row.id });
      toastFn("تم إنشاء القسم");
    });
  }

  async function createFile(name: string) {
    const secId = sectionId;
    if (!secId) return;
    await run(async () => {
      const row = await api<FileRow>("/api/file", { method: "POST", body: JSON.stringify({ sectionId: secId, name }) });
      await refresh();
      setView({ t: "file", id: row.id });
      toastFn("تم إنشاء الملف");
    });
  }

  const noteDefaults: Record<NoteType, { title: string; content: string }> = {
    note: { title: "ملاحظة جديدة", content: "" },
    checklist: { title: "قائمة مرجعية", content: "[ ] عنصر أول\n[ ] عنصر ثاني" },
    drawing: { title: "كتابة يدوية", content: "" },
    voice: { title: "تسجيل صوتي", content: "" },
  };

  // Create a note. Its parent file is: explicit target, or current file, or null (home root).
  async function createNote(type: NoteType = "note") {
    const fid = view.t === "file" ? view.id : null;
    const def = noteDefaults[type];
    await run(async () => {
      const row = await api<NoteRow>("/api/note", {
        method: "POST",
        body: JSON.stringify({ fileId: fid, title: def.title, content: def.content, type }),
      });
      await refresh();
      setJustCreated(true);
      setOpenNoteId(row.id);
    });
  }

  // Create a file. Parent section = current section, or null (home root).
  function newFileFlow() {
    const secId = view.t === "section" ? view.id : view.t === "file" ? sectionId : null;
    showPrompt("اسم الملف الجديد", "مثال: ردود العملاء", (fn) => createFileIn(secId, fn), "إنشاء");
  }

  async function createFileIn(secId: string | null, name: string) {
    await run(async () => {
      const row = await api<FileRow>("/api/file", { method: "POST", body: JSON.stringify({ sectionId: secId, name }) });
      await refresh();
      setView({ t: "file", id: row.id });
      toastFn("تم إنشاء الملف");
    });
  }

  function goBack() {
    setQ("");
    if (view.t === "file") {
      const sec = fileRow?.sectionId ?? null;
      setView(sec ? { t: "section", id: sec } : { t: "home" });
    } else if (view.t === "section") {
      setView({ t: "home" });
    }
  }

  function onPlus() {
    // Always offer the same 5 core options everywhere (home / section / file).
    const items: ActionItem[] = [
      { label: "ملاحظة", icon: <INote className="h-5 w-5 text-grass-700" />, onClick: () => createNote("note") },
      {
        label: "قسم",
        icon: <ISection className="h-5 w-5 text-grass-700" />,
        onClick: () => showPrompt("اسم القسم الجديد", "مثال: خطط العمل", createSection, "إنشاء"),
      },
      { label: "ملف", icon: <IFolder className="h-5 w-5 text-grass-700" />, onClick: newFileFlow },
      { label: "قائمة مرجعية", icon: <IChecklist className="h-5 w-5 text-grass-700" />, onClick: () => createNote("checklist") },
      { label: "كتابة يدوية", icon: <IPen className="h-5 w-5 text-grass-700" />, onClick: () => createNote("drawing") },
    ];
    setModal({ kind: "actions", title: "إنشاء جديد", items });
  }

  // Show two choices: save to phone files, or direct download.
  function exportItem(kind: "all" | "section" | "file" | "note", id?: string) {
    const filename = `mialahadzat-${kind === "all" ? "backup" : kind}-${id ? id.slice(0, 8) : todayStamp()}.json`;
    const fetchObj = async () => {
      const url = id ? `/api/export?kind=${kind}&id=${id}` : "/api/export?kind=all";
      const res = await fetch(url);
      if (!res.ok) throw new Error("تعذر تحميل النسخة");
      return res.json();
    };

    setModal({
      kind: "actions",
      title: "نسخة احتياطية",
      items: [
        {
          label: "حفظ في ملفات الهاتف",
          icon: <IDownload className="h-5 w-5 text-grass-700" />,
          onClick: async () => {
            setBusy(true);
            try {
              const obj = await fetchObj();
              const r = await saveToFiles(obj, filename);
              if (r === "saved") toastFn("تم الحفظ في المكان الذي اخترته");
              else if (r === "shared") toastFn("اختر «حفظ في الملفات»");
              else if (r === "downloaded") toastFn("حُفظت في مجلد التنزيلات");
            } catch (e: any) {
              toastFn(e?.message || "تعذر الحفظ");
            } finally {
              setBusy(false);
            }
          },
        },
        {
          label: "تنزيل للهاتف",
          icon: <IDownload className="h-5 w-5 text-grass-700" />,
          onClick: async () => {
            setBusy(true);
            try {
              const obj = await fetchObj();
              downloadFileDirect(obj, filename);
              toastFn("تم التنزيل — تجده في ملفات جهازك (مجلد التنزيلات)");
            } catch (e: any) {
              toastFn(e?.message || "تعذر التنزيل");
            } finally {
              setBusy(false);
            }
          },
        },
      ],
    });
  }

  async function onRestoreFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setBusy(true);
    try {
      const text = await file.text();
      const obj = JSON.parse(text);
      const res = await api<{ ok: boolean; sections: number; files: number; notes: number; skipped: number }>(
        "/api/restore",
        { method: "POST", body: JSON.stringify(obj) },
      );
      await refresh();
      toastFn(`تمت الاستعادة: ${res.sections} قسم، ${res.files} ملف، ${res.notes} ملاحظة${res.skipped ? ` (تخطي ${res.skipped})` : ""}`);
    } catch {
      toastFn("ملف النسخة الاحتياطية غير صالح");
    } finally {
      setBusy(false);
    }
  }

  const resUrl = (type: TrashItem["type"]) =>
    type === "section" ? "section" : type === "file" ? "file" : "note";

  async function restoreItem(it: TrashItem) {
    await run(async () => {
      await api(`/api/${resUrl(it.type)}/${it.id}`, { method: "PATCH", body: JSON.stringify({ action: "restore" }) });
      await refresh();
      toastFn("تمت الاستعادة");
    });
  }

  function purgeItem(it: TrashItem) {
    confirmAction(
      "حذف نهائي؟",
      `سيُحذف «${it.name}» وكل ما بداخله نهائياً ولا يمكن التراجع.`,
      async () => {
        await run(async () => {
          await api(`/api/${resUrl(it.type)}/${it.id}`, { method: "PATCH", body: JSON.stringify({ action: "purge" }) });
          await refresh();
          toastFn("تم الحذف النهائي");
        });
      },
      true,
      "حذف نهائي",
    );
  }

  function emptyTrash() {
    confirmAction(
      "إفراغ سلة المهملات؟",
      "سيتم حذف كل عناصر السلة نهائياً ولا يمكن التراجع.",
      async () => {
        await run(async () => {
          await api("/api/trash", { method: "POST", body: JSON.stringify({ action: "empty" }) });
          await refresh();
          toastFn("أُفرغت السلة");
        });
      },
      true,
      "إفراغ",
    );
  }

  function sectionMenu(s: SectionRow) {
    setModal({
      kind: "actions",
      title: s.name,
      items: [
        {
          label: "تحديد",
          icon: <ISelect className="h-5 w-5 text-grass-700" />,
          onClick: () => startSelect("section", s.id),
        },
        {
          label: "مشاركة (تلقرام / واتساب)",
          icon: <IShare className="h-5 w-5 text-grass-700" />,
          onClick: () => shareMenu(s.name, textOfSection(s)),
        },
        {
          label: "إعادة تسمية",
          icon: <IPencil className="h-5 w-5 text-grass-700" />,
          onClick: () =>
            showPrompt("إعادة تسمية القسم", s.name, async (v) => {
              await run(async () => {
                await api(`/api/section/${s.id}`, { method: "PATCH", body: JSON.stringify({ action: "rename", name: v }) });
                await refresh();
              });
            }, "حفظ"),
        },
        {
          label: "نسخة احتياطية (JSON)",
          icon: <IDownload className="h-5 w-5 text-grass-700" />,
          onClick: () => exportItem("section", s.id),
        },
        {
          label: "حذف إلى السلة",
          danger: true,
          icon: <ITrash className="h-5 w-5" />,
          onClick: () =>
            confirmAction(
              "حذف القسم؟",
              `سيُنقل قسم «${s.name}» وكل ما بداخله إلى سلة المهملات.`,
              async () => {
                await run(async () => {
                  await api(`/api/section/${s.id}`, { method: "PATCH", body: JSON.stringify({ action: "delete" }) });
                  await refresh();
                  if (view.t === "section" && view.id === s.id) setView({ t: "home" });
                });
              },
            ),
        },
      ],
    });
  }

  function fileMenu(f: FileRow) {
    setModal({
      kind: "actions",
      title: f.name,
      items: [
        {
          label: "تحديد",
          icon: <ISelect className="h-5 w-5 text-grass-700" />,
          onClick: () => startSelect("file", f.id),
        },
        {
          label: "مشاركة (تلقرام / واتساب)",
          icon: <IShare className="h-5 w-5 text-grass-700" />,
          onClick: () => shareMenu(f.name, textOfFile(f)),
        },
        {
          label: "إعادة تسمية",
          icon: <IPencil className="h-5 w-5 text-grass-700" />,
          onClick: () =>
            showPrompt("إعادة تسمية الملف", f.name, async (v) => {
              await run(async () => {
                await api(`/api/file/${f.id}`, { method: "PATCH", body: JSON.stringify({ action: "rename", name: v }) });
                await refresh();
              });
            }, "حفظ"),
        },
        {
          label: "نقل إلى قسم آخر",
          icon: <IMove className="h-5 w-5 text-grass-700" />,
          onClick: () =>
            setModal({
              kind: "move",
              title: "نقل الملف إلى قسم:",
              kindItem: "file",
              currentParentId: f.sectionId,
              onPick: async (secId) => {
                await run(async () => {
                  await api(`/api/file/${f.id}`, { method: "PATCH", body: JSON.stringify({ action: "move", sectionId: secId }) });
                  await refresh();
                  toastFn("تم نقل الملف");
                });
              },
            }),
        },
        {
          label: "نسخة احتياطية (JSON)",
          icon: <IDownload className="h-5 w-5 text-grass-700" />,
          onClick: () => exportItem("file", f.id),
        },
        {
          label: "حذف إلى السلة",
          danger: true,
          icon: <ITrash className="h-5 w-5" />,
          onClick: () =>
            confirmAction(
              "حذف الملف؟",
              `سيُنقل ملف «${f.name}» وكل ملاحظاته إلى سلة المهملات.`,
              async () => {
                await run(async () => {
                  await api(`/api/file/${f.id}`, { method: "PATCH", body: JSON.stringify({ action: "delete" }) });
                  await refresh();
                  if (view.t === "file" && view.id === f.id)
                    setView(f.sectionId ? { t: "section", id: f.sectionId } : { t: "home" });
                });
              },
            ),
        },
      ],
    });
  }

  async function setNoteMeta(id: string, patch: { tag?: string; pinned?: boolean; archived?: boolean }) {
    await run(async () => {
      await api(`/api/note/${id}`, { method: "PATCH", body: JSON.stringify({ action: "meta", ...patch }) });
      await refresh();
      toastFn("تم التحديث");
    });
  }

  const TAGS: { key: string; label: string; color: string }[] = [
    { key: "", label: "بدون وسم", color: "#9ca3af" },
    { key: "important", label: "مهم", color: "#f59e0b" },
    { key: "urgent", label: "عاجل", color: "#dc2626" },
    { key: "done", label: "منجز", color: "#16a34a" },
    { key: "idea", label: "فكرة", color: "#2563eb" },
  ];

  function tagMenu(n: NoteRow) {
    setModal({
      kind: "actions",
      title: "اختر وسماً",
      items: TAGS.map((t) => ({
        label: t.label + (n.tag === t.key ? " ✓" : ""),
        icon: <span className="h-4 w-4 rounded-full" style={{ background: t.color, display: "inline-block" }} />,
        onClick: () => setNoteMeta(n.id, { tag: t.key }),
      })),
    });
  }

  function noteMenu(n: NoteRow) {
    setModal({
      kind: "actions",
      title: n.title || "ملاحظة",
      items: [
        {
          label: "فتح",
          icon: <INote className="h-5 w-5 text-grass-700" />,
          onClick: () => setOpenNoteId(n.id),
        },
        {
          label: n.pinned ? "إلغاء التثبيت" : "تثبيت في الأعلى",
          icon: <IPin className="h-5 w-5 text-grass-700" />,
          onClick: () => setNoteMeta(n.id, { pinned: !n.pinned }),
        },
        {
          label: "وسم ملوّن",
          icon: <ITag className="h-5 w-5 text-grass-700" />,
          onClick: () => tagMenu(n),
        },
        {
          label: n.archived ? "إلغاء الأرشفة" : "أرشفة",
          icon: <IArchive className="h-5 w-5 text-grass-700" />,
          onClick: () => setNoteMeta(n.id, { archived: !n.archived }),
        },
        {
          label: "تحديد",
          icon: <ISelect className="h-5 w-5 text-grass-700" />,
          onClick: () => startSelect("note", n.id),
        },
        {
          label: "مشاركة (تلقرام / واتساب)",
          icon: <IShare className="h-5 w-5 text-grass-700" />,
          onClick: () => shareMenu(n.title || "ملاحظة", textOfNote(n)),
        },
        {
          label: "نسخ كاملة",
          icon: <ICopy className="h-5 w-5 text-grass-700" />,
          onClick: async () => {
            const ok = await copyText((n.title ? n.title + "\n\n" : "") + n.content);
            toastFn(ok ? "تم نسخ الملاحظة كاملة" : "تعذر النسخ");
          },
        },
        {
          label: "نقل إلى ملف آخر",
          icon: <IMove className="h-5 w-5 text-grass-700" />,
          onClick: () =>
            setModal({
              kind: "move",
              title: "نقل الملاحظة إلى:",
              kindItem: "note",
              currentParentId: n.fileId,
              onPick: async (fid) => {
                await run(async () => {
                  await api(`/api/note/${n.id}`, { method: "PATCH", body: JSON.stringify({ action: "move", fileId: fid }) });
                  await refresh();
                  toastFn("تم نقل الملاحظة");
                });
              },
            }),
        },
        {
          label: "نسخة احتياطية (JSON)",
          icon: <IDownload className="h-5 w-5 text-grass-700" />,
          onClick: () => exportItem("note", n.id),
        },
        {
          label: "حذف إلى السلة",
          danger: true,
          icon: <ITrash className="h-5 w-5" />,
          onClick: () =>
            confirmAction(
              "حذف الملاحظة؟",
              `ستنتقل «${n.title || "الملاحظة"}» إلى سلة المهملات ويمكنك استعادتها لاحقاً.`,
              async () => {
                await run(async () => {
                  await api(`/api/note/${n.id}`, { method: "PATCH", body: JSON.stringify({ action: "delete" }) });
                  await refresh();
                });
              },
            ),
        },
      ],
    });
  }

  async function shareApp() {
    const r = await shareText(window.location.href);
    if (r === "shared") toastFn("تمت مشاركة الموقع");
    else if (r === "copied") toastFn("تم نسخ رابط الموقع");
  }



  // Build a plain-text export of a section / file / note for sharing.
  function textOfNote(n: NoteRow) {
    return (n.title ? n.title + "\n\n" : "") + n.content;
  }
  function textOfFile(f: FileRow) {
    if (!data) return f.name;
    const ns = data.notes.filter((n) => n.fileId === f.id && !n.deletedAt);
    return `📁 ${f.name}\n\n` + ns.map((n) => `— ${n.title || "بدون عنوان"}\n${n.content}`).join("\n\n———\n\n");
  }
  function textOfSection(s: SectionRow) {
    if (!data) return s.name;
    const fs = data.files.filter((f) => f.sectionId === s.id && !f.deletedAt);
    const parts = fs.map((f) => textOfFile(f));
    return `📂 ${s.name}\n\n` + parts.join("\n\n========\n\n");
  }

  /* ------------------------------ multi-select ------------------------------ */
  function startSelect(type: "section" | "file" | "note", firstId: string) {
    setSelection({ type, ids: new Set([firstId]) });
  }
  function toggleSelect(id: string) {
    setSelection((prev) => {
      if (!prev) return prev;
      const ids = new Set(prev.ids);
      if (ids.has(id)) ids.delete(id);
      else ids.add(id);
      return { ...prev, ids };
    });
  }
  const isSelecting = selection !== null;
  const selCount = selection?.ids.size ?? 0;

  async function bulkDelete() {
    if (!selection || selCount === 0) return;
    const type = selection.type;
    const ids = [...selection.ids];
    confirmAction(
      "حذف المحدد؟",
      `سيُنقل ${selCount} عنصراً إلى سلة المهملات.`,
      async () => {
        await run(async () => {
          for (const id of ids) {
            await api(`/api/${type}/${id}`, { method: "PATCH", body: JSON.stringify({ action: "delete" }) });
          }
          await refresh();
          setSelection(null);
          toastFn("تم النقل إلى السلة");
        });
      },
    );
  }

  async function bulkBackup() {
    if (!selection || selCount === 0) return;
    const type = selection.type;
    const ids = [...selection.ids];
    setBusy(true);
    try {
      const bundles = await Promise.all(
        ids.map((id) => fetch(`/api/export?kind=${type}&id=${id}`).then((r) => r.json())),
      );
      const r = await downloadJson(
        { app: "mialahadzat", version: 1, exportedAt: new Date().toISOString(), bundle: bundles },
        `mialahadzat-${type}-selection-${todayStamp()}.json`,
      );
      if (r === "saved") toastFn("تم حفظ نسخة المحدد في المكان الذي اخترته");
      else if (r === "shared") toastFn("اختر «حفظ في الملفات» أو أرسلها");
      else if (r === "downloaded") toastFn("حُفظت نسخة المحدد في مجلد التنزيلات");
    } catch {
      toastFn("تعذر التنزيل");
    } finally {
      setBusy(false);
    }
  }

  function bulkMove() {
    if (!selection || selCount === 0) return;
    const type = selection.type;
    const ids = [...selection.ids];
    if (type === "section") {
      toastFn("الأقسام لا تُنقل — هي المستوى الأعلى");
      return;
    }
    setModal({
      kind: "move",
      title: type === "note" ? "نقل الملاحظات المحددة إلى:" : "نقل الملفات المحددة إلى قسم:",
      kindItem: type === "note" ? "note" : "file",
      currentParentId: null,
      onPick: async (parentId) => {
        await run(async () => {
          for (const id of ids) {
            const body = type === "note" ? { action: "move", fileId: parentId } : { action: "move", sectionId: parentId };
            await api(`/api/${type}/${id}`, { method: "PATCH", body: JSON.stringify(body) });
          }
          await refresh();
          setSelection(null);
          toastFn("تم النقل");
        });
      },
    });
  }

  function bulkShare() {
    if (!selection || !data || selCount === 0) return;
    const type = selection.type;
    const ids = [...selection.ids];
    let text = "";
    if (type === "section") text = ids.map((id) => textOfSection(data.sections.find((s) => s.id === id)!)).filter(Boolean).join("\n\n\n");
    else if (type === "file") text = ids.map((id) => textOfFile(data.files.find((f) => f.id === id)!)).filter(Boolean).join("\n\n\n");
    else text = ids.map((id) => textOfNote(data.notes.find((n) => n.id === id)!)).filter(Boolean).join("\n\n———\n\n");
    shareMenu(`${selCount} عنصر`, text);
  }

  // Opens a share-target picker (Telegram / WhatsApp / system / copy).
  // Ask for a telegram username and open a direct chat with the text ready to send.
  function sendTelegramDirect(text: string) {
    showPrompt(
      "أدخل يوزر تلقرام المستلم",
      "مثال: @username",
      async (v) => {
        const ok = await sendToTelegramUser(v, text);
        if (!ok) {
          toastFn("يوزر غير صالح");
          return;
        }
        updatePref({ lastTelegramUser: v.trim() });
        toastFn("فُتحت محادثة تلقرام — النص جاهز للإرسال");
      },
      "فتح المحادثة",
      prefs.lastTelegramUser,
    );
  }

  function sendWhatsAppDirect(text: string) {
    showPrompt(
      "أدخل رقم واتساب المستلم (مع رمز الدولة)",
      "مثال: 9665xxxxxxxx",
      (v) => {
        sendToWhatsAppNumber(v, text);
        updatePref({ lastWhatsAppNumber: v.trim() });
        toastFn("فُتحت محادثة واتساب — النص جاهز للإرسال");
      },
      "فتح المحادثة",
      prefs.lastWhatsAppNumber,
    );
  }

  // Create a new file inside a section then hand its id to the note-move callback.
  async function moveNoteIntoNewFile(sectionId: string, onPick: (fileId: string | null) => void) {
    await run(async () => {
      const f = await api<FileRow>("/api/file", {
        method: "POST",
        body: JSON.stringify({ sectionId, name: "ملف جديد" }),
      });
      await refresh();
      onPick(f.id);
    });
  }

  function shareMenu(title: string, text: string) {
    setModal({
      kind: "actions",
      title: "مشاركة: " + title,
      items: [
        {
          label: "إرسال مباشر ليوزر تلقرام",
          icon: <ITelegram className="h-5 w-5 text-[#229ED9]" />,
          onClick: () => sendTelegramDirect(text),
        },
        {
          label: "إرسال مباشر لرقم واتساب",
          icon: <IWhatsApp className="h-5 w-5 text-[#25D366]" />,
          onClick: () => sendWhatsAppDirect(text),
        },
        {
          label: "تلقرام (اختيار المحادثة)",
          icon: <ITelegram className="h-5 w-5 text-[#229ED9]" />,
          onClick: () => shareToTelegram(text),
        },
        {
          label: "واتساب (اختيار المحادثة)",
          icon: <IWhatsApp className="h-5 w-5 text-[#25D366]" />,
          onClick: () => shareToWhatsApp(text),
        },
        {
          label: "مشاركة عبر التطبيقات…",
          icon: <IShare className="h-5 w-5 text-grass-700" />,
          onClick: async () => {
            const r = await shareText(text);
            if (r === "shared") toastFn("تمت المشاركة");
            else if (r === "copied") toastFn("تم نسخ النص — جاهز للصق");
          },
        },
        {
          label: "نسخ النص",
          icon: <ICopy className="h-5 w-5 text-grass-700" />,
          onClick: async () => {
            const ok = await copyText(text);
            toastFn(ok ? "تم النسخ" : "تعذر النسخ");
          },
        },
      ],
    });
  }

  // Lock type chooser: PIN / pattern / password
  function chooseLock() {
    setModal({
      kind: "actions",
      title: "نوع القفل",
      items: [
        {
          label: "رمز رقمي (PIN)",
          icon: <ILock className="h-5 w-5 text-grass-700" />,
          onClick: () =>
            showPrompt("اختر رمزاً رقمياً (4 أرقام أو أكثر)", "مثال: 1234", (v) => {
              const pin = v.replace(/\D/g, "");
              if (pin.length < 4) {
                toastFn("الرمز يجب أن يكون 4 أرقام على الأقل");
                return;
              }
              updatePref({ lockKind: "pin", lockSecret: pin });
              toastFn("تم تفعيل القفل الرقمي");
            }, "تفعيل"),
        },
        {
          label: "كلمة سر (حروف وأرقام)",
          icon: <ILock className="h-5 w-5 text-grass-700" />,
          onClick: () =>
            showPrompt("اختر كلمة السر (4 خانات أو أكثر)", "كلمة السر", (v) => {
              if (v.trim().length < 4) {
                toastFn("كلمة السر قصيرة جداً");
                return;
              }
              updatePref({ lockKind: "password", lockSecret: v });
              toastFn("تم تفعيل قفل كلمة السر");
            }, "تفعيل"),
        },
        {
          label: "نمط (رسم)",
          icon: <ILock className="h-5 w-5 text-grass-700" />,
          onClick: () => setPatternSetup(true),
        },
      ],
    });
  }

  function removeLock() {
    confirmAction(
      "إلغاء القفل؟",
      "سيتم فتح الموقع مباشرة بدون رمز.",
      () => {
        updatePref({ lockKind: "none", lockSecret: null });
        toastFn("تم إلغاء القفل");
      },
      false,
      "إلغاء القفل",
    );
  }

  async function toggleBiometric(next: boolean) {
    if (!next) {
      updatePref({ biometricLock: false });
      toastFn("تم إيقاف قفل البصمة");
      return;
    }
    const available = await biometricAvailable();
    if (!available) {
      toastFn("جهازك لا يدعم البصمة، أو افتح الموقع مباشرة (ليس داخل معاينة)");
      return;
    }
    const ok = await biometricVerify();
    if (ok) {
      updatePref({ biometricLock: true });
      toastFn("تم تفعيل قفل البصمة");
    } else {
      toastFn("لم تكتمل عملية التحقق بالبصمة");
    }
  }

  function resetSettings() {
    confirmAction(
      "العودة إلى الإعدادات الأولية؟",
      "سيُعاد ضبط المظهر والألوان وحجم الخط ونمط العرض. لن تتأثر ملاحظاتك أو أقسامك.",
      () => {
        updatePref({
          dark: DEFAULT_PREFS.dark,
          accent: DEFAULT_PREFS.accent,
          fontSize: DEFAULT_PREFS.fontSize,
          titleOnly: DEFAULT_PREFS.titleOnly,
          listMode: DEFAULT_PREFS.listMode,
        });
        toastFn("تمت إعادة الضبط");
      },
      false,
      "إعادة الضبط",
    );
  }

  function chooseDisguise() {
    setModal({
      kind: "actions",
      title: "تمويه التطبيق (عند الإضافة للشاشة)",
      items: DISGUISES.map((d) => ({
        label: d.label + (prefs.disguise === d.key ? " ✓" : ""),
        icon: <span className="text-lg">{d.icon}</span>,
        onClick: () => {
          updatePref({ disguise: d.key });
          toastFn(
            d.key === "notes"
              ? "تم إلغاء التمويه"
              : `تم اختيار تمويه: ${d.appName} — أعد إضافة الموقع للشاشة ليظهر بالاسم الجديد`,
          );
        },
      })),
    });
  }

  function aboutApp() {
    setModal({
      kind: "confirm",
      title: "عن التطبيق",
      message:
        "الملاحظات — دفتر عملك الخاص. موقع لحفظ خططك وردودك وبياناتك وروابطك بشكل منظّم وآمن: أقسام ← ملفات ← ملاحظات، مع بحث ونسخ ومشاركة ونسخ احتياطي وقفل. كل بياناتك محفوظة على السيرفر وتظهر على أي جهاز يفتح الرابط.",
      confirmLabel: "حسناً",
      danger: false,
      onConfirm: () => {},
    });
  }

  async function doSync() {
    setSyncing(true);
    try {
      await refresh();
      toastFn("تمت المزامنة — أحدث نسخة معروضة الآن");
    } finally {
      window.setTimeout(() => setSyncing(false), 400);
    }
  }

  // Email a backup: opens the mail app with the JSON attached-as-text so the user
  // can keep a copy in their inbox. Also lets them register/change the email.
  async function emailBackup() {
    const send = async (email: string) => {
      updatePref({ syncEmail: email });
      try {
        const res = await fetch("/api/export?kind=all");
        const obj = await res.json();
        const body = encodeURIComponent(
          "نسخة احتياطية من موقع الملاحظات (JSON):\n\n" + JSON.stringify(obj, null, 2).slice(0, 1800) + "\n\n... (النسخة الكاملة يُفضّل حفظها كملف من زر نسخ احتياطي)",
        );
        const subj = encodeURIComponent("نسخة احتياطية — الملاحظات " + todayStamp());
        window.location.href = `mailto:${email}?subject=${subj}&body=${body}`;
        toastFn("فُتح تطبيق البريد — أرسل الرسالة لحفظ النسخة");
      } catch {
        toastFn("تعذر تجهيز النسخة");
      }
    };
    showPrompt(
      "بريدك للمزامنة/النسخ الاحتياطي",
      "example@gmail.com",
      (v) => {
        if (!/.+@.+\..+/.test(v)) {
          toastFn("بريد غير صالح");
          return;
        }
        send(v);
      },
      "إرسال نسخة للبريد",
      prefs.syncEmail,
    );
  }

  function syncNow() {
    setModal({
      kind: "actions",
      title: "مزامنة",
      items: [
        {
          label: "تحديث الآن (جلب آخر التعديلات)",
          icon: <ISync className="h-5 w-5 text-grass-700" />,
          onClick: () => doSync(),
        },
        {
          label: prefs.syncEmail ? `إرسال نسخة للبريد (${prefs.syncEmail})` : "تسجيل بريد وإرسال نسخة",
          icon: <IInfo className="h-5 w-5 text-grass-700" />,
          onClick: () => emailBackup(),
        },
      ],
    });
  }

  /* --------------------------------- render --------------------------------- */

  if (locked) {
    return (
      <>
        <LockScreen prefs={prefs} onUnlock={() => setLocked(false)} onWrong={(m) => toastFn(m)} />
        <Toast msg={toast} />
      </>
    );
  }

  if (loadErr && !data) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 px-4">
        <p className="text-base font-extrabold text-ink-900">تعذر الاتصال بالخادم</p>
        <Btn onClick={() => refresh()}>إعادة المحاولة</Btn>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="h-10 w-10 animate-spin rounded-full border-4 border-grass-200 border-t-grass-600" />
      </div>
    );
  }

  const gridCls = listMode ? "grid grid-cols-1 gap-2" : "grid grid-cols-2 gap-2 md:grid-cols-3 lg:grid-cols-4";

  const selProps = (type: "section" | "file" | "note", id: string) => ({
    selecting: isSelecting && selection?.type === type,
    selected: selection?.type === type && selection.ids.has(id),
    onToggle: () => toggleSelect(id),
    onLongPress: () => startSelect(type, id),
  });

  const mainContent = (
    <>
      <nav className="mx-auto flex w-full max-w-5xl items-center gap-1 px-3 pt-3 text-[13px] font-extrabold text-ink-400">
        <button
          onClick={() => {
            setView({ t: "home" });
            setQ("");
          }}
          className={view.t === "home" ? "text-grass-700" : "transition hover:text-grass-700"}
        >
          الملاحظات
        </button>
        {view.t !== "home" && sectionRow && (
          <>
            <IChevronL className="h-3.5 w-3.5" />
            <button
              onClick={() => setView({ t: "section", id: sectionRow.id })}
              className={`truncate ${view.t === "section" ? "text-grass-700" : "transition hover:text-grass-700"}`}
            >
              {sectionRow.name}
            </button>
          </>
        )}
        {view.t === "file" && fileRow && (
          <>
            <IChevronL className="h-3.5 w-3.5" />
            <span className="truncate text-grass-700">{fileRow.name}</span>
          </>
        )}
      </nav>

      {searchOpen && q.trim().length > 0 ? (
        <ResultsView
          q={q}
          res={results}
          data={data}
          onOpenNote={(id) => {
            setSearchOpen(false);
            setQ("");
            setOpenNoteId(id);
          }}
          onOpenFile={(id) => {
            setSearchOpen(false);
            setQ("");
            setView({ t: "file", id });
          }}
          onOpenSection={(id) => {
            setSearchOpen(false);
            setQ("");
            setView({ t: "section", id });
          }}
        />
      ) : (
        <main className="mx-auto w-full max-w-5xl px-3 py-3">
          {view.t === "home" &&
            (sectionsLive.length === 0 && rootFiles.length === 0 && rootNotes.length === 0 ? (
              <Empty
                icon={<IFolder className="h-14 w-14" />}
                title="لا توجد عناصر بعد"
                desc="اضغط + لإنشاء قسم أو ملف أو ملاحظة. يمكنك نقل أي ملف أو ملاحظة لقسم لاحقاً."
                action="إنشاء جديد"
                onAction={onPlus}
              />
            ) : (
              <div className={gridCls}>
                {sectionsLive.map((s) => (
                  <FolderCard
                    key={s.id}
                    big
                    name={s.name}
                    sub={`${fileCount(s.id)} ملف • ${noteCountInSection(s.id)} ملاحظة`}
                    date={fmtDate(s.createdAt)}
                    onOpen={() => {
                      setView({ t: "section", id: s.id });
                      setQ("");
                    }}
                    onMenu={() => sectionMenu(s)}
                    {...selProps("section", s.id)}
                  />
                ))}
                {rootFiles.map((f) => (
                  <FolderCard
                    key={f.id}
                    name={f.name}
                    sub={`${noteCountInFile(f.id)} ملاحظة`}
                    date={fmtDate(f.createdAt)}
                    onOpen={() => {
                      setView({ t: "file", id: f.id });
                      setQ("");
                    }}
                    onMenu={() => fileMenu(f)}
                    {...selProps("file", f.id)}
                  />
                ))}
                {rootNotes.map((n) => (
                  <NoteCard
                    key={n.id}
                    note={n}
                    titleOnly={prefs.titleOnly}
                    onOpen={() => setOpenNoteId(n.id)}
                    onMenu={() => noteMenu(n)}
                    {...selProps("note", n.id)}
                    onCopy={async () => {
                      const ok = await copyText((n.title ? n.title + "\n\n" : "") + n.content);
                      toastFn(ok ? "تم نسخ الملاحظة كاملة" : "تعذر النسخ");
                    }}
                  />
                ))}
              </div>
            ))}

          {view.t === "section" &&
            (sectionRow === null ? (
              <Empty
                icon={<IFolder className="h-14 w-14" />}
                title="هذا القسم غير موجود"
                desc="ربما تم حذفه أو أنه غير متوفر."
                action="العودة للبداية"
                onAction={() => setView({ t: "home" })}
              />
            ) : (
              (() => {
                const fs = data.files.filter((f) => f.sectionId === view.id && !f.deletedAt);
                return fs.length === 0 ? (
                  <Empty
                    icon={<IFolder className="h-14 w-14" />}
                    title="لا توجد ملفات بعد"
                    desc={`أنشئ أول ملف داخل قسم «${sectionRow.name}».`}
                    action="ملف جديد"
                    onAction={onPlus}
                  />
                ) : (
                  <div className={gridCls}>
                    {fs.map((f) => (
                      <FolderCard
                        key={f.id}
                        name={f.name}
                        sub={`${noteCountInFile(f.id)} ملاحظة`}
                        date={fmtDate(f.createdAt)}
                        onOpen={() => {
                          setView({ t: "file", id: f.id });
                          setQ("");
                        }}
                        onMenu={() => fileMenu(f)}
                        {...selProps("file", f.id)}
                      />
                    ))}
                  </div>
                );
              })()
            ))}

          {view.t === "file" &&
            (fileRow === null ? (
              <Empty
                icon={<INote className="h-14 w-14" />}
                title="هذا الملف غير موجود"
                desc="ربما تم حذفه أو أنه غير متوفر."
                action="العودة للبداية"
                onAction={() => setView({ t: "home" })}
              />
            ) : (
              (() => {
                const ns = data.notes
                  .filter((n) => n.fileId === view.id && !n.deletedAt && !n.archived)
                  .sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt.localeCompare(a.updatedAt));
                return ns.length === 0 ? (
                  <Empty
                    icon={<INote className="h-14 w-14" />}
                    title="لا توجد ملاحظات بعد"
                    desc="اضغط + لإنشاء أول ملاحظة داخل هذا الملف."
                    action="ملاحظة جديدة"
                    onAction={onPlus}
                  />
                ) : (
                  <div className={gridCls}>
                    {ns.map((n) => (
                      <NoteCard
                        key={n.id}
                        note={n}
                        titleOnly={prefs.titleOnly}
                        onOpen={() => setOpenNoteId(n.id)}
                        onMenu={() => noteMenu(n)}
                        {...selProps("note", n.id)}
                        onCopy={async () => {
                          const ok = await copyText((n.title ? n.title + "\n\n" : "") + n.content);
                          toastFn(ok ? "تم نسخ الملاحظة كاملة" : "تعذر النسخ");
                        }}
                      />
                    ))}
                  </div>
                );
              })()
            ))}
        </main>
      )}
    </>
  );

  const stats = [
    ["الأقسام", sectionsLive.length],
    ["الملفات", data.files.filter((f) => !f.deletedAt).length],
    ["الملاحظات", data.notes.filter((n) => !n.deletedAt).length],
    ["في سلة المهملات", trashItems.length],
  ] as const;

  return (
    <div className="min-h-screen pb-16">
      {/* ---------------------------- selection bar ---------------------------- */}
      {isSelecting && (
        <header className="sticky top-0 z-40 bg-grass-700 text-white shadow">
          <div className="mx-auto flex h-14 w-full max-w-5xl items-center gap-1 px-2">
            <button onClick={() => setSelection(null)} title="إلغاء التحديد" className="rounded-full p-2 transition hover:bg-white/15">
              <IX className="h-6 w-6" />
            </button>
            <span className="text-lg font-extrabold">{selCount} محدد</span>
            <div className="flex flex-1 items-center justify-end gap-0.5">
              {selection?.type !== "section" && (
                <button onClick={bulkMove} title="نقل" className="rounded-full p-2 transition hover:bg-white/15">
                  <IMove className="h-5 w-5" />
                </button>
              )}
              <button onClick={bulkShare} title="مشاركة" className="rounded-full p-2 transition hover:bg-white/15">
                <IShare className="h-5 w-5" />
              </button>
              <button onClick={bulkBackup} title="نسخة احتياطية" className="rounded-full p-2 transition hover:bg-white/15">
                <IDownload className="h-5 w-5" />
              </button>
              <button onClick={bulkDelete} title="حذف" className="rounded-full p-2 transition hover:bg-white/15">
                <ITrash className="h-5 w-5" />
              </button>
            </div>
          </div>
        </header>
      )}

      {/* ------------------------------- header ------------------------------- */}
      <header className={`sticky top-0 z-40 bg-grass-600 text-white shadow ${isSelecting ? "hidden" : ""}`}>
        <div className="mx-auto flex h-14 w-full max-w-5xl items-center justify-between px-3">
          <div className="flex items-center gap-1">
            {view.t !== "home" && (
              <button onClick={goBack} title="رجوع" className="rounded-full p-2 transition hover:bg-white/15">
                <IBack className="h-6 w-6" />
              </button>
            )}
            <button onClick={() => setSheet(true)} title="القائمة" className="rounded-full p-2 transition hover:bg-white/15">
              <IMenu className="h-6 w-6" />
            </button>
            <h1 className="truncate text-lg font-extrabold tracking-wide">
              {view.t === "home"
                ? "الملاحظات"
                : view.t === "section"
                  ? sectionRow?.name ?? "قسم"
                  : fileRow?.name ?? "ملف"}
            </h1>
          </div>
          <div className="flex items-center gap-0.5">
            <button
              onClick={() => {
                setSearchOpen((v) => !v);
                setQ("");
                if (page) setPage(null);
              }}
              title="بحث"
              className={`rounded-full p-2 transition hover:bg-white/15 ${searchOpen ? "bg-white/15" : ""}`}
            >
              <ISearch className="h-5 w-5" />
            </button>
            <button onClick={() => setListMode((m) => !m)} title="تبديل العرض" className="rounded-full p-2 transition hover:bg-white/15">
              {listMode ? <IGrid className="h-5 w-5" /> : <IList className="h-5 w-5" />}
            </button>
            <button
              onClick={onPlus}
              title="جديد"
              className="ml-1 rounded-full bg-white/15 p-2 transition hover:bg-white/25"
            >
              <IPlus className="h-6 w-6" />
            </button>
          </div>
        </div>
        {searchOpen && (
          <div className="border-t border-white/20 px-3 pb-3">
            <div className="mx-auto flex w-full max-w-5xl items-center gap-2">
              <div className="relative flex-1">
                <input
                  ref={searchRef}
                  autoFocus
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="ابحث باسم القسم أو الملف أو الملاحظة..."
                  className="w-full rounded-full bg-white py-2.5 pr-10 pl-10 text-sm font-bold text-ink-900 outline-none placeholder:text-ink-400"
                />
                <ISearch className="pointer-events-none absolute top-1/2 right-3.5 h-4 w-4 -translate-y-1/2 text-ink-400" />
                {q && (
                  <button
                    onClick={() => setQ("")}
                    className="absolute top-1/2 left-2 -translate-y-1/2 rounded-full p-1 text-ink-400 transition hover:bg-black/5"
                  >
                    <IX className="h-4 w-4" />
                  </button>
                )}
              </div>
              <button
                onClick={() => {
                  setSearchOpen(false);
                  setQ("");
                  setResults(null);
                }}
                title="إغلاق البحث"
                className="rounded-full p-2 text-white/90 transition hover:bg-white/15"
              >
                <IX className="h-5 w-5" />
              </button>
            </div>
          </div>
        )}
      </header>

      {/* -------------------------------- main -------------------------------- */}
      {mainContent}

      {/* ----------------------------- settings page ---------------------------- */}
      {page === "settings" && (
        <PageShell title="الإعدادات" onBack={() => setPage(null)}>
          {/* Settings list — matches the reference app layout */}
          <div className="overflow-hidden rounded-2xl border border-line bg-white">
            <SettingRow
              icon={<IRestore className="h-6 w-6" />}
              label="العودة إلى الإعدادات الأولية"
              onClick={resetSettings}
            />

            {prefs.lockKind !== "none" ? (
              <SettingRow
                icon={<ILock className="h-6 w-6" />}
                label="إلغاء القفل من التطبيق"
                value={
                  prefs.lockKind === "pin"
                    ? "قفل رقمي مُفعّل"
                    : prefs.lockKind === "password"
                      ? "قفل بكلمة سر مُفعّل"
                      : "قفل بالنمط مُفعّل"
                }
                onClick={removeLock}
              />
            ) : (
              <SettingRow
                icon={<ILock className="h-6 w-6" />}
                label="قفل التطبيق"
                value="رقم / كلمة سر / نمط"
                onClick={chooseLock}
              />
            )}

            <SettingRow
              icon={<IFinger className="h-6 w-6" />}
              label="قفل الموقع بالبصمة"
              value={prefs.biometricLock ? "مُفعّل" : "استخدم بصمة/وجه الجهاز عند الفتح"}
              right={<RowSwitch value={prefs.biometricLock} onChange={toggleBiometric} />}
              onClick={() => toggleBiometric(!prefs.biometricLock)}
            />

            <SettingRow
              icon={<IMask className="h-6 w-6" />}
              label="تمويه التطبيق"
              value={DISGUISES.find((d) => d.key === prefs.disguise)?.label ?? "الملاحظات"}
              onClick={chooseDisguise}
            />

            <SettingRow
              icon={<IMoon className="h-6 w-6" />}
              label="الوضع الليلي"
              right={<RowSwitch value={prefs.dark} onChange={(v) => updatePref({ dark: v })} />}
              onClick={() => updatePref({ dark: !prefs.dark })}
            />

            <div className="flex items-center gap-4 border-b border-line bg-white px-4 py-4">
              <span className="flex w-8 shrink-0 justify-center text-grass-600">
                <IPalette className="h-6 w-6" />
              </span>
              <span className="min-w-0 flex-1 text-[15px] font-bold text-ink-900">نظام الألوان</span>
              <div className="flex shrink-0 gap-1.5">
                {ACCENTS.map((a) => (
                  <button
                    key={a.key}
                    onClick={() => updatePref({ accent: a.key })}
                    title={a.label}
                    style={{ background: a.color }}
                    className={`h-6 w-6 rounded-md transition ${
                      prefs.accent === a.key ? "ring-2 ring-offset-1 ring-ink-900/40" : ""
                    }`}
                  />
                ))}
              </div>
            </div>

            <div className="flex items-center gap-4 border-b border-line bg-white px-4 py-4">
              <span className="flex w-8 shrink-0 justify-center text-grass-600">
                <IFontSize className="h-6 w-6" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-[15px] font-bold text-ink-900">حجم الخط</span>
                <span className="mt-0.5 block text-[12px] font-bold text-ink-400">{prefs.fontSize}</span>
              </span>
              <div className="flex shrink-0 items-center gap-2">
                <button
                  onClick={() => updatePref({ fontSize: Math.max(14, prefs.fontSize - 1) })}
                  className="flex h-8 w-8 items-center justify-center rounded-lg bg-grass-50 text-lg font-extrabold text-grass-700"
                >
                  −
                </button>
                <button
                  onClick={() => updatePref({ fontSize: Math.min(26, prefs.fontSize + 1) })}
                  className="flex h-8 w-8 items-center justify-center rounded-lg bg-grass-50 text-lg font-extrabold text-grass-700"
                >
                  +
                </button>
              </div>
            </div>

            <SettingRow
              icon={<INote className="h-6 w-6" />}
              label="أظهر فقط عنوان الملاحظة"
              right={<RowSwitch value={prefs.titleOnly} onChange={(v) => updatePref({ titleOnly: v })} />}
              onClick={() => updatePref({ titleOnly: !prefs.titleOnly })}
            />

            <SettingRow
              icon={prefs.listMode ? <IList className="h-6 w-6" /> : <IGrid className="h-6 w-6" />}
              label="نمط العرض"
              value={prefs.listMode ? "قائمة" : "شبكة"}
              onClick={() => updatePref({ listMode: !prefs.listMode })}
            />

            <SettingRow
              icon={<ISync className={`h-6 w-6 ${syncing ? "animate-spin" : ""}`} />}
              label="مزامنة الآن"
              value="جلب آخر التعديلات من أي جهاز"
              onClick={syncNow}
            />

            <SettingRow icon={<IInfo className="h-6 w-6" />} label="عن التطبيق" onClick={aboutApp} />
          </div>

          {/* Site link */}
          <div className="mt-4 overflow-hidden rounded-2xl border border-grass-300 bg-grass-50 p-4">
            <p className="text-sm font-extrabold text-ink-900">رابط موقعك</p>
            <p className="mt-1 text-[11px] font-bold leading-5 text-ink-600">
              انسخ هذا الرابط وأرسله لهاتفك الثاني لتفتح فيه كل الملاحظات.
            </p>
            <div className="mt-2 flex items-center gap-2 rounded-xl border border-line bg-white p-2">
              <span dir="ltr" className="min-w-0 flex-1 truncate text-[12px] font-bold text-grass-800">
                {siteUrl}
              </span>
              <button
                onClick={async () => {
                  const ok = await copyText(siteUrl);
                  toastFn(ok ? "تم نسخ الرابط — أرسله لهاتفك الثاني" : "تعذر النسخ");
                }}
                className="shrink-0 rounded-lg bg-grass-600 px-3 py-1.5 text-[12px] font-extrabold text-white transition hover:bg-grass-700"
              >
                نسخ
              </button>
            </div>
          </div>

          {/* Stats */}
          <div className="mt-4 rounded-2xl border border-line bg-white p-4">
            <p className="mb-3 text-sm font-extrabold text-ink-900">إحصائيات</p>
            <div className="grid grid-cols-2 gap-2">
              {stats.map(([label, n]) => (
                <div key={label} className="rounded-xl bg-grass-50 p-3 text-center">
                  <p className="text-2xl font-extrabold text-grass-800">{n}</p>
                  <p className="mt-0.5 text-[11px] font-bold text-ink-600">{label}</p>
                </div>
              ))}
            </div>
          </div>
        </PageShell>
      )}

      {/* -------------------------------- trash page ------------------------------ */}
      {page === "vault" && (
        <Vault onBack={() => setPage(null)} toast={toastFn} requireLock title="الخزنة المحمية" />
      )}

      {page === "pwmgr" && (
        <Vault onBack={() => setPage(null)} toast={toastFn} requireLock={false} title="مدير كلمات المرور" />
      )}

      {page === "sites" && <Sites onBack={() => setPage(null)} toast={toastFn} />}

      {page === "archived" && (
        <PageShell title="الملاحظات المؤرشفة" onBack={() => setPage(null)}>
          {(() => {
            const arch = data.notes
              .filter((n) => n.archived && !n.deletedAt)
              .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
            if (arch.length === 0)
              return (
                <Empty
                  icon={<IArchive className="h-14 w-14" />}
                  title="لا توجد ملاحظات مؤرشفة"
                  desc="الملاحظات التي تؤرشفها تظهر هنا، ويمكنك إرجاعها في أي وقت."
                />
              );
            return (
              <ul className="space-y-2">
                {arch.map((n) => (
                  <li key={n.id} className="flex items-center gap-3 rounded-xl border border-line bg-white p-3">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-grass-50 text-grass-700">
                      <INote className="h-5 w-5" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-extrabold text-ink-900">{n.title || "بدون عنوان"}</p>
                      <p className="text-[11px] font-bold text-ink-400">{fmtDate(n.updatedAt)}</p>
                    </div>
                    <button
                      onClick={() => setOpenNoteId(n.id)}
                      title="فتح"
                      className="rounded-lg bg-grass-50 p-2 text-grass-700 transition hover:bg-grass-100"
                    >
                      <INote className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => setNoteMeta(n.id, { archived: false })}
                      title="إلغاء الأرشفة"
                      className="rounded-lg bg-grass-50 p-2 text-grass-700 transition hover:bg-grass-100"
                    >
                      <IArchive className="h-5 w-5" />
                    </button>
                  </li>
                ))}
              </ul>
            );
          })()}
        </PageShell>
      )}

      {page === "trash" && (
        <PageShell title="سلة المهملات" onBack={() => setPage(null)}>
          {trashItems.length === 0 ? (
            <Empty icon={<ITrash className="h-14 w-14" />} title="السلة فارغة" desc="كل ما تحذفه سيظهر هنا ويمكنك استعادته في أي وقت." />
          ) : (
            <>
              <div className="mb-3 flex justify-end">
                <Btn variant="danger" onClick={emptyTrash} disabled={busy}>
                  إفراغ السلة
                </Btn>
              </div>
              <ul className="space-y-2">
                {trashItems.map((it) => (
                  <li key={it.type + it.id} className="flex items-center gap-3 rounded-xl border border-line bg-white p-3">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-grass-50 text-grass-700">
                      {it.type === "section" ? (
                        <IFolder className="h-5 w-5" />
                      ) : it.type === "file" ? (
                        <IFolder className="h-5 w-5" />
                      ) : (
                        <INote className="h-5 w-5" />
                      )}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-extrabold text-ink-900">{it.name}</p>
                      <p className="text-[11px] font-bold text-ink-400">
                        {it.sub} • {fmtDate(it.deletedAt)}
                      </p>
                    </div>
                    <button
                      onClick={() => restoreItem(it)}
                      title="استعادة"
                      className="rounded-lg bg-grass-50 p-2 text-grass-700 transition hover:bg-grass-100"
                    >
                      <IRestore className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => purgeItem(it)}
                      title="حذف نهائي"
                      className="rounded-lg bg-red-50 p-2 text-red-600 transition hover:bg-red-100"
                    >
                      <IX className="h-5 w-5" />
                    </button>
                  </li>
                ))}
              </ul>
            </>
          )}
        </PageShell>
      )}

      {/* ------------------------------- bottom sheet ------------------------------ */}
      {sheet && (
        <Overlay bottom onClose={() => setSheet(false)}>
          <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-ink-900/15" />

          {/* Direct Telegram send at the very top */}
          <div className="px-4 pb-3">
            <button
              onClick={() => {
                setSheet(false);
                sendTelegramDirect(window.location.href);
              }}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#229ED9] py-3 text-sm font-extrabold text-white transition hover:brightness-110"
            >
              <ITelegram className="h-5 w-5" />
              إرسال مباشر لتلقرام
            </button>
          </div>

          <div className="grid grid-cols-3 gap-y-6 px-4">
            {/* 10 core items (always visible) */}
            <SheetItem icon={<IGear className="h-8 w-8" />} label="الإعدادات" onClick={() => { setSheet(false); setPage("settings"); }} />
            <SheetItem icon={<ITrash className="h-8 w-8" />} label="سلة المهملات" onClick={() => { setSheet(false); setPage("trash"); }} />
            <SheetItem icon={<IDownload className="h-8 w-8" />} label="نسخ احتياطي" onClick={() => { setSheet(false); exportItem("all"); }} />

            <SheetItem icon={<IUpload className="h-8 w-8" />} label="استعادة" onClick={() => { setSheet(false); fileInputRef.current?.click(); }} />
            <SheetItem icon={<IShare className="h-8 w-8" />} label="مشاركة" onClick={() => { setSheet(false); shareApp(); }} />
            <SheetItem
              icon={<ISearch className="h-8 w-8" />}
              label="بحث"
              onClick={() => {
                setSheet(false);
                setSearchOpen(true);
                window.setTimeout(() => searchRef.current?.focus(), 60);
              }}
            />

            <SheetItem icon={<ILink className="h-8 w-8" />} label="مدير المواقع" onClick={() => { setSheet(false); setPage("sites"); }} />
            <SheetItem icon={<ILock className="h-8 w-8" />} label="مدير كلمات المرور" onClick={() => { setSheet(false); setPage("pwmgr"); }} />
            <SheetItem icon={<ISync className="h-8 w-8" />} label="مزامنة" onClick={() => { setSheet(false); syncNow(); }} />

            {/* Extra items — shown when "إظهار الكل" is toggled */}
            {sheetAll && (
              <>
                <SheetItem icon={<ILock className="h-8 w-8" />} label="الخزنة" onClick={() => { setSheet(false); setPage("vault"); }} />
                <SheetItem icon={<ITag className="h-8 w-8" />} label="وسوم ملونة" onClick={() => { setSheet(false); toastFn("افتح أي ملاحظة ← خيارات ← وسم ملوّن"); }} />
                <SheetItem icon={<IPin className="h-8 w-8" />} label="تثبيت الملاحظات" onClick={() => { setSheet(false); toastFn("افتح أي ملاحظة ← خيارات ← تثبيت في الأعلى"); }} />

                <SheetItem icon={<IArchive className="h-8 w-8" />} label="الأرشفة" onClick={() => { setSheet(false); setPage("archived"); }} />
                <SheetItem icon={<IInfo className="h-8 w-8" />} label="عداد وإحصائيات" onClick={() => { setSheet(false); setPage("settings"); }} />
                <SheetItem icon={<IInfo className="h-8 w-8" />} label="عن التطبيق" onClick={() => { setSheet(false); aboutApp(); }} />

                <SheetItem icon={<ISoon className="h-8 w-8" />} label="تذكيرات" onClick={() => { setSheet(false); toastFn("ميزة قادمة قريباً"); }} />
                <SheetItem icon={<ISoon className="h-8 w-8" />} label="بحث متقدم" onClick={() => { setSheet(false); toastFn("ميزة قادمة قريباً"); }} />
                <SheetItem icon={<ISoon className="h-8 w-8" />} label="ترتيب يدوي" onClick={() => { setSheet(false); toastFn("ميزة قادمة قريباً"); }} />

                <SheetItem icon={<IPrint className="h-8 w-8" />} label="تصدير PDF" onClick={() => { setSheet(false); toastFn("افتح أي ملاحظة ← زر PDF"); }} />
                <SheetItem icon={<ISoon className="h-8 w-8" />} label="إخفاء الحساس" onClick={() => { setSheet(false); toastFn("ميزة قادمة قريباً"); }} />
                <SheetItem icon={<ISoon className="h-8 w-8" />} label="ألوان الأقسام" onClick={() => { setSheet(false); toastFn("ميزة قادمة قريباً"); }} />

                <SheetItem icon={<ISoon className="h-8 w-8" />} label="ربط الملاحظات" onClick={() => { setSheet(false); toastFn("ميزة قادمة قريباً"); }} />
                <SheetItem icon={<ISoon className="h-8 w-8" />} label="قوالب جاهزة" onClick={() => { setSheet(false); toastFn("ميزة قادمة قريباً"); }} />
                <SheetItem icon={<ISoon className="h-8 w-8" />} label="سجل التعديلات" onClick={() => { setSheet(false); toastFn("ميزة قادمة قريباً"); }} />
              </>
            )}
          </div>

          <button
            onClick={() => setSheetAll((v) => !v)}
            className="mx-4 mt-6 w-[calc(100%-2rem)] rounded-xl border border-line bg-white py-2.5 text-sm font-extrabold text-grass-700 transition hover:bg-grass-50"
          >
            {sheetAll ? "إغلاق الكل ▲" : "إظهار الكل ▼"}
          </button>

          <p className="mt-3 text-center text-[11px] font-extrabold text-ink-600/60">الملاحظات — دفتر عملك الخاص</p>
        </Overlay>
      )}

      {/* ---------------------------------- modals ---------------------------------- */}
      {modal && (
        <Overlay onClose={() => !busy && setModal(null)}>
          {modal.kind === "prompt" && (
            <>
              <h3 className="text-base font-extrabold text-ink-900">{modal.title}</h3>
              <input
                autoFocus
                value={promptValue}
                onChange={(e) => setPromptValue(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && submitPrompt()}
                placeholder={modal.placeholder}
                className="mt-3 w-full rounded-xl border border-line bg-white px-3 py-2.5 text-sm font-bold text-ink-900 outline-none focus:border-grass-500"
              />
              <div className="mt-4 flex gap-2">
                <Btn className="flex-1" disabled={busy} onClick={submitPrompt}>
                  {modal.submitLabel || "حفظ"}
                </Btn>
                <Btn variant="ghost" onClick={() => setModal(null)}>
                  إلغاء
                </Btn>
              </div>
            </>
          )}
          {modal.kind === "confirm" && (
            <>
              <h3 className="text-base font-extrabold text-ink-900">{modal.title}</h3>
              <p className="mt-2 text-sm font-bold leading-7 text-ink-600">{modal.message}</p>
              <div className="mt-4 flex gap-2">
                <Btn
                  className="flex-1"
                  variant={modal.danger ? "danger" : "primary"}
                  disabled={busy}
                  onClick={async () => {
                    const m = modal;
                    setModal(null);
                    await m.onConfirm();
                  }}
                >
                  {modal.confirmLabel || "تأكيد"}
                </Btn>
                <Btn variant="ghost" onClick={() => setModal(null)}>
                  إلغاء
                </Btn>
              </div>
            </>
          )}
          {modal.kind === "actions" && (
            <div className="max-h-[60vh] space-y-1 overflow-y-auto">
              <h3 className="truncate px-1 pb-2 text-base font-extrabold text-ink-900">{modal.title}</h3>
              {modal.items.map((it, i) => (
                <ModalRow
                  key={i}
                  icon={it.icon}
                  label={it.label}
                  danger={it.danger}
                  disabled={busy}
                  onClick={() => {
                    if (busy) return;
                    it.onClick();
                  }}
                />
              ))}
            </div>
          )}
          {modal.kind === "move" &&
            (() => {
              const m = modal;
              const pick = (id: string | null, isCurrent: boolean) => (
                <button
                  disabled={isCurrent || busy}
                  onClick={() => {
                    const onPick = m.onPick;
                    setModal(null);
                    onPick(id);
                  }}
                  className={`flex w-full items-center gap-2 rounded-xl border p-3 text-right transition ${
                    isCurrent
                      ? "cursor-default border-grass-300 bg-grass-50"
                      : "border-line bg-white hover:border-grass-300 hover:bg-grass-50"
                  }`}
                >
                  {id === null ? (
                    <IGrid className="h-5 w-5 shrink-0 text-grass-700" />
                  ) : (
                    <IFolder className="h-5 w-5 shrink-0 text-grass-700" />
                  )}
                  <span className="min-w-0 flex-1 truncate text-sm font-extrabold text-ink-900">
                    {id === null ? "الصفحة الرئيسية (بدون قسم/ملف)" : m.kindItem === "note" ? data.files.find((f) => f.id === id)?.name : sectionsLive.find((s) => s.id === id)?.name}
                  </span>
                  {isCurrent && <span className="shrink-0 text-[11px] font-bold text-grass-700">الموضع الحالي</span>}
                </button>
              );
              return (
                <div className="max-h-[65vh] space-y-2 overflow-y-auto">
                  <h3 className="px-1 pb-1 text-base font-extrabold text-ink-900">{m.title}</h3>

                  {/* Root option */}
                  <div className="space-y-1">{pick(null, m.currentParentId === null)}</div>

                  {m.kindItem === "file" ? (
                    <div className="space-y-1">
                      <p className="px-1 pb-1 pt-2 text-[11px] font-extrabold text-ink-400">الأقسام</p>
                      {sectionsLive.length === 0 && (
                        <p className="p-3 text-center text-sm font-bold text-ink-400">لا توجد أقسام. أنشئ قسماً أولاً.</p>
                      )}
                      {sectionsLive.map((s) => (
                        <div key={s.id}>{pick(s.id, s.id === m.currentParentId)}</div>
                      ))}
                    </div>
                  ) : (
                    <>
                      {sectionsLive.length === 0 && (
                        <p className="p-3 text-center text-sm font-bold text-ink-400">
                          لا توجد أقسام بعد. أنشئ قسماً وملفاً أولاً.
                        </p>
                      )}
                      {sectionsLive.map((s) => {
                        const fs = data.files.filter((f) => f.sectionId === s.id && !f.deletedAt);
                        return (
                          <div key={s.id}>
                            <div className="flex items-center justify-between px-1 pb-1 pt-3">
                              <p className="text-[12px] font-extrabold text-grass-700">📂 {s.name}</p>
                              <button
                                onClick={() => {
                                  const onPick = m.onPick;
                                  setModal(null);
                                  // Move into this section by creating a new file, then move note into it.
                                  moveNoteIntoNewFile(s.id, onPick);
                                }}
                                className="rounded-md bg-grass-50 px-2 py-0.5 text-[11px] font-bold text-grass-700 transition hover:bg-grass-100"
                              >
                                + ملف جديد هنا
                              </button>
                            </div>
                            <div className="space-y-1">
                              {fs.length === 0 ? (
                                <p className="px-1 pb-1 text-[11px] font-bold text-ink-400">لا ملفات — أنشئ ملفاً هنا</p>
                              ) : (
                                fs.map((f) => <div key={f.id}>{pick(f.id, f.id === m.currentParentId)}</div>)
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </>
                  )}

                  <div className="pt-2">
                    <Btn variant="ghost" className="w-full" onClick={() => setModal(null)}>
                      إلغاء
                    </Btn>
                  </div>
                </div>
              );
            })()}
        </Overlay>
      )}

      {/* ---------------------------- pattern setup ---------------------------- */}
      {patternSetup && (
        <PatternSetup
          onCancel={() => setPatternSetup(false)}
          onDone={(seq) => {
            setPatternSetup(false);
            updatePref({ lockKind: "pattern", lockSecret: seq });
            toastFn("تم تفعيل قفل النمط");
          }}
        />
      )}

      {/* ------------------------------- note overlay ------------------------------- */}
      {openNote && (
        <NoteView
          key={openNoteId ?? "note"}
          note={openNote}
          file={openNoteFile}
          section={openNoteSection}
          initialEditing={justCreated}
          onBack={() => {
            setOpenNoteId(null);
            setJustCreated(false);
          }}
          onRefresh={refresh}
          onShareMenu={shareMenu}
          onAskDelete={() =>
            confirmAction(
              "حذف الملاحظة؟",
              "ستنتقل الملاحظة إلى سلة المهملات ويمكنك استعادتها في أي وقت.",
              async () => {
                const id = openNote.id;
                await run(async () => {
                  await api(`/api/note/${id}`, { method: "PATCH", body: JSON.stringify({ action: "delete" }) });
                  await refresh();
                  setOpenNoteId(null);
                  toastFn("نُقلت الملاحظة إلى السلة");
                });
              },
            )
          }
          toast={toastFn}
        />
      )}

      <Toast msg={toast} />

      <input ref={fileInputRef} type="file" accept=".json,application/json" className="hidden" onChange={onRestoreFile} />

      {openNote && <PrintArea note={openNote} file={openNoteFile} section={openNoteSection} />}
    </div>
  );
}

/* -------------------------------- ResultsView -------------------------------- */

function ResultsView({
  q,
  res,
  data,
  onOpenNote,
  onOpenFile,
  onOpenSection,
}: {
  q: string;
  res: SearchResult | null;
  data: Data;
  onOpenNote: (id: string) => void;
  onOpenFile: (id: string) => void;
  onOpenSection: (id: string) => void;
}) {
  const secs = res?.sections ?? [];
  const fils = (res?.files ?? []).map((f) => ({
    ...f,
    sectionName: data.sections.find((s) => s.id === f.sectionId)?.name ?? "",
  }));
  const nots = (res?.notes ?? []).map((n) => {
    const f = data.files.find((x) => x.id === n.fileId);
    const s = f ? data.sections.find((x) => x.id === f.sectionId) : null;
    const flat = n.content.replace(/\s+/g, " ");
    let snip = flat.slice(0, 100);
    const idx = flat.toLowerCase().indexOf(q.trim().toLowerCase());
    if (idx > 40) snip = "… " + flat.slice(idx - 25, idx + 75);
    return { ...n, fileName: f?.name ?? "", sectionName: s?.name ?? "", snip };
  });

  const total = secs.length + fils.length + nots.length;

  return (
    <main className="mx-auto w-full max-w-5xl space-y-4 px-3 py-3">
      <p className="text-[13px] font-extrabold text-ink-400">
        {total === 0 ? `لا توجد نتائج` : `${total} نتيجة`}
        {total === 0 && ` لـ «${q.trim()}»`}
      </p>
      {total === 0 ? (
        <div className="flex flex-col items-center gap-2 py-14 text-ink-400">
          <ISearch className="h-10 w-10" />
          <p className="text-sm font-extrabold">جرّب كلمة أقصر أو اسم ملف / ملاحظة</p>
        </div>
      ) : (
        <div className="space-y-2">
          {secs.map((s) => (
            <ResultRow
              key={s.id}
              icon={<IFolder className="h-5 w-5" />}
              name={s.name}
              sub="قسم"
              onClick={() => onOpenSection(s.id)}
            />
          ))}
          {fils.map((f) => (
            <ResultRow
              key={f.id}
              icon={<IFolder className="h-5 w-5" />}
              name={f.name}
              sub={`ملف — ${f.sectionName}`}
              onClick={() => onOpenFile(f.id)}
            />
          ))}
          {nots.map((n) => (
            <ResultRow
              key={n.id}
              icon={<INote className="h-5 w-5" />}
              name={n.title || "بدون عنوان"}
              sub={
                <>
                  {n.sectionName} / {n.fileName}
                  {n.snip ? ` — ${n.snip}` : ""}
                </>
              }
              onClick={() => onOpenNote(n.id)}
            />
          ))}
        </div>
      )}
    </main>
  );
}
