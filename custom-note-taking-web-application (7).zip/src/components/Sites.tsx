"use client";

import { useEffect, useState } from "react";
import type { SiteRow } from "@/lib/types";
import { api, copyText } from "@/lib/client";
import { PageShell, Btn, Overlay } from "./Modal";
import { IPlus, ICopy, IPencil, ITrash, ILink } from "./Icons";

type Draft = { groupName: string; name: string; url: string; note: string };
const EMPTY: Draft = { groupName: "", name: "", url: "", note: "" };

export default function Sites({ onBack, toast }: { onBack: () => void; toast: (m: string) => void }) {
  const [rows, setRows] = useState<SiteRow[]>([]);
  const [busy, setBusy] = useState(false);
  const [editing, setEditing] = useState<SiteRow | "new" | null>(null);
  const [draft, setDraft] = useState<Draft>(EMPTY);

  async function load() {
    const d = await api<{ sites: SiteRow[] }>("/api/site");
    setRows(
      d.sites.sort((a, b) => a.groupName.localeCompare(b.groupName) || a.name.localeCompare(b.name)),
    );
  }
  useEffect(() => {
    load().catch(() => toast("تعذر التحميل"));
  }, []);

  const fullUrl = (u: string) => (/^https?:\/\//.test(u) ? u : `https://${u}`);

  async function save() {
    setBusy(true);
    try {
      if (editing === "new") await api("/api/site", { method: "POST", body: JSON.stringify(draft) });
      else if (editing) await api(`/api/site/${editing.id}`, { method: "PATCH", body: JSON.stringify({ action: "update", ...draft }) });
      await load();
      setEditing(null);
      setDraft(EMPTY);
      toast("تم الحفظ");
    } catch {
      toast("تعذر الحفظ");
    } finally {
      setBusy(false);
    }
  }

  async function del(row: SiteRow) {
    if (!confirm(`حذف «${row.name || "الموقع"}»؟`)) return;
    await api(`/api/site/${row.id}`, { method: "PATCH", body: JSON.stringify({ action: "delete" }) });
    await load();
    toast("تم الحذف");
  }

  return (
    <PageShell title="مدير المواقع" onBack={onBack}>
      <Btn
        className="mb-3 w-full"
        onClick={() => {
          setDraft(EMPTY);
          setEditing("new");
        }}
      >
        <span className="inline-flex items-center gap-1">
          <IPlus className="h-4 w-4" /> إضافة موقع
        </span>
      </Btn>

      {rows.length === 0 ? (
        <div className="flex flex-col items-center gap-2 py-16 text-center text-ink-400">
          <ILink className="h-12 w-12" />
          <p className="text-sm font-extrabold">لا توجد مواقع بعد — أضف أول موقع</p>
        </div>
      ) : (
        <ul className="space-y-2">
          {rows.map((r) => (
            <li key={r.id} className="rounded-xl border border-line bg-white p-3">
              <div className="flex items-start gap-2">
                <div className="min-w-0 flex-1">
                  {r.groupName && (
                    <span className="mb-1 inline-block rounded-md bg-grass-50 px-2 py-0.5 text-[10px] font-extrabold text-grass-700">
                      📁 {r.groupName}
                    </span>
                  )}
                  <p className="truncate text-[15px] font-extrabold text-ink-900">{r.name || "بدون اسم"}</p>
                  {r.url && (
                    <a
                      href={fullUrl(r.url)}
                      target="_blank"
                      rel="noopener noreferrer"
                      dir="ltr"
                      className="mt-0.5 flex items-center gap-1 truncate text-[12px] font-bold text-grass-700 underline"
                    >
                      <ILink className="h-3.5 w-3.5 shrink-0" />
                      <span className="truncate">{r.url}</span>
                    </a>
                  )}
                </div>
                <button onClick={async () => { await copyText(fullUrl(r.url)); toast("تم نسخ الرابط"); }} className="rounded-lg p-1.5 text-ink-400 hover:bg-grass-50 hover:text-grass-700">
                  <ICopy className="h-4 w-4" />
                </button>
                <button onClick={() => { setDraft({ groupName: r.groupName, name: r.name, url: r.url, note: r.note }); setEditing(r); }} className="rounded-lg p-1.5 text-ink-400 hover:bg-grass-50 hover:text-grass-700">
                  <IPencil className="h-4 w-4" />
                </button>
                <button onClick={() => del(r)} className="rounded-lg p-1.5 text-red-500 hover:bg-red-50">
                  <ITrash className="h-4 w-4" />
                </button>
              </div>
              {r.note && <p className="mt-2 whitespace-pre-wrap text-[12px] font-bold leading-6 text-ink-600">{r.note}</p>}
              {r.url && (
                <a
                  href={fullUrl(r.url)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-2 block rounded-lg bg-grass-600 py-2 text-center text-[13px] font-extrabold text-white transition hover:bg-grass-700"
                >
                  فتح الموقع
                </a>
              )}
            </li>
          ))}
        </ul>
      )}

      {editing && (
        <Overlay onClose={() => !busy && setEditing(null)}>
          <h3 className="mb-3 text-base font-extrabold text-ink-900">{editing === "new" ? "إضافة موقع" : "تعديل"}</h3>
          <div className="space-y-2">
            <input value={draft.groupName} onChange={(e) => setDraft((d) => ({ ...d, groupName: e.target.value }))} placeholder="الملف / المجموعة (اختياري)" className="w-full rounded-xl border border-line bg-white px-3 py-2.5 text-sm font-bold outline-none focus:border-grass-500" />
            <input value={draft.name} onChange={(e) => setDraft((d) => ({ ...d, name: e.target.value }))} placeholder="اسم الموقع" className="w-full rounded-xl border border-line bg-white px-3 py-2.5 text-sm font-bold outline-none focus:border-grass-500" />
            <input value={draft.url} onChange={(e) => setDraft((d) => ({ ...d, url: e.target.value }))} placeholder="الرابط — https://..." dir="ltr" className="w-full rounded-xl border border-line bg-white px-3 py-2.5 text-sm font-bold outline-none focus:border-grass-500" />
            <textarea value={draft.note} onChange={(e) => setDraft((d) => ({ ...d, note: e.target.value }))} placeholder="ملاحظة (اختياري)" rows={3} className="w-full resize-y rounded-xl border border-line bg-white px-3 py-2.5 text-sm font-bold outline-none focus:border-grass-500" />
          </div>
          <div className="mt-4 flex gap-2">
            <Btn className="flex-1" disabled={busy} onClick={save}>حفظ</Btn>
            <Btn variant="ghost" onClick={() => setEditing(null)}>إلغاء</Btn>
          </div>
        </Overlay>
      )}
    </PageShell>
  );
}
