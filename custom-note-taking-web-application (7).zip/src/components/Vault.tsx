"use client";

import { useEffect, useState } from "react";
import type { PasswordRow } from "@/lib/types";
import { api, copyText } from "@/lib/client";
import { PageShell, Btn, Overlay } from "./Modal";
import { ILock, IPlus, ICopy, IPencil, ITrash, IX, ILink } from "./Icons";

type Draft = { groupName: string; siteName: string; url: string; username: string; password: string; note: string };
const EMPTY: Draft = { groupName: "", siteName: "", url: "", username: "", password: "", note: "" };

export default function Vault({
  onBack,
  toast,
  requireLock = true,
  title = "الخزنة — مدير كلمات المرور",
}: {
  onBack: () => void;
  toast: (m: string) => void;
  requireLock?: boolean;
  title?: string;
}) {
  const [unlocked, setUnlocked] = useState(!requireLock);
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);
  const [rows, setRows] = useState<PasswordRow[]>([]);
  const [reveal, setReveal] = useState<Record<string, boolean>>({});
  const [editing, setEditing] = useState<PasswordRow | "new" | null>(null);
  const [draft, setDraft] = useState<Draft>(EMPTY);
  const [changePw, setChangePw] = useState(false);
  const [curPw, setCurPw] = useState("");
  const [newPw, setNewPw] = useState("");

  async function load() {
    const d = await api<{ passwords: PasswordRow[] }>("/api/vault");
    setRows(
      d.passwords.sort(
        (a, b) => a.groupName.localeCompare(b.groupName) || a.siteName.localeCompare(b.siteName),
      ),
    );
  }

  useEffect(() => {
    if (unlocked) load().catch(() => toast("تعذر التحميل"));
  }, [unlocked]);

  async function unlock() {
    setBusy(true);
    try {
      const r = await api<{ ok: boolean }>("/api/vault", {
        method: "POST",
        body: JSON.stringify({ action: "verify", password: pw }),
      });
      if (r.ok) {
        setUnlocked(true);
        setPw("");
      } else toast("كلمة المرور غير صحيحة");
    } catch {
      toast("تعذر التحقق");
    } finally {
      setBusy(false);
    }
  }

  async function save() {
    setBusy(true);
    try {
      if (editing === "new") {
        await api("/api/password", { method: "POST", body: JSON.stringify(draft) });
      } else if (editing) {
        await api(`/api/password/${editing.id}`, { method: "PATCH", body: JSON.stringify({ action: "update", ...draft }) });
      }
      await load();
      setEditing(null);
      setDraft(EMPTY);
      toast("تم الحفظ");
    } catch {
      toast("تعذر الحفظ");
    } finally {
      setBusy(false);
    }
  }

  async function del(row: PasswordRow) {
    if (!confirm(`حذف «${row.siteName || "العنصر"}» نهائياً؟`)) return;
    await api(`/api/password/${row.id}`, { method: "PATCH", body: JSON.stringify({ action: "delete" }) });
    await load();
    toast("تم الحذف");
  }

  async function doChangePassword() {
    setBusy(true);
    try {
      await api("/api/vault", { method: "POST", body: JSON.stringify({ action: "change", current: curPw, next: newPw }) });
      setChangePw(false);
      setCurPw("");
      setNewPw("");
      toast("تم تغيير كلمة مرور الخزنة");
    } catch (e: any) {
      toast(e?.message || "تعذر التغيير");
    } finally {
      setBusy(false);
    }
  }

  // ----- Locked screen -----
  if (!unlocked) {
    return (
      <PageShell title="الخزنة المحمية" onBack={onBack}>
        <div className="mx-auto flex max-w-sm flex-col items-center gap-4 pt-10">
          <div className="flex h-20 w-20 items-center justify-center rounded-full bg-grass-50 text-grass-600">
            <ILock className="h-10 w-10" />
          </div>
          <p className="text-base font-extrabold text-ink-900">أدخل كلمة مرور الخزنة</p>
          <p className="-mt-2 text-center text-xs font-bold text-ink-400">
            كلمة المرور الافتراضية هي 1234 — غيّرها من داخل الخزنة.
          </p>
          <input
            autoFocus
            type="password"
            value={pw}
            onChange={(e) => setPw(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && unlock()}
            placeholder="كلمة المرور"
            className="w-full rounded-xl border border-line bg-white px-3 py-3 text-center text-lg font-extrabold text-ink-900 outline-none focus:border-grass-500"
          />
          <Btn className="w-full" disabled={busy} onClick={unlock}>
            {busy ? "جارٍ التحقق..." : "فتح الخزنة"}
          </Btn>
        </div>
      </PageShell>
    );
  }

  // ----- Unlocked -----
  return (
    <PageShell title={title} onBack={onBack}>
      <div className="mb-3 flex gap-2">
        <Btn
          className="flex-1"
          onClick={() => {
            setDraft(EMPTY);
            setEditing("new");
          }}
        >
          <span className="inline-flex items-center gap-1">
            <IPlus className="h-4 w-4" /> إضافة كلمة مرور
          </span>
        </Btn>
        <Btn variant="ghost" onClick={() => setChangePw(true)}>
          تغيير كلمة مرور الخزنة
        </Btn>
      </div>

      {rows.length === 0 ? (
        <div className="flex flex-col items-center gap-2 py-16 text-center text-ink-400">
          <ILock className="h-12 w-12" />
          <p className="text-sm font-extrabold">الخزنة فارغة — أضف أول كلمة مرور</p>
        </div>
      ) : (
        <ul className="space-y-2">
          {rows.map((r) => (
            <li key={r.id} className="rounded-xl border border-line bg-white p-3">
              <div className="flex items-start gap-2">
                <div className="min-w-0 flex-1">
                  {r.groupName && (
                    <span className="mb-1 inline-block rounded-md bg-grass-50 px-2 py-0.5 text-[10px] font-extrabold text-grass-700">
                      📁 {r.groupName}
                    </span>
                  )}
                  <p className="truncate text-[15px] font-extrabold text-ink-900">{r.siteName || "بدون اسم"}</p>
                  {r.url && (
                    <a
                      href={/^https?:\/\//.test(r.url) ? r.url : `https://${r.url}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      dir="ltr"
                      className="mt-0.5 flex items-center gap-1 truncate text-[12px] font-bold text-grass-700 underline"
                    >
                      <ILink className="h-3.5 w-3.5 shrink-0" />
                      <span className="truncate">{r.url}</span>
                    </a>
                  )}
                </div>
                <button onClick={() => { setDraft({ groupName: r.groupName, siteName: r.siteName, url: r.url, username: r.username, password: r.password, note: r.note }); setEditing(r); }} className="rounded-lg p-1.5 text-ink-400 hover:bg-grass-50 hover:text-grass-700">
                  <IPencil className="h-4 w-4" />
                </button>
                <button onClick={() => del(r)} className="rounded-lg p-1.5 text-red-500 hover:bg-red-50">
                  <ITrash className="h-4 w-4" />
                </button>
              </div>

              {r.username && (
                <div className="mt-2 flex items-center gap-2 rounded-lg bg-grass-50 px-2 py-1.5">
                  <span className="text-[11px] font-bold text-ink-400">المستخدم:</span>
                  <span dir="ltr" className="min-w-0 flex-1 truncate text-[13px] font-bold text-ink-900">{r.username}</span>
                  <button onClick={async () => { await copyText(r.username); toast("تم نسخ اسم المستخدم"); }} className="shrink-0 rounded p-1 text-grass-700 hover:bg-white">
                    <ICopy className="h-3.5 w-3.5" />
                  </button>
                </div>
              )}

              <div className="mt-1.5 flex items-center gap-2 rounded-lg bg-grass-50 px-2 py-1.5">
                <span className="text-[11px] font-bold text-ink-400">كلمة المرور:</span>
                <span dir="ltr" className="min-w-0 flex-1 truncate text-[13px] font-bold text-ink-900">
                  {reveal[r.id] ? r.password : "••••••••"}
                </span>
                <button onClick={() => setReveal((p) => ({ ...p, [r.id]: !p[r.id] }))} className="shrink-0 rounded px-1.5 text-[11px] font-bold text-grass-700 hover:bg-white">
                  {reveal[r.id] ? "إخفاء" : "إظهار"}
                </button>
                <button onClick={async () => { await copyText(r.password); toast("تم نسخ كلمة المرور"); }} className="shrink-0 rounded p-1 text-grass-700 hover:bg-white">
                  <ICopy className="h-3.5 w-3.5" />
                </button>
              </div>

              {r.note && <p className="mt-2 whitespace-pre-wrap text-[12px] font-bold leading-6 text-ink-600">{r.note}</p>}
            </li>
          ))}
        </ul>
      )}

      {/* Add / edit dialog */}
      {editing && (
        <Overlay onClose={() => !busy && setEditing(null)}>
          <h3 className="mb-3 text-base font-extrabold text-ink-900">
            {editing === "new" ? "إضافة كلمة مرور" : "تعديل"}
          </h3>
          <div className="space-y-2">
            {(
              [
                ["groupName", "الملف / المجموعة (اختياري)", "مثال: بنوك"],
                ["siteName", "اسم الموقع / التطبيق", "مثال: انستقرام"],
                ["url", "الرابط (اختياري)", "https://..."],
                ["username", "اسم المستخدم / البريد", ""],
                ["password", "كلمة المرور", ""],
              ] as const
            ).map(([key, label, ph]) => (
              <input
                key={key}
                value={draft[key]}
                onChange={(e) => setDraft((d) => ({ ...d, [key]: e.target.value }))}
                placeholder={label + (ph ? ` — ${ph}` : "")}
                dir={key === "url" || key === "username" || key === "password" ? "ltr" : "rtl"}
                className="w-full rounded-xl border border-line bg-white px-3 py-2.5 text-sm font-bold text-ink-900 outline-none focus:border-grass-500"
              />
            ))}
            <textarea
              value={draft.note}
              onChange={(e) => setDraft((d) => ({ ...d, note: e.target.value }))}
              placeholder="ملاحظة (اختياري)"
              rows={3}
              className="w-full resize-y rounded-xl border border-line bg-white px-3 py-2.5 text-sm font-bold text-ink-900 outline-none focus:border-grass-500"
            />
          </div>
          <div className="mt-4 flex gap-2">
            <Btn className="flex-1" disabled={busy} onClick={save}>حفظ</Btn>
            <Btn variant="ghost" onClick={() => setEditing(null)}>إلغاء</Btn>
          </div>
        </Overlay>
      )}

      {/* Change vault password */}
      {changePw && (
        <Overlay onClose={() => !busy && setChangePw(false)}>
          <h3 className="mb-3 text-base font-extrabold text-ink-900">تغيير كلمة مرور الخزنة</h3>
          <div className="space-y-2">
            <input type="password" value={curPw} onChange={(e) => setCurPw(e.target.value)} placeholder="كلمة المرور الحالية" className="w-full rounded-xl border border-line bg-white px-3 py-2.5 text-sm font-bold outline-none focus:border-grass-500" />
            <input type="password" value={newPw} onChange={(e) => setNewPw(e.target.value)} placeholder="كلمة المرور الجديدة" className="w-full rounded-xl border border-line bg-white px-3 py-2.5 text-sm font-bold outline-none focus:border-grass-500" />
          </div>
          <div className="mt-4 flex gap-2">
            <Btn className="flex-1" disabled={busy} onClick={doChangePassword}>تغيير</Btn>
            <Btn variant="ghost" onClick={() => setChangePw(false)}>إلغاء</Btn>
          </div>
        </Overlay>
      )}
    </PageShell>
  );
}
