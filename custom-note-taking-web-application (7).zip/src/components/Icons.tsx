import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement>;

function Svg(p: P) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.9}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      {...p}
    />
  );
}

export const IPlus = (p: P) => (
  <Svg {...p}>
    <path d="M12 5v14M5 12h14" />
  </Svg>
);

export const ISearch = (p: P) => (
  <Svg {...p}>
    <circle cx="11" cy="11" r="7" />
    <path d="M21 21l-4.3-4.3" />
  </Svg>
);

export const IMenu = (p: P) => (
  <Svg {...p}>
    <path d="M4 6h16M4 12h16M4 18h16" />
  </Svg>
);

export const IList = (p: P) => (
  <Svg {...p}>
    <path d="M4 6h16M4 12h16M4 18h10" />
  </Svg>
);

export const IGrid = (p: P) => (
  <Svg {...p}>
    <rect x="4" y="4" width="6.5" height="6.5" rx="1.5" />
    <rect x="13.5" y="4" width="6.5" height="6.5" rx="1.5" />
    <rect x="4" y="13.5" width="6.5" height="6.5" rx="1.5" />
    <rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.5" />
  </Svg>
);

export const IFolder = (p: P) => (
  <Svg {...p}>
    <path d="M3 7a2 2 0 0 1 2-2h4l2 2.4h8a2 2 0 0 1 2 2V17a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
  </Svg>
);

export const INote = (p: P) => (
  <Svg {...p}>
    <path d="M6 2h9l5 5v13a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2z" />
    <path d="M14 2v6h6M9 13h6M9 17h4" />
  </Svg>
);

export const ITrash = (p: P) => (
  <Svg {...p}>
    <path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3" />
  </Svg>
);

export const IGear = (p: P) => (
  <Svg {...p}>
    <circle cx="12" cy="12" r="3.2" />
    <path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.7 1.7 0 0 0-1.87-.34 1.7 1.7 0 0 0-1 1.55V21a2 2 0 1 1-4 0v-.09a1.7 1.7 0 0 0-1-1.55 1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.7 1.7 0 0 0 .34-1.87 1.7 1.7 0 0 0-1.55-1H3a2 2 0 1 1 0-4h.09a1.7 1.7 0 0 0 1.55-1 1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.7 1.7 0 0 0 1.87.34h0a1.7 1.7 0 0 0 1-1.55V3a2 2 0 1 1 4 0v.09a1.7 1.7 0 0 0 1 1.55 1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.7 1.7 0 0 0-.34 1.87v0a1.7 1.7 0 0 0 1.55 1H21a2 2 0 1 1 0 4h-.09a1.7 1.7 0 0 0-1.55 1z" />
  </Svg>
);

export const IShare = (p: P) => (
  <Svg {...p}>
    <circle cx="18" cy="5" r="2.6" />
    <circle cx="6" cy="12" r="2.6" />
    <circle cx="18" cy="19" r="2.6" />
    <path d="M8.4 13.3l7.2 4.4M15.6 6.3L8.4 10.7" />
  </Svg>
);

export const ICopy = (p: P) => (
  <Svg {...p}>
    <rect x="9" y="9" width="11" height="11" rx="2" />
    <path d="M5 15V5a2 2 0 0 1 2-2h10" />
  </Svg>
);

export const IDownload = (p: P) => (
  <Svg {...p}>
    <path d="M12 3v12M7 10l5 5 5-5M5 21h14" />
  </Svg>
);

export const IUpload = (p: P) => (
  <Svg {...p}>
    <path d="M12 21V9M7 14l5-5 5 5M5 3h14" />
  </Svg>
);

export const IPrint = (p: P) => (
  <Svg {...p}>
    <path d="M6 9V3h12v6M6 14H4a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-2M6 14h12v7H6z" />
  </Svg>
);

export const IPencil = (p: P) => (
  <Svg {...p}>
    <path d="M17 3a2.83 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5z" />
  </Svg>
);

export const IX = (p: P) => (
  <Svg {...p}>
    <path d="M6 6l12 12M18 6L6 18" />
  </Svg>
);

/** Back arrow (points right, for RTL). */
export const IBack = (p: P) => (
  <Svg {...p}>
    <path d="M5 12h14M13 6l6 6-6 6" />
  </Svg>
);

export const IRestore = (p: P) => (
  <Svg {...p}>
    <path d="M1 4v6h6" />
    <path d="M3.5 15a9 9 0 1 0 2-9.4L1 10" />
  </Svg>
);

export const ICheck = (p: P) => (
  <Svg {...p}>
    <path d="M4 12l5 5L20 7" />
  </Svg>
);

export const IKebab = (p: P) => (
  <Svg {...p}>
    <circle cx="12" cy="5" r="0.9" fill="currentColor" />
    <circle cx="12" cy="12" r="0.9" fill="currentColor" />
    <circle cx="12" cy="19" r="0.9" fill="currentColor" />
    <path d="M12 5h.01M12 12h.01M12 19h.01" />
  </Svg>
);

export const IChevronL = (p: P) => (
  <Svg {...p}>
    <path d="M15 6l-6 6 6 6" />
  </Svg>
);

export const ILink = (p: P) => (
  <Svg {...p}>
    <path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7" />
    <path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7" />
  </Svg>
);

export const IChecklist = (p: P) => (
  <Svg {...p}>
    <path d="M4 6.5l1.5 1.5L8.5 5" />
    <path d="M4 12.5l1.5 1.5L8.5 11" />
    <path d="M4 18.5l1.5 1.5L8.5 17" />
    <path d="M12 6h8M12 12h8M12 18h8" />
  </Svg>
);

export const IPen = (p: P) => (
  <Svg {...p}>
    <path d="M4 20c3-1 4-2 6-6 1.5-3 2.5-6 5-8 1.6-1.3 3.5.4 2.5 2.2-1.4 2.6-4 4-6.5 5.2-2.1 1-3.5 2.2-4 4.4" />
    <path d="M4 20l3-1" />
  </Svg>
);

export const IMic = (p: P) => (
  <Svg {...p}>
    <rect x="9" y="3" width="6" height="11" rx="3" />
    <path d="M5 11a7 7 0 0 0 14 0M12 18v3M8 21h8" />
  </Svg>
);

export const ISection = (p: P) => (
  <Svg {...p}>
    <path d="M3 7a2 2 0 0 1 2-2h4l2 2.4h8a2 2 0 0 1 2 2V17a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
    <path d="M12 11v5M9.5 13.5h5" />
  </Svg>
);

export const IMoon = (p: P) => (
  <Svg {...p}>
    <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" />
  </Svg>
);

export const IPalette = (p: P) => (
  <Svg {...p}>
    <path d="M12 3a9 9 0 0 0 0 18c1.7 0 2-1.3 1.2-2.2-.8-1 .1-2.3 1.3-2.3H17a4 4 0 0 0 4-4c0-4.7-4-9.5-9-9.5z" />
    <circle cx="7.5" cy="11" r="1" fill="currentColor" />
    <circle cx="10" cy="7.5" r="1" fill="currentColor" />
    <circle cx="14.5" cy="7.5" r="1" fill="currentColor" />
    <circle cx="17" cy="11" r="1" fill="currentColor" />
  </Svg>
);

export const IFontSize = (p: P) => (
  <Svg {...p}>
    <path d="M3 18l4-11 4 11M4 14h6" />
    <path d="M14 18l3-8 3 8M15 15h4" />
  </Svg>
);

export const ILock = (p: P) => (
  <Svg {...p}>
    <rect x="5" y="11" width="14" height="10" rx="2" />
    <path d="M8 11V8a4 4 0 0 1 8 0v3M12 15v2" />
  </Svg>
);

export const IUnlock = (p: P) => (
  <Svg {...p}>
    <rect x="5" y="11" width="14" height="10" rx="2" />
    <path d="M8 11V8a4 4 0 0 1 7.5-2M12 15v2" />
  </Svg>
);

export const ISync = (p: P) => (
  <Svg {...p}>
    <path d="M21 12a9 9 0 0 1-15 6.7L3 16" />
    <path d="M3 12a9 9 0 0 1 15-6.7L21 8" />
    <path d="M21 3v5h-5M3 21v-5h5" />
  </Svg>
);

export const IMove = (p: P) => (
  <Svg {...p}>
    <path d="M3 7a2 2 0 0 1 2-2h4l2 2.4h8a2 2 0 0 1 2 2V17a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
    <path d="M12 15l3-3-3-3M15 12H8" />
  </Svg>
);

export const ITelegram = (p: P) => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...p}>
    <path d="M21.94 4.3 18.9 19.1c-.23 1.02-.84 1.27-1.7.79l-4.7-3.46-2.27 2.18c-.25.25-.46.46-.94.46l.34-4.78 8.7-7.86c.38-.34-.08-.53-.59-.19L6.99 13.2l-4.63-1.45c-1-.31-1.02-1 .21-1.48L20.65 3.2c.84-.31 1.57.2 1.29 1.1z" />
  </svg>
);

export const IWhatsApp = (p: P) => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...p}>
    <path d="M17.5 14.4c-.3-.15-1.77-.87-2.04-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.65.07-.3-.15-1.26-.46-2.4-1.48-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.46.13-.61.14-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.8.37-.27.3-1.04 1.02-1.04 2.48s1.07 2.88 1.22 3.08c.15.2 2.1 3.2 5.08 4.49.71.3 1.26.49 1.69.62.71.23 1.36.2 1.87.12.57-.08 1.77-.72 2.02-1.42.25-.7.25-1.29.17-1.42-.07-.13-.27-.2-.57-.35zM12.05 2C6.5 2 2 6.5 2 12.05c0 1.77.46 3.5 1.35 5.03L2 22l5.06-1.33a10 10 0 0 0 4.99 1.27h.01c5.55 0 10.05-4.5 10.05-10.05C22.11 6.5 17.6 2 12.05 2z" />
  </svg>
);

export const ICheckbox = (p: P) => (
  <Svg {...p}>
    <rect x="4" y="4" width="16" height="16" rx="3" />
  </Svg>
);

export const ICheckboxOn = (p: P) => (
  <svg viewBox="0 0 24 24" aria-hidden="true" {...p}>
    <rect x="4" y="4" width="16" height="16" rx="3" fill="currentColor" />
    <path d="M8 12l3 3 5-5" fill="none" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const ISelect = (p: P) => (
  <Svg {...p}>
    <path d="M9 11l3 3L22 4" />
    <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" />
  </Svg>
);

export const IBackupRestore = (p: P) => (
  <Svg {...p}>
    <path d="M3 12a9 9 0 1 0 3-6.7L3 8" />
    <path d="M3 3v5h5" />
    <path d="M12 8v4l3 2" />
  </Svg>
);

export const ICart = (p: P) => (
  <Svg {...p}>
    <path d="M3 4h2l2.4 12.3a1.5 1.5 0 0 0 1.5 1.2h8.2a1.5 1.5 0 0 0 1.5-1.2L21 8H6" />
    <circle cx="9.5" cy="20.5" r="1.3" fill="currentColor" />
    <circle cx="17.5" cy="20.5" r="1.3" fill="currentColor" />
  </Svg>
);

export const IStar = (p: P) => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...p}>
    <path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.9 6.1 20.5l1.2-6.5L2.5 9.4l6.6-.9z" />
  </svg>
);

export const IApps = (p: P) => (
  <Svg {...p}>
    <rect x="3" y="3" width="7" height="7" rx="1.5" />
    <rect x="14" y="3" width="7" height="7" rx="1.5" />
    <rect x="3" y="14" width="7" height="7" rx="1.5" />
    <rect x="14" y="14" width="7" height="7" rx="1.5" />
  </Svg>
);

export const IFinger = (p: P) => (
  <Svg {...p}>
    <path d="M12 11v3a5 5 0 0 1-1 3" />
    <path d="M8.5 9.5a4 4 0 0 1 7 2.5v1a8 8 0 0 1-1 4" />
    <path d="M5.5 12a6.5 6.5 0 0 1 12-3.4" />
    <path d="M15.5 15.5a10 10 0 0 1-.7 3" />
    <path d="M9 21a12 12 0 0 0 1-5v-4a2 2 0 0 1 4 0" />
  </Svg>
);

export const IInfo = (p: P) => (
  <Svg {...p}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 11v5" />
    <circle cx="12" cy="7.6" r="0.6" fill="currentColor" />
  </Svg>
);

export const IMask = (p: P) => (
  <Svg {...p}>
    <path d="M3 7c3-1 5-1 9-1s6 0 9 1c0 5-2 8-5 8-1.6 0-2.4-1-4-1s-2.4 1-4 1c-3 0-5-3-5-8z" />
    <circle cx="8.5" cy="10.5" r="1.1" fill="currentColor" />
    <circle cx="15.5" cy="10.5" r="1.1" fill="currentColor" />
  </Svg>
);

export const IPin = (p: P) => (
  <Svg {...p}>
    <path d="M9 3h6l-1 6 3 3H7l3-3-1-6zM12 15v6" />
  </Svg>
);

export const ITag = (p: P) => (
  <Svg {...p}>
    <path d="M3 7v5.6a2 2 0 0 0 .6 1.4l7 7a2 2 0 0 0 2.8 0l5.6-5.6a2 2 0 0 0 0-2.8l-7-7A2 2 0 0 0 10.6 5H5a2 2 0 0 0-2 2z" />
    <circle cx="7.5" cy="9.5" r="1.2" fill="currentColor" />
  </Svg>
);

export const IArchive = (p: P) => (
  <Svg {...p}>
    <rect x="3" y="4" width="18" height="4" rx="1" />
    <path d="M5 8v11a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8M9 12h6" />
  </Svg>
);

export const ISoon = (p: P) => (
  <Svg {...p}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 8v4l3 2" />
  </Svg>
);

export const IPinned = (p: P) => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...p}>
    <path d="M9 3h6l-1 6 3 3H7l3-3-1-6z" />
    <rect x="11.2" y="15" width="1.6" height="6" rx="0.8" />
  </svg>
);
