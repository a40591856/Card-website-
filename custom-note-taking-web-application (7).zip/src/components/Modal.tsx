"use client";

import type { ReactNode } from "react";

export function Overlay({
  onClose,
  children,
  bottom = false,
}: {
  onClose: () => void;
  children: ReactNode;
  bottom?: boolean;
}) {
  return (
    <div
      className={`fixed inset-0 z-[70] flex ${
        bottom ? "items-end" : "items-center justify-center p-4"
      }`}
    >
      <div className="anim-fade absolute inset-0 bg-black/45" onClick={onClose} />
      <div
        className={
          bottom
            ? "anim-sheet relative w-full rounded-t-3xl bg-sheet pb-6 pt-2 shadow-2xl"
            : "anim-pop relative w-full max-w-sm rounded-2xl bg-white p-4 shadow-2xl"
        }
      >
        {children}
      </div>
    </div>
  );
}

export function ModalRow({
  icon,
  label,
  danger = false,
  disabled = false,
  onClick,
}: {
  icon?: ReactNode;
  label: string;
  danger?: boolean;
  disabled?: boolean;
  onClick: () => void;
}) {
  return (
    <button
      disabled={disabled}
      onClick={onClick}
      className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-right text-sm font-bold transition disabled:opacity-50 ${
        danger ? "text-red-600 hover:bg-red-50" : "text-ink-900 hover:bg-grass-50"
      }`}
    >
      {icon}
      <span className="min-w-0 flex-1 truncate">{label}</span>
    </button>
  );
}

export function Btn({
  children,
  onClick,
  variant = "primary",
  disabled = false,
  className = "",
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "ghost" | "danger";
  disabled?: boolean;
  className?: string;
}) {
  const styles = {
    primary: "bg-grass-600 text-white hover:bg-grass-700",
    ghost: "border border-line bg-white text-ink-600 hover:bg-grass-50",
    danger: "bg-red-600 text-white hover:bg-red-700",
  }[variant];
  return (
    <button
      disabled={disabled}
      onClick={onClick}
      className={`rounded-xl px-4 py-2.5 text-sm font-bold transition ${styles} ${
        disabled ? "cursor-not-allowed opacity-50" : ""
      } ${className}`}
    >
      {children}
    </button>
  );
}

export function Toast({ msg }: { msg: string | null }) {
  if (!msg) return null;
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-8 z-[90] flex justify-center px-4">
      <div className="anim-pop rounded-full bg-ink-900 px-5 py-2.5 text-sm font-bold text-white shadow-xl">
        {msg}
      </div>
    </div>
  );
}

export function PageShell({
  title,
  onBack,
  children,
}: {
  title: string;
  onBack: () => void;
  children: ReactNode;
}) {
  return (
    <div className="anim-fade fixed inset-0 z-50 overflow-y-auto bg-[#f3f6f3]">
      <header className="sticky top-0 z-10 flex h-14 items-center gap-2 bg-grass-600 px-2 text-white shadow">
        <button onClick={onBack} title="رجوع" className="rounded-full p-2 transition hover:bg-white/15">
          <BackIcon />
        </button>
        <h2 className="text-lg font-extrabold">{title}</h2>
      </header>
      <div className="mx-auto w-full max-w-3xl px-3 py-4 pb-16">{children}</div>
    </div>
  );
}

import { IBack } from "./Icons";
function BackIcon() {
  return <IBack className="h-6 w-6" />;
}
