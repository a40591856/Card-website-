"use client";

import { useRef, useState } from "react";
import type { Prefs } from "@/lib/prefs";
import { biometricVerify } from "@/lib/client";
import { IFinger, ILock, IX } from "./Icons";

/* ------------------------------- Pattern lock ------------------------------ */

function PatternPad({
  onComplete,
  hint,
}: {
  onComplete: (seq: string) => void;
  hint?: string;
}) {
  const [active, setActive] = useState<number[]>([]);
  const drawing = useRef(false);
  const dots = [0, 1, 2, 3, 4, 5, 6, 7, 8];

  const addDot = (i: number) => {
    setActive((prev) => (prev.includes(i) ? prev : [...prev, i]));
  };
  const finish = () => {
    drawing.current = false;
    if (active.length >= 3) onComplete(active.join("-"));
    else if (active.length > 0) {
      setActive([]);
    }
  };

  const pointFromEvent = (clientX: number, clientY: number, el: HTMLElement) => {
    const dotEls = el.querySelectorAll<HTMLElement>("[data-dot]");
    dotEls.forEach((d) => {
      const r = d.getBoundingClientRect();
      const cx = r.left + r.width / 2;
      const cy = r.top + r.height / 2;
      const dist = Math.hypot(clientX - cx, clientY - cy);
      if (dist < r.width * 0.7) addDot(Number(d.dataset.dot));
    });
  };

  return (
    <div className="flex flex-col items-center gap-3">
      <div
        className="grid grid-cols-3 gap-6 rounded-2xl bg-white/10 p-6 touch-none"
        onMouseDown={(e) => {
          drawing.current = true;
          setActive([]);
          pointFromEvent(e.clientX, e.clientY, e.currentTarget);
        }}
        onMouseMove={(e) => {
          if (drawing.current) pointFromEvent(e.clientX, e.clientY, e.currentTarget);
        }}
        onMouseUp={finish}
        onMouseLeave={() => drawing.current && finish()}
        onTouchStart={(e) => {
          drawing.current = true;
          setActive([]);
          const t = e.touches[0];
          pointFromEvent(t.clientX, t.clientY, e.currentTarget);
        }}
        onTouchMove={(e) => {
          const t = e.touches[0];
          pointFromEvent(t.clientX, t.clientY, e.currentTarget);
        }}
        onTouchEnd={finish}
      >
        {dots.map((i) => (
          <div
            key={i}
            data-dot={i}
            className={`flex h-12 w-12 items-center justify-center rounded-full border-2 transition ${
              active.includes(i) ? "border-white bg-white" : "border-white/50"
            }`}
          >
            {active.includes(i) && <span className="h-4 w-4 rounded-full bg-grass-600" />}
          </div>
        ))}
      </div>
      {hint && <p className="text-xs font-bold text-white/70">{hint}</p>}
    </div>
  );
}

/* ------------------------------- Lock screen ------------------------------- */

export default function LockScreen({
  prefs,
  onUnlock,
  onWrong,
}: {
  prefs: Prefs;
  onUnlock: () => void;
  onWrong: (m: string) => void;
}) {
  const [pin, setPin] = useState("");
  const [pwd, setPwd] = useState("");

  const check = (value: string) => {
    if (value === prefs.lockSecret) {
      onUnlock();
    } else {
      onWrong("غير صحيح، حاول مرة أخرى");
      setPin("");
      setPwd("");
    }
  };

  const tryBiometric = async () => {
    const ok = await biometricVerify();
    if (ok) onUnlock();
    else onWrong("لم تكتمل عملية التحقق بالبصمة");
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-5 bg-grass-600 px-6 text-white">
      <div className="flex h-20 w-20 items-center justify-center rounded-full bg-white/15">
        {prefs.biometricLock && prefs.lockKind === "none" ? (
          <IFinger className="h-10 w-10" />
        ) : (
          <ILock className="h-10 w-10" />
        )}
      </div>
      <p className="text-lg font-extrabold">التطبيق مقفل</p>

      {prefs.lockKind === "pin" && (
        <>
          <p className="-mt-3 text-sm font-bold text-white/80">أدخل الرمز الرقمي</p>
          <input
            autoFocus
            type="password"
            inputMode="numeric"
            value={pin}
            onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))}
            onKeyDown={(e) => e.key === "Enter" && check(pin)}
            placeholder="• • • •"
            className="w-48 rounded-2xl bg-white/95 py-3 text-center text-2xl font-extrabold tracking-[0.4em] text-ink-900 outline-none"
          />
          <button
            onClick={() => check(pin)}
            className="rounded-xl bg-white px-8 py-2.5 text-sm font-extrabold text-grass-700 transition hover:bg-white/90"
          >
            فتح
          </button>
        </>
      )}

      {prefs.lockKind === "password" && (
        <>
          <p className="-mt-3 text-sm font-bold text-white/80">أدخل كلمة السر</p>
          <input
            autoFocus
            type="password"
            value={pwd}
            onChange={(e) => setPwd(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && check(pwd)}
            placeholder="كلمة السر"
            className="w-60 rounded-2xl bg-white/95 py-3 text-center text-lg font-extrabold text-ink-900 outline-none"
          />
          <button
            onClick={() => check(pwd)}
            className="rounded-xl bg-white px-8 py-2.5 text-sm font-extrabold text-grass-700 transition hover:bg-white/90"
          >
            فتح
          </button>
        </>
      )}

      {prefs.lockKind === "pattern" && (
        <>
          <p className="-mt-3 text-sm font-bold text-white/80">ارسم نمط الفتح</p>
          <PatternPad onComplete={check} />
        </>
      )}

      {prefs.biometricLock && (
        <button
          onClick={tryBiometric}
          className="flex items-center gap-2 rounded-xl bg-white/15 px-6 py-3 text-sm font-extrabold text-white transition hover:bg-white/25"
        >
          <IFinger className="h-6 w-6" />
          {prefs.lockKind === "none" ? "افتح بالبصمة" : "أو افتح بالبصمة"}
        </button>
      )}
    </div>
  );
}

/* --------------------------- Pattern setup dialog -------------------------- */

export function PatternSetup({
  onDone,
  onCancel,
}: {
  onDone: (seq: string) => void;
  onCancel: () => void;
}) {
  const [first, setFirst] = useState<string | null>(null);

  return (
    <div className="fixed inset-0 z-[80] flex flex-col items-center justify-center gap-5 bg-grass-700 px-6 text-white">
      <button onClick={onCancel} className="absolute top-4 left-4 rounded-full p-2 hover:bg-white/15">
        <IX className="h-6 w-6" />
      </button>
      <p className="text-lg font-extrabold">{first ? "أعد رسم النمط للتأكيد" : "ارسم نمط الفتح"}</p>
      <PatternPad
        key={first ? "confirm" : "first"}
        hint="اربط 3 نقاط على الأقل"
        onComplete={(seq) => {
          if (!first) setFirst(seq);
          else if (seq === first) onDone(seq);
          else {
            setFirst(null);
          }
        }}
      />
      {first && <p className="text-xs font-bold text-white/70">إذا لم يتطابق النمط ستبدأ من جديد</p>}
    </div>
  );
}
