"use client";

import { useState } from "react";
import type { FileRow, NoteRow, SectionRow } from "@/lib/types";
import { api, blocksOf, copyText, downloadJson, fmtDate, Linkify } from "@/lib/client";
import { ICopy, IDownload, IPencil, IPrint, IShare, ITrash, IX, ILink, ICheck } from "./Icons";

function ActBtn({
  icon,
  label,
  danger = false,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  danger?: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-1 rounded-lg px-1 py-2 text-[10.5px] font-bold transition ${
        danger ? "text-red-600 hover:bg-red-50" : "text-ink-600 hover:bg-grass-50"
      }`}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}

function MiniBtn({
  icon,
  label,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-bold text-ink-400 transition hover:bg-grass-50 hover:text-grass-700"
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}

export default function NoteView({
  note,
  file,
  section,
  initialEditing,
  onBack,
  onRefresh,
  onAskDelete,
  onShareMenu,
  toast,
}: {
  note: NoteRow;
  file: FileRow | null;
  section: SectionRow | null;
  initialEditing: boolean;
  onBack: () => void;
  onRefresh: () => Promise<unknown>;
  onAskDelete: () => void;
  onShareMenu: (title: string, text: string) => void;
  toast: (m: string) => void;
}) {
  const [editing, setEditing] = useState(initialEditing);
  const [title, setTitle] = useState(note.title);
  const [content, setContent] = useState(note.content);
  const [busy, setBusy] = useState(false);

  const fullText = (note.title ? note.title + "\n\n" : "") + note.content;
  const blocks = blocksOf(note.content);
  const isChecklist = (note.type ?? "note") === "checklist";

  async function toggleChecklistLine(lineIndex: number) {
    const lines = note.content.split("\n");
    const l = lines[lineIndex] ?? "";
    const m = l.match(/^\s*\[( |x|X)?\]\s?(.*)$/);
    if (m) {
      const checked = (m[1] || "").toLowerCase() === "x";
      lines[lineIndex] = `[${checked ? " " : "x"}] ${m[2]}`;
    }
    const next = lines.join("\n");
    setContent(next);
    try {
      await api(`/api/note/${note.id}`, {
        method: "PATCH",
        body: JSON.stringify({ action: "update", title: note.title, content: next }),
      });
      await onRefresh();
    } catch {
      toast("تعذر الحفظ");
    }
  }

  const directLink =
    typeof window !== "undefined"
      ? `${window.location.origin}${window.location.pathname}?n=${note.id}`
      : "";

  async function doCopyAll() {
    const ok = await copyText(fullText);
    toast(ok ? "تم نسخ الملاحظة كاملة" : "تعذر النسخ");
  }
  function doShareAll() {
    onShareMenu(note.title || "ملاحظة", fullText);
  }
  function doPrint() {
    window.print();
  }
  async function doBackup() {
    const r = await downloadJson(
      {
        app: "mialahadzat",
        version: 1,
        exportedAt: new Date().toISOString(),
        section: section || null,
        file: file || null,
        note,
      },
      `mialahadzat-note-${note.id.slice(0, 8)}.json`,
    );
    if (r === "saved") toast("تم حفظ النسخة في المكان الذي اخترته");
    else if (r === "shared") toast("اختر «حفظ في الملفات» أو أرسلها");
    else if (r === "downloaded") toast("حُفظت في مجلد التنزيلات بهاتفك");
  }
  async function doCopyBlock(b: string) {
    const ok = await copyText(b);
    toast(ok ? "تم نسخ هذا المربع" : "تعذر النسخ");
  }
  function doShareBlock(b: string) {
    onShareMenu("جزء من الملاحظة", b);
  }
  async function doDeleteBlock(blockIndex: number) {
    // blocks are split on blank lines; rebuild content without the chosen block
    const remaining = blocks.filter((_, i) => i !== blockIndex);
    const next = remaining.join("\n\n");
    setContent(next);
    try {
      await api(`/api/note/${note.id}`, {
        method: "PATCH",
        body: JSON.stringify({ action: "update", title: note.title, content: next }),
      });
      await onRefresh();
      toast("تم حذف هذا الجزء");
    } catch {
      toast("تعذر الحذف");
    }
  }
  async function doCopyLink() {
    const ok = await copyText(directLink);
    toast(ok ? "تم نسخ رابط الملاحظة" : "تعذر النسخ");
  }
  async function save() {
    setBusy(true);
    try {
      await api(`/api/note/${note.id}`, {
        method: "PATCH",
        body: JSON.stringify({ action: "update", title, content }),
      });
      await onRefresh();
      setEditing(false);
      toast("تم حفظ الملاحظة");
    } catch (e: any) {
      toast(e?.message || "تعذر الحفظ");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="anim-fade fixed inset-0 z-50 overflow-y-auto bg-[#f3f6f3]">
      {/* Top bar */}
      <header className="sticky top-0 z-10 flex h-14 items-center justify-between bg-grass-600 px-2 text-white shadow">
        <button onClick={onBack} title="إغلاق" className="rounded-full p-2 transition hover:bg-white/15">
          <IX className="h-6 w-6" />
        </button>
        <div className="min-w-0 text-center">
          <p className="text-sm font-extrabold leading-4">ملاحظة</p>
          {file && (
            <p className="mx-auto max-w-[60vw] truncate text-[11px] font-bold text-white/70">
              {section?.name ? section.name + " / " : ""}
              {file.name}
            </p>
          )}
        </div>
        {editing ? (
          <button
            onClick={save}
            disabled={busy}
            title="حفظ"
            className="rounded-full bg-white/15 p-2 transition hover:bg-white/25 disabled:opacity-50"
          >
            <ICheck className="h-6 w-6" />
          </button>
        ) : (
          <div className="w-10" />
        )}
      </header>

      {/* Action bar */}
      {!editing && (
        <div className="sticky top-14 z-10 grid grid-cols-6 border-b border-line bg-white px-1 shadow-sm">
          <ActBtn icon={<ICopy className="h-5 w-5" />} label="نسخ" onClick={doCopyAll} />
          <ActBtn icon={<IShare className="h-5 w-5" />} label="مشاركة" onClick={doShareAll} />
          <ActBtn icon={<IPrint className="h-5 w-5" />} label="PDF" onClick={doPrint} />
          <ActBtn icon={<IDownload className="h-5 w-5" />} label="نسخة" onClick={doBackup} />
          <ActBtn icon={<IPencil className="h-5 w-5" />} label="تعديل" onClick={() => setEditing(true)} />
          <ActBtn icon={<ITrash className="h-5 w-5" />} label="حذف" danger onClick={onAskDelete} />
        </div>
      )}

      <div className="mx-auto w-full max-w-2xl px-4 pb-24 pt-4">
        {editing ? (
          <>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="عنوان الملاحظة"
              className="w-full border-b-2 border-line bg-transparent pb-2 text-xl font-extrabold outline-none focus:border-grass-500"
            />
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="اكتب ملاحظتك هنا... (نص طويل بلا حدود تقريباً)"
              rows={16}
              className="mt-3 w-full resize-y rounded-xl border border-line bg-white p-3 text-[15px] leading-8 outline-none focus:border-grass-500"
            />
            <p className="mt-2 text-xs font-bold leading-6 text-ink-400">
              اضغط سطر فارغ بين الفقرات — كل فقرة ستظهر في مربع مستقل مع زر نسخ خاص بها.
            </p>
            <div className="mt-4 flex gap-2">
              <button
                disabled={busy}
                onClick={save}
                className="flex-1 rounded-xl bg-grass-600 py-3 text-sm font-extrabold text-white transition hover:bg-grass-700 disabled:opacity-50"
              >
                {busy ? "جارٍ الحفظ..." : "حفظ الملاحظة"}
              </button>
              <button
                onClick={() => {
                  setTitle(note.title);
                  setContent(note.content);
                  setEditing(false);
                }}
                className="rounded-xl border border-line bg-white px-5 text-sm font-extrabold text-ink-600 transition hover:bg-grass-50"
              >
                إلغاء
              </button>
            </div>
          </>
        ) : (
          <>
            <h1 className="text-xl font-extrabold leading-8 text-ink-900">
              {note.title || "بدون عنوان"}
            </h1>
            <p className="mt-1 text-xs font-bold text-ink-400">{fmtDate(note.updatedAt)}</p>

            <button
              onClick={doCopyLink}
              title="نسخ الرابط المباشر لهذه الملاحظة"
              className="mt-3 flex w-full items-center gap-2 rounded-xl border border-dashed border-grass-300 bg-grass-50 px-3 py-2 text-right text-[12px] font-bold text-grass-800 transition hover:bg-grass-100"
            >
              <ILink className="h-4 w-4 shrink-0" />
              <span className="min-w-0 flex-1 truncate" dir="ltr">
                {directLink}
              </span>
              <span className="shrink-0 rounded-md bg-white px-2 py-0.5 text-[11px] shadow-sm">نسخ</span>
            </button>

            {isChecklist ? (
              <div className="mt-4 space-y-1.5">
                {note.content.split("\n").map((line, i) => {
                  if (!line.trim())
                    return <div key={i} className="h-2" />;
                  const m = line.match(/^\s*\[( |x|X)?\]\s?(.*)$/);
                  if (!m)
                    return (
                      <p key={i} className="px-1 text-[15px] font-bold text-ink-900">
                        {line}
                      </p>
                    );
                  const checked = (m[1] || "").toLowerCase() === "x";
                  return (
                    <button
                      key={i}
                      onClick={() => toggleChecklistLine(i)}
                      className="flex w-full items-center gap-2.5 rounded-xl border border-line bg-white p-3 text-right transition hover:bg-grass-50"
                    >
                      <span
                        className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md border-2 ${
                          checked ? "border-grass-600 bg-grass-600 text-white" : "border-ink-400/40"
                        }`}
                      >
                        {checked && <ICheck className="h-3.5 w-3.5" />}
                      </span>
                      <span
                        className={`min-w-0 flex-1 text-[15px] ${
                          checked ? "text-ink-400 line-through" : "font-bold text-ink-900"
                        }`}
                      >
                        {m[2] || "—"}
                      </span>
                    </button>
                  );
                })}
                {!note.content.trim() && (
                  <p className="rounded-xl border border-dashed border-line bg-white p-6 text-center text-sm font-bold text-ink-400">
                    لا توجد عناصر — اضغط «تعديل» وأضف أسطراً تبدأ بـ [ ]
                  </p>
                )}
                <p className="pt-1 text-[11px] font-bold leading-6 text-ink-400">
                  ابدأ كل سطر بـ <span dir="ltr">[ ]</span> لعنصر غير منجز و<span dir="ltr">[x]</span> لعنصر منجز — اضغط المربع لتبديل الحالة.
                </p>
              </div>
            ) : (
            <div className="mt-4 space-y-3">
              {blocks.length === 0 && (
                <p className="rounded-xl border border-dashed border-line bg-white p-6 text-center text-sm font-bold text-ink-400">
                  لا يوجد محتوى بعد — اضغط «تعديل» لكتابة الملاحظة
                </p>
              )}
              {blocks.map((b, i) => (
                <div
                  key={i}
                  className="rounded-xl border border-line bg-white p-3 shadow-[0_1px_2px_rgba(20,40,20,0.04)]"
                >
                  <div className="note-body whitespace-pre-wrap leading-8 text-ink-900">
                    <Linkify text={b} />
                  </div>
                  <div className="mt-2 flex items-center gap-1 border-t border-line/70 pt-1.5">
                    <MiniBtn
                      icon={<ICopy className="h-3.5 w-3.5" />}
                      label="نسخ المربع"
                      onClick={() => doCopyBlock(b)}
                    />
                     <MiniBtn
                       icon={<IShare className="h-3.5 w-3.5" />}
                       label="مشاركة المربع"
                       onClick={() => doShareBlock(b)}
                     />
                     <button
                       onClick={() => doDeleteBlock(i)}
                       className="flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-bold text-red-500 transition hover:bg-red-50"
                     >
                       <ITrash className="h-3.5 w-3.5" />
                       <span>حذف المربع</span>
                     </button>
                  </div>
                </div>
              ))}
            </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
